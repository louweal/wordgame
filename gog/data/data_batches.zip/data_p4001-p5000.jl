{"word": ["Rattle"], "author": "trentonlf"}
{"word": ["noise"], "author": "mariabarring"}
{"word": ["Racket"], "author": "Yezemin"}
{"word": [" ", " Ninja'd :( ", " ", " ^Tennis."], "author": "gixgox"}
{"word": ["Elbow"], "author": "Revarye"}
{"word": ["Arm ", " ", " Edit: Ninja'd"], "author": "Habanerose"}
{"word": ["army"], "author": "Accatone"}
{"word": ["Formation"], "author": "trentonlf"}
{"word": ["Dancing."], "author": "Hickory"}
{"word": ["lap"], "author": "Ardal"}
{"word": ["Dog"], "author": "Zoltan999"}
{"word": ["Companion"], "author": "trentonlf"}
{"word": ["Buddy."], "author": "Narcia_"}
{"word": [], "author": "Zordu"}
{"word": ["M\u0336a\u0336t\u0336e\u0336. [Ninja'd] ", " ", " Wrapping."], "author": "Hickory"}
{"word": ["sealed"], "author": "Pickle1477"}
{"word": ["envelope"], "author": "Smogg"}
{"word": ["post"], "author": "XYCat"}
{"word": ["postmodernism"], "author": "Accatone"}
{"word": ["Culture."], "author": "HypersomniacLive"}
{"word": ["Shock"], "author": "trentonlf"}
{"word": [], "author": "gixgox"}
{"word": ["Stone"], "author": "PaterAlf"}
{"word": ["Dead."], "author": "Narcia_"}
{"word": ["deceased"], "author": "Dzsono"}
{"word": ["Afterlife"], "author": "trentonlf"}
{"word": ["heaven"], "author": "camplify"}
{"word": ["Abyss."], "author": "ShadowPatriarch"}
{"word": ["Vast."], "author": "HypersomniacLive"}
{"word": ["Sweeping"], "author": "trentonlf"}
{"word": ["Conspiracy."], "author": "ShadowPatriarch"}
{"word": ["theory"], "author": "le_chevalier"}
{"word": ["mathematical"], "author": "Zordu"}
{"word": ["Scientific ", " ", " Edit: Ninja'd"], "author": "Habanerose"}
{"word": ["Experimental."], "author": "HypersomniacLive"}
{"word": ["Method ", " ", " ninja'd ", " ", " Physics"], "author": "trentonlf"}
{"word": ["Matter."], "author": "Hickory"}
{"word": ["Mass"], "author": "tort1234"}
{"word": ["Consumption."], "author": "ShadowPatriarch"}
{"word": ["Partake"], "author": "trentonlf"}
{"word": ["stuff"], "author": "apehater"}
{"word": ["crust"], "author": "le_chevalier"}
{"word": ["pie"], "author": "Ardal"}
{"word": ["Circle"], "author": "flummoxed"}
{"word": ["Ring."], "author": "ShadowPatriarch"}
{"word": ["SADAKO"], "author": "ashwald"}
{"word": ["hair"], "author": "park_84"}
{"word": ["spray"], "author": "Dzsono"}
{"word": [], "author": "viperfdl"}
{"word": [" Paint."], "author": "Hickory"}
{"word": ["Canvas"], "author": "trentonlf"}
{"word": ["Sailcloth."], "author": "HypersomniacLive"}
{"word": ["sea"], "author": "Ritualisto"}
{"word": ["."], "author": "Hickory"}
{"word": ["Pickles"], "author": "Yezemin"}
{"word": [], "author": "trentonlf"}
{"word": [], "author": "Zoltan999"}
{"word": ["Alkali."], "author": "Hickory"}
{"word": ["Battery"], "author": "Yezemin"}
{"word": ["Zap!"], "author": "TDP"}
{"word": ["Electricity"], "author": "trentonlf"}
{"word": ["Lightning"], "author": "Habanerose"}
{"word": ["Flash."], "author": "ShadowPatriarch"}
{"word": ["Flasher."], "author": "HypersomniacLive"}
{"word": [], "author": "trentonlf"}
{"word": ["Gramps?"], "author": "gixgox"}
{"word": ["Awkward!"], "author": "Hickory"}
{"word": ["Carefree :)"], "author": "trentonlf"}
{"word": ["Careless?"], "author": "HypersomniacLive"}
{"word": ["less"], "author": "Accatone"}
{"word": ["average"], "author": "Smogg"}
{"word": ["Median."], "author": "Hickory"}
{"word": ["greenwich"], "author": "mariabarring"}
{"word": ["Maritime"], "author": "trentonlf"}
{"word": ["ship"], "author": "Ritualisto"}
{"word": ["Navy."], "author": "ShadowPatriarch"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Armada."], "author": "HypersomniacLive"}
{"word": ["[Ninja'd] ", " ", " Fleet."], "author": "Hickory"}
{"word": ["nautical"], "author": "Dzsono"}
{"word": ["Mile."], "author": "ShadowPatriarch"}
{"word": ["Ninja'd ", " ", " Marker"], "author": "trentonlf"}
{"word": ["Pen."], "author": "Hickory"}
{"word": ["Pal."], "author": "ShadowPatriarch"}
{"word": ["SECAM"], "author": "gixgox"}
{"word": ["Broadcast"], "author": "truhlik"}
{"word": ["view"], "author": "kmonster"}
{"word": ["few"], "author": "apehater"}
{"word": ["Pew."], "author": "Hickory"}
{"word": ["Pleasure"], "author": "muter"}
{"word": ["Stew."], "author": "ShadowPatriarch"}
{"word": ["Stewardess."], "author": "LoboBlanco"}
{"word": ["Plane"], "author": "Habanerose"}
{"word": ["Planescape"], "author": "Casval_Deikun"}
{"word": ["Torment"], "author": "trentonlf"}
{"word": ["Torrent."], "author": "ShadowPatriarch"}
{"word": ["Pirate"], "author": "Revarye"}
{"word": ["Bay"], "author": "SeeJayGamer"}
{"word": ["Inlet"], "author": "trentonlf"}
{"word": ["Gauntlet"], "author": "park_84"}
{"word": ["sword"], "author": "mariabarring"}
{"word": ["knight"], "author": "Ritualisto"}
{"word": ["white"], "author": "Ardal"}
{"word": ["horse"], "author": "Smogg"}
{"word": ["mount"], "author": "le_chevalier"}
{"word": [], "author": "Treasure"}
{"word": ["Runner"], "author": "Yezemin"}
{"word": ["Athlete."], "author": "ShadowPatriarch"}
{"word": ["Competitor."], "author": "Hickory"}
{"word": ["Challenger."], "author": "gixgox"}
{"word": ["Rival"], "author": "trentonlf"}
{"word": ["Nemesis"], "author": "Yezemin"}
{"word": ["Foe."], "author": "Narcia_"}
{"word": ["Rival. ", " ", " ", " edit: apologies. For some reason, I didnt see that earlier entry."], "author": "ShadowPatriarch"}
{"word": [" ", " Repetition."], "author": "Hickory"}
{"word": ["Copy-Pasta"], "author": "Habanerose"}
{"word": ["Copycat."], "author": "LoboBlanco"}
{"word": ["Plagiarism."], "author": "gixgox"}
{"word": ["plague"], "author": "apehater"}
{"word": ["Epidemic."], "author": "Hickory"}
{"word": ["Game studio"], "author": "GreenDamsel"}
{"word": ["indie"], "author": "BlackDawn"}
{"word": ["Games"], "author": "Habanerose"}
{"word": ["Strategy."], "author": "LeonKillsAshley"}
{"word": ["Tactics"], "author": "Habanerose"}
{"word": ["Gambit."], "author": "Hickory"}
{"word": ["Cards"], "author": "Yezemin"}
{"word": ["Solitaire"], "author": "BenKii"}
{"word": ["Spider."], "author": "HypersomniacLive"}
{"word": ["Predator."], "author": "ShadowPatriarch"}
{"word": ["alien"], "author": "Dzsono"}
{"word": ["Space"], "author": "PaterAlf"}
{"word": ["Galaxy"], "author": "TDP"}
{"word": ["GOG"], "author": "DrakoPensulo"}
{"word": ["bear"], "author": "le_chevalier"}
{"word": ["Werebear."], "author": "Casval_Deikun"}
{"word": ["Were-Rabbit."], "author": "ShadowPatriarch"}
{"word": ["Curse"], "author": "truhlik"}
{"word": ["Swear"], "author": "le_chevalier"}
{"word": ["Oath"], "author": "Yezemin"}
{"word": ["Breaker."], "author": "ShadowPatriarch"}
{"word": ["C-c-c-c-c-combo"], "author": "GreenDamsel"}
{"word": ["Hadoken"], "author": "park_84"}
{"word": ["Knockout"], "author": "Revarye"}
{"word": ["Champion"], "author": "flubbucket"}
{"word": ["Conqueror."], "author": "Hickory"}
{"word": ["william"], "author": "Ardal"}
{"word": ["Norman."], "author": "ShadowPatriarch"}
{"word": ["Frank."], "author": "Hickory"}
{"word": ["Ricky?"], "author": "gixgox"}
{"word": [" Gael"], "author": "ShadowPatriarch"}
{"word": ["Kal-El"], "author": "mariabarring"}
{"word": ["Boob Window"], "author": "GreenDamsel"}
{"word": ["Cape."], "author": "Narcia_"}
{"word": ["Cowl"], "author": "Zoltan999"}
{"word": ["Hood"], "author": "Pickle1477"}
{"word": ["Scarf."], "author": "Hickory"}
{"word": ["Tuque"], "author": "agentcarr16"}
{"word": ["cap"], "author": "Ritualisto"}
{"word": ["Bottle"], "author": "blakstar"}
{"word": ["of"], "author": "Stryder2931"}
{"word": ["Preposition."], "author": "Hickory"}
{"word": ["Intent."], "author": "HypersomniacLive"}
{"word": ["Plan"], "author": "Hardrada"}
{"word": ["thought"], "author": "camplify"}
{"word": ["think"], "author": "RebelCurse"}
{"word": ["Lemma"], "author": "flummoxed"}
{"word": ["Proof."], "author": "xieliming"}
{"word": ["Pudding"], "author": "TDP"}
{"word": ["Hungry"], "author": "muter"}
{"word": ["Hungary"], "author": "Dzsono"}
{"word": ["Magyar."], "author": "ShadowPatriarch"}
{"word": ["Nation"], "author": "Azrael360"}
{"word": ["state"], "author": "le_chevalier"}
{"word": ["Republic."], "author": "ShadowPatriarch"}
{"word": ["Rebellion"], "author": "xalegra"}
{"word": ["referendum"], "author": "Dzsono"}
{"word": ["Plebiscite."], "author": "Hickory"}
{"word": ["Constitution."], "author": "ShadowPatriarch"}
{"word": ["law"], "author": "Ritualisto"}
{"word": ["Jurisdiction."], "author": "gixgox"}
{"word": ["Judge"], "author": "Yezemin"}
{"word": ["Judy."], "author": "ShadowPatriarch"}
{"word": ["."], "author": "Hickory"}
{"word": ["Sucker"], "author": "Zoltan999"}
{"word": ["Timer."], "author": "gixgox"}
{"word": ["Record."], "author": "HypersomniacLive"}
{"word": ["Microphone"], "author": "mariabarring"}
{"word": ["Speaker."], "author": "Narcia_"}
{"word": ["Listener."], "author": "gixgox"}
{"word": ["Observer."], "author": "Hickory"}
{"word": ["Pattern"], "author": "GreenDamsel"}
{"word": ["Design"], "author": "Habanerose"}
{"word": ["Plan"], "author": "blakstar"}
{"word": ["Goal."], "author": "REDVWIN"}
{"word": ["Penalty."], "author": "Hickory"}
{"word": ["Kick"], "author": "truhlik"}
{"word": ["Punch"], "author": "Revarye"}
{"word": ["Fruit"], "author": "coryrj1995"}
{"word": ["Ninja."], "author": "xieliming"}
{"word": [" Cocktail."], "author": "Hickory"}
{"word": ["Drink ", " ", " Edit: Ninja'd"], "author": "Habanerose"}
{"word": ["Thirsty."], "author": "HypersomniacLive"}
{"word": ["dehydration"], "author": "Dzsono"}
{"word": ["drink"], "author": "kmonster"}
{"word": ["beer"], "author": "DrakoPensulo"}
{"word": ["Keg."], "author": "Hickory"}
{"word": ["Drum."], "author": "Casval_Deikun"}
{"word": ["Steel."], "author": "gixgox"}
{"word": ["stainless"], "author": "le_chevalier"}
{"word": ["immaculate"], "author": "Ardal"}
{"word": ["Spotless."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": [], "author": "blakstar"}
{"word": ["Black"], "author": "Yezemin"}
{"word": ["Widow"], "author": "le_chevalier"}
{"word": ["Venomous"], "author": "agentcarr16"}
{"word": ["Serpent."], "author": "ShadowPatriarch"}
{"word": ["Fang."], "author": "Hickory"}
{"word": ["Sharp."], "author": "Narcia_"}
{"word": ["Television"], "author": "ShadowPatriarch"}
{"word": ["show"], "author": "XYCat"}
{"word": ["Event"], "author": "Azrael360"}
{"word": ["Festival"], "author": "Habanerose"}
{"word": ["Music"], "author": "Yezemin"}
{"word": ["Harmony."], "author": "Hickory"}
{"word": ["Balance"], "author": "Habanerose"}
{"word": ["Zen"], "author": "Yezemin"}
{"word": ["Enlightenment."], "author": "Hickory"}
{"word": ["Kant"], "author": "Ardal"}
{"word": ["Reason"], "author": "flummoxed"}
{"word": ["Purpose."], "author": "Hickory"}
{"word": ["Role."], "author": "REDVWIN"}
{"word": ["Atcting."], "author": "HypersomniacLive"}
{"word": ["Film"], "author": "muter"}
{"word": ["thin"], "author": "Lifthrasil"}
{"word": ["Thick"], "author": "Revarye"}
{"word": ["Voluminous."], "author": "gixgox"}
{"word": ["Voluptuous."], "author": "LoboBlanco"}
{"word": ["Lascivious."], "author": "gixgox"}
{"word": ["salacious"], "author": "Dzsono"}
{"word": ["Hentai"], "author": "Casval_Deikun"}
{"word": ["Pervert."], "author": "xieliming"}
{"word": ["perpetrator"], "author": "le_chevalier"}
{"word": ["Criminal"], "author": "Yezemin"}
{"word": ["Smooth"], "author": "park_84"}
{"word": ["Smoothie."], "author": "ShadowPatriarch"}
{"word": ["Fruit"], "author": "Hardrada"}
{"word": ["BANANAAAAAAAAAAAAA"], "author": "ashwald"}
{"word": ["nuts"], "author": "le_chevalier"}
{"word": ["big"], "author": "Ritualisto"}
{"word": ["."], "author": "gixgox"}
{"word": ["Orafice"], "author": "Zoltan999"}
{"word": ["Orifice."], "author": "Hickory"}
{"word": ["Pipe."], "author": "Narcia_"}
{"word": [], "author": "gixgox"}
{"word": ["Rats."], "author": "ShadowPatriarch"}
{"word": ["underground"], "author": "Accatone"}
{"word": ["dwarf"], "author": "Smogg"}
{"word": ["Red"], "author": "truhlik"}
{"word": ["Hat."], "author": "gixgox"}
{"word": ["Chapeau."], "author": "agentcarr16"}
{"word": ["French."], "author": "REDVWIN"}
{"word": ["Quarter."], "author": "gixgox"}
{"word": ["pounder"], "author": "Ardal"}
{"word": ["Hammer."], "author": "Hickory"}
{"word": ["Nails."], "author": "HypersomniacLive"}
{"word": ["pierce"], "author": "Dzsono"}
{"word": ["Puncture."], "author": "Hickory"}
{"word": ["steel"], "author": "kmonster"}
{"word": ["Superman"], "author": "Revarye"}
{"word": ["Ultraman"], "author": "le_chevalier"}
{"word": ["Batman"], "author": "Wholesalespy52"}
{"word": ["DC"], "author": "Casval_Deikun"}
{"word": ["Electricity"], "author": "Hardrada"}
{"word": ["Bill."], "author": "ShadowPatriarch"}
{"word": ["Murray"], "author": "Yezemin"}
{"word": ["Ghostbuster"], "author": "park_84"}
{"word": ["Beam."], "author": "xieliming"}
{"word": ["Jim."], "author": "ShadowPatriarch"}
{"word": ["earthworm"], "author": "Smogg"}
{"word": ["Fishing."], "author": "Hickory"}
{"word": ["Trout"], "author": "Habanerose"}
{"word": ["fish"], "author": "Ritualisto"}
{"word": ["Lure."], "author": "gixgox"}
{"word": ["bait"], "author": "Ardal"}
{"word": ["Irritate."], "author": "ShadowPatriarch"}
{"word": ["Annoy"], "author": "blakstar"}
{"word": ["Irk"], "author": "Yezemin"}
{"word": ["Bother."], "author": "Hickory"}
{"word": ["bug"], "author": "Zoltan999"}
{"word": ["bugbear"], "author": "le_chevalier"}
{"word": ["Owlbear"], "author": "agentcarr16"}
{"word": [], "author": "gixgox"}
{"word": ["Root."], "author": "Narcia_"}
{"word": ["Android."], "author": "VampiroAlhazred"}
{"word": ["Cyborg."], "author": "Hickory"}
{"word": ["."], "author": "REDVWIN"}
{"word": ["Bot"], "author": "TDP"}
{"word": ["Contraction."], "author": "Hickory"}
{"word": ["Contradiction"], "author": "agentcarr16"}
{"word": ["objection"], "author": "Ritualisto"}
{"word": ["protest"], "author": "RebelCurse"}
{"word": ["Assertion."], "author": "HypersomniacLive"}
{"word": ["rejection"], "author": "samuraigaiden"}
{"word": ["employment"], "author": "Dzsono"}
{"word": ["Sacking :("], "author": "gixgox"}
{"word": ["Webbing."], "author": "Hickory"}
{"word": ["Fabric."], "author": "HypersomniacLive"}
{"word": ["Social"], "author": "Revarye"}
{"word": [], "author": "gixgox"}
{"word": ["Foe."], "author": "LeonKillsAshley"}
{"word": ["foederatus"], "author": "le_chevalier"}
{"word": ["Rome."], "author": "xieliming"}
{"word": ["Carthage."], "author": "ShadowPatriarch"}
{"word": ["Garbage"], "author": "park_84"}
{"word": ["bin"], "author": "Smogg"}
{"word": ["binary"], "author": "Dzsono"}
{"word": ["Vinary."], "author": "gixgox"}
{"word": ["vinegary"], "author": "BlackDawn"}
{"word": ["Sour."], "author": "Hickory"}
{"word": ["Grapes"], "author": "Yezemin"}
{"word": ["Wine."], "author": "ShadowPatriarch"}
{"word": ["vine"], "author": "Ardal"}
{"word": ["hill"], "author": "Ritualisto"}
{"word": ["valley"], "author": "Smogg"}
{"word": ["Dale."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["Micro"], "author": "Habanerose"}
{"word": ["Commodore"], "author": "park_84"}
{"word": ["brigadier"], "author": "le_chevalier"}
{"word": ["."], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["Ship."], "author": "Narcia_"}
{"word": ["."], "author": "REDVWIN"}
{"word": ["entrepreneur"], "author": "Ardal"}
{"word": ["Visionary"], "author": "Zoltan999"}
{"word": ["Prescient."], "author": "Hickory"}
{"word": ["Omniscient"], "author": "agentcarr16"}
{"word": ["nosy"], "author": "Dzsono"}
{"word": ["nose"], "author": "Ritualisto"}
{"word": ["hair"], "author": "Ardal"}
{"word": ["Bald."], "author": "ShadowPatriarch"}
{"word": ["Eagle"], "author": "Revarye"}
{"word": ["Sight."], "author": "LoboBlanco"}
{"word": ["Prey."], "author": "HypersomniacLive"}
{"word": ["food"], "author": "camplify"}
{"word": ["Farm."], "author": "xieliming"}
{"word": ["Agriculture."], "author": "LeonKillsAshley"}
{"word": ["Wheat"], "author": "park_84"}
{"word": ["Bread"], "author": "Habanerose"}
{"word": ["Sliced."], "author": "gixgox"}
{"word": ["Cheese."], "author": "ShadowPatriarch"}
{"word": ["cracker"], "author": "Smogg"}
{"word": ["Fire"], "author": "Yezemin"}
{"word": ["Dragon."], "author": "ShadowPatriarch"}
{"word": ["wyvern"], "author": "Ardal"}
{"word": ["Basilisk."], "author": "Hickory"}
{"word": ["gorgon"], "author": "le_chevalier"}
{"word": [], "author": "Treasure"}
{"word": [], "author": "Zoltan999"}
{"word": ["Beach."], "author": "Narcia_"}
{"word": ["Miami."], "author": "Casval_Deikun"}
{"word": [" Shore."], "author": "Hickory"}
{"word": ["Bank."], "author": "HypersomniacLive"}
{"word": ["robbery"], "author": "Smogg"}
{"word": ["money"], "author": "park_84"}
{"word": ["Bag."], "author": "xieliming"}
{"word": ["tea"], "author": "Dzsono"}
{"word": ["Leaves."], "author": "HypersomniacLive"}
{"word": ["green"], "author": "Ritualisto"}
{"word": ["Party."], "author": "ShadowPatriarch"}
{"word": ["Celebration"], "author": "blakstar"}
{"word": ["Anniversary"], "author": "DrakoPensulo"}
{"word": ["golden"], "author": "Zordu"}
{"word": ["thing"], "author": "kmonster"}
{"word": ["Item"], "author": "coryrj1995"}
{"word": ["inventory"], "author": "le_chevalier"}
{"word": ["Count"], "author": "Yezemin"}
{"word": ["Alucard"], "author": "flummoxed"}
{"word": ["Dracula"], "author": "Hardrada"}
{"word": ["Blood"], "author": "park_84"}
{"word": ["Shed."], "author": "ShadowPatriarch"}
{"word": ["Garden"], "author": "Revarye"}
{"word": ["Fence."], "author": "Hickory"}
{"word": ["Wall"], "author": "Habanerose"}
{"word": ["Brick"], "author": "blakstar"}
{"word": ["Pig."], "author": "omega64"}
{"word": ["Flies"], "author": "koima57"}
{"word": ["dirty"], "author": "Ritualisto"}
{"word": ["Naughty"], "author": "Yezemin"}
{"word": ["Spanking."], "author": "gixgox"}
{"word": ["Punishment"], "author": "Zoltan999"}
{"word": ["Suffering ", " ", " Edit: Ninja'd"], "author": "Habanerose"}
{"word": ["hate"], "author": "Pickle1477"}
{"word": ["Spite"], "author": "TDP"}
{"word": ["Petty."], "author": "Narcia_"}
{"word": ["Piddling."], "author": "Hickory"}
{"word": ["Inconsequential."], "author": "LeonKillsAshley"}
{"word": ["Trivial"], "author": "agentcarr16"}
{"word": ["Pursuit"], "author": "Decatonkeil"}
{"word": ["Stalk."], "author": "HypersomniacLive"}
{"word": ["prey"], "author": "Ardal"}
{"word": ["pounce"], "author": "Dzsono"}
{"word": ["Ambush."], "author": "Hickory"}
{"word": ["Predator"], "author": "Revarye"}
{"word": ["Alien"], "author": "blakstar"}
{"word": ["Foreign."], "author": "HypersomniacLive"}
{"word": ["Legion."], "author": "ShadowPatriarch"}
{"word": ["demon"], "author": "le_chevalier"}
{"word": ["Doom"], "author": "flummoxed"}
{"word": ["mood"], "author": "truhlik"}
{"word": ["dark"], "author": "Ritualisto"}
{"word": ["Obscured"], "author": "Yezemin"}
{"word": ["files"], "author": "motorkar"}
{"word": ["Classified"], "author": "park_84"}
{"word": ["secrecy"], "author": "Smogg"}
{"word": ["Confidential."], "author": "ShadowPatriarch"}
{"word": ["Secretive."], "author": "gixgox"}
{"word": ["password"], "author": "camplify"}
{"word": ["Crack."], "author": "xieliming"}
{"word": ["Coke"], "author": "Habanerose"}
{"word": ["Lemonade."], "author": "gixgox"}
{"word": ["Fuzzy"], "author": "mariabarring"}
{"word": ["Logic."], "author": "ShadowPatriarch"}
{"word": [], "author": "Zoltan999"}
{"word": ["musician"], "author": "Ardal"}
{"word": ["Bard."], "author": "Narcia_"}
{"word": [], "author": "gixgox"}
{"word": ["Minstrel."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["Meisters\u00e4nger."], "author": "Hickory"}
{"word": ["Lager"], "author": "agentcarr16"}
{"word": ["german"], "author": "Ritualisto"}
{"word": ["Shepard"], "author": "Hardrada"}
{"word": ["woof!"], "author": "Dzsono"}
{"word": [" "], "author": "gixgox"}
{"word": ["Wool"], "author": "Revarye"}
{"word": ["Fleece."], "author": "HypersomniacLive"}
{"word": ["swindle"], "author": "Zordu"}
{"word": ["Con"], "author": "agentcarr16"}
{"word": ["Pro"], "author": "Pickle1477"}
{"word": ["Elite."], "author": "xieliming"}
{"word": ["Dangerous."], "author": "VampiroAlhazred"}
{"word": ["Unhinged"], "author": "Yezemin"}
{"word": ["Enlightened."], "author": "ShadowPatriarch"}
{"word": [" Deranged."], "author": "Hickory"}
{"word": ["unbalanced"], "author": "le_chevalier"}
{"word": ["Unfair"], "author": "park_84"}
{"word": ["uneven"], "author": "le_chevalier"}
{"word": ["bumpy"], "author": "ashwald"}
{"word": [], "author": "gixgox"}
{"word": ["Rage."], "author": "Hickory"}
{"word": ["Fury"], "author": "Yezemin"}
{"word": ["Unleashed"], "author": "Zoltan999"}
{"word": ["Extricated."], "author": "Hickory"}
{"word": ["liberty"], "author": "Ardal"}
{"word": ["Choice."], "author": "Narcia_"}
{"word": ["Unique"], "author": "TDP"}
{"word": ["rare"], "author": "Ritualisto"}
{"word": ["Scarce."], "author": "REDVWIN"}
{"word": ["Scanty."], "author": "Hickory"}
{"word": ["Clad."], "author": "xieliming"}
{"word": ["iron"], "author": "Dzsono"}
{"word": ["Will."], "author": "Hickory"}
{"word": ["Power."], "author": "ShadowPatriarch"}
{"word": ["plant"], "author": "le_chevalier"}
{"word": ["Zombie"], "author": "Revarye"}
{"word": ["Undead"], "author": "Pickle1477"}
{"word": ["Revenant."], "author": "gixgox"}
{"word": ["Oscar"], "author": "park_84"}
{"word": ["Leo"], "author": "flummoxed"}
{"word": ["Pope."], "author": "ShadowPatriarch"}
{"word": ["Rome"], "author": "Yezemin"}
{"word": ["empire"], "author": "Smogg"}
{"word": ["Chinese"], "author": "Habanerose"}
{"word": ["Japanese"], "author": "agentcarr16"}
{"word": ["Korean."], "author": "ShadowPatriarch"}
{"word": ["Asia. ", " <home of the ninjas>"], "author": "gixgox"}
{"word": ["Continent"], "author": "blakstar"}
{"word": ["Landmass."], "author": "Hickory"}
{"word": ["green"], "author": "Ritualisto"}
{"word": ["Light"], "author": "Yezemin"}
{"word": ["."], "author": "gixgox"}
{"word": ["Stardom."], "author": "Hickory"}
{"word": ["Astro."], "author": "Narcia_"}
{"word": ["Boy"], "author": "Yezemin"}
{"word": ["girl"], "author": "Ardal"}
{"word": ["Vagina"], "author": "Habanerose"}
{"word": ["Erogenous."], "author": "Hickory"}
{"word": ["Zone"], "author": "TDP"}
{"word": ["Twilight"], "author": "agentcarr16"}
{"word": ["Dusk."], "author": "Hickory"}
{"word": ["Dawn"], "author": "Revarye"}
{"word": ["morning"], "author": "le_chevalier"}
{"word": ["Tired."], "author": "coryrj1995"}
{"word": ["awake"], "author": "camplify"}
{"word": ["Consciousness."], "author": "LeonKillsAshley"}
{"word": ["Subconscious."], "author": "LoboBlanco"}
{"word": ["instinct"], "author": "Hardrada"}
{"word": ["basic"], "author": "Ardal"}
{"word": ["acid"], "author": "Dzsono"}
{"word": ["Visual. ", " ", " Edit: ninja'd ", " ", " Alkaline."], "author": "ShadowPatriarch"}
{"word": ["Battery"], "author": "park_84"}
{"word": ["charge"], "author": "le_chevalier"}
{"word": ["Attack"], "author": "Yezemin"}
{"word": ["Failed"], "author": "Gnostic"}
{"word": ["State."], "author": "toxicTom"}
{"word": ["Police"], "author": "Cavenagh"}
{"word": ["Guard."], "author": "Casval_Deikun"}
{"word": ["Dog"], "author": "blakstar"}
{"word": ["Wild."], "author": "ShadowPatriarch"}
{"word": ["Hunt ", " ", " :P"], "author": "Cavenagh"}
{"word": ["Search"], "author": "Zoltan999"}
{"word": [], "author": "gixgox"}
{"word": ["Kill"], "author": "Habanerose"}
{"word": ["Time."], "author": "Narcia_"}
{"word": [], "author": "gixgox"}
{"word": ["Permit."], "author": "Hickory"}
{"word": ["Hermit."], "author": "Casval_Deikun"}
{"word": [], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["Alpha"], "author": "Yezemin"}
{"word": ["beta"], "author": "Accatone"}
{"word": ["Testing."], "author": "Hickory"}
{"word": ["standardised"], "author": "Dzsono"}
{"word": ["Normalized."], "author": "xieliming"}
{"word": ["ordinary"], "author": "camplify"}
{"word": ["Common."], "author": "LoboBlanco"}
{"word": ["Denominator"], "author": "DrakoPensulo"}
{"word": ["Divisor."], "author": "Hickory"}
{"word": ["dividend"], "author": "Ardal"}
{"word": ["Quotient."], "author": "gixgox"}
{"word": ["Fraction"], "author": "park_84"}
{"word": ["Friction."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["fan"], "author": "le_chevalier"}
{"word": [], "author": "gixgox"}
{"word": ["(my) reality"], "author": "le_chevalier"}
{"word": ["Verity."], "author": "Hickory"}
{"word": ["Truth."], "author": "ShadowPatriarch"}
{"word": ["Honesty"], "author": "Yezemin"}
{"word": ["Policy"], "author": "Revarye"}
{"word": ["guideline"], "author": "Dzsono"}
{"word": ["employee"], "author": "XYCat"}
{"word": [" ", " <ninja'd again> ", " Boss."], "author": "gixgox"}
{"word": [], "author": "Zoltan999"}
{"word": ["racing"], "author": "Smogg"}
{"word": ["Stripes."], "author": "Narcia_"}
{"word": [], "author": "gixgox"}
{"word": ["Snow"], "author": "Yezemin"}
{"word": ["Bunny."], "author": "HypersomniacLive"}
{"word": ["Bugs"], "author": "truhlik"}
{"word": ["Creepy-crawlies."], "author": "Hickory"}
{"word": ["Cetipedes?"], "author": "gixgox"}
{"word": ["Legs"], "author": "koima57"}
{"word": ["Walker."], "author": "xieliming"}
{"word": [], "author": "blakstar"}
{"word": ["van"], "author": "kmonster"}
{"word": ["Black"], "author": "Hardrada"}
{"word": ["Humour."], "author": "ShadowPatriarch"}
{"word": ["Laughter."], "author": "Hickory"}
{"word": ["Medicine"], "author": "Revarye"}
{"word": ["Quackery."], "author": "gixgox"}
{"word": ["money"], "author": "Ritualisto"}
{"word": ["stash"], "author": "Moonbeam"}
{"word": ["Loot"], "author": "Habanerose"}
{"word": ["pirate"], "author": "Ardal"}
{"word": ["captain"], "author": "Smogg"}
{"word": ["Ship"], "author": "toxicTom"}
{"word": [], "author": "gixgox"}
{"word": ["Port."], "author": "ShadowPatriarch"}
{"word": ["Royale."], "author": "HypersomniacLive"}
{"word": ["regal"], "author": "Ardal"}
{"word": [], "author": "Vokter"}
{"word": ["Sphere"], "author": "toxicTom"}
{"word": [], "author": "Zoltan999"}
{"word": ["Vacuum."], "author": "Hickory"}
{"word": ["Space."], "author": "Narcia_"}
{"word": ["Open."], "author": "coryrj1995"}
{"word": ["free"], "author": "park_84"}
{"word": ["bluebird"], "author": "XYCat"}
{"word": [" Wild."], "author": "Hickory"}
{"word": ["Domesticated."], "author": "HypersomniacLive"}
{"word": ["cultivation"], "author": "le_chevalier"}
{"word": ["Manipulation."], "author": "Hickory"}
{"word": ["Genetics."], "author": "REDVWIN"}
{"word": ["DNA."], "author": "LoboBlanco"}
{"word": ["RNA"], "author": "Accatone"}
{"word": ["RNG"], "author": "Habanerose"}
{"word": [" Lineage."], "author": "Hickory"}
{"word": ["Heritage"], "author": "agentcarr16"}
{"word": ["Legacy."], "author": "HypersomniacLive"}
{"word": ["Estate."], "author": "REDVWIN"}
{"word": ["Demesne."], "author": "ShadowPatriarch"}
{"word": ["Demise"], "author": "kmonster"}
{"word": ["wane"], "author": "Dzsono"}
{"word": ["Wax."], "author": "Hickory"}
{"word": ["figure"], "author": "Vehdra"}
{"word": ["public"], "author": "le_chevalier"}
{"word": ["enemy"], "author": "truhlik"}
{"word": ["adversaries"], "author": "Ardal"}
{"word": ["Rivals"], "author": "Yezemin"}
{"word": ["Foes"], "author": "park_84"}
{"word": ["Friends"], "author": "Habanerose"}
{"word": ["Buds."], "author": "xieliming"}
{"word": [], "author": "Zoltan999"}
{"word": ["Joint"], "author": "Lifthrasil"}
{"word": ["Hinge."], "author": "gixgox"}
{"word": ["Rust"], "author": "Pickle1477"}
{"word": ["game"], "author": "Ritualisto"}
{"word": ["Play."], "author": "Narcia_"}
{"word": ["."], "author": "gixgox"}
{"word": ["Easy"], "author": "Habanerose"}
{"word": ["Simple."], "author": "Hickory"}
{"word": ["mind"], "author": "Smogg"}
{"word": ["games"], "author": "Ardal"}
{"word": ["Hunger"], "author": "Revarye"}
{"word": ["Mockingjay."], "author": "gixgox"}
{"word": ["Mockingbird."], "author": "Ikarugamesh"}
{"word": ["Mimicry."], "author": "Hickory"}
{"word": ["insect"], "author": "BlackDawn"}
{"word": ["Arthropods."], "author": "HypersomniacLive"}
{"word": ["Butterfly"], "author": "flummoxed"}
{"word": ["Metamorphosis."], "author": "xieliming"}
{"word": ["^ ", "."], "author": "HypersomniacLive"}
{"word": ["Umbrella."], "author": "Hickory"}
{"word": ["Flagella."], "author": "gixgox"}
{"word": ["Flagpole"], "author": "agentcarr16"}
{"word": ["flag-bearer"], "author": "le_chevalier"}
{"word": ["march"], "author": "Dzsono"}
{"word": ["."], "author": "Hickory"}
{"word": ["heart"], "author": "Ardal"}
{"word": ["Core."], "author": "REDVWIN"}
{"word": ["Earth"], "author": "Yezemin"}
{"word": ["Planet"], "author": "Azrael360"}
{"word": ["Universe."], "author": "ShadowPatriarch"}
{"word": ["Galaxy"], "author": "Habanerose"}
{"word": [], "author": "blakstar"}
{"word": ["Bar"], "author": "Yezemin"}
{"word": [], "author": "Revarye"}
{"word": ["Country"], "author": "JDelekto"}
{"word": [], "author": "Casval_Deikun"}
{"word": ["Animal"], "author": "truhlik"}
{"word": ["pet"], "author": "Ritualisto"}
{"word": ["Peeve"], "author": "Zoltan999"}
{"word": ["annoy"], "author": "Pickle1477"}
{"word": ["Buzzing."], "author": "Narcia_"}
{"word": ["Tinnitus."], "author": "Hickory"}
{"word": ["Thanatos"], "author": "park_84"}
{"word": ["death"], "author": "Ardal"}
{"word": ["Star."], "author": "gixgox"}
{"word": ["dwarf"], "author": "Dzsono"}
{"word": ["Overshadow."], "author": "Hickory"}
{"word": ["Undertale."], "author": "gixgox"}
{"word": ["Pacifist."], "author": "xieliming"}
{"word": ["Hippie"], "author": "park_84"}
{"word": ["Flower"], "author": "Vokter"}
{"word": ["bee"], "author": "camplify"}
{"word": ["bumble"], "author": "Ardal"}
{"word": ["hum"], "author": "le_chevalier"}
{"word": ["sing"], "author": "Ritualisto"}
{"word": ["Lyrics"], "author": "Habanerose"}
{"word": ["Score."], "author": "gixgox"}
{"word": ["notation"], "author": "Dzsono"}
{"word": ["Syllabary."], "author": "Hickory"}
{"word": ["Sylvan."], "author": "Casval_Deikun"}
{"word": ["sly"], "author": "Accatone"}
{"word": ["fly"], "author": "truhlik"}
{"word": ["Soar"], "author": "Dzsono"}
{"word": ["Roar"], "author": "Dino4914"}
{"word": ["Raw."], "author": "Hickory"}
{"word": ["Cooked."], "author": "coryrj1995"}
{"word": [], "author": "gixgox"}
{"word": ["Gassed."], "author": "xieliming"}
{"word": ["Eliminated."], "author": "ShadowPatriarch"}
{"word": ["vanished"], "author": "Dzsono"}
{"word": ["persecuted"], "author": "Ardal"}
{"word": ["Evasive"], "author": "park_84"}
{"word": ["Elusive"], "author": "TDP"}
{"word": ["slippery"], "author": "le_chevalier"}
{"word": ["Slope"], "author": "Yezemin"}
{"word": ["Incline."], "author": "Hickory"}
{"word": ["Decline"], "author": "Habanerose"}
{"word": ["Recline."], "author": "gixgox"}
{"word": ["Supine."], "author": "Hickory"}
{"word": ["Sleepy."], "author": "Narcia_"}
{"word": ["Exhausted"], "author": "Zoltan999"}
{"word": ["Weary"], "author": "Revarye"}
{"word": ["spent"], "author": "litildivil"}
{"word": ["Paid"], "author": "agentcarr16"}
{"word": ["advertisement"], "author": "Ardal"}
{"word": ["Revenue."], "author": "REDVWIN"}
{"word": ["e"], "author": "gixgox"}
{"word": ["Expenditure."], "author": "Hickory"}
{"word": ["Overhead."], "author": "HypersomniacLive"}
{"word": ["Engineering."], "author": "ShadowPatriarch"}
{"word": ["Software."], "author": "xieliming"}
{"word": ["browser"], "author": "Ritualisto"}
{"word": ["Grazer."], "author": "Hickory"}
{"word": ["bovine"], "author": "Dzsono"}
{"word": ["Sluggish."], "author": "HypersomniacLive"}
{"word": ["Slow"], "author": "Dino4914"}
{"word": ["Motion."], "author": "LoboBlanco"}
{"word": ["Picture"], "author": "Revarye"}
{"word": ["Dictionary."], "author": "ShadowPatriarch"}
{"word": [], "author": "le_chevalier"}
{"word": ["Narcolepsy."], "author": "LeonKillsAshley"}
{"word": ["Narcotic"], "author": "park_84"}
{"word": ["Drug"], "author": "Yezemin"}
{"word": ["dealer"], "author": "Smogg"}
{"word": ["weapons"], "author": "Ardal"}
{"word": ["arms"], "author": "ashwald"}
{"word": ["Legs."], "author": "gixgox"}
{"word": ["Feet"], "author": "Yezemin"}
{"word": ["Hands"], "author": "Habanerose"}
{"word": ["Palm."], "author": "ShadowPatriarch"}
{"word": ["Tree."], "author": "Hickory"}
{"word": ["Beard ", " ", " ;-)"], "author": "Zoltan999"}
{"word": ["Whiskers."], "author": "Narcia_"}
{"word": ["Kitty"], "author": "TDP"}
{"word": ["dog"], "author": "JinKazaragi"}
{"word": ["wolf"], "author": "camplify"}
{"word": ["Cry"], "author": "Yezemin"}
{"word": ["Baby"], "author": "Revarye"}
{"word": ["doll"], "author": "gixgox"}
{"word": ["Strings."], "author": "REDVWIN"}
{"word": ["Chords."], "author": "coryrj1995"}
{"word": ["lord"], "author": "Accatone"}
{"word": ["Lady"], "author": "Habanerose"}
{"word": ["Aristocracy."], "author": "Casval_Deikun"}
{"word": ["Nobility."], "author": "xieliming"}
{"word": ["Bloodsuckers."], "author": "gixgox"}
{"word": ["vampire"], "author": "BlackDawn"}
{"word": ["hunter"], "author": "Smogg"}
{"word": ["trail"], "author": "Ardal"}
{"word": ["odyssey"], "author": "Dzsono"}
{"word": ["Space"], "author": "Revarye"}
{"word": ["time"], "author": "Ritualisto"}
{"word": [], "author": "gixgox"}
{"word": [], "author": "le_chevalier"}
{"word": ["Godfather."], "author": "ShadowPatriarch"}
{"word": ["."], "author": "Hickory"}
{"word": ["scary"], "author": "Ardal"}
{"word": ["Gloomy"], "author": "park_84"}
{"word": ["winter"], "author": "Dzsono"}
{"word": ["frost"], "author": "Smogg"}
{"word": ["Slush."], "author": "gixgox"}
{"word": ["Sleet"], "author": "agentcarr16"}
{"word": ["P\u0336u\u0336p\u0336p\u0336i\u0336e\u0336. [Ninja'd] ", " ", " Hail."], "author": "Hickory"}
{"word": ["Mary."], "author": "Nel-A"}
{"word": ["Bloody"], "author": "Zoltan999"}
{"word": ["Rare."], "author": "Nel-A"}
{"word": ["Beauty."], "author": "Narcia_"}
{"word": ["Beast"], "author": "Yezemin"}
{"word": ["Monster"], "author": "Azrael360"}
{"word": ["Card"], "author": "flummoxed"}
{"word": ["Deck."], "author": "REDVWIN"}
{"word": ["."], "author": "Hickory"}
{"word": ["Bridge"], "author": "Nel-A"}
{"word": ["jump"], "author": "camplify"}
{"word": ["run"], "author": "Smogg"}
{"word": ["Shadow."], "author": "HypersomniacLive"}
{"word": ["spectre"], "author": "Dzsono"}
{"word": ["Espionage"], "author": "Nel-A"}
{"word": ["spy"], "author": "RebelCurse"}
{"word": ["Windows"], "author": "VampiroAlhazred"}
{"word": ["Solaris."], "author": "REDVWIN"}
{"word": ["Oracle"], "author": "Revarye"}
{"word": ["Delphi."], "author": "xieliming"}
{"word": ["Agent."], "author": "LoboBlanco"}
{"word": ["."], "author": "Hickory"}
{"word": ["Citrus"], "author": "le_chevalier"}
{"word": ["lemonade"], "author": "SalarShushan"}
{"word": ["summer"], "author": "truhlik"}
{"word": ["Time"], "author": "park_84"}
{"word": ["Sand"], "author": "flummoxed"}
{"word": ["Desert."], "author": "ShadowPatriarch"}
{"word": ["hot"], "author": "Ritualisto"}
{"word": ["cold"], "author": "Treasure"}
{"word": ["siberia"], "author": "Smogg"}
{"word": ["Russia"], "author": "Yezemin"}
{"word": ["."], "author": "gixgox"}
{"word": ["craft"], "author": "LemonKoopa"}
{"word": ["arts"], "author": "Ardal"}
{"word": ["brushes"], "author": "ashwald"}
{"word": ["pencils"], "author": "Habanerose"}
{"word": ["Canvas."], "author": "gixgox"}
{"word": ["Blank"], "author": "Yezemin"}
{"word": ["mind"], "author": "Dzsono"}
{"word": ["Mined"], "author": "Nel-A"}
{"word": ["Coal"], "author": "Zoltan999"}
{"word": ["Coalition."], "author": "gixgox"}
{"word": ["willing"], "author": "Ardal"}
{"word": ["Amenable"], "author": "agentcarr16"}
{"word": ["Affable."], "author": "Hickory"}
{"word": ["Gentle."], "author": "REDVWIN"}
{"word": ["."], "author": "gixgox"}
{"word": ["Games."], "author": "Hickory"}
{"word": ["relaxation"], "author": "Dzsono"}
{"word": ["Massage."], "author": "LoboBlanco"}
{"word": ["body"], "author": "Ritualisto"}
{"word": ["Celestial."], "author": "LoboBlanco"}
{"word": ["Fury."], "author": "xieliming"}
{"word": ["Rage."], "author": "Hickory"}
{"word": ["road"], "author": "Zordu"}
{"word": ["block"], "author": "NuffCatnip"}
{"word": ["detour"], "author": "muter"}
{"word": ["."], "author": "gixgox"}
{"word": ["Checkmate."], "author": "LeonKillsAshley"}
{"word": ["King"], "author": "blakstar"}
{"word": ["Kong."], "author": "gixgox"}
{"word": ["Gong."], "author": "HypersomniacLive"}
{"word": [], "author": "le_chevalier"}
{"word": ["Manure."], "author": "Hickory"}
{"word": ["Fertilizer."], "author": "ShadowPatriarch"}
{"word": ["Soil."], "author": "coryrj1995"}
{"word": ["Dirt"], "author": "park_84"}
{"word": ["Mud"], "author": "Yezemin"}
{"word": ["sludge"], "author": "Dzsono"}
{"word": ["Puppy."], "author": "gixgox"}
{"word": ["Cute"], "author": "Yezemin"}
{"word": ["Witty"], "author": "Nel-A"}
{"word": ["Clever"], "author": "blakstar"}
{"word": ["Foxy"], "author": "ScotchMonkey"}
{"word": ["Sly."], "author": "Hickory"}
{"word": ["Covert."], "author": "ShadowPatriarch"}
{"word": ["Agent"], "author": "Revarye"}
{"word": ["Secret"], "author": "Nel-A"}
{"word": ["Identity"], "author": "Zoltan999"}
{"word": ["Face"], "author": "Pickle1477"}
{"word": ["Body"], "author": "coryrj1995"}
{"word": ["mind"], "author": "Ardal"}
{"word": ["Open"], "author": "Yezemin"}
{"word": ["source"], "author": "VampiroAlhazred"}
{"word": ["Beginning"], "author": "Nel-A"}
{"word": ["End"], "author": "TDP"}
{"word": ["The"], "author": "Cavenagh"}
{"word": ["Only"], "author": "Nel-A"}
{"word": ["Time."], "author": "Narcia_"}
{"word": ["Space"], "author": "Yezemin"}
{"word": ["station"], "author": "Smogg"}
{"word": ["House "], "author": "gixgox"}
{"word": ["Bungalo"], "author": "Nel-A"}
{"word": ["electric"], "author": "camplify"}
{"word": ["spot"], "author": "apehater"}
{"word": ["remover"], "author": "Dzsono"}
{"word": ["Convey"], "author": "Nel-A"}
{"word": ["Thoughts."], "author": "Ikarugamesh"}
{"word": ["Ideas."], "author": "REDVWIN"}
{"word": ["Concept"], "author": "Hardrada"}
{"word": ["Art."], "author": "ShadowPatriarch"}
{"word": ["Figurative"], "author": "park_84"}
{"word": ["symbolic"], "author": "le_chevalier"}
{"word": ["Iconic."], "author": "gixgox"}
{"word": ["Homogenous"], "author": "Nel-A"}
{"word": ["Uniform."], "author": "xieliming"}
{"word": ["Military"], "author": "QuickyBard"}
{"word": ["Salute"], "author": "Revarye"}
{"word": ["Acknowledge"], "author": "Zoltan999"}
{"word": ["Affirm."], "author": "Narcia_"}
{"word": ["validate"], "author": "Pickle1477"}
{"word": ["confirm"], "author": "Habanerose"}
{"word": ["Accept"], "author": "Azrael360"}
{"word": ["decline"], "author": "camplify"}
{"word": ["line"], "author": "Accatone"}
{"word": ["Toe"], "author": "Yezemin"}
{"word": ["Heel."], "author": "Hickory"}
{"word": ["High."], "author": "gixgox"}
{"word": ["Higher."], "author": "BenKii"}
{"word": ["Celestial."], "author": "gixgox"}
{"word": ["heaven"], "author": "Ritualisto"}
{"word": ["Grace"], "author": "Nel-A"}
{"word": ["fall"], "author": "BlackDawn"}
{"word": ["Spring."], "author": "gixgox"}
{"word": ["bounce"], "author": "Dzsono"}
{"word": ["disco"], "author": "apehater"}
{"word": ["balls"], "author": "muter"}
{"word": ["Gonad."], "author": "xieliming"}
{"word": ["Nutsack"], "author": "Habanerose"}
{"word": ["Scrotum."], "author": "Hickory"}
{"word": ["crinkle"], "author": "Dzsono"}
{"word": ["Wrinkle"], "author": "park_84"}
{"word": ["Old"], "author": "Hardrada"}
{"word": ["Ancient"], "author": "Yezemin"}
{"word": ["prehistorical"], "author": "le_chevalier"}
{"word": ["Dinosaur."], "author": "ShadowPatriarch"}
{"word": ["Triceratops"], "author": "QuickyBard"}
{"word": ["Horns"], "author": "Zoltan999"}
{"word": [], "author": "gixgox"}
{"word": [], "author": "blakstar"}
{"word": ["Strand."], "author": "Hickory"}
{"word": ["Stranded"], "author": "skimmie"}
{"word": ["Surf."], "author": "gixgox"}
{"word": ["Waves"], "author": "Mr.Caine"}
{"word": ["sea"], "author": "Accatone"}
{"word": ["ocean"], "author": "Pickle1477"}
{"word": ["water"], "author": "camplify"}
{"word": ["Life"], "author": "Nel-A"}
{"word": [], "author": "XYCat"}
{"word": ["Vitality"], "author": "Revarye"}
{"word": ["Endurance."], "author": "REDVWIN"}
{"word": ["Strenght"], "author": "Habanerose"}
{"word": ["Power"], "author": "Nel-A"}
{"word": ["Struggle"], "author": "Yezemin"}
{"word": ["strain"], "author": "Dzsono"}
{"word": [], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["Moil."], "author": "agentcarr16"}
{"word": ["synonym"], "author": "Dzsono"}
{"word": ["Similarity."], "author": "Hickory"}
{"word": ["Resemblance."], "author": "VampiroAlhazred"}
{"word": ["Conformance."], "author": "ShadowPatriarch"}
{"word": ["conformity"], "author": "le_chevalier"}
{"word": ["Compliance."], "author": "xieliming"}
{"word": ["Navigator"], "author": "Nel-A"}
{"word": ["Explorer"], "author": "Habanerose"}
{"word": ["Browser."], "author": "Narcia_"}
{"word": ["essential"], "author": "Ardal"}
{"word": ["sure"], "author": "ashwald"}
{"word": [" Obedience."], "author": "Hickory"}
{"word": [" *pets*"], "author": "ashwald"}
{"word": ["Feral."], "author": "ShadowPatriarch"}
{"word": ["Chav"], "author": "Cavenagh"}
{"word": ["youth"], "author": "Dzsono"}
{"word": ["Exuberance."], "author": "gixgox"}
{"word": ["Hyperactivity."], "author": "Hickory"}
{"word": ["Sugar"], "author": "Nel-A"}
{"word": ["Honey"], "author": "agentcarr16"}
{"word": ["Diabetes."], "author": "xieliming"}
{"word": ["Sickness."], "author": "RebelCurse"}
{"word": ["cold"], "author": "JinKazaragi"}
{"word": ["Chill."], "author": "Hickory"}
{"word": ["Netflix"], "author": "Nel-A"}
{"word": ["Youtube"], "author": "Habanerose"}
{"word": ["behemoth"], "author": "Dzsono"}
{"word": ["Monstrous"], "author": "Revarye"}
{"word": ["Abomination."], "author": "LoboBlanco"}
{"word": ["Unloved!"], "author": "REDVWIN"}
{"word": ["Frankenstein"], "author": "park_84"}
{"word": ["Doctor"], "author": "Yezemin"}
{"word": ["Who."], "author": "ShadowPatriarch"}
{"word": ["Else."], "author": "gixgox"}
{"word": ["you"], "author": "Ritualisto"}
{"word": ["too"], "author": "le_chevalier"}
{"word": ["Two"], "author": "Yezemin"}
{"word": ["Sequel."], "author": "xieliming"}
{"word": ["Prequel"], "author": "Nel-A"}
{"word": ["before"], "author": "Pickle1477"}
{"word": ["After."], "author": "Narcia_"}
{"word": ["math"], "author": "Ardal"}
{"word": ["Precision"], "author": "Nel-A"}
{"word": ["Engineering"], "author": "Revarye"}
{"word": ["Bridge."], "author": "Hickory"}
{"word": ["bum"], "author": "apehater"}
{"word": ["bang"], "author": "Ritualisto"}
{"word": ["Explosion"], "author": "swatkat"}
{"word": ["scammer"], "author": "apehater"}
{"word": ["fraud"], "author": "Dzsono"}
{"word": [], "author": "gixgox"}
{"word": ["shady"], "author": "Zordu"}
{"word": ["Slim"], "author": "Nel-A"}
{"word": ["Stylized."], "author": "LoboBlanco"}
{"word": ["font"], "author": "Ardal"}
{"word": ["typeset"], "author": "Dzsono"}
{"word": ["Word"], "author": "Ritualisto"}
{"word": ["Clippy"], "author": "park_84"}
{"word": ["Assistant."], "author": "ShadowPatriarch"}
{"word": ["minion"], "author": "viperfdl"}
{"word": ["Familiar"], "author": "flummoxed"}
{"word": ["Acquainted."], "author": "gixgox"}
{"word": ["Acquaintance."], "author": "xieliming"}
{"word": ["associate"], "author": "le_chevalier"}
{"word": ["assassin"], "author": "mariabarring"}
{"word": ["Assailant."], "author": "Hickory"}
{"word": ["Assault"], "author": "TDP"}
{"word": [], "author": "gixgox"}
{"word": ["Astir."], "author": "Hickory"}
{"word": ["Bestir."], "author": "ShadowPatriarch"}
{"word": ["Rouse"], "author": "Nel-A"}
{"word": ["rabble"], "author": "JDelekto"}
{"word": ["Plebian"], "author": "Zoltan999"}
{"word": ["."], "author": "Hickory"}
{"word": ["commoner"], "author": "Ardal"}
{"word": ["Noble."], "author": "Narcia_"}
{"word": ["Patrician."], "author": "REDVWIN"}
{"word": ["royalty"], "author": "Dzsono"}
{"word": ["Monarchy"], "author": "blakstar"}
{"word": ["King"], "author": "Yezemin"}
{"word": ["."], "author": "Hickory"}
{"word": ["Venom."], "author": "LoboBlanco"}
{"word": ["Death"], "author": "DrakoPensulo"}
{"word": ["Cerberus"], "author": "park_84"}
{"word": ["guardian"], "author": "Ardal"}
{"word": ["Warden."], "author": "gixgox"}
{"word": ["Caretaker."], "author": "Hickory"}
{"word": ["Janitor"], "author": "Yezemin"}
{"word": ["Custodian"], "author": "Zoltan999"}
{"word": ["Responsibility"], "author": "Nel-A"}
{"word": ["Trust."], "author": "Narcia_"}
{"word": ["mutual"], "author": "Ardal"}
{"word": ["agreement"], "author": "VampiroAlhazred"}
{"word": ["Consensus."], "author": "gixgox"}
{"word": ["general"], "author": "le_chevalier"}
{"word": ["generic"], "author": "Accatone"}
{"word": ["trademarked"], "author": "Zordu"}
{"word": ["Copyright"], "author": "coryrj1995"}
{"word": ["infringement"], "author": "Smogg"}
{"word": ["Penalty."], "author": "REDVWIN"}
{"word": ["kick"], "author": "truhlik"}
{"word": ["Box."], "author": "xieliming"}
{"word": ["cat"], "author": "XYCat"}
{"word": ["lion"], "author": "Accatone"}
{"word": ["candy"], "author": "apehater"}
{"word": ["broccoli"], "author": "Dzsono"}
{"word": ["Green."], "author": "ShadowPatriarch"}
{"word": ["traffic"], "author": "kmonster"}
{"word": ["Light."], "author": "gixgox"}
{"word": ["Dark"], "author": "agentcarr16"}
{"word": ["Space"], "author": "MightyPinecone"}
{"word": ["Abyss."], "author": "ShadowPatriarch"}
{"word": ["Deep"], "author": "park_84"}
{"word": ["Blue"], "author": "squidbee"}
{"word": ["Sea"], "author": "Yezemin"}
{"word": ["bottom"], "author": "Ardal"}
{"word": ["Base"], "author": "Revarye"}
{"word": ["house"], "author": "Ritualisto"}
{"word": [], "author": "blakstar"}
{"word": [], "author": "Zoltan999"}
{"word": ["."], "author": "gixgox"}
{"word": ["medic"], "author": "Accatone"}
{"word": ["Engineer."], "author": "ShadowPatriarch"}
{"word": ["Grease."], "author": "Hickory"}
{"word": ["Oil"], "author": "Yezemin"}
{"word": [], "author": "gixgox"}
{"word": ["shade"], "author": "Ardal"}
{"word": [], "author": "MightyPinecone"}
{"word": ["Greece"], "author": "Nel-A"}
{"word": ["ancient"], "author": "Pickle1477"}
{"word": ["Mystery"], "author": "Nel-A"}
{"word": ["."], "author": "gixgox"}
{"word": ["Irrigo"], "author": "Wholesalespy52"}
{"word": [" Conundrum."], "author": "Hickory"}
{"word": ["Difficult."], "author": "Narcia_"}
{"word": ["hard"], "author": "viperfdl"}
{"word": ["Tough"], "author": "Nel-A"}
{"word": ["Guy."], "author": "Ikarugamesh"}
{"word": ["Male."], "author": "REDVWIN"}
{"word": ["specimen"], "author": "Ardal"}
{"word": ["Laboratory"], "author": "Nel-A"}
{"word": ["Rat."], "author": "Hickory"}
{"word": ["Bat."], "author": "gixgox"}
{"word": ["Vampire."], "author": "REDVWIN"}
{"word": ["Fangs"], "author": "MightyPinecone"}
{"word": ["Snake"], "author": "Nel-A"}
{"word": ["Cobra"], "author": "RebelCurse"}
{"word": ["Stallone"], "author": "Nel-A"}
{"word": [" Venom."], "author": "Hickory"}
{"word": ["Viper"], "author": "Azrael360"}
{"word": ["Dodge."], "author": "ShadowPatriarch"}
{"word": ["Avoid."], "author": "Hickory"}
{"word": ["extricate"], "author": "Dzsono"}
{"word": ["Free"], "author": "park_84"}
{"word": ["Speech"], "author": "Yezemin"}
{"word": ["loud"], "author": "Ritualisto"}
{"word": ["clear"], "author": "le_chevalier"}
{"word": ["Present."], "author": "xieliming"}
{"word": ["Gift"], "author": "blakstar"}
{"word": ["Card"], "author": "Habanerose"}
{"word": ["Business"], "author": "Zoltan999"}
{"word": ["Jobs"], "author": "Habanerose"}
{"word": ["restructured"], "author": "Ardal"}
{"word": ["Metamorphosis."], "author": "Hickory"}
{"word": ["Transformation."], "author": "gixgox"}
{"word": ["Change"], "author": "Yezemin"}
{"word": ["Become"], "author": "Nel-A"}
{"word": ["Achieve."], "author": "REDVWIN"}
{"word": ["Goals."], "author": "Narcia_"}
{"word": ["Score"], "author": "Pickle1477"}
{"word": ["Win"], "author": "Nel-A"}
{"word": ["Prevail."], "author": "Hickory"}
{"word": ["Trascend."], "author": "REDVWIN"}
{"word": ["Exceed"], "author": "Nel-A"}
{"word": ["Overshadow."], "author": "ShadowPatriarch"}
{"word": ["loom"], "author": "Dzsono"}
{"word": ["Weave."], "author": "Hickory"}
{"word": ["Sow."], "author": "xieliming"}
{"word": ["Pig"], "author": "Habanerose"}
{"word": ["farm"], "author": "Smogg"}
{"word": ["Cow"], "author": "park_84"}
{"word": ["Cowboy"], "author": "VampiroAlhazred"}
{"word": ["Ranch."], "author": "ShadowPatriarch"}
{"word": ["Dressing"], "author": "flummoxed"}
{"word": ["salad"], "author": "le_chevalier"}
{"word": ["caesar"], "author": "truhlik"}
{"word": ["Rome"], "author": "Ritualisto"}
{"word": ["Brutus."], "author": "gixgox"}
{"word": ["stab"], "author": "Niggles"}
{"word": ["Wound"], "author": "Yezemin"}
{"word": ["bandages"], "author": "Ardal"}
{"word": ["Wrap"], "author": "Zoltan999"}
{"word": ["rap"], "author": "Accatone"}
{"word": [], "author": "gixgox"}
{"word": [], "author": "flubbucket"}
{"word": ["Tub."], "author": "Narcia_"}
{"word": ["Barrel."], "author": "ShadowPatriarch"}
{"word": ["Roll"], "author": "Nel-A"}
{"word": ["Tumble."], "author": "Hickory"}
{"word": ["Weed."], "author": "gixgox"}
{"word": ["Smoke"], "author": "Nel-A"}
{"word": ["Signal."], "author": "xieliming"}
{"word": ["Alert"], "author": "Nel-A"}
{"word": ["warning"], "author": "Dzsono"}
{"word": ["Threat"], "author": "Nel-A"}
{"word": ["scare"], "author": "RebelCurse"}
{"word": ["red"], "author": "kmonster"}
{"word": ["Blood"], "author": "Revarye"}
{"word": ["Vampire"], "author": "blakstar"}
{"word": ["Crypt."], "author": "gixgox"}
{"word": ["creepy"], "author": "le_chevalier"}
{"word": ["Creeper."], "author": "LoboBlanco"}
{"word": ["Lurker."], "author": "xieliming"}
{"word": ["forum"], "author": "Dzsono"}
{"word": ["Romanum"], "author": "truhlik"}
{"word": ["imperium"], "author": "le_chevalier"}
{"word": ["Fall"], "author": "park_84"}
{"word": ["Autumn"], "author": "Yezemin"}
{"word": ["spring"], "author": "Ritualisto"}
{"word": ["Winter."], "author": "ShadowPatriarch"}
{"word": ["depression"], "author": "Ardal"}
{"word": ["Survived."], "author": "gixgox"}
{"word": ["alive"], "author": "JinKazaragi"}
{"word": ["Buried"], "author": "Zoltan999"}
{"word": ["Mortality"], "author": "Nel-A"}
{"word": ["Eternity."], "author": "Narcia_"}
{"word": ["Infinity."], "author": "Hickory"}
{"word": ["Beyond"], "author": "Yezemin"}
{"word": ["Ulterior."], "author": "REDVWIN"}
{"word": ["motives"], "author": "Ardal"}
{"word": ["Purpose."], "author": "Hickory"}
{"word": ["mine"], "author": "kmonster"}
{"word": ["Gold"], "author": "Yezemin"}
{"word": ["silver"], "author": "JinKazaragi"}
{"word": ["lining"], "author": "BlackDawn"}
{"word": ["Embroidered"], "author": "Nel-A"}
{"word": ["stitch"], "author": "Dzsono"}
{"word": ["Side."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["pillars"], "author": "apehater"}
{"word": ["Obsidian"], "author": "RyeFlavoredBread"}
{"word": ["Glass."], "author": "Hickory"}
{"word": ["armor"], "author": "le_chevalier"}
{"word": ["Plate."], "author": "LoboBlanco"}
{"word": ["Mail."], "author": "xieliming"}
{"word": ["arrival"], "author": "Dzsono"}
{"word": ["Flight"], "author": "RyeFlavoredBread"}
{"word": ["Retreat"], "author": "Yezemin"}
{"word": ["run"], "author": "Ritualisto"}
{"word": ["Forrest"], "author": "park_84"}
{"word": ["."], "author": "gixgox"}
{"word": ["Canadian"], "author": "Habanerose"}
{"word": ["Maple"], "author": "Revarye"}
{"word": ["tree"], "author": "JinKazaragi"}
{"word": ["House"], "author": "truhlik"}
{"word": ["Address."], "author": "ShadowPatriarch"}
{"word": ["Speech"], "author": "Yezemin"}
{"word": ["Communique."], "author": "gixgox"}
{"word": ["Dispatch"], "author": "Zoltan999"}
{"word": ["Box."], "author": "Hickory"}
{"word": ["Suggestion."], "author": "gixgox"}
{"word": ["Hypnotic."], "author": "Narcia_"}
{"word": ["Mesmeric."], "author": "Hickory"}
{"word": ["Entranced"], "author": "Nel-A"}
{"word": ["Enchanted"], "author": "Yezemin"}
{"word": ["slot"], "author": "JinKazaragi"}
{"word": ["fit"], "author": "Dzsono"}
{"word": ["Slender."], "author": "REDVWIN"}
{"word": ["light"], "author": "JinKazaragi"}
{"word": ["Wave."], "author": "Hickory"}
{"word": ["Gesture."], "author": "ShadowPatriarch"}
{"word": ["goodwill"], "author": "le_chevalier"}
{"word": ["friendly"], "author": "Ritualisto"}
{"word": ["Hug"], "author": "park_84"}
{"word": ["Kiss."], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["Up."], "author": "xieliming"}
{"word": [". ", " ", " ", " "], "author": "gixgox"}
{"word": ["Tentacle"], "author": "Nel-A"}
{"word": ["Day"], "author": "JDelekto"}
{"word": ["off"], "author": "gixgox"}
{"word": ["Bueller"], "author": "JDelekto"}
{"word": ["Character"], "author": "Nel-A"}
{"word": ["sheet"], "author": "Smogg"}
{"word": ["Flat"], "author": "Nel-A"}
{"word": ["tire"], "author": "Zordu"}
{"word": ["change"], "author": "Dzsono"}
{"word": ["Factor."], "author": "REDVWIN"}
{"word": ["Base."], "author": "LoboBlanco"}
{"word": ["ball"], "author": "apehater"}
{"word": ["foot"], "author": "JinKazaragi"}
{"word": ["athlete"], "author": "Ardal"}
{"word": ["Sweat."], "author": "Antimateria"}
{"word": ["Blood"], "author": "Habanerose"}
{"word": ["Red"], "author": "truhlik"}
{"word": ["Blue"], "author": "park_84"}
{"word": ["sea"], "author": "LesterKnight99"}
{"word": ["Lake"], "author": "Yezemin"}
{"word": ["water"], "author": "Ritualisto"}
{"word": ["thirst"], "author": "Smogg"}
{"word": ["Coffee."], "author": "gixgox"}
{"word": ["Bean."], "author": "Hickory"}
{"word": ["gas"], "author": "JDelekto"}
{"word": ["Station."], "author": "gixgox"}
{"word": ["Train"], "author": "Yezemin"}
{"word": [], "author": "Zoltan999"}
{"word": ["Day"], "author": "JDelekto"}
{"word": [], "author": "gixgox"}
{"word": ["Repetition."], "author": "Hickory"}
{"word": ["echo"], "author": "JDelekto"}
{"word": ["Reverberate"], "author": "Nel-A"}
{"word": ["resonate"], "author": "le_chevalier"}
{"word": ["Vibrate."], "author": "Hickory"}
{"word": ["Humm"], "author": "Antimateria"}
{"word": ["boom"], "author": "apehater"}
{"word": ["sonic"], "author": "Smogg"}
{"word": ["robotnik"], "author": "muter"}
{"word": ["Sputnik."], "author": "xieliming"}
{"word": ["pioneer"], "author": "Dzsono"}
{"word": ["engineer"], "author": "le_chevalier"}
{"word": ["Sneer"], "author": "Revarye"}
{"word": ["Smirk."], "author": "Hickory"}
{"word": ["Smug"], "author": "Yezemin"}
{"word": ["grin"], "author": "Ardal"}
{"word": ["smile"], "author": "Ritualisto"}
{"word": ["Teeth"], "author": "park_84"}
{"word": ["Enamel."], "author": "Hickory"}
{"word": ["Nails"], "author": "Hardrada"}
{"word": ["."], "author": "gixgox"}
{"word": ["Ban"], "author": "Zoltan999"}
{"word": ["Hammer"], "author": "mariabarring"}
{"word": ["Time"], "author": "omega64"}
{"word": ["Lord."], "author": "gixgox"}
{"word": ["doctor"], "author": "Dzsono"}
{"word": ["doc"], "author": "Accatone"}
{"word": ["Brown."], "author": "Narcia_"}
{"word": ["Fox."], "author": "xieliming"}
{"word": ["Hare."], "author": "Swampland"}
{"word": ["food"], "author": "JinKazaragi"}
{"word": ["Thought"], "author": "litildivil"}
{"word": ["Reflection."], "author": "ShadowPatriarch"}
{"word": ["mirror"], "author": "Smogg"}
{"word": ["Mimic."], "author": "REDVWIN"}
{"word": ["Panto", "."], "author": "Hickory"}
{"word": ["farce"], "author": "Dzsono"}
{"word": ["horror"], "author": "kmonster"}
{"word": ["Suspense."], "author": "LoboBlanco"}
{"word": ["Anticipation"], "author": "blakstar"}
{"word": ["preparation"], "author": "le_chevalier"}
{"word": ["Meditation."], "author": "semigroups"}
{"word": ["Enlightenment."], "author": "ShadowPatriarch"}
{"word": ["Serenity"], "author": "Revarye"}
{"word": ["Wisdom"], "author": "Madshaker"}
{"word": ["Hermit"], "author": "Yezemin"}
{"word": ["Alone"], "author": "park_84"}
{"word": ["Home."], "author": "xieliming"}
{"word": ["Court."], "author": "ShadowPatriarch"}
{"word": ["Divorce"], "author": "Zoltan999"}
{"word": ["expensive"], "author": "JinKazaragi"}
{"word": ["money"], "author": "Ritualisto"}
{"word": ["Laundering."], "author": "gixgox"}
{"word": ["Cleanup."], "author": "Hickory"}
{"word": ["Mess"], "author": "blakstar"}
{"word": ["Hall"], "author": "Pickle1477"}
{"word": ["Great."], "author": "Narcia_"}
{"word": ["^^ ...way ", " ", " ^ negligible "], "author": "gixgox"}
{"word": ["hasty"], "author": "pokooj"}
{"word": [" Trivial."], "author": "Hickory"}
{"word": ["Pursuit"], "author": "Yezemin"}
{"word": ["Hot."], "author": "xieliming"}
{"word": ["Sun"], "author": "Azrael360"}
{"word": ["star"], "author": "JinKazaragi"}
{"word": ["star"], "author": "Dzsono"}
{"word": ["star"], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["Orion."], "author": "LoboBlanco"}
{"word": ["belt"], "author": "Smogg"}
{"word": ["Black"], "author": "Yezemin"}
{"word": ["white"], "author": "Ritualisto"}
{"word": ["blank"], "author": "le_chevalier"}
{"word": ["Slate."], "author": "ShadowPatriarch"}
{"word": ["Condition"], "author": "Zoltan999"}
{"word": ["Prepare."], "author": "Hickory"}
{"word": ["Ready"], "author": "GabesterOne"}
{"word": ["no"], "author": "Accatone"}
{"word": ["sir"], "author": "park_84"}
{"word": ["Madam."], "author": "semigroups"}
{"word": ["madman"], "author": "XYCat"}
{"word": ["Genius."], "author": "Narcia_"}
{"word": ["Professor."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["Neutron"], "author": "GabesterOne"}
{"word": ["Isaac"], "author": "Cavenagh"}
{"word": [], "author": "gixgox"}
{"word": [" Particle."], "author": "Hickory"}
{"word": ["cannon"], "author": "Ardal"}
{"word": ["Bullet."], "author": "REDVWIN"}
{"word": ["Proof."], "author": "Hickory"}
{"word": ["concept"], "author": "truhlik"}
{"word": ["Idea"], "author": "Yezemin"}
{"word": ["Spark."], "author": "xieliming"}
{"word": ["Ignite."], "author": "Hickory"}
{"word": ["Extinguish"], "author": "blakstar"}
{"word": ["suffocate"], "author": "Dzsono"}
{"word": ["Strangle."], "author": "semigroups"}
{"word": ["Garotte."], "author": "Hickory"}
{"word": ["string"], "author": "le_chevalier"}
{"word": ["Theory."], "author": "gixgox"}
{"word": ["Corollary."], "author": "REDVWIN"}
{"word": ["Result"], "author": "park_84"}
{"word": ["End."], "author": "ShadowPatriarch"}
{"word": ["Final"], "author": "Yezemin"}
{"word": ["Fantasy"], "author": "Ritualisto"}
{"word": ["Crystals."], "author": "omega64"}
{"word": ["Mineral."], "author": "Hickory"}
{"word": ["water"], "author": "Ardal"}
{"word": ["One Piece is sort of related to water but no. :P ", " ", " Fish."], "author": "omega64"}
{"word": ["seafood"], "author": "le_chevalier"}
{"word": [" Funny."], "author": "ShadowPatriarch"}
{"word": [" [harrisonson's post is spam. Down-rep and report as spam. If enough people do this it will disappear.] ", " ", " ", " S\u0336u\u0336c\u0336h\u0336i\u0336. [Edit: typo] ", " Sushi."], "author": "Hickory"}
{"word": [" I know, Already did that. ;) ", " Did you mean Sushi? ", " ", " Japan."], "author": "omega64"}
{"word": [" [Yes, of course. I hate typos. :) ] ", " ", " Island."], "author": "Hickory"}
{"word": ["treasure"], "author": "GabesterOne"}
{"word": ["Hunt"], "author": "Zoltan999"}
{"word": ["Quarry."], "author": "Hickory"}
{"word": [" Mine ( it's nacho cheese!)"], "author": "Sturleson"}
{"word": ["gold"], "author": "GabesterOne"}
{"word": ["Heart"], "author": "Yezemin"}
{"word": [], "author": "gixgox"}
{"word": [" Radio"], "author": "Sturleson"}
{"word": ["Antenna."], "author": "Hickory"}
{"word": ["signal"], "author": "Dzsono"}
{"word": ["Smoke"], "author": "Revarye"}
{"word": ["fire"], "author": "JinKazaragi"}
{"word": ["^^ ", " ", " ", " ^", " "], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["flame"], "author": "GabesterOne"}
{"word": ["Crush"], "author": "Nel-A"}
{"word": [], "author": "REDVWIN"}
{"word": ["Rust"], "author": "agentcarr16"}
{"word": [" Metal"], "author": "jpwiseguy"}
{"word": ["Ore"], "author": "Hardrada"}
{"word": ["mining"], "author": "Smogg"}
{"word": ["Company."], "author": "ShadowPatriarch"}
{"word": ["GOG."], "author": "REDVWIN"}
{"word": ["bear"], "author": "Zordu"}
{"word": ["simulator"], "author": "GabesterOne"}
{"word": ["SIMS"], "author": "clisair"}
{"word": ["Simoleon."], "author": "LoboBlanco"}
{"word": ["Career"], "author": "Dzsono"}
{"word": ["Occupation."], "author": "ShadowPatriarch"}
{"word": ["work"], "author": "Ritualisto"}
{"word": ["Labor"], "author": "park_84"}
{"word": ["Childbirth."], "author": "Hickory"}
{"word": ["Natural"], "author": "Zoltan999"}
{"word": ["Logical."], "author": "ShadowPatriarch"}
{"word": ["Spock."], "author": "omega64"}
{"word": ["Pointy"], "author": "Yezemin"}
{"word": ["Ears."], "author": "Narcia_"}
{"word": [" ", " ", " <for the ninja>: "], "author": "gixgox"}
{"word": ["Dust."], "author": "Hickory"}
{"word": ["dirt"], "author": "JinKazaragi"}
{"word": ["turd"], "author": "le_chevalier"}
{"word": ["hanky"], "author": "apehater"}
{"word": ["Tissue"], "author": "Nel-A"}
{"word": ["Soft."], "author": "xieliming"}
{"word": ["hard"], "author": "Ritualisto"}
{"word": ["Boiled"], "author": "Yezemin"}
{"word": ["mulled"], "author": "Dzsono"}
{"word": ["Spiced"], "author": "blakstar"}
{"word": ["Savoury."], "author": "Hickory"}
{"word": ["Eggs"], "author": "JDelekto"}
{"word": ["Omelette."], "author": "REDVWIN"}
{"word": ["breakfast"], "author": "JDelekto"}
{"word": ["bread"], "author": "JinKazaragi"}
{"word": ["Butter."], "author": "ShadowPatriarch"}
{"word": ["Sandwich."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["Japan"], "author": "GabesterOne"}
{"word": ["Honor"], "author": "park_84"}
{"word": ["guard"], "author": "Ardal"}
{"word": ["Protect"], "author": "blakstar"}
{"word": ["Duty"], "author": "Revarye"}
{"word": ["Task"], "author": "JDelekto"}
{"word": ["."], "author": "gixgox"}
{"word": ["diversion"], "author": "JDelekto"}
{"word": ["Distraction"], "author": "Yezemin"}
{"word": ["entertainment"], "author": "JDelekto"}
{"word": ["Spectacle."], "author": "Hickory"}
{"word": ["Extravaganza"], "author": "Zoltan999"}
{"word": ["Variety."], "author": "REDVWIN"}
{"word": ["Diversity."], "author": "Hickory"}
{"word": ["Adversity"], "author": "TDP"}
{"word": ["misadventure"], "author": "le_chevalier"}
{"word": ["Accident."], "author": "Hickory"}
{"word": ["happening"], "author": "Ardal"}
{"word": ["science"], "author": "le_chevalier"}
{"word": ["physics"], "author": "JinKazaragi"}
{"word": ["Chemistry."], "author": "Hickory"}
{"word": ["bond"], "author": "Dzsono"}
{"word": ["Metallic."], "author": "xieliming"}
{"word": ["Sheen."], "author": "Hickory"}
{"word": ["Her"], "author": "Abovet"}
{"word": ["Story"], "author": "semigroups"}
{"word": ["Legend"], "author": "Azrael360"}
{"word": ["Hitch"], "author": "devjock"}
{"word": [], "author": "gixgox"}
{"word": ["memoir"], "author": "devjock"}
{"word": ["reminder"], "author": "JDelekto"}
{"word": ["Amnesia."], "author": "ShadowPatriarch"}
{"word": ["Alzheimer"], "author": "Stooner"}
{"word": ["dementia"], "author": "Zordu"}
{"word": ["forget"], "author": "Dzsono"}
{"word": ["Memento"], "author": "park_84"}
{"word": ["Backwards"], "author": "truhlik"}
{"word": ["past"], "author": "Ritualisto"}
{"word": ["Present."], "author": "xieliming"}
{"word": ["Gift."], "author": "gixgox"}
{"word": ["birthday"], "author": "Accatone"}
{"word": [" ", " ", " ", " Candle."], "author": "gixgox"}
{"word": ["Wax."], "author": "ShadowPatriarch"}
{"word": ["Honeycomb."], "author": "Hickory"}
{"word": ["Bees"], "author": "semigroups"}
{"word": ["wasp"], "author": "Ardal"}
{"word": ["Sting."], "author": "Hickory"}
{"word": ["Pain."], "author": "coryrj1995"}
{"word": ["Barrier"], "author": "Cavenagh"}
{"word": ["resistance"], "author": "nigelbeans"}
{"word": ["futile"], "author": "viperfdl"}
{"word": ["Hopeless."], "author": "Hickory"}
{"word": ["case"], "author": "Smogg"}
{"word": ["Luggage"], "author": "Zoltan999"}
{"word": ["Suit"], "author": "bigyE"}
{"word": ["Costume"], "author": "TDP"}
{"word": ["Outfit."], "author": "Hickory"}
{"word": ["outside"], "author": "Accatone"}
{"word": [], "author": "gixgox"}
{"word": ["exoplanet"], "author": "le_chevalier"}
{"word": ["extrasolar"], "author": "Si0ned"}
{"word": ["rogue planets"], "author": "GabesterOne"}
{"word": [" Extraterrestrial."], "author": "Hickory"}
{"word": ["Alien."], "author": "ShadowPatriarch"}
{"word": ["Foreign."], "author": "REDVWIN"}
{"word": ["Exotic."], "author": "Hickory"}
{"word": ["Curiosity."], "author": "Narcia_"}
{"word": ["Knowledge"], "author": "Azrael360"}
{"word": ["Book."], "author": "xieliming"}
{"word": ["reserve"], "author": "Dzsono"}
{"word": ["Stash."], "author": "REDVWIN"}
{"word": ["Hoard."], "author": "Hickory"}
{"word": ["collect"], "author": "le_chevalier"}
{"word": ["call"], "author": "Zordu"}
{"word": ["Phone"], "author": "VampiroAlhazred"}
{"word": ["E.T."], "author": "park_84"}
{"word": [" Dial."], "author": "Hickory"}
{"word": ["home"], "author": "Ritualisto"}
{"word": ["Heart"], "author": "flubbucket"}
{"word": ["Hearth."], "author": "Hickory"}
{"word": ["home"], "author": "Ardal"}
{"word": ["Sweet"], "author": "Yezemin"}
{"word": ["sugar"], "author": "JinKazaragi"}
{"word": ["... "], "author": "gixgox"}
{"word": ["Capsule."], "author": "Narcia_"}
{"word": ["Receptacle."], "author": "Hickory"}
{"word": ["Socket"], "author": "Zoltan999"}
{"word": ["Wrench."], "author": "Hickory"}
{"word": ["Bolt"], "author": "Pickle1477"}
{"word": ["Screw."], "author": "coryrj1995"}
{"word": ["Thread."], "author": "Hickory"}
{"word": ["forum (like GOG's Forum ;))"], "author": "GabesterOne"}
{"word": ["word-association"], "author": "devjock"}
{"word": [" Psychotherapy"], "author": "agentcarr16"}
{"word": ["Quackery."], "author": "Hickory"}
{"word": ["medical"], "author": "GabesterOne"}
{"word": ["Assistant"], "author": "Azrael360"}
{"word": ["Personal"], "author": "cose_vecchie"}
{"word": ["Intimate."], "author": "Hickory"}
{"word": ["Knowledge"], "author": "cose_vecchie"}
{"word": ["wisdom"], "author": "Dzsono"}
{"word": ["Cleric."], "author": "xieliming"}
{"word": ["Priest"], "author": "blakstar"}
{"word": ["Paedophile."], "author": "gixgox"}
{"word": ["children"], "author": "GabesterOne"}
{"word": ["Cartoon"], "author": "Revarye"}
{"word": ["Carbon"], "author": "truhlik"}
{"word": ["Graphite"], "author": "park_84"}
{"word": ["Pencil."], "author": "ShadowPatriarch"}
{"word": ["paper"], "author": "Ritualisto"}
{"word": ["article"], "author": "le_chevalier"}
{"word": ["Slander."], "author": "omega64"}
{"word": ["law"], "author": "Ardal"}
{"word": ["Restriction."], "author": "Hickory"}
{"word": ["Limitation."], "author": "gixgox"}
{"word": ["restraint"], "author": "GabesterOne"}
{"word": ["Handcuffs"], "author": "Zoltan999"}
{"word": ["Arrest"], "author": "Yezemin"}
{"word": ["Prison."], "author": "omega64"}
{"word": ["showers (gotta get dat ass >:) )"], "author": "GabesterOne"}
{"word": ["^ Outed!"], "author": "Hickory"}
{"word": ["^ pastor (such as Ted Haggard xD)"], "author": "GabesterOne"}
{"word": ["Juxtaposition."], "author": "Hickory"}
{"word": ["Paradox"], "author": "devjock"}
{"word": [], "author": "Dzsono"}
{"word": ["Probability."], "author": "Hickory"}
{"word": [" Scientist"], "author": "TARFU"}
{"word": ["Probability."], "author": "Hickory"}
{"word": ["Statistics"], "author": "TARFU"}
{"word": ["."], "author": "Hickory"}
{"word": ["Falsehoods"], "author": "TARFU"}
{"word": ["False."], "author": "xieliming"}
{"word": ["True"], "author": "blakstar"}
{"word": ["fact"], "author": "GabesterOne"}
{"word": [">implying"], "author": "devjock"}
{"word": ["suggesting"], "author": "TARFU"}
{"word": ["Indicative."], "author": "Hickory"}
{"word": ["Lead."], "author": "LoboBlanco"}
{"word": ["follow (like we all do to each other in this word game :) )"], "author": "GabesterOne"}
{"word": ["Trail"], "author": "TARFU"}
{"word": ["Game."], "author": "ShadowPatriarch"}
{"word": ["Thrones"], "author": "park_84"}
{"word": ["combat"], "author": "Ritualisto"}
{"word": ["Kombat."], "author": "omega64"}
{"word": ["babality"], "author": "devjock"}
{"word": ["Fatality"], "author": "Zoltan999"}
{"word": ["."], "author": "gixgox"}
{"word": ["DEATH (some thing we will all experience, hopefully EA first)"], "author": "GabesterOne"}
{"word": ["Life"], "author": "Yezemin"}
{"word": ["Love."], "author": "omega64"}
{"word": ["Sex ( had to do it xD )"], "author": "GabesterOne"}
{"word": ["Blind. ", " ", " ", " ", " ", " Procreation."], "author": "ShadowPatriarch"}
{"word": ["cosmos"], "author": "Accatone"}
{"word": ["Astronomical."], "author": "Narcia_"}
{"word": ["."], "author": "gixgox"}
{"word": ["Time."], "author": "Hickory"}
{"word": ["Age"], "author": "truhlik"}
{"word": ["era"], "author": "le_chevalier"}
{"word": ["."], "author": "gixgox"}
{"word": ["Epoch."], "author": "REDVWIN"}
{"word": ["Period."], "author": "Hickory"}
{"word": ["Punctuation!"], "author": "TARFU"}
{"word": ["Punctuality."], "author": "Hickory"}
{"word": ["promptness"], "author": "GabesterOne"}
{"word": ["Immediacy"], "author": "Yezemin"}
{"word": ["Urgency"], "author": "TARFU"}
{"word": ["fast"], "author": "Ritualisto"}
{"word": ["furious"], "author": "gixgox"}
{"word": ["Irate"], "author": "TARFU"}
{"word": ["Livid."], "author": "Hickory"}
{"word": ["capricious"], "author": "Dzsono"}
{"word": ["mercurial"], "author": "TARFU"}
{"word": ["Volatile."], "author": "ShadowPatriarch"}
{"word": ["labile"], "author": "le_chevalier"}
{"word": ["Unstable."], "author": "Hickory"}
{"word": ["Explosive"], "author": "park_84"}
{"word": ["."], "author": "gixgox"}
{"word": ["Nobel"], "author": "Ardal"}
{"word": ["human"], "author": "Ritualisto"}
{"word": ["Xenos"], "author": "Zoltan999"}
{"word": [" Nature."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": [" ", " insect"], "author": "Accatone"}
{"word": ["Bug."], "author": "xieliming"}
{"word": ["eggs"], "author": "GabesterOne"}
{"word": ["bacon"], "author": "cose_vecchie"}
{"word": ["Pig."], "author": "omega64"}
{"word": ["."], "author": "Hickory"}
{"word": ["Dexterity"], "author": "blakstar"}
{"word": ["stats"], "author": "GabesterOne"}
{"word": ["Qualities."], "author": "Narcia_"}
{"word": ["."], "author": "Hickory"}
{"word": ["Knight"], "author": "TARFU"}
{"word": ["Gabriel"], "author": "VampiroAlhazred"}
{"word": ["Malia"], "author": "ashwald"}
{"word": ["Obama"], "author": "GabesterOne"}
{"word": ["Kenyan"], "author": "TARFU"}
{"word": ["nationality"], "author": "Ardal"}
{"word": ["Citizenship."], "author": "gixgox"}
{"word": ["Membership."], "author": "Hickory"}
{"word": ["member"], "author": "Ritualisto"}
{"word": ["Rank."], "author": "xieliming"}
{"word": ["Level"], "author": "Azrael360"}
{"word": ["experience"], "author": "Dzsono"}
{"word": ["Points"], "author": "TARFU"}
{"word": ["Score."], "author": "Narcia_"}
{"word": ["Ranking."], "author": "gixgox"}
{"word": ["position"], "author": "GabesterOne"}
{"word": ["Center"], "author": "tort1234"}
{"word": ["Equidistant."], "author": "ShadowPatriarch"}
{"word": ["Central"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": ["drama"], "author": "le_chevalier"}
{"word": ["Tear"], "author": "park_84"}
{"word": ["GOG-Forums"], "author": "gixgox"}
{"word": ["Here"], "author": "pokooj"}
{"word": ["there"], "author": "Ardal"}
{"word": ["location"], "author": "GabesterOne"}
{"word": ["destination"], "author": "Zoltan999"}
{"word": ["final"], "author": "viperfdl"}
{"word": ["Ultimate."], "author": "ShadowPatriarch"}
{"word": ["."], "author": "gixgox"}
{"word": ["Final."], "author": "xieliming"}
{"word": ["Exam"], "author": "Yezemin"}
{"word": ["Test"], "author": "Pickle1477"}
{"word": ["Voight-Kampff"], "author": "viperfdl"}
{"word": ["Replicant?"], "author": "Nel-A"}
{"word": ["robots"], "author": "GabesterOne"}
{"word": ["Automation."], "author": "Hickory"}
{"word": ["Oscar"], "author": "Moonbeam"}
{"word": ["Academy."], "author": "REDVWIN"}
{"word": ["Police"], "author": "Yezemin"}
{"word": ["Dog."], "author": "Hickory"}
{"word": ["Cat"], "author": "Azrael360"}
{"word": ["girl"], "author": "Ardal"}
{"word": ["boy"], "author": "Ritualisto"}
{"word": ["male"], "author": "TARFU"}
{"word": ["Puberty"], "author": "Accatone"}
{"word": ["dragon"], "author": "kmonster"}
{"word": ["fire"], "author": "TARFU"}
{"word": ["melt"], "author": "Dzsono"}
{"word": ["Ice."], "author": "Hickory"}
{"word": ["Glacier"], "author": "TARFU"}
{"word": ["Freeze."], "author": "xieliming"}
{"word": ["Mister"], "author": "TARFU"}
{"word": ["Sandman"], "author": "park_84"}
{"word": [], "author": "gixgox"}
{"word": ["prelude"], "author": "le_chevalier"}
{"word": ["piece"], "author": "Ardal"}
{"word": ["One"], "author": "Yezemin"}
{"word": ["Step."], "author": "Hickory"}
{"word": ["pets"], "author": "Accatone"}
{"word": ["Hamster"], "author": "TDP"}
{"word": ["dance"], "author": "Smogg"}
{"word": ["Club"], "author": "Habanerose"}
{"word": ["Truncheon"], "author": "TARFU"}
{"word": ["Staff."], "author": "ShadowPatriarch"}
{"word": ["Meeting."], "author": "Hickory"}
{"word": ["Date"], "author": "DrakoPensulo"}
{"word": ["."], "author": "gixgox"}
{"word": ["love"], "author": "Ritualisto"}
{"word": ["Potion."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["startrek"], "author": "devjock"}
{"word": ["galaxy"], "author": "Dzsono"}
{"word": [], "author": "gixgox"}
{"word": ["Power."], "author": "xieliming"}
{"word": ["Horse"], "author": "TARFU"}
{"word": ["armor"], "author": "GabesterOne"}
{"word": ["hotdog"], "author": "JDelekto"}
{"word": ["Mustard."], "author": "shadowmirage"}
{"word": ["Gas"], "author": "TARFU"}
{"word": ["Cloud"], "author": "park_84"}
{"word": ["Cover."], "author": "Hickory"}
{"word": ["picture"], "author": "Ritualisto"}
{"word": ["View"], "author": "Abovet"}
{"word": ["."], "author": "gixgox"}
{"word": ["Belief."], "author": "ShadowPatriarch"}
{"word": ["Faith"], "author": "Yezemin"}
{"word": ["Fervour"], "author": "Zoltan999"}
{"word": ["effervescence"], "author": "JDelekto"}
{"word": ["bubbles"], "author": "Ardal"}
{"word": ["testicles"], "author": "Eynit"}
{"word": ["gonads"], "author": "JDelekto"}
{"word": ["reproduction"], "author": "Accatone"}
{"word": ["copycat"], "author": "JDelekto"}
{"word": ["Killer"], "author": "blakstar"}
{"word": ["terminator"], "author": "le_chevalier"}
{"word": ["Termination"], "author": "Accatone"}
{"word": ["."], "author": "gixgox"}
{"word": ["Analyst."], "author": "Hickory"}
{"word": ["numbers"], "author": "Smogg"}
{"word": ["\u03c0"], "author": "truhlik"}
{"word": ["weebl"], "author": "devjock"}
{"word": ["animator"], "author": "GabesterOne"}
{"word": ["artist"], "author": "JDelekto"}
{"word": ["Paint."], "author": "Narcia_"}
{"word": ["Draw."], "author": "ShadowPatriarch"}
{"word": ["sign"], "author": "JDelekto"}
{"word": ["language"], "author": "Zordu"}
{"word": ["communication"], "author": "JDelekto"}
{"word": ["Radio"], "author": "TARFU"}
{"word": ["waves"], "author": "Smogg"}
{"word": ["Gesticulates."], "author": "Hickory"}
{"word": ["nods"], "author": "RebelCurse"}
{"word": ["motions"], "author": "Dzsono"}
{"word": ["Gestures"], "author": "TARFU"}
{"word": ["Touch."], "author": "xieliming"}
{"word": ["feel"], "author": "le_chevalier"}
{"word": ["Sense"], "author": "TARFU"}
{"word": ["smell"], "author": "Zordu"}
{"word": ["Olfaction."], "author": "ShadowPatriarch"}
{"word": ["Nasal"], "author": "TARFU"}
{"word": ["Mucus"], "author": "park_84"}
{"word": ["slime"], "author": "Ritualisto"}
{"word": ["mud"], "author": "le_chevalier"}
{"word": ["Sludge"], "author": "Yezemin"}
{"word": ["Waste."], "author": "xieliming"}
{"word": ["garbage (like roman reigns)"], "author": "GabesterOne"}
{"word": ["Disposal."], "author": "Hickory"}
{"word": ["discrete"], "author": "Ardal"}
{"word": ["Secret"], "author": "Zoltan999"}
{"word": ["spy"], "author": "GabesterOne"}
{"word": ["Peek."], "author": "REDVWIN"}
{"word": ["Observe."], "author": "Narcia_"}
{"word": ["Monitor."], "author": "gixgox"}
{"word": ["Resolution."], "author": "Hickory"}
{"word": ["Determination."], "author": "ShadowPatriarch"}
{"word": ["Resolve"], "author": "TARFU"}
{"word": ["ending (just like HHH's wwe title reign)"], "author": "GabesterOne"}
{"word": ["Credits."], "author": "xieliming"}
{"word": ["restart"], "author": "Ritualisto"}
{"word": ["Recommence"], "author": "TARFU"}
{"word": ["Resume"], "author": "Madshaker"}
{"word": ["R\u00e9sum\u00e9."], "author": "Hickory"}
{"word": ["pronunciation"], "author": "Dzsono"}
{"word": ["Elocution"], "author": "TARFU"}
{"word": ["Articulation."], "author": "Hickory"}
{"word": ["speech (something that roman reigns cant do naturally)"], "author": "GabesterOne"}
{"word": ["Monologue"], "author": "TARFU"}
{"word": ["Solo"], "author": "TDP"}
{"word": ["flying"], "author": "Zordu"}
{"word": ["Soaring"], "author": "TARFU"}
{"word": ["Gliding."], "author": "Hickory"}
{"word": ["Drifting."], "author": "ShadowPatriarch"}
{"word": ["Wood."], "author": "xieliming"}
{"word": ["Chuck"], "author": "Yezemin"}
{"word": ["Norris"], "author": "park_84"}
{"word": [" Coppice."], "author": "Hickory"}
{"word": ["Bush"], "author": "koima57"}
{"word": ["Plants"], "author": "GabesterOne"}
{"word": ["Peppers"], "author": "coryrj1995"}
{"word": ["Banana."], "author": "Narcia_"}
{"word": [], "author": "Zoltan999"}
{"word": ["Comfortable..."], "author": "GhostwriterDoF"}
{"word": ["relax"], "author": "GabesterOne"}
{"word": ["lax"], "author": "Accatone"}
{"word": ["lazy"], "author": "Pickle1477"}
{"word": ["sleepy"], "author": "BenKii"}
{"word": ["Drowsy."], "author": "Hickory"}
{"word": ["tired"], "author": "GabesterOne"}
{"word": ["Exhausted"], "author": "Yezemin"}
{"word": ["Knackered."], "author": "Hickory"}
{"word": ["Sleep."], "author": "xieliming"}
{"word": ["Bed"], "author": "TARFU"}
{"word": ["Roses."], "author": "REDVWIN"}
{"word": ["garden"], "author": "Smogg"}
{"word": ["Horticulture."], "author": "ShadowPatriarch"}
{"word": ["Botany"], "author": "TARFU"}
{"word": ["."], "author": "Hickory"}
{"word": ["Hounds"], "author": "Hardrada"}
{"word": ["Puppies"], "author": "TARFU"}
{"word": ["dogs"], "author": "GabesterOne"}
{"word": ["hot"], "author": "Smogg"}
{"word": ["cool"], "author": "RebelCurse"}
{"word": ["fool"], "author": "apehater"}
{"word": ["Tool."], "author": "Hickory"}
{"word": ["ghoul"], "author": "Dzsono"}
{"word": ["Zombie"], "author": "TARFU"}
{"word": ["undead"], "author": "GabesterOne"}
{"word": ["Turn."], "author": "xieliming"}
{"word": ["Rotate"], "author": "blakstar"}
{"word": ["up"], "author": "SamMagel"}
{"word": ["Above."], "author": "Hickory"}
{"word": ["down"], "author": "GabesterOne"}
{"word": ["Under"], "author": "le_chevalier"}
{"word": ["Below"], "author": "TARFU"}
{"word": ["Oz."], "author": "Tauto"}
{"word": ["witch"], "author": "GabesterOne"}
{"word": ["sandwich"], "author": "Dzsono"}
{"word": ["hotdog"], "author": "le_chevalier"}
{"word": ["Hamburger."], "author": "ShadowPatriarch"}
{"word": ["frankfurter"], "author": "le_chevalier"}
{"word": ["Wiener."], "author": "gixgox"}
{"word": ["Dishrag ", " ", " Edit: No wait.. I thought this was one word at a time. =D. ", " ", " Wimp might be more fitting then."], "author": "Antimateria"}
{"word": ["Weak"], "author": "park_84"}
{"word": ["hard"], "author": "Ritualisto"}
{"word": ["reset"], "author": "skimmie"}
{"word": ["Reboot."], "author": "ShadowPatriarch"}
{"word": ["Relaunch."], "author": "gixgox"}
{"word": ["rebirth"], "author": "viperfdl"}
{"word": ["death"], "author": "Accatone"}
{"word": ["Funeral"], "author": "Yezemin"}
{"word": [" ", " "], "author": "gixgox"}
{"word": ["music"], "author": "GabesterOne"}
{"word": ["Composer."], "author": "Hickory"}
{"word": ["Conductor."], "author": "Narcia_"}
{"word": ["Artist"], "author": "Zoltan999"}
{"word": ["paintings"], "author": "GabesterOne"}
{"word": ["Doodles."], "author": "Hickory"}
{"word": ["leisure"], "author": "Ardal"}
{"word": ["Lazy"], "author": "Yezemin"}
{"word": ["fat"], "author": "GabesterOne"}
{"word": ["Overweight"], "author": "TARFU"}
{"word": ["gargantuan"], "author": "Dzsono"}
{"word": ["giant"], "author": "truhlik"}
{"word": ["Humongous."], "author": "Hickory"}
{"word": ["Andre :)"], "author": "GabesterOne"}
{"word": ["Huge"], "author": "Azrael360"}
{"word": ["Large"], "author": "TARFU"}
{"word": ["Elephant"], "author": "TDP"}
{"word": ["enormous"], "author": "RebelCurse"}
{"word": ["Prodigious"], "author": "TARFU"}
{"word": ["hunger"], "author": "kmonster"}
{"word": ["games"], "author": "GabesterOne"}
{"word": ["Pasttimes."], "author": "Hickory"}
{"word": ["hobbies"], "author": "Dzsono"}
{"word": ["Amusement"], "author": "TARFU"}
{"word": ["enjoyment"], "author": "le_chevalier"}
{"word": ["Pleasure."], "author": "xieliming"}
{"word": ["Fun"], "author": "Yezemin"}
{"word": ["Carnival"], "author": "park_84"}
{"word": ["Rio"], "author": "motorkar"}
{"word": ["Brazil"], "author": "Ritualisto"}
{"word": ["Amazon."], "author": "ShadowPatriarch"}
{"word": ["store"], "author": "JinKazaragi"}
{"word": ["cache"], "author": "le_chevalier"}
{"word": ["cash"], "author": "Accatone"}
{"word": ["bucks"], "author": "GabesterOne"}
{"word": ["Deer."], "author": "Narcia_"}
{"word": ["elk"], "author": "GabesterOne"}
{"word": ["Moose."], "author": "gixgox"}
{"word": ["Caribou"], "author": "coryrj1995"}
{"word": ["Reindeer."], "author": "Hickory"}
{"word": ["dear"], "author": "Accatone"}
{"word": ["smear"], "author": "apehater"}
{"word": ["Smudge"], "author": "TARFU"}
{"word": ["Obscure."], "author": "Hickory"}
{"word": ["Dark"], "author": "Yezemin"}
{"word": ["Matter"], "author": "TDP"}
{"word": ["Energy."], "author": "Hickory"}
{"word": ["drink"], "author": "Ritualisto"}
{"word": ["gulp"], "author": "Dzsono"}
{"word": ["imbibe"], "author": "TARFU"}
{"word": ["sip"], "author": "le_chevalier"}
{"word": ["Trickle"], "author": "Hardrada"}
{"word": ["Drip"], "author": "TARFU"}
{"word": ["Trip"], "author": "truhlik"}
{"word": ["Advisor."], "author": "xieliming"}
{"word": ["Consultant"], "author": "Yezemin"}
{"word": ["Call"], "author": "park_84"}
{"word": ["Hello"], "author": "Dzsono"}
{"word": ["goodbye"], "author": "le_chevalier"}
{"word": ["Farewell."], "author": "ShadowPatriarch"}
{"word": ["Later"], "author": "tort1234"}
{"word": ["Afterwards"], "author": "Nel-A"}
{"word": ["Before."], "author": "Narcia_"}
{"word": ["past"], "author": "GabesterOne"}
{"word": ["Prehistoric"], "author": "Zoltan999"}
{"word": ["Archaic."], "author": "gixgox"}
{"word": ["aged"], "author": "GabesterOne"}
{"word": ["Matured"], "author": "Yezemin"}
{"word": ["Wizened..."], "author": "GhostwriterDoF"}
{"word": ["Wrinkled."], "author": "Hickory"}
{"word": ["Forgetful."], "author": "gixgox"}
{"word": ["Absentminded"], "author": "TARFU"}
{"word": ["Scatterbrained"], "author": "Yezemin"}
{"word": ["confusion"], "author": "GabesterOne"}
{"word": ["Senile."], "author": "gixgox"}
{"word": ["Doddering."], "author": "Hickory"}
{"word": ["Drooling."], "author": "gixgox"}
{"word": ["Baby"], "author": "bravoman"}
{"word": ["Infant."], "author": "Hickory"}
{"word": ["parasite"], "author": "Dzsono"}
{"word": ["Virus"], "author": "TDP"}
{"word": [" Cynical."], "author": "Hickory"}
{"word": [" sometimes ;)"], "author": "Dzsono"}
{"word": ["never"], "author": "JDelekto"}
{"word": [], "author": "gixgox"}
{"word": ["forever"], "author": "le_chevalier"}
{"word": ["young"], "author": "JDelekto"}
{"word": ["Ancient"], "author": "TARFU"}
{"word": ["history"], "author": "JDelekto"}
{"word": ["was"], "author": "kmonster"}
{"word": ["repeated"], "author": "JDelekto"}
{"word": ["Loop."], "author": "xieliming"}
{"word": ["Rollercoaster"], "author": "park_84"}
{"word": ["fun"], "author": "Ritualisto"}
{"word": ["amusement"], "author": "Abovet"}
{"word": ["Games."], "author": "ShadowPatriarch"}
{"word": ["Rules."], "author": "gixgox"}
{"word": ["Regulations."], "author": "Hickory"}
{"word": ["Laws"], "author": "truhlik"}
{"word": ["broken"], "author": "JDelekto"}
{"word": ["fix"], "author": "Ardal"}
{"word": ["Repair"], "author": "Yezemin"}
{"word": ["patch"], "author": "JDelekto"}
{"word": [". ", " ", " <sorry didn't F5> ", " (Patch) Day"], "author": "gixgox"}
{"word": ["self"], "author": "JDelekto"}
{"word": ["defence"], "author": "Smogg"}
{"word": ["advocated"], "author": "JDelekto"}
{"word": ["Attorney."], "author": "Narcia_"}
{"word": ["fees"], "author": "JDelekto"}
{"word": ["flee"], "author": "Accatone"}
{"word": ["Flea"], "author": "Zoltan999"}
{"word": ["Market."], "author": "gixgox"}
{"word": ["prices"], "author": "JDelekto"}
{"word": ["Cost."], "author": "Hickory"}
{"word": ["business"], "author": "JDelekto"}
{"word": ["Activity."], "author": "ShadowPatriarch"}
{"word": ["fluctuation"], "author": "JDelekto"}
{"word": ["Chaos."], "author": "ShadowPatriarch"}
{"word": ["Anarchy"], "author": "Yezemin"}
{"word": ["Violence."], "author": "Hickory"}
{"word": ["funding"], "author": "JDelekto"}
{"word": ["Stretch."], "author": "Hickory"}
{"word": ["budget"], "author": "JDelekto"}
{"word": ["organized"], "author": "GabesterOne"}
{"word": ["collective"], "author": "JDelekto"}
{"word": ["queensryche. =)"], "author": "Antimateria"}
{"word": ["disturbed"], "author": "JDelekto"}
{"word": ["mind"], "author": "BlackDawn"}
{"word": ["wind"], "author": "apehater"}
{"word": ["blows"], "author": "Zordu"}
{"word": ["gale"], "author": "Dzsono"}
{"word": ["."], "author": "gixgox"}
{"word": ["tsunami"], "author": "GabesterOne"}
{"word": ["Soup."], "author": "JamesGoblin"}
{"word": [" Wave."], "author": "Hickory"}
{"word": ["Seismic."], "author": "ShadowPatriarch"}
{"word": ["tectonic"], "author": "Dzsono"}
{"word": ["Plates"], "author": "McGuuffin"}
{"word": ["Dish"], "author": "park_84"}
{"word": ["washing"], "author": "Smogg"}
{"word": ["water"], "author": "Ritualisto"}
{"word": ["essential"], "author": "Ardal"}
{"word": ["Fundamental"], "author": "Yezemin"}
{"word": ["."], "author": "gixgox"}
{"word": ["Sherlock."], "author": "Ikarugamesh"}
{"word": ["misquote"], "author": "cose_vecchie"}
{"word": [], "author": "gixgox"}
{"word": ["Undeniably."], "author": "Hickory"}
{"word": ["deniable"], "author": "JDelekto"}
{"word": ["denial"], "author": "GabesterOne"}
{"word": ["truth"], "author": "JDelekto"}
{"word": ["universe"], "author": "Accatone"}
{"word": ["Parallel."], "author": "Hickory"}
{"word": ["lines"], "author": "Smogg"}
{"word": ["Dots. ", " <Oh those naughty ninjas....>"], "author": "gixgox"}
{"word": ["Universe"], "author": "Yezemin"}
{"word": [" Specks."], "author": "Hickory"}
{"word": ["Glasses"], "author": "TARFU"}
{"word": ["eye"], "author": "Ritualisto"}
{"word": ["witness"], "author": "le_chevalier"}
{"word": ["observe"], "author": "Hardrada"}
{"word": ["Testimony"], "author": "tort1234"}
{"word": ["Affidavit."], "author": "Hickory"}
{"word": ["evidence"], "author": "le_chevalier"}
{"word": ["methodology"], "author": "Dzsono"}
{"word": ["paradigm"], "author": "park_84"}
{"word": ["Archetype"], "author": "TARFU"}
{"word": ["Template."], "author": "xieliming"}
{"word": ["Boilerplate."], "author": "gixgox"}
{"word": ["Recyclable."], "author": "ShadowPatriarch"}
{"word": ["Plastic"], "author": "TARFU"}
{"word": ["fantastic"], "author": "Dzsono"}
{"word": ["Four."], "author": "gixgox"}
{"word": [], "author": "le_chevalier"}
{"word": ["."], "author": "Hickory"}
{"word": ["Hexakosioihexekontahexaphobia."], "author": "VampiroAlhazred"}
{"word": ["christianity"], "author": "Ardal"}
{"word": ["Catholics"], "author": "Yezemin"}
{"word": ["Xenophobia"], "author": "sanscript"}
{"word": ["racist (just like black lives matters)"], "author": "GabesterOne"}
{"word": [" Fallacy."], "author": "ShadowPatriarch"}
{"word": ["Politics."], "author": "Narcia_"}
{"word": ["Divided"], "author": "TDP"}
{"word": ["video"], "author": "Accatone"}
{"word": ["Tape"], "author": "Yezemin"}
{"word": [" Separated."], "author": "Hickory"}
{"word": ["Apart"], "author": "TARFU"}
{"word": ["away"], "author": "GabesterOne"}
{"word": ["Edit: Ninja'd ", " ", " Far"], "author": "Accatone"}
{"word": ["Kingdom"], "author": "truhlik"}
{"word": ["Realm."], "author": "Hickory"}
{"word": ["ruler"], "author": "Ardal"}
{"word": ["King."], "author": "xieliming"}
{"word": ["crab"], "author": "Smogg"}
{"word": ["Meat."], "author": "Hickory"}
{"word": ["Corpse."], "author": "REDVWIN"}
{"word": ["body"], "author": "RebelCurse"}
{"word": ["Parts."], "author": "gixgox"}
{"word": ["farts"], "author": "apehater"}
{"word": ["concealment"], "author": "Dzsono"}
{"word": ["illicit"], "author": "GabesterOne"}
{"word": ["Illegal"], "author": "TARFU"}
{"word": ["illegitimate"], "author": "le_chevalier"}
{"word": ["Criminal."], "author": "ShadowPatriarch"}
{"word": ["thugs ( like black lives matter)"], "author": "GabesterOne"}
{"word": ["Prison"], "author": "Azrael360"}
{"word": ["Cage"], "author": "Yezemin"}
{"word": ["Jail"], "author": "park_84"}
{"word": ["thrown"], "author": "Ardal"}
{"word": ["Throne."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": [], "author": "sanscript"}
{"word": ["Voyage."], "author": "ShadowPatriarch"}
{"word": ["Lights (a Journey song)"], "author": "GabesterOne"}
{"word": ["Shadows"], "author": "blakstar"}
{"word": ["Gloom"], "author": "Hardrada"}
{"word": ["Dark"], "author": "TDP"}
{"word": ["Abyss"], "author": "Zoltan999"}
{"word": ["Blue"], "author": "Yezemin"}
{"word": ["sky"], "author": "Accatone"}
{"word": ["Cloud"], "author": "Pickle1477"}
{"word": ["storage"], "author": "Ritualisto"}
{"word": ["Steerage."], "author": "GhostwriterDoF"}
{"word": ["----- ", " ", " deck"], "author": "sanscript"}
{"word": ["ship"], "author": "GabesterOne"}
{"word": ["Vessel."], "author": "REDVWIN"}
{"word": ["carrier"], "author": "Dzsono"}
{"word": ["Pigeon"], "author": "truhlik"}
{"word": ["Post."], "author": "Hickory"}
{"word": ["Forum"], "author": "cose_vecchie"}
{"word": ["Drama."], "author": "gixgox"}
{"word": ["Shakespeare"], "author": "TARFU"}
{"word": ["romeo"], "author": "BlackDawn"}
{"word": ["Juliette"], "author": "GabesterOne"}
{"word": ["Hurricane."], "author": "Hickory"}
{"word": ["Kick."], "author": "Narcia_"}
{"word": [" Typhoon. ", " ", " "], "author": "ShadowPatriarch"}
{"word": ["Tornado"], "author": "agentcarr16"}
{"word": ["weather"], "author": "Ardal"}
{"word": ["."], "author": "Hickory"}
{"word": ["air"], "author": "Ritualisto"}
{"word": ["gas ( stuff that comes out of my but every time i go to tacobell)"], "author": "GabesterOne"}
{"word": ["descriptive"], "author": "Dzsono"}
{"word": ["Informative"], "author": "Azrael360"}
{"word": ["."], "author": "Hickory"}
{"word": ["Overcharge."], "author": "xieliming"}
{"word": ["Overprice."], "author": "gixgox"}
{"word": ["overrated"], "author": "le_chevalier"}
{"word": ["Oversell. ", " ", " ", " "], "author": "ShadowPatriarch"}
{"word": ["Overeager."], "author": "gixgox"}
{"word": ["Zealous"], "author": "TARFU"}
{"word": ["Fanatic"], "author": "Yezemin"}
{"word": ["Fundamentalist"], "author": "JDelekto"}
{"word": ["mindset"], "author": "Ardal"}
{"word": ["Open."], "author": "Narcia_"}
{"word": ["."], "author": "gixgox"}
{"word": ["Highborn"], "author": "agentcarr16"}
{"word": ["Entitled."], "author": "Hickory"}
{"word": ["deserving"], "author": "Dzsono"}
{"word": ["Worthy"], "author": "TARFU"}
{"word": ["Successor."], "author": "Hickory"}
{"word": ["Heir"], "author": "Yezemin"}
{"word": ["Herr"], "author": "truhlik"}
{"word": ["Title."], "author": "Hickory"}
{"word": ["Designation"], "author": "TARFU"}
{"word": ["Label"], "author": "koima57"}
{"word": ["Staple"], "author": "agentcarr16"}
{"word": ["Role."], "author": "REDVWIN"}
{"word": ["Play."], "author": "gixgox"}
{"word": ["station"], "author": "apehater"}
{"word": ["train"], "author": "Smogg"}
{"word": ["steam ", " ", " [sorry for edit, firstly I've added station, but that was one before the train :-)]"], "author": "motorkar"}
{"word": ["locomotive"], "author": "sluniq"}
{"word": [], "author": "gixgox"}
{"word": ["Movement"], "author": "TARFU"}
{"word": ["Speed."], "author": "xieliming"}
{"word": ["Velocity"], "author": "blakstar"}
{"word": ["Acceleration"], "author": "TARFU"}
{"word": ["Momentum."], "author": "Hickory"}
{"word": ["unstoppable"], "author": "GabesterOne"}
{"word": ["unbreakable"], "author": "le_chevalier"}
{"word": ["Inevitable."], "author": "ShadowPatriarch"}
{"word": ["Unavoidable."], "author": "LoboBlanco"}
{"word": ["destiny"], "author": "Zordu"}
{"word": ["Fate"], "author": "TARFU"}
{"word": ["Bungie"], "author": "VampiroAlhazred"}
{"word": ["Elastic"], "author": "Dzsono"}
{"word": ["Rubber"], "author": "TARFU"}
{"word": ["eraser"], "author": "le_chevalier"}
{"word": ["Head"], "author": "Yezemin"}
{"word": ["Tail"], "author": "park_84"}
{"word": ["animal"], "author": "Ritualisto"}
{"word": ["Primal"], "author": "Dzsono"}
{"word": ["rage"], "author": "Ardal"}
{"word": [], "author": "blakstar"}
{"word": ["Gun"], "author": "JDelekto"}
{"word": ["weapon"], "author": "Dzsono"}
{"word": ["Lethal"], "author": "Zoltan999"}
{"word": ["dangerous"], "author": "GabesterOne"}
{"word": ["Fearsome."], "author": "Narcia_"}
{"word": ["Imposing."], "author": "REDVWIN"}
{"word": ["Daunting."], "author": "GhostwriterDoF"}
{"word": ["bold (like donald trump running for president)"], "author": "GabesterOne"}
{"word": ["old"], "author": "apehater"}
{"word": ["Rolled."], "author": "Hickory"}
{"word": ["Spun"], "author": "TARFU"}
{"word": ["Twisted"], "author": "agentcarr16"}
{"word": ["ending"], "author": "Ardal"}
{"word": ["Drydrowning"], "author": "sanscript"}
{"word": [" yikes"], "author": "ashwald"}
{"word": [" Conclusion."], "author": "Hickory"}
{"word": ["final"], "author": "Smogg"}
{"word": ["."], "author": "gixgox"}
{"word": ["Gaffer."], "author": "Hickory"}
{"word": ["television"], "author": "GabesterOne"}
{"word": ["stream"], "author": "Dzsono"}
{"word": ["River"], "author": "TARFU"}
{"word": ["elves"], "author": "GabesterOne"}
{"word": ["Wood."], "author": "xieliming"}
{"word": ["logs"], "author": "GabesterOne"}
{"word": ["Error."], "author": "ShadowPatriarch"}
{"word": ["Mistake"], "author": "Yezemin"}
{"word": ["Glitch"], "author": "park_84"}
{"word": ["exploit"], "author": "le_chevalier"}
{"word": ["Advantage."], "author": "Hickory"}
{"word": ["perk"], "author": "le_chevalier"}
{"word": ["disadvantage"], "author": "Ritualisto"}
{"word": ["drawback"], "author": "VampiroAlhazred"}
{"word": ["problem"], "author": "JDelekto"}
{"word": ["Issue"], "author": "truhlik"}
{"word": ["Technical"], "author": "Zoltan999"}
{"word": ["Machine."], "author": "Narcia_"}
{"word": ["."], "author": "gixgox"}
{"word": ["HATE (because i am AM!)"], "author": "GabesterOne"}
{"word": ["apathy"], "author": "Dzsono"}
{"word": ["Empathy"], "author": "agentcarr16"}
{"word": ["Vicarious."], "author": "Hickory"}
{"word": ["Empathetic."], "author": "ShadowPatriarch"}
{"word": ["Sympathetic"], "author": "TARFU"}
{"word": ["ear"], "author": "Dzsono"}
{"word": ["balance"], "author": "Ardal"}
{"word": ["Vertigo."], "author": "Hickory"}
{"word": ["Hitchcock"], "author": "TARFU"}
{"word": ["Birds"], "author": "cose_vecchie"}
{"word": ["Wings."], "author": "REDVWIN"}
{"word": ["chicken"], "author": "XYCat"}
{"word": ["Fried"], "author": "TARFU"}
{"word": ["Unhealthy"], "author": "Azrael360"}
{"word": ["Cholesterol."], "author": "Hickory"}
{"word": ["delicious"], "author": "le_chevalier"}
{"word": ["Edible"], "author": "TARFU"}
{"word": ["Consume."], "author": "xieliming"}
{"word": ["become"], "author": "JDelekto"}
{"word": ["breakfast"], "author": "McGuuffin"}
{"word": ["Bacon"], "author": "TARFU"}
{"word": ["eggs"], "author": "JDelekto"}
{"word": ["Salt"], "author": "Antimateria"}
{"word": ["Sugar"], "author": "park_84"}
{"word": ["sauce"], "author": "le_chevalier"}
{"word": ["Hot"], "author": "TARFU"}
{"word": ["chocolate"], "author": "Smogg"}
{"word": ["sweet"], "author": "Ritualisto"}
{"word": [], "author": "gixgox"}
{"word": ["apparitions"], "author": "Dzsono"}
{"word": ["Mirage."], "author": "Hickory"}
{"word": ["oasis"], "author": "Ardal"}
{"word": ["Water"], "author": "Antimateria"}
{"word": [], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["gangster"], "author": "Smogg"}
{"word": ["Mob."], "author": "Narcia_"}
{"word": ["mop"], "author": "Accatone"}
{"word": ["Sewer."], "author": "Antimateria"}
{"word": ["Rats"], "author": "Yezemin"}
{"word": ["Dungeon."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": [" Prison."], "author": "ShadowPatriarch"}
{"word": ["planet"], "author": "Smogg"}
{"word": ["Orbit"], "author": "Yezemin"}
{"word": ["Electron."], "author": "REDVWIN"}
{"word": ["tron"], "author": "Accatone"}
{"word": [" Microscope."], "author": "Hickory"}
{"word": ["small"], "author": "Ritualisto"}
{"word": ["Tiny"], "author": "TARFU"}
{"word": ["Miniscule"], "author": "Yezemin"}
{"word": ["Microscopic"], "author": "SamMagel"}
{"word": [], "author": "REDVWIN"}
{"word": ["Molecular."], "author": "Hickory"}
{"word": ["nanorobotics"], "author": "Smogg"}
{"word": ["mitochondria"], "author": "Dzsono"}
{"word": ["Energy."], "author": "Hickory"}
{"word": ["Electricity"], "author": "TARFU"}
{"word": ["outage"], "author": "Ardal"}
{"word": ["Disruption."], "author": "Hickory"}
{"word": ["Ion."], "author": "LoboBlanco"}
{"word": ["Cannon."], "author": "Hickory"}
{"word": ["Ball"], "author": "blakstar"}
{"word": ["Medicine."], "author": "ShadowPatriarch"}
{"word": ["Cure"], "author": "TARFU"}
{"word": ["elixir"], "author": "le_chevalier"}
{"word": ["Potion."], "author": "xieliming"}
{"word": ["Cauldron"], "author": "park_84"}
{"word": ["Kettle"], "author": "TARFU"}
{"word": ["Pot."], "author": "gixgox"}
{"word": ["black"], "author": "Dzsono"}
{"word": ["Inky"], "author": "TARFU"}
{"word": ["tar"], "author": "JDelekto"}
{"word": ["."], "author": "gixgox"}
{"word": ["weight"], "author": "Ardal"}
{"word": ["dead"], "author": "ashwald"}
{"word": ["Ringer."], "author": "Narcia_"}
{"word": ["Bell."], "author": "Hickory"}
{"word": ["foundry"], "author": "le_chevalier"}
{"word": ["industrial"], "author": "JDelekto"}
{"word": ["revolution"], "author": "agentcarr16"}
{"word": ["elliptic"], "author": "JDelekto"}
{"word": ["Orbit."], "author": "Hickory"}
{"word": ["planetary"], "author": "JDelekto"}
{"word": ["satellite"], "author": "Dzsono"}
{"word": ["weather"], "author": "Smogg"}
{"word": ["environment"], "author": "JDelekto"}
{"word": ["Ecosystem."], "author": "REDVWIN"}
{"word": ["Biodome."], "author": "LoboBlanco"}
{"word": ["movie"], "author": "GabesterOne"}
{"word": ["Franchise."], "author": "Hickory"}
{"word": ["MacDonalds."], "author": "JDelekto"}
{"word": ["Garbage."], "author": "Hickory"}
{"word": ["collector"], "author": "truhlik"}
{"word": ["Connoisseur"], "author": "TARFU"}
{"word": ["Buff."], "author": "Hickory"}
{"word": ["enthusiast"], "author": "Dzsono"}
{"word": ["hoarder"], "author": "JDelekto"}
{"word": ["Squirrel"], "author": "blakstar"}
{"word": ["Furry"], "author": "gixgox"}
{"word": ["toes"], "author": "JDelekto"}
{"word": ["foot (some one make a tmnt reference for the next post :D )"], "author": "GabesterOne"}
{"word": ["clan"], "author": "JDelekto"}
{"word": ["family"], "author": "Hardrada"}
{"word": ["Album. ", " ", " (Sorry, JD, I got ninja'd and edited. :D )"], "author": "Hickory"}
{"word": ["feud"], "author": "JDelekto"}
{"word": ["conflict"], "author": "GabesterOne"}
{"word": ["clash"], "author": "JDelekto"}
{"word": ["collision"], "author": "Dzsono"}
{"word": ["Repair"], "author": "coryrj1995"}
{"word": ["Fix"], "author": "TARFU"}
{"word": ["renew"], "author": "GabesterOne"}
{"word": ["Remake."], "author": "VampiroAlhazred"}
{"word": ["Reboot"], "author": "Yezemin"}
{"word": ["restart"], "author": "le_chevalier"}
{"word": ["Reset"], "author": "park_84"}
{"word": ["new"], "author": "Ritualisto"}
{"word": ["refreshed"], "author": "Dzsono"}
{"word": ["Lifted."], "author": "gixgox"}
{"word": ["Hoisted."], "author": "Hickory"}
{"word": ["physics"], "author": "sanscript"}
{"word": ["Science"], "author": "Yezemin"}
{"word": ["Fiction."], "author": "Hickory"}
{"word": ["Fact."], "author": "Narcia_"}
{"word": ["Subjective."], "author": "Hickory"}
{"word": ["opinionated"], "author": "GabesterOne"}
{"word": ["ambivalent"], "author": "Dzsono"}
{"word": ["Lackadaisical"], "author": "TARFU"}
{"word": ["Nonchalant."], "author": "Hickory"}
{"word": ["Carefree"], "author": "Zoltan999"}
{"word": ["Relaxed."], "author": "ShadowPatriarch"}
{"word": ["Hypnagogia"], "author": "sanscript"}
{"word": ["Hallucination."], "author": "Hickory"}
{"word": ["Delirium"], "author": "TARFU"}
{"word": ["Mesmeric."], "author": "REDVWIN"}
{"word": ["Trance."], "author": "Hickory"}
{"word": ["Shenanigans."], "author": "Lin545"}
{"word": ["Hijinks"], "author": "TARFU"}
{"word": ["Mischief."], "author": "Hickory"}
{"word": ["night"], "author": "GabesterOne"}
{"word": ["Owl"], "author": "TARFU"}
{"word": ["Predator."], "author": "xieliming"}
{"word": ["stalk"], "author": "Dzsono"}
{"word": ["Beanstalk"], "author": "TDP"}
{"word": ["eat"], "author": "kmonster"}
{"word": ["devour"], "author": "le_chevalier"}
{"word": ["Consume."], "author": "Hickory"}
{"word": ["Ingest"], "author": "TARFU"}
{"word": ["absorb"], "author": "codyaj1995"}
{"word": ["devour"], "author": "motorkar"}
{"word": ["Again"], "author": "park_84"}
{"word": ["repetition"], "author": "Smogg"}
{"word": ["Iteration."], "author": "Hickory"}
{"word": ["replay"], "author": "Ritualisto"}
{"word": ["Value"], "author": "Yezemin"}
{"word": ["market"], "author": "Dzsono"}
{"word": ["Stall."], "author": "Hickory"}
{"word": ["Jukebox"], "author": "devjock"}
{"word": ["bar (since those are the only places that I see jukeboxes these days)"], "author": "GabesterOne"}
{"word": ["Gold"], "author": "Zoltan999"}
{"word": ["Finch."], "author": "Narcia_"}
{"word": ["Seed."], "author": "Hickory"}
{"word": ["Pod"], "author": "Yezemin"}
{"word": ["Container"], "author": "hurvl"}
{"word": ["."], "author": "gixgox"}
{"word": ["kick"], "author": "Ardal"}
{"word": [], "author": "Azrael360"}
{"word": ["Sinking"], "author": "TARFU"}
{"word": ["Ship."], "author": "ShadowPatriarch"}
{"word": ["Sea."], "author": "REDVWIN"}
{"word": ["Salt"], "author": "Hardrada"}
{"word": ["Pepper"], "author": "Yezemin"}
{"word": ["Spicy"], "author": "TARFU"}
{"word": ["city (spicy city :) )"], "author": "GabesterOne"}
{"word": ["mayor"], "author": "GabesterOne"}
{"word": ["Leader."], "author": "coryrj1995"}
{"word": ["voting"], "author": "Ritualisto"}
{"word": ["Choice."], "author": "Hickory"}
{"word": ["Decision"], "author": "agentcarr16"}
{"word": ["Tree."], "author": "xieliming"}
{"word": ["Binary"], "author": "blakstar"}
{"word": ["hexadecimal"], "author": "Dzsono"}
{"word": ["alphanumeric"], "author": "le_chevalier"}
{"word": ["Keypad"], "author": "TARFU"}
{"word": ["Numeric."], "author": "Hickory"}
{"word": ["Numbers"], "author": "Yezemin"}
{"word": ["Cardinal"], "author": "park_84"}
{"word": ["college"], "author": "le_chevalier"}
{"word": ["Campus."], "author": "Hickory"}
{"word": ["grounds"], "author": "Dzsono"}
{"word": ["Fields."], "author": "ShadowPatriarch"}
{"word": ["Hedgerows."], "author": "Hickory"}
{"word": ["bocage"], "author": "le_chevalier"}
{"word": [" Villers?"], "author": "ashwald"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Sconces."], "author": "Narcia_"}
{"word": ["palisade"], "author": "Ardal"}
{"word": ["wall (TRUMP 2016!)"], "author": "GabesterOne"}
{"word": ["Brick."], "author": "Hickory"}
{"word": ["Block"], "author": "agentcarr16"}
{"word": ["Buster."], "author": "gixgox"}
{"word": ["Bunker"], "author": "Pickle1477"}
{"word": ["trenches"], "author": "GabesterOne"}
{"word": ["Cover."], "author": "REDVWIN"}
{"word": ["Girl"], "author": "cose_vecchie"}
{"word": ["Female"], "author": "Yezemin"}
{"word": ["feminist"], "author": "GabesterOne"}
{"word": ["Rights"], "author": "agentcarr16"}
{"word": ["Fallacy."], "author": "Hickory"}
{"word": ["error"], "author": "Ritualisto"}
{"word": ["Mistake"], "author": "Azrael360"}
{"word": ["."], "author": "Hickory"}
{"word": ["Embarrassment."], "author": "xieliming"}
{"word": ["humiliation"], "author": "GabesterOne"}
{"word": ["failure"], "author": "Dzsono"}
{"word": ["Epic"], "author": "SpellSword"}
{"word": [" Defeat."], "author": "Hickory"}
{"word": ["conquered! (like bernie sanders in the ny primaries!)"], "author": "GabesterOne"}
{"word": ["Command."], "author": "xieliming"}
{"word": ["Order."], "author": "Hickory"}
{"word": ["silence"], "author": "le_chevalier"}
{"word": ["peacefulness"], "author": "GabesterOne"}
{"word": ["sleepiness"], "author": "le_chevalier"}
{"word": ["Narcolepsy"], "author": "Yezemin"}
{"word": ["Sheep"], "author": "park_84"}
{"word": ["wool"], "author": "Smogg"}
{"word": ["Fabric"], "author": "Zoltan999"}
{"word": ["time"], "author": "Ardal"}
{"word": ["wormhole"], "author": "Dzsono"}
{"word": ["travel"], "author": "GabesterOne"}
{"word": ["Explore."], "author": "Narcia_"}
{"word": ["Investigate."], "author": "REDVWIN"}
{"word": ["Scrutinise."], "author": "Hickory"}
{"word": ["criticize"], "author": "GabesterOne"}
{"word": ["negative"], "author": "hurvl"}
{"word": ["Pessimistic"], "author": "TARFU"}
{"word": ["Depressed."], "author": "ShadowPatriarch"}
{"word": ["Sad (\u2013_\u2013)"], "author": "Azrael360"}
{"word": ["Morose."], "author": "Hickory"}
{"word": ["Melancholy"], "author": "TARFU"}
{"word": ["loneliness"], "author": "Ardal"}
{"word": ["forsaken"], "author": "GabesterOne"}
{"word": ["Gods"], "author": "truhlik"}
{"word": ["Irrelevant."], "author": "Hickory"}
{"word": ["Useless"], "author": "koima57"}
{"word": ["Obsolete"], "author": "TARFU"}
{"word": ["absolute"], "author": "Accatone"}
{"word": ["value"], "author": "GabesterOne"}
{"word": ["Proposition"], "author": "Dzsono"}
{"word": ["Suggestion"], "author": "agentcarr16"}
{"word": ["Hypnosis"], "author": "blakstar"}
{"word": ["Trance"], "author": "TARFU"}
{"word": ["Music."], "author": "Hickory"}
{"word": ["man (love the music man :) )"], "author": "GabesterOne"}
{"word": ["machine"], "author": "le_chevalier"}
{"word": ["mechanism"], "author": "TARFU"}
{"word": ["Apparatus"], "author": "Yezemin"}
{"word": ["Goldberg"], "author": "park_84"}
{"word": [], "author": "cose_vecchie"}
{"word": ["."], "author": "Hickory"}
{"word": ["link"], "author": "Ritualisto"}
{"word": ["Passage"], "author": "Dzsono"}
{"word": ["alcove"], "author": "JDelekto"}
{"word": ["Hidden."], "author": "xieliming"}
{"word": ["Obscured"], "author": "Yezemin"}
{"word": ["forgotten"], "author": "GabesterOne"}
{"word": ["Past"], "author": "TDP"}
{"word": ["Passed."], "author": "Hickory"}
{"word": ["Away."], "author": "Narcia_"}
{"word": ["cast"], "author": "Ardal"}
{"word": ["production"], "author": "GabesterOne"}
{"word": ["Merchandise."], "author": "Hickory"}
{"word": ["Supply."], "author": "REDVWIN"}
{"word": ["quantity"], "author": "Accatone"}
{"word": ["lot"], "author": "apehater"}
{"word": ["Auction."], "author": "Hickory"}
{"word": ["Bargain"], "author": "TARFU"}
{"word": ["Sale."], "author": "Ikarugamesh"}
{"word": ["Discount"], "author": "Yezemin"}
{"word": ["Bid"], "author": "Rick_Sirocco"}
{"word": ["Offer"], "author": "TARFU"}
{"word": [], "author": "LesterKnight99"}
{"word": ["RUBBISH! :-P"], "author": "blakstar"}
{"word": ["Garbage"], "author": "TARFU"}
{"word": ["RARE! :)"], "author": "Rick_Sirocco"}
{"word": ["WARE!"], "author": "GabesterOne"}
{"word": ["."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["sect"], "author": "DrakoPensulo"}
{"word": ["Orthodox"], "author": "Dzsono"}
{"word": ["Greek"], "author": "TARFU"}
{"word": ["Sparta"], "author": "GabesterOne"}
{"word": ["City-state."], "author": "Hickory"}
{"word": ["agoge ", " ", " *ninja'd * ", " ", " independent"], "author": "le_chevalier"}
{"word": ["Unhindered"], "author": "TARFU"}
{"word": ["Unfettered."], "author": "Hickory"}
{"word": ["Free."], "author": "ShadowPatriarch"}
{"word": ["gratis"], "author": "park_84"}
{"word": ["zero"], "author": "Ritualisto"}
{"word": ["Hour."], "author": "Hickory"}
{"word": ["Happy"], "author": "Decatonkeil"}
{"word": ["birthday"], "author": "Ardal"}
{"word": ["Cake. "], "author": "gixgox"}
{"word": ["Icing."], "author": "Hickory"}
{"word": ["Mint"], "author": "agentcarr16"}
{"word": ["Tea."], "author": "Narcia_"}
{"word": ["pepper :)"], "author": "GabesterOne"}
{"word": [], "author": "gixgox"}
{"word": ["Slaughter :D"], "author": "GabesterOne"}
{"word": ["Massacre"], "author": "Zoltan999"}
{"word": ["Decimate."], "author": "Hickory"}
{"word": ["Deplete."], "author": "gixgox"}
{"word": ["Empty"], "author": "BenKii"}
{"word": ["Vacuous."], "author": "REDVWIN"}
{"word": ["Airhead"], "author": "Dzsono"}
{"word": ["California."], "author": "Hickory"}
{"word": ["Smog"], "author": "TARFU"}
{"word": ["Pollution."], "author": "Ikarugamesh"}
{"word": ["New Jersey"], "author": "TARFU"}
{"word": ["State"], "author": "DrakoPensulo"}
{"word": ["Mind."], "author": "xieliming"}
{"word": ["Suspicious"], "author": "le_chevalier"}
{"word": ["Wary"], "author": "TARFU"}
{"word": ["hesitant"], "author": "Dzsono"}
{"word": ["nervous"], "author": "GabesterOne"}
{"word": ["Anxious"], "author": "park_84"}
{"word": ["Vallium"], "author": "Tamamba"}
{"word": ["Medication"], "author": "TARFU"}
{"word": ["Treatment."], "author": "ShadowPatriarch"}
{"word": ["cure"], "author": "Ritualisto"}
{"word": ["Remedy."], "author": "Hickory"}
{"word": ["intervention"], "author": "Dzsono"}
{"word": ["divine"], "author": "Ardal"}
{"word": ["Mundane."], "author": "Hickory"}
{"word": ["Boring"], "author": "Zoltan999"}
{"word": ["Bland"], "author": "TDP"}
{"word": ["taste"], "author": "Ardal"}
{"word": ["Flavour."], "author": "Hickory"}
{"word": ["spices"], "author": "JDelekto"}
{"word": ["Arrakis"], "author": "Solei"}
{"word": ["sand"], "author": "Smogg"}
{"word": ["Dirt."], "author": "Ikarugamesh"}
{"word": ["mud"], "author": "Dzsono"}
{"word": ["pies"], "author": "JDelekto"}
{"word": ["Pastries."], "author": "Narcia_"}
{"word": ["kitchen"], "author": "JDelekto"}
{"word": ["Sink."], "author": "Hickory"}
{"word": ["swim"], "author": "le_chevalier"}
{"word": ["Float"], "author": "Tamamba"}
{"word": ["Caoutchouc."], "author": "REDVWIN"}
{"word": [" Levitate."], "author": "Hickory"}
{"word": ["spell"], "author": "GabesterOne"}
{"word": ["onomatopoeia"], "author": "JDelekto"}
{"word": [" Interlude."], "author": "Hickory"}
{"word": [" "], "author": "REDVWIN"}
{"word": ["Music"], "author": "TARFU"}
{"word": ["Notes"], "author": "agentcarr16"}
{"word": ["Partition"], "author": "koima57"}
{"word": [], "author": "truhlik"}
{"word": ["software"], "author": "JDelekto"}
{"word": ["Program."], "author": "xieliming"}
{"word": ["Code."], "author": "Hickory"}
{"word": ["breaker"], "author": "Cavenagh"}
{"word": ["Circuit"], "author": "blakstar"}
{"word": ["Board."], "author": "Hickory"}
{"word": ["Bored"], "author": "agentcarr16"}
{"word": ["Chopping."], "author": "Narcia_"}
{"word": ["fell"], "author": "Dzsono"}
{"word": ["fall"], "author": "DrakoPensulo"}
{"word": [" chopped (like the tree fell after being chopped down)"], "author": "GabesterOne"}
{"word": [], "author": "gixgox"}
{"word": ["cave"], "author": "le_chevalier"}
{"word": ["Darkness"], "author": "TARFU"}
{"word": ["Eternal"], "author": "VampiroAlhazred"}
{"word": ["Endless"], "author": "Yezemin"}
{"word": ["expanse"], "author": "Dzsono"}
{"word": ["Space."], "author": "xieliming"}
{"word": ["Oddity"], "author": "park_84"}
{"word": ["singularity"], "author": "Ritualisto"}
{"word": ["density"], "author": "Smogg"}
{"word": ["specific"], "author": "Ardal"}
{"word": ["Gravity."], "author": "Hickory"}
{"word": ["falls"], "author": "GabesterOne"}
{"word": ["Cascade"], "author": "Yezemin"}
{"word": ["Gush."], "author": "Hickory"}
{"word": ["Geyser"], "author": "Zoltan999"}
{"word": ["Pressure."], "author": "Narcia_"}
{"word": [], "author": "gixgox"}
{"word": ["epic"], "author": "Dzsono"}
{"word": ["fail"], "author": "cose_vecchie"}
{"word": ["Unsuccessful"], "author": "TARFU"}
{"word": ["Attempt."], "author": "Hickory"}
{"word": ["trying"], "author": "GabesterOne"}
{"word": ["Striving"], "author": "TARFU"}
{"word": ["aim"], "author": "Ardal"}
{"word": ["Bot."], "author": "xieliming"}
{"word": ["Pot"], "author": "doctorsinister"}
{"word": ["Weed..."], "author": "Azrael360"}
{"word": ["Grass."], "author": "gixgox"}
{"word": ["Green"], "author": "blakstar"}
{"word": ["rookie"], "author": "Dzsono"}
{"word": ["Debutant."], "author": "REDVWIN"}
{"word": ["Novice."], "author": "ShadowPatriarch"}
{"word": ["Initiate"], "author": "TARFU"}
{"word": ["Padawan."], "author": "REDVWIN"}
{"word": ["Jedi"], "author": "Yezemin"}
{"word": ["Force"], "author": "park_84"}
{"word": ["Pry"], "author": "Tamamba"}
{"word": ["sniff"], "author": "Ritualisto"}
{"word": [" Lever."], "author": "Hickory"}
{"word": ["machine"], "author": "Smogg"}
{"word": [], "author": "Zoltan999"}
{"word": ["cult"], "author": "GabesterOne"}
{"word": ["indoctrination"], "author": "Dzsono"}
{"word": ["Brainwash."], "author": "Hickory"}
{"word": ["Mouthwash."], "author": "agentcarr16"}
{"word": ["clean"], "author": "GabesterOne"}
{"word": ["sterile"], "author": "BenKii"}
{"word": ["Aseptic."], "author": "Hickory"}
{"word": ["germaphobe"], "author": "GabesterOne"}
{"word": ["Hypochondriac"], "author": "TARFU"}
{"word": ["Nincompoop."], "author": "Hickory"}
{"word": ["weirdo"], "author": "Ardal"}
{"word": ["Special."], "author": "xieliming"}
{"word": ["Sundae."], "author": "Narcia_"}
{"word": ["Fudge"], "author": "TARFU"}
{"word": ["Bungle."], "author": "Hickory"}
{"word": ["Err"], "author": "Dzsono"}
{"word": ["human"], "author": "le_chevalier"}
{"word": ["Community."], "author": "Casval_Deikun"}
{"word": ["College"], "author": "Yezemin"}
{"word": ["University"], "author": "park_84"}
{"word": ["degree"], "author": "GabesterOne"}
{"word": ["end"], "author": "Ritualisto"}
{"word": ["finish"], "author": "Ardal"}
{"word": ["Him!"], "author": "Chandoraa"}
{"word": ["He."], "author": "Hickory"}
{"word": [" dead."], "author": "gixgox"}
{"word": ["expired"], "author": "Dzsono"}
{"word": ["Deceased"], "author": "Zoltan999"}
{"word": ["Resuscitated."], "author": "Narcia_"}
{"word": ["Rescued"], "author": "agentcarr16"}
{"word": ["Liberated."], "author": "Hickory"}
{"word": ["Unburdened."], "author": "gixgox"}
{"word": ["Free"], "author": "Pickle1477"}
{"word": ["boundless"], "author": "GabesterOne"}
{"word": ["Endless"], "author": "TARFU"}
{"word": ["eternity"], "author": "BlackDawn"}
{"word": ["Forever"], "author": "Yezemin"}
{"word": ["Batman"], "author": "truhlik"}
{"word": ["Comic."], "author": "Hickory"}
{"word": ["superhero"], "author": "Smogg"}
{"word": ["valiant"], "author": "GabesterOne"}
{"word": ["\u2026Hearts."], "author": "Casval_Deikun"}
{"word": ["Love"], "author": "Azrael360"}
{"word": ["Hate"], "author": "Hardrada"}
{"word": ["despair"], "author": "GabesterOne"}
{"word": ["hopelessness"], "author": "Ardal"}
{"word": ["Fear."], "author": "xieliming"}
{"word": ["Dread."], "author": "Hickory"}
{"word": ["judge"], "author": "GabesterOne"}
{"word": ["Jury"], "author": "blakstar"}
{"word": ["executioner"], "author": "Dzsono"}
{"word": ["excalibur"], "author": "kmonster"}
{"word": ["Arthur."], "author": "gixgox"}
{"word": ["Knight"], "author": "TARFU"}
{"word": ["Chivalry."], "author": "REDVWIN"}
{"word": ["Morals"], "author": "LesterKnight99"}
{"word": ["right"], "author": "GabesterOne"}
{"word": ["Left"], "author": "coryrj1995"}
{"word": ["port"], "author": "le_chevalier"}
{"word": ["Harbour"], "author": "Yezemin"}
{"word": ["Dock"], "author": "park_84"}
{"word": ["Park"], "author": "LesterKnight99"}
{"word": ["green"], "author": "Ritualisto"}
{"word": ["plants"], "author": "LesterKnight99"}
{"word": ["Flora."], "author": "ShadowPatriarch"}
{"word": ["allergies"], "author": "Emob78"}
{"word": ["Desensitisation."], "author": "gixgox"}
{"word": ["medical"], "author": "Ardal"}
{"word": ["Emergency."], "author": "Hickory"}
{"word": ["Urgent"], "author": "Zoltan999"}
{"word": ["Immediate."], "author": "Narcia_"}
{"word": ["Soon."], "author": "Allinstein"}
{"word": ["Quick"], "author": "coryrj1995"}
{"word": ["silver"], "author": "Dzsono"}
{"word": ["Lining."], "author": "Hickory"}
{"word": ["Coat"], "author": "TARFU"}
{"word": ["Sugar"], "author": "koima57"}
{"word": ["Sweet"], "author": "blakstar"}
{"word": ["Sour."], "author": "Hickory"}
{"word": ["Cream."], "author": "ShadowPatriarch"}
{"word": ["ointment"], "author": "LesterKnight99"}
{"word": ["Unction."], "author": "gixgox"}
{"word": ["Unguent."], "author": "Hickory"}
{"word": ["salve"], "author": "Ardal"}
{"word": [], "author": "gixgox"}
{"word": ["Rex."], "author": "Hickory"}
{"word": ["King"], "author": "TARFU"}
{"word": ["overlord"], "author": "Dzsono"}
{"word": ["Farm."], "author": "xieliming"}
{"word": ["state"], "author": "DrakoPensulo"}
{"word": ["Condition"], "author": "TARFU"}
{"word": ["term"], "author": "le_chevalier"}
{"word": ["Specification."], "author": "REDVWIN"}
{"word": ["Technical"], "author": "Azrael360"}
{"word": ["Cogs"], "author": "park_84"}
{"word": ["Spanner"], "author": "Solei"}
{"word": ["key"], "author": "Ritualisto"}
{"word": ["Lock"], "author": "Yezemin"}
{"word": ["radar"], "author": "le_chevalier"}
{"word": ["."], "author": "Chandoraa"}
{"word": ["kindness"], "author": "Ardal"}
{"word": ["Amity."], "author": "Hickory"}
{"word": ["Friendship."], "author": "Narcia_"}
{"word": ["Fellowship"], "author": "Zoltan999"}
{"word": ["Camaraderie."], "author": "Hickory"}
{"word": ["Comradeship."], "author": "gixgox"}
{"word": ["togetherness"], "author": "Dzsono"}
{"word": ["Friendship."], "author": "Casval_Deikun"}
{"word": ["Rivalry"], "author": "RagnarokDay"}
{"word": ["Enmity."], "author": "Hickory"}
{"word": ["entity"], "author": "apehater"}
{"word": [" Antipathy."], "author": "ShadowPatriarch"}
{"word": ["Hostility"], "author": "TARFU"}
{"word": ["Contention."], "author": "Hickory"}
{"word": ["dispute"], "author": "Ardal"}
{"word": ["Argument"], "author": "Yezemin"}
{"word": ["Catfight."], "author": "gixgox"}
{"word": ["Dogfight."], "author": "LoboBlanco"}
{"word": ["Combat"], "author": "blakstar"}
{"word": ["Patrol."], "author": "Hickory"}
{"word": ["ambush"], "author": "Dzsono"}
{"word": ["Surveil."], "author": "REDVWIN"}
{"word": ["Reconnoiter"], "author": "TARFU"}
{"word": ["scouting"], "author": "GabesterOne"}
{"word": ["Boy"], "author": "park_84"}
{"word": ["girl"], "author": "Ritualisto"}
{"word": ["Female"], "author": "TARFU"}
{"word": ["Gender."], "author": "ShadowPatriarch"}
{"word": ["Neutral."], "author": "gixgox"}
{"word": ["Biased."], "author": "Hickory"}
{"word": ["Prejudiced"], "author": "Yezemin"}
{"word": ["juiced"], "author": "JDelekto"}
{"word": ["steroids ", " ", " Edit: ninja'd"], "author": "Dzsono"}
{"word": ["Muscles."], "author": "xieliming"}
{"word": ["Weights."], "author": "Narcia_"}
{"word": ["Scale"], "author": "PaterAlf"}
{"word": ["law"], "author": "GabesterOne"}
{"word": ["order"], "author": "gixgox"}
{"word": ["Command."], "author": "Hickory"}
{"word": ["Conquer."], "author": "REDVWIN"}
{"word": ["Subdue."], "author": "Hickory"}
{"word": ["backlash"], "author": "JDelekto"}
{"word": [], "author": "Casval_Deikun"}
{"word": ["cowgirl"], "author": "apehater"}
{"word": ["frogman"], "author": "JDelekto"}
{"word": ["Spiderwoman."], "author": "gixgox"}
{"word": ["Tomboy."], "author": "Hickory"}
{"word": ["Jo March."], "author": "semigroups"}
{"word": ["Incorrect."], "author": "Hickory"}
{"word": ["False."], "author": "xieliming"}
{"word": [], "author": "gixgox"}
{"word": ["Mistake"], "author": "Habanerose"}
{"word": ["made"], "author": "Ardal"}
{"word": ["Crafted"], "author": "TDP"}
{"word": ["devised"], "author": "le_chevalier"}
{"word": ["planned"], "author": "LesterKnight99"}
{"word": ["objective"], "author": "GabesterOne"}
{"word": ["aim"], "author": "Dzsono"}
{"word": ["Target."], "author": "Casval_Deikun"}
{"word": [], "author": "LesterKnight99"}
{"word": ["Hell"], "author": "TARFU"}
{"word": [" Goal."], "author": "Hickory"}
{"word": [" Rufus"], "author": "LesterKnight99"}
{"word": ["Ruffle"], "author": "park_84"}
{"word": ["Snuggle."], "author": "Casval_Deikun"}
{"word": ["cuddle"], "author": "Ritualisto"}
{"word": ["embrace"], "author": "Dzsono"}
{"word": ["Hug"], "author": "Yezemin"}
{"word": ["Kiss"], "author": "agentcarr16"}
{"word": [], "author": "gixgox"}
{"word": ["Life"], "author": "Yezemin"}
{"word": ["Evolution."], "author": "Hickory"}
{"word": ["species"], "author": "le_chevalier"}
{"word": ["Genealogy."], "author": "Narcia_"}
{"word": ["Ancestry."], "author": "Hickory"}
{"word": ["Bloodlines."], "author": "REDVWIN"}
{"word": ["pedigree"], "author": "Ardal"}
{"word": ["Race."], "author": "LoboBlanco"}
{"word": ["drive"], "author": "LesterKnight99"}
{"word": ["lamborghini"], "author": "Smogg"}
{"word": ["Murci\u00e9lago"], "author": "VampiroAlhazred"}
{"word": [], "author": "Solei"}
{"word": ["glorious"], "author": "Dzsono"}
{"word": ["Victory."], "author": "xieliming"}
{"word": ["success"], "author": "le_chevalier"}
{"word": ["Failure"], "author": "TDP"}
{"word": ["error"], "author": "JDelekto"}
{"word": ["Mistake."], "author": "Casval_Deikun"}
{"word": ["bad"], "author": "Ritualisto"}
{"word": ["lesson"], "author": "le_chevalier"}
{"word": ["Professor."], "author": "ShadowPatriarch"}
{"word": ["confessor"], "author": "Dzsono"}
{"word": ["Whistleblower."], "author": "Hickory"}
{"word": ["Rat"], "author": "Zoltan999"}
{"word": ["King."], "author": "Narcia_"}
{"word": ["Monarch."], "author": "Hickory"}
{"word": ["Butterfly"], "author": "Yezemin"}
{"word": [], "author": "gixgox"}
{"word": ["butter"], "author": "Accatone"}
{"word": ["Margarine!"], "author": "GabesterOne"}
{"word": ["french"], "author": "Ardal"}
{"word": ["kiss"], "author": "le_chevalier"}
{"word": ["Smooch."], "author": "Hickory"}
{"word": ["pucker"], "author": "Dzsono"}
{"word": ["luv"], "author": "GabesterOne"}
{"word": ["Passion"], "author": "agentcarr16"}
{"word": ["Fruit."], "author": "Hickory"}
{"word": ["Vegetable"], "author": "blakstar"}
{"word": ["Salad"], "author": "RagnarokDay"}
{"word": ["Dressing."], "author": "gixgox"}
{"word": ["Clothing."], "author": "LoboBlanco"}
{"word": ["apparel"], "author": "Dzsono"}
{"word": ["Fabric"], "author": "park_84"}
{"word": ["Material"], "author": "Yezemin"}
{"word": ["witness"], "author": "le_chevalier"}
{"word": ["trial"], "author": "Ritualisto"}
{"word": ["Legal."], "author": "ShadowPatriarch"}
{"word": ["bureaucrat"], "author": "Emob78"}
{"word": ["Politician."], "author": "xieliming"}
{"word": ["Liar."], "author": "Hickory"}
{"word": ["hypocrite"], "author": "Accatone"}
{"word": ["contradiction"], "author": "Dzsono"}
{"word": ["Objection!"], "author": "Narcia_"}
{"word": ["Overruled."], "author": "Hickory"}
{"word": ["judge"], "author": "Ardal"}
{"word": ["trial"], "author": "ashwald"}
{"word": ["demo"], "author": "LesterKnight99"}
{"word": ["Demonstration."], "author": "Casval_Deikun"}
{"word": ["Rally."], "author": "Hickory"}
{"word": ["protest"], "author": "LesterKnight99"}
{"word": ["Communism."], "author": "Casval_Deikun"}
{"word": ["Ideology."], "author": "Hickory"}
{"word": ["Religion."], "author": "gixgox"}
{"word": ["Faith"], "author": "Yezemin"}
{"word": ["Blindness."], "author": "Hickory"}
{"word": ["sight"], "author": "GabesterOne"}
{"word": ["Blindness"], "author": "sayfullah"}
{"word": [" ", " Repeat."], "author": "REDVWIN"}
{"word": ["again"], "author": "Ritualisto"}
{"word": ["once ", " ", " ", " ", " Sorry for that."], "author": "sayfullah"}
{"word": ["Limited."], "author": "REDVWIN"}
{"word": ["edition"], "author": "Smogg"}
{"word": ["Issue."], "author": "Hickory"}
{"word": ["Tissue"], "author": "agentcarr16"}
{"word": ["lost"], "author": "kmonster"}
{"word": ["Forgotten"], "author": "koima57"}
{"word": ["trash"], "author": "GabesterOne"}
{"word": ["Whip"], "author": "Cavenagh"}
{"word": [" Paper."], "author": "Hickory"}
{"word": ["Craft."], "author": "gixgox"}
{"word": [" what's wrong with 'lost tissue' ", " ", " 'The regrowth of lost tissues' ", " ", " you think you own this thread, I'm sure you're a bot, you're on here 24/7 ", " ", " [edit] and stop derailing this thread, stop picking and choosing what word to reply to. it's immature."], "author": "Cavenagh"}
{"word": [" Pasttime."], "author": "Hickory"}
{"word": ["age"], "author": "EPurpl3"}
{"word": [" spending all day and night on a forum :P"], "author": "Cavenagh"}
{"word": [" Dickhead."], "author": "Hickory"}
{"word": ["Swear."], "author": "xieliming"}
{"word": ["promise (something ted cruz can't keep)"], "author": "GabesterOne"}
{"word": ["Guarantee"], "author": "TARFU"}
{"word": ["endorsement"], "author": "Dzsono"}
{"word": ["Pre-moderation."], "author": "Casval_Deikun"}
{"word": ["post-moderation?"], "author": "sayfullah"}
{"word": ["Censorship."], "author": "ShadowPatriarch"}
{"word": ["Dictator"], "author": "park_84"}
{"word": ["dogeship ", " ", " ninja'd ", " ", " despot"], "author": "le_chevalier"}
{"word": ["Tyranny."], "author": "Casval_Deikun"}
{"word": ["Dictator"], "author": "agentcarr16"}
{"word": ["Loop."], "author": "Chandoraa"}
{"word": ["Spiral."], "author": "Hickory"}
{"word": ["Whorl."], "author": "Dawnreader"}
{"word": ["coil"], "author": "ashwald"}
{"word": ["spiral"], "author": "Dzsono"}
{"word": ["Staircase"], "author": "Zoltan999"}
{"word": ["Escalator."], "author": "ShadowPatriarch"}
{"word": ["Conveyor."], "author": "Hickory"}
{"word": ["Belt."], "author": "Narcia_"}
{"word": ["Black"], "author": "Yezemin"}
{"word": ["ebony"], "author": "Ardal"}
{"word": [], "author": "gixgox"}
{"word": ["Coast."], "author": "Chandoraa"}
{"word": ["ocean"], "author": "GabesterOne"}
{"word": ["Current."], "author": "Hickory"}
{"word": ["Electric"], "author": "blakstar"}
{"word": ["power ( like how powerful donald trump is)"], "author": "GabesterOne"}
{"word": ["level"], "author": "RagnarokDay"}
{"word": ["Tier"], "author": "TARFU"}
{"word": ["status"], "author": "GabesterOne"}
{"word": ["Position."], "author": "Hickory"}
{"word": ["left"], "author": "Ritualisto"}
{"word": ["Port"], "author": "TARFU"}
{"word": ["Alcohol"], "author": "Dzsono"}
{"word": ["Still."], "author": "Hickory"}
{"word": ["Pose."], "author": "xieliming"}
{"word": ["Picture"], "author": "coryrj1995"}
{"word": ["Memory"], "author": "RagnarokDay"}
{"word": ["Lane."], "author": "Hickory"}
{"word": ["highway"], "author": "GabesterOne"}
{"word": ["Drive."], "author": "semigroups"}
{"word": ["Ride"], "author": "coryrj1995"}
{"word": ["Hell"], "author": "aspen28570"}
{"word": ["Satan."], "author": "Casval_Deikun"}
{"word": ["Devil"], "author": "TARFU"}
{"word": ["Lucifer"], "author": "GabesterOne"}
{"word": ["Beelzebub"], "author": "park_84"}
{"word": ["Baal"], "author": "le_chevalier"}
{"word": ["Mephistopheles."], "author": "Casval_Deikun"}
{"word": ["Gabriel."], "author": "ShadowPatriarch"}
{"word": ["prophet"], "author": "Dzsono"}
{"word": ["False"], "author": "Zoltan999"}
{"word": ["true"], "author": "Ritualisto"}
{"word": ["Veracity"], "author": "Yezemin"}
{"word": ["Fidelity."], "author": "Hickory"}
{"word": ["high"], "author": "Ardal"}
{"word": ["Tide."], "author": "Narcia_"}
{"word": ["."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["Fodder."], "author": "Hickory"}
{"word": ["Cannon"], "author": "Yezemin"}
{"word": ["gun"], "author": "le_chevalier"}
{"word": ["control"], "author": "Ardal"}
{"word": ["Manipulation"], "author": "TARFU"}
{"word": ["Exploitation."], "author": "Hickory"}
{"word": ["Movie."], "author": "Ikarugamesh"}
{"word": ["cinema"], "author": "Smogg"}
{"word": ["Theatre."], "author": "REDVWIN"}
{"word": ["Ticket."], "author": "Hickory"}
{"word": ["Speeding"], "author": "agentcarr16"}
{"word": [], "author": "gixgox"}
{"word": ["link"], "author": "Ritualisto"}
{"word": ["connection"], "author": "sayfullah"}
{"word": ["bound"], "author": "Accatone"}
{"word": ["Trussed."], "author": "Hickory"}
{"word": ["Skewers"], "author": "Gilden"}
{"word": ["stakes"], "author": "le_chevalier"}
{"word": ["Steaks."], "author": "Hickory"}
{"word": ["meat"], "author": "GabesterOne"}
{"word": ["Barbecue"], "author": "TARFU"}
{"word": ["Grill."], "author": "Casval_Deikun"}
{"word": ["Drill."], "author": "xieliming"}
{"word": ["Sergeant."], "author": "ShadowPatriarch"}
{"word": ["Army"], "author": "le_chevalier"}
{"word": ["Now"], "author": "park_84"}
{"word": ["Never."], "author": "Casval_Deikun"}
{"word": [], "author": "gixgox"}
{"word": ["Always."], "author": "Hickory"}
{"word": ["sometimes"], "author": "sayfullah"}
{"word": ["Monsters."], "author": "Chandoraa"}
{"word": ["humanoid"], "author": "Ardal"}
{"word": ["Insectoid."], "author": "Hickory"}
{"word": [], "author": "Zoltan999"}
{"word": ["arachnid"], "author": "Dzsono"}
{"word": ["spiders (like spooderman)"], "author": "GabesterOne"}
{"word": ["Web."], "author": "Hickory"}
{"word": ["net"], "author": "ashwald"}
{"word": ["Weight"], "author": "Yezemin"}
{"word": ["Mass."], "author": "ShadowPatriarch"}
{"word": ["Effect"], "author": "Dawnreader"}
{"word": ["Influence."], "author": "Narcia_"}
{"word": [], "author": "gixgox"}
{"word": ["Epidemic."], "author": "Hickory"}
{"word": ["Contagion."], "author": "GhostwriterDoF"}
{"word": ["plague"], "author": "Ritualisto"}
{"word": ["scourge"], "author": "Dzsono"}
{"word": ["Scorch"], "author": "Yezemin"}
{"word": ["burnt (like all the bernie sanders supporters by june)"], "author": "GabesterOne"}
{"word": ["Overcooked."], "author": "Hickory"}
{"word": ["Overclocked"], "author": "Habanerose"}
{"word": ["overworked (cant stop the trump train!)"], "author": "GabesterOne"}
{"word": ["Underpaid."], "author": "Hickory"}
{"word": ["Exploited."], "author": "gixgox"}
{"word": ["Explosion"], "author": "doctorsinister"}
{"word": ["boom"], "author": "sayfullah"}
{"word": ["sonic"], "author": "Dzsono"}
{"word": ["Ultra"], "author": "Abovet"}
{"word": ["Sound."], "author": "Hickory"}
{"word": ["Noise"], "author": "TARFU"}
{"word": ["Howl"], "author": "TDP"}
{"word": ["Growl."], "author": "agentcarr16"}
{"word": ["Dog"], "author": "TARFU"}
{"word": ["bitch"], "author": "GabesterOne"}
{"word": ["Female."], "author": "xieliming"}
{"word": ["Eve."], "author": "Casval_Deikun"}
{"word": ["Snake"], "author": "PaterAlf"}
{"word": ["Solid"], "author": "truhlik"}
{"word": ["stable"], "author": "le_chevalier"}
{"word": ["Constant"], "author": "park_84"}
{"word": ["Pi"], "author": "s_a"}
{"word": ["pipi"], "author": "apehater"}
{"word": ["wet"], "author": "Ritualisto"}
{"word": ["doused"], "author": "Dzsono"}
{"word": ["Submerged"], "author": "Yezemin"}
{"word": ["Submarine"], "author": "Zoltan999"}
{"word": ["Nemo"], "author": "vlodimer"}
{"word": ["tasty"], "author": "apehater"}
{"word": ["pizza"], "author": "Smogg"}
{"word": ["Pepperoni."], "author": "ShadowPatriarch"}
{"word": ["Sausage."], "author": "Narcia_"}
{"word": ["Casserole."], "author": "Hickory"}
{"word": [], "author": "Dzsono"}
{"word": ["Stew."], "author": "Hickory"}
{"word": ["stewed"], "author": "JDelekto"}
{"word": ["Boiled"], "author": "TDP"}
{"word": ["hard"], "author": "JDelekto"}
{"word": ["rock"], "author": "Smogg"}
{"word": ["bed"], "author": "Ardal"}
{"word": ["Cover."], "author": "Hickory"}
{"word": ["Conceal"], "author": "TARFU"}
{"word": ["obfuscate"], "author": "Ardal"}
{"word": ["Garble."], "author": "Hickory"}
{"word": ["Static"], "author": "TARFU"}
{"word": ["Fixed."], "author": "Hickory"}
{"word": ["all"], "author": "kmonster"}
{"word": ["Loosened,"], "author": "gixgox"}
{"word": ["Slacken."], "author": "Hickory"}
{"word": ["Slackware"], "author": "Solei"}
{"word": ["Kernel"], "author": "coryrj1995"}
{"word": ["Corn"], "author": "TARFU"}
{"word": ["Field."], "author": "xieliming"}
{"word": ["dreams"], "author": "JDelekto"}
{"word": ["fantasy (like sjw's arguments)"], "author": "GabesterOne"}
{"word": ["drama"], "author": "JDelekto"}
{"word": ["theater"], "author": "TARFU"}
{"word": ["Actor."], "author": "Casval_Deikun"}
{"word": ["participant"], "author": "Dzsono"}
{"word": ["guy"], "author": "Ritualisto"}
{"word": ["gal"], "author": "park_84"}
{"word": ["Pal."], "author": "ShadowPatriarch"}
{"word": ["television"], "author": "Smogg"}
{"word": ["film"], "author": "le_chevalier"}
{"word": ["Coating."], "author": "Hickory"}
{"word": ["rubber"], "author": "Smogg"}
{"word": ["glue"], "author": "Dzsono"}
{"word": [" ", " <my duck is too lame for ninjas> ", " ", " Paste."], "author": "gixgox"}
{"word": ["Hunt"], "author": "Yezemin"}
{"word": ["Safari"], "author": "Zoltan999"}
{"word": ["Browser"], "author": "blakstar"}
{"word": ["internet"], "author": "Ardal"}
{"word": ["Provider."], "author": "Narcia_"}
{"word": ["Breadwinner."], "author": "Hickory"}
{"word": ["leech"], "author": "apehater"}
{"word": ["sucker"], "author": "Ardal"}
{"word": ["punch"], "author": "enurbenur"}
{"word": ["fruit"], "author": "camplify"}
{"word": ["[Ninja'd] ", " ", " Cocktail."], "author": "Hickory"}
{"word": ["Cruise"], "author": "Emob78"}
{"word": ["Tom"], "author": "XYCat"}
{"word": ["Thumb."], "author": "Hickory"}
{"word": ["Like. (Facebook)"], "author": "REDVWIN"}
{"word": ["button"], "author": "Ritualisto"}
{"word": ["butt"], "author": "apehater"}
{"word": ["Cigarette"], "author": "TARFU"}
{"word": ["Filter"], "author": "blakstar"}
{"word": ["air"], "author": "apehater"}
{"word": ["full"], "author": "kmonster"}
{"word": ["Sated."], "author": "Hickory"}
{"word": ["Satisfied."], "author": "xieliming"}
{"word": ["Happy"], "author": "TARFU"}
{"word": ["serene"], "author": "Dzsono"}
{"word": ["republic"], "author": "le_chevalier"}
{"word": ["Coruscant."], "author": "LoboBlanco"}
{"word": ["Senate"], "author": "Yezemin"}
{"word": ["Bureaucrats"], "author": "TARFU"}
{"word": ["Forms."], "author": "toxicTom"}
{"word": ["Worms"], "author": "park_84"}
{"word": ["Dune."], "author": "gixgox"}
{"word": ["water"], "author": "Ardal"}
{"word": ["weather"], "author": "le_chevalier"}
{"word": ["System"], "author": "Zoltan999"}
{"word": ["shock"], "author": "enurbenur"}
{"word": ["After"], "author": "Yezemin"}
{"word": [], "author": "gixgox"}
{"word": ["Incinerator."], "author": "Hickory"}
{"word": ["Trash"], "author": "Narcia_"}
{"word": ["Rubbish"], "author": "TARFU"}
{"word": ["Junk"], "author": "toxicTom"}
{"word": ["Yard."], "author": "Hickory"}
{"word": ["Ship"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["ponies"], "author": "GabesterOne"}
{"word": ["unicorns"], "author": "Dzsono"}
{"word": ["goats"], "author": "sayfullah"}
{"word": ["Satyrs."], "author": "Hickory"}
{"word": ["Minotaur"], "author": "TARFU"}
{"word": ["strange"], "author": "Ritualisto"}
{"word": ["Weird."], "author": "Ikarugamesh"}
{"word": ["Science."], "author": "Hickory"}
{"word": ["Research."], "author": "Ikarugamesh"}
{"word": ["hypothesis"], "author": "Dzsono"}
{"word": ["Conclusion."], "author": "LoboBlanco"}
{"word": ["Guess"], "author": "TARFU"}
{"word": ["estimate"], "author": "le_chevalier"}
{"word": ["guessing"], "author": "GabesterOne"}
{"word": ["Quiz."], "author": "Casval_Deikun"}
{"word": ["Test"], "author": "TARFU"}
{"word": ["trial"], "author": "le_chevalier"}
{"word": ["Combat"], "author": "Yezemin"}
{"word": ["ant"], "author": "le_chevalier"}
{"word": ["Man"], "author": "park_84"}
{"word": ["Human"], "author": "TARFU"}
{"word": ["culture"], "author": "Smogg"}
{"word": ["Civilization."], "author": "ShadowPatriarch"}
{"word": ["Technology"], "author": "TARFU"}
{"word": ["Wheel"], "author": "s_a"}
{"word": ["Round"], "author": "Yezemin"}
{"word": ["Fight!"], "author": "park_84"}
{"word": ["street"], "author": "Ritualisto"}
{"word": ["Wise"], "author": "Zoltan999"}
{"word": ["guy"], "author": "enurbenur"}
{"word": ["brush"], "author": "GabesterOne"}
{"word": ["Hair"], "author": "Yezemin"}
{"word": ["Elastic."], "author": "Narcia_"}
{"word": [], "author": "gixgox"}
{"word": ["Ache."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["sadness"], "author": "GabesterOne"}
{"word": [], "author": "REDVWIN"}
{"word": ["legend"], "author": "Dzsono"}
{"word": ["fable (love the wolf among us btw :) )"], "author": "GabesterOne"}
{"word": ["\u041cythology"], "author": "s_a"}
{"word": ["Saga"], "author": "TARFU"}
{"word": ["Chronicle."], "author": "Hickory"}
{"word": ["news"], "author": "sayfullah"}
{"word": ["Media"], "author": "TARFU"}
{"word": ["Mogul."], "author": "Hickory"}
{"word": ["Mongol."], "author": "ShadowPatriarch"}
{"word": ["steppe"], "author": "Ardal"}
{"word": [], "author": "gixgox"}
{"word": ["Barbarians"], "author": "TARFU"}
{"word": ["Goths"], "author": "Hardrada"}
{"word": [" ", " Unfair."], "author": "Hickory"}
{"word": [" Life"], "author": "TARFU"}
{"word": ["lost"], "author": "kmonster"}
{"word": ["Puppy."], "author": "Hickory"}
{"word": ["fresh"], "author": "Dzsono"}
{"word": ["Vegetable"], "author": "TARFU"}
{"word": ["herb"], "author": "le_chevalier"}
{"word": ["Medicine"], "author": "Yezemin"}
{"word": ["Cure"], "author": "park_84"}
{"word": ["music"], "author": "skimmie"}
{"word": ["song"], "author": "Ritualisto"}
{"word": ["Bard."], "author": "xieliming"}
{"word": ["Lute"], "author": "NuffCatnip"}
{"word": ["Piper"], "author": "Emob78"}
{"word": ["Earmuffs."], "author": "gixgox"}
{"word": ["cap"], "author": "BlackDawn"}
{"word": ["Ushanka =)"], "author": "s_a"}
{"word": ["soviets"], "author": "GabesterOne"}
{"word": ["Non-existant."], "author": "Hickory"}
{"word": ["god ( >:) )"], "author": "GabesterOne"}
{"word": ["Hallucination"], "author": "Yezemin"}
{"word": ["Truth."], "author": "ShadowPatriarch"}
{"word": ["dare."], "author": "skimmie"}
{"word": ["Gambit."], "author": "Hickory"}
{"word": ["chess"], "author": "cose_vecchie"}
{"word": ["Pawn"], "author": "TARFU"}
{"word": ["Broker."], "author": "Hickory"}
{"word": ["bond"], "author": "s_a"}
{"word": ["007"], "author": "EPurpl3"}
{"word": [" Pledge."], "author": "Hickory"}
{"word": ["promise"], "author": "Dzsono"}
{"word": [], "author": "gixgox"}
{"word": ["Kickstarter"], "author": "coryrj1995"}
{"word": ["Con"], "author": "Tauto"}
{"word": ["Scam"], "author": "TARFU"}
{"word": ["Nigeria."], "author": "xieliming"}
{"word": ["Prince"], "author": "le_chevalier"}
{"word": ["Castle."], "author": "Casval_Deikun"}
{"word": ["Defense"], "author": "Yezemin"}
{"word": ["Protection."], "author": "Hickory"}
{"word": ["Preservative"], "author": "park_84"}
{"word": ["Condom"], "author": "Habanerose"}
{"word": ["Hollow."], "author": "ShadowPatriarch"}
{"word": ["Pantera"], "author": "enurbenur"}
{"word": ["band"], "author": "Ritualisto"}
{"word": ["guitar"], "author": "s_a"}
{"word": ["air"], "author": "gixgox"}
{"word": ["wind"], "author": "le_chevalier"}
{"word": [], "author": "gixgox"}
{"word": ["breeze"], "author": "Dzsono"}
{"word": ["Cool"], "author": "Zoltan999"}
{"word": ["Chilly."], "author": "Hickory"}
{"word": ["Freezing."], "author": "Narcia_"}
{"word": ["windy"], "author": "GabesterOne"}
{"word": ["stormy"], "author": "JinKazaragi"}
{"word": ["Blizzard."], "author": "REDVWIN"}
{"word": ["."], "author": "gixgox"}
{"word": ["wizard :)"], "author": "GabesterOne"}
{"word": [" Meteorologist."], "author": "GhostwriterDoF"}
{"word": ["Forecaster."], "author": "Hickory"}
{"word": ["Predict"], "author": "TDP"}
{"word": ["Prophecy"], "author": "Yezemin"}
{"word": ["chosen"], "author": "GabesterOne"}
{"word": ["Selected"], "author": "agentcarr16"}
{"word": ["Hand-picked."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["equipped"], "author": "GabesterOne"}
{"word": ["Erect."], "author": "Kleetus"}
{"word": ["high"], "author": "kmonster"}
{"word": ["Jinks."], "author": "Hickory"}
{"word": ["dodges"], "author": "Dzsono"}
{"word": ["evade"], "author": "Habanerose"}
{"word": ["Invade"], "author": "agentcarr16"}
{"word": ["Space."], "author": "xieliming"}
{"word": ["."], "author": "gixgox"}
{"word": ["rigs"], "author": "GabesterOne"}
{"word": ["Oil"], "author": "TARFU"}
{"word": ["Slick."], "author": "Hickory"}
{"word": ["sleek"], "author": "le_chevalier"}
{"word": ["Design"], "author": "Yezemin"}
{"word": ["Barcelona"], "author": "park_84"}
{"word": ["city"], "author": "Ritualisto"}
{"word": ["megalopolis"], "author": "Dzsono"}
{"word": ["Decepticons"], "author": "Emob78"}
{"word": ["transformers"], "author": "GabesterOne"}
{"word": ["Capacitors"], "author": "Allinstein"}
{"word": ["Resistors."], "author": "Hickory"}
{"word": ["Resistance"], "author": "skimmie"}
{"word": ["Futile"], "author": "Crappynuker1"}
{"word": ["Pointless."], "author": "Hickory"}
{"word": ["dispute"], "author": "s_a"}
{"word": ["Territory."], "author": "Ikarugamesh"}
{"word": ["Zone"], "author": "TARFU"}
{"word": ["Ozone."], "author": "Hickory"}
{"word": ["oxygen"], "author": "s_a"}
{"word": ["Nitrogen"], "author": "coryrj1995"}
{"word": ["Carbon"], "author": "LesterKnight99"}
{"word": ["Fiber"], "author": "TARFU"}
{"word": ["bar"], "author": "GabesterOne"}
{"word": ["Maid"], "author": "Habanerose"}
{"word": ["Servant"], "author": "TARFU"}
{"word": ["Wife."], "author": "Kleetus"}
{"word": ["Husband."], "author": "agentcarr16"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": [" Lackey."], "author": "Hickory"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["dangly"], "author": "Ardal"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["Phallic."], "author": "xieliming"}
{"word": ["dead"], "author": "kmonster"}
{"word": ["graveyard"], "author": "TARFU"}
{"word": ["lol ", " ", " Edit: or should i say penis. =D"], "author": "Antimateria"}
{"word": ["Lackey."], "author": "Hickory"}
{"word": ["Slave"], "author": "Antimateria"}
{"word": ["Thrall"], "author": "TARFU"}
{"word": ["hearthstone"], "author": "camplify"}
{"word": ["wow"], "author": "GabesterOne"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": [" Bondage."], "author": "Hickory"}
{"word": ["Imprison."], "author": "semigroups"}
{"word": ["encage"], "author": "le_chevalier"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["protrusion"], "author": "Dzsono"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["cock"], "author": "GabesterOne"}
{"word": [" Immure."], "author": "Hickory"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["Multiple"], "author": "park_84"}
{"word": ["Tentacles"], "author": "Habanerose"}
{"word": ["animal"], "author": "Ritualisto"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": [" ", " ", " ", " Someone here really likes dongs :P"], "author": "Habanerose"}
{"word": ["Natural."], "author": "xieliming"}
{"word": ["Bush ", " ", " (haven't seen this much cock since my days as a male prostitute in a cock farm)"], "author": "Antimateria"}
{"word": ["fire"], "author": "Smogg"}
{"word": ["Hot"], "author": "Yezemin"}
{"word": ["Tamale"], "author": "Zoltan999"}
{"word": ["Spicy."], "author": "Narcia_"}
{"word": ["fire"], "author": "Dzsono"}
{"word": ["Water"], "author": "PaterAlf"}
{"word": ["Pressure."], "author": "Hickory"}
{"word": ["suppresion"], "author": "Ardal"}
{"word": ["Prevention."], "author": "Hickory"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["Prevention."], "author": "Hickory"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["Prevention."], "author": "Hickory"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["Prevention."], "author": "Hickory"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["idiot"], "author": "apehater"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": [" Pubescent."], "author": "gixgox"}
{"word": ["Dick."], "author": "xieliming"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["vagina"], "author": "GabesterOne"}
{"word": ["Squirting."], "author": "Kleetus"}
{"word": ["prevention"], "author": "Dzsono"}
{"word": ["Interdiction."], "author": "Hickory"}
{"word": ["Banning."], "author": "REDVWIN"}
{"word": ["Restricting"], "author": "TARFU"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": [" Impeding."], "author": "Hickory"}
{"word": ["Preventing"], "author": "LesterKnight99"}
{"word": [" Penis."], "author": "Kleetus"}
{"word": ["testicles"], "author": "GabesterOne"}
{"word": ["Twins."], "author": "Kleetus"}
{"word": ["pairs"], "author": "le_chevalier"}
{"word": ["Fruit."], "author": "Kleetus"}
{"word": [], "author": "AndreaLebowski"}
{"word": ["Worm."], "author": "Kleetus"}
{"word": [], "author": "AndreaLebowski"}
{"word": ["STD."], "author": "Kleetus"}
{"word": [" Thwarting."], "author": "Hickory"}
{"word": ["Confounding."], "author": "gixgox"}
{"word": ["factor"], "author": "Dzsono"}
{"word": ["Component."], "author": "Hickory"}
{"word": ["part"], "author": "Ritualisto"}
{"word": ["missing"], "author": "Ardal"}
{"word": ["link"], "author": "Smogg"}
{"word": ["par"], "author": "Tauto"}
{"word": ["excellence"], "author": "gixgox"}
{"word": ["Prowess."], "author": "Hickory"}
{"word": ["Fighting."], "author": "Narcia_"}
{"word": ["Beating."], "author": "toxicTom"}
{"word": ["Punishment"], "author": "Zoltan999"}
{"word": ["Discipline."], "author": "Hickory"}
{"word": ["Structure"], "author": "TARFU"}
{"word": ["regimen"], "author": "Dzsono"}
{"word": ["Zoltan:)"], "author": "Moonbeam"}
{"word": ["Dude"], "author": "JDelekto"}
{"word": ["Bowling"], "author": "PaterAlf"}
{"word": ["Strike"], "author": "TARFU"}
{"word": ["Force"], "author": "cose_vecchie"}
{"word": ["gravity"], "author": "Smogg"}
{"word": ["Testicles. ", " ", " ", " Penis."], "author": "Kleetus"}
{"word": [" Mass."], "author": "Hickory"}
{"word": ["effect"], "author": "apehater"}
{"word": ["Pray."], "author": "Kleetus"}
{"word": ["Deity"], "author": "TDP"}
{"word": ["Dictator."], "author": "Kleetus"}
{"word": [" Cause."], "author": "Hickory"}
{"word": [" Penis."], "author": "Kleetus"}
{"word": ["^ funny."], "author": "Tauto"}
{"word": ["Unexpected."], "author": "xieliming"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": [" predictable"], "author": "Dzsono"}
{"word": ["Anticipated."], "author": "Hickory"}
{"word": ["Expected."], "author": "Kleetus"}
{"word": [" Forecast."], "author": "ShadowPatriarch"}
{"word": [" You've just broken the second of the only two rules of the game."], "author": "Kleetus"}
{"word": [" Weather"], "author": "TARFU"}
{"word": ["Front."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": ["Front."], "author": "Hickory"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["Front."], "author": "Hickory"}
{"word": ["Hetrosexual."], "author": "Kleetus"}
{"word": ["Vulgarity."], "author": "Casval_Deikun"}
{"word": ["Rear."], "author": "Kleetus"}
{"word": ["Common"], "author": "park_84"}
{"word": ["Slut."], "author": "Kleetus"}
{"word": ["Front."], "author": "Hickory"}
{"word": ["... end"], "author": "gixgox"}
{"word": ["Terminus."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["word"], "author": "Ritualisto"}
{"word": ["."], "author": "gixgox"}
{"word": ["lyrical"], "author": "Dzsono"}
{"word": ["expressive"], "author": "Zoltan999"}
{"word": ["Art"], "author": "Yezemin"}
{"word": ["Gallery."], "author": "Hickory"}
{"word": ["National ", " ", " "], "author": "gixgox"}
{"word": ["News."], "author": "Narcia_"}
{"word": ["Informative"], "author": "Azrael360"}
{"word": ["informant"], "author": "GabesterOne"}
{"word": ["Mole"], "author": "Pickle1477"}
{"word": ["Rodent"], "author": "BenKii"}
{"word": ["Incisors."], "author": "Hickory"}
{"word": ["cutter"], "author": "le_chevalier"}
{"word": ["circumcision (perfect time for penis guy to reply)"], "author": "GabesterOne"}
{"word": [" Sloop."], "author": "Hickory"}
{"word": ["vessel"], "author": "Dzsono"}
{"word": ["ironclad"], "author": "Ardal"}
{"word": ["submarine"], "author": "GabesterOne"}
{"word": [" Steamship."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": ["Steamship."], "author": "Hickory"}
{"word": ["Dreadnought"], "author": "TARFU"}
{"word": ["Texas (", "))"], "author": "GabesterOne"}
{"word": ["State."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": ["State."], "author": "Hickory"}
{"word": [" Dock."], "author": "Kleetus"}
{"word": ["State."], "author": "Hickory"}
{"word": ["Alabama."], "author": "REDVWIN"}
{"word": ["Obama"], "author": "samuraigaiden"}
{"word": ["Care."], "author": "Kleetus"}
{"word": ["good"], "author": "kmonster"}
{"word": [" Penis."], "author": "Kleetus"}
{"word": [" Beneficial."], "author": "REDVWIN"}
{"word": ["Rewarding."], "author": "Hickory"}
{"word": ["Pay."], "author": "xieliming"}
{"word": ["Lucrative."], "author": "gixgox"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": [" investment"], "author": "Dzsono"}
{"word": ["Risk."], "author": "REDVWIN"}
{"word": ["Ukraine"], "author": "TARFU"}
{"word": ["Annexed."], "author": "Kleetus"}
{"word": [" Assessment."], "author": "ShadowPatriarch"}
{"word": ["Evaluation."], "author": "Hickory"}
{"word": ["Mark"], "author": "park_84"}
{"word": ["Chalk"], "author": "TARFU"}
{"word": ["Pencil"], "author": "LesterKnight99"}
{"word": ["Write"], "author": "Yezemin"}
{"word": ["letter"], "author": "Smogg"}
{"word": ["send"], "author": "ashwald"}
{"word": ["receive"], "author": "enurbenur"}
{"word": ["Radio."], "author": "Casval_Deikun"}
{"word": ["broadcast"], "author": "le_chevalier"}
{"word": ["static"], "author": "Emob78"}
{"word": ["Electricity"], "author": "TARFU"}
{"word": ["Energy."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["button"], "author": "Ritualisto"}
{"word": ["nose"], "author": "Hardrada"}
{"word": ["Cone"], "author": "Zoltan999"}
{"word": ["traffic ", " (I thought about saying head, but didn't.)"], "author": "Gerin"}
{"word": ["Jam"], "author": "Yezemin"}
{"word": ["mercantile"], "author": "Dzsono"}
{"word": ["bazaar"], "author": "Ardal"}
{"word": ["Market."], "author": "ShadowPatriarch"}
{"word": ["Price."], "author": "Narcia_"}
{"word": ["money ( ", " )"], "author": "GabesterOne"}
{"word": ["Currency"], "author": "Yezemin"}
{"word": [], "author": "AndreaLebowski"}
{"word": ["Realm"], "author": "TARFU"}
{"word": [], "author": "AndreaLebowski"}
{"word": ["Amnesia"], "author": "Yezemin"}
{"word": ["Confusion."], "author": "Hickory"}
{"word": ["Disorientation"], "author": "TARFU"}
{"word": ["dizzy"], "author": "LesterKnight99"}
{"word": [" Penis."], "author": "Kleetus"}
{"word": [" Spell."], "author": "Hickory"}
{"word": [" magic"], "author": "LesterKnight99"}
{"word": [" Penis."], "author": "Kleetus"}
{"word": ["long"], "author": "Ritualisto"}
{"word": ["short"], "author": "camplify"}
{"word": ["Hairy."], "author": "Kleetus"}
{"word": [], "author": "AndreaLebowski"}
{"word": ["Pube."], "author": "Kleetus"}
{"word": [" Potion."], "author": "Hickory"}
{"word": ["Elixir"], "author": "agentcarr16"}
{"word": ["Lube."], "author": "Kleetus"}
{"word": [" Salve."], "author": "gixgox"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["Repeat."], "author": "xieliming"}
{"word": ["Repeat."], "author": "Kleetus"}
{"word": ["again"], "author": "GabesterOne"}
{"word": [" Balm."], "author": "Hickory"}
{"word": ["Lube."], "author": "Kleetus"}
{"word": ["Balm."], "author": "Hickory"}
{"word": ["Lip."], "author": "gixgox"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Service."], "author": "Hickory"}
{"word": ["work"], "author": "LesterKnight99"}
{"word": ["Station."], "author": "gixgox"}
{"word": ["Train"], "author": "TARFU"}
{"word": ["Toilet."], "author": "Kleetus"}
{"word": [" "], "author": "REDVWIN"}
{"word": ["Track."], "author": "Hickory"}
{"word": ["Race."], "author": "Kleetus"}
{"word": ["Hippodrome."], "author": "REDVWIN"}
{"word": ["Hippopotamus."], "author": "Kleetus"}
{"word": [" velodrome"], "author": "Dzsono"}
{"word": [" Velopotamus."], "author": "Kleetus"}
{"word": ["Velociraptor"], "author": "park_84"}
{"word": [" Hippocraptor."], "author": "Kleetus"}
{"word": [" Theropods."], "author": "gixgox"}
{"word": ["Carnivorous"], "author": "Zoltan999"}
{"word": ["Meat"], "author": "Yezemin"}
{"word": ["Butcher (", ")"], "author": "GabesterOne"}
{"word": ["Chop"], "author": "Pickle1477"}
{"word": ["Diablo"], "author": "Dzsono"}
{"word": ["El-Pollo"], "author": "Narcia_"}
{"word": [], "author": "AndreaLebowski"}
{"word": ["Chicken"], "author": "Yezemin"}
{"word": ["fried"], "author": "GabesterOne"}
{"word": [], "author": "AndreaLebowski"}
{"word": ["mashed"], "author": "skimmie"}
{"word": ["goo"], "author": "Ardal"}
{"word": ["slime"], "author": "Smogg"}
{"word": ["ball"], "author": "GabesterOne"}
{"word": ["foot"], "author": "truhlik"}
{"word": [], "author": "gixgox"}
{"word": ["Banquet."], "author": "Hickory"}
{"word": ["Hall."], "author": "ShadowPatriarch"}
{"word": ["Effect."], "author": "gixgox"}
{"word": ["Cause"], "author": "blakstar"}
{"word": ["Just"], "author": "VampiroAlhazred"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Compositors."], "author": "Casval_Deikun"}
{"word": ["keyboard"], "author": "GabesterOne"}
{"word": ["HiD."], "author": "Kleetus"}
{"word": [" Clavier."], "author": "gixgox"}
{"word": ["Harp."], "author": "kroge"}
{"word": ["Harpsichord."], "author": "Hickory"}
{"word": ["Fingerboard."], "author": "Kleetus"}
{"word": ["Harpsichord."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": ["Harpsichord."], "author": "Hickory"}
{"word": ["Cembalo."], "author": "Kleetus"}
{"word": [" Piano."], "author": "gixgox"}
{"word": ["Accordion."], "author": "REDVWIN"}
{"word": [" Honda."], "author": "Kleetus"}
{"word": ["Toyota."], "author": "xieliming"}
{"word": [" Concertina."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": [" Theaterina."], "author": "Kleetus"}
{"word": [" Marimba."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": [" Xylophone."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" Pixma."], "author": "Kleetus"}
{"word": [" Lore"], "author": "Dzsono"}
{"word": ["story"], "author": "GabesterOne"}
{"word": ["Floor."], "author": "Kleetus"}
{"word": [" Anecdote."], "author": "Hickory"}
{"word": ["Tale"], "author": "TARFU"}
{"word": [" Story."], "author": "Kleetus"}
{"word": [" Yarn."], "author": "Hickory"}
{"word": ["Wool"], "author": "Yezemin"}
{"word": ["Sheep"], "author": "TARFU"}
{"word": ["sleep"], "author": "park_84"}
{"word": ["Steep."], "author": "Hickory"}
{"word": ["harsh"], "author": "Ritualisto"}
{"word": ["Cruel."], "author": "ShadowPatriarch"}
{"word": [], "author": "AndreaLebowski"}
{"word": ["Goal."], "author": "Kleetus"}
{"word": ["Proposition."], "author": "gixgox"}
{"word": ["offer"], "author": "le_chevalier"}
{"word": ["trade"], "author": "skimmie"}
{"word": ["Route"], "author": "Yezemin"}
{"word": ["Map"], "author": "Zoltan999"}
{"word": ["Compass."], "author": "Hickory"}
{"word": ["Sextant."], "author": "gixgox"}
{"word": ["Stars."], "author": "Narcia_"}
{"word": ["universe"], "author": "GabesterOne"}
{"word": ["eternity"], "author": "Dzsono"}
{"word": ["Forever"], "author": "Yezemin"}
{"word": [], "author": "cose_vecchie"}
{"word": [], "author": "AndreaLebowski"}
{"word": ["Souls"], "author": "cose_vecchie"}
{"word": ["Spirit. ", " ", " Spirit. ", " ", " Spirit."], "author": "ShadowPatriarch"}
{"word": ["tree"], "author": "GabesterOne"}
{"word": ["Leaf"], "author": "TARFU"}
{"word": ["Frond."], "author": "Hickory"}
{"word": ["tail"], "author": "Ritualisto"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": ["Love."], "author": "Tauto"}
{"word": ["Ejaculation."], "author": "Kleetus"}
{"word": [" Brush."], "author": "Hickory"}
{"word": ["Love."], "author": "Tauto"}
{"word": [" Hey, guess what? ", " ", " I just conversed with tinyE, and you were right, he really is tiny."], "author": "Kleetus"}
{"word": ["Brush."], "author": "Hickory"}
{"word": [" I told you so:)"], "author": "Tauto"}
{"word": ["Brush."], "author": "Hickory"}
{"word": ["bristle"], "author": "Smogg"}
{"word": ["Prick."], "author": "Kleetus"}
{"word": [" thistle"], "author": "Dzsono"}
{"word": [], "author": "blakstar"}
{"word": ["Bagpipes."], "author": "Hickory"}
{"word": ["<ninjas in ...> ", " Kilts."], "author": "gixgox"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["Again."], "author": "xieliming"}
{"word": ["Repeater."], "author": "gixgox"}
{"word": [" Penis."], "author": "Kleetus"}
{"word": [" Tartan."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Plaid"], "author": "TARFU"}
{"word": ["Wool."], "author": "Kleetus"}
{"word": [" Twill."], "author": "Hickory"}
{"word": ["Tweed."], "author": "gixgox"}
{"word": [" Wool."], "author": "Kleetus"}
{"word": ["Bull."], "author": "Tauto"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Stream. ", " ", " BTW, everyone is cheating and breaking Rule #2. ", " ", " No selective quoting of previous posts, post above only. ", " ", " Not one to name names, but I'm pretty sure it was Hickory who started doing it."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Ocean"], "author": "Azrael360"}
{"word": ["Sea"], "author": "TARFU"}
{"word": ["Men."], "author": "Kleetus"}
{"word": [" Shell."], "author": "Hickory"}
{"word": ["Casing. ", " ", " See, I told you all it was Hickory breaking the rules. ", " ", " I have a good mind to make a full report."], "author": "Kleetus"}
{"word": [" Shell."], "author": "Hickory"}
{"word": ["Armor."], "author": "Casval_Deikun"}
{"word": ["All."], "author": "Kleetus"}
{"word": [" Plate."], "author": "Hickory"}
{"word": [" Sea."], "author": "Kleetus"}
{"word": [" \u0421orselet."], "author": "Casval_Deikun"}
{"word": [" Girdlelet."], "author": "Kleetus"}
{"word": [" Brassiere."], "author": "Hickory"}
{"word": ["Clothes"], "author": "Casval_Deikun"}
{"word": [" Brasslet"], "author": "Kleetus"}
{"word": [" Raiment."], "author": "Hickory"}
{"word": ["cloth"], "author": "Ritualisto"}
{"word": ["Fabric."], "author": "ShadowPatriarch"}
{"word": ["Material"], "author": "Yezemin"}
{"word": ["resource"], "author": "le_chevalier"}
{"word": ["Reservoir."], "author": "Hickory"}
{"word": ["Dogs"], "author": "skimmie"}
{"word": ["Cats."], "author": "Casval_Deikun"}
{"word": ["Mice."], "author": "gixgox"}
{"word": [" Cheese."], "author": "LePerros"}
{"word": ["Cake"], "author": "blakstar"}
{"word": ["Crumbs."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["Graham."], "author": "Narcia_"}
{"word": ["Cracker"], "author": "Zoltan999"}
{"word": ["Cheese"], "author": "Yezemin"}
{"word": ["Burger."], "author": "gixgox"}
{"word": ["King"], "author": "cose_vecchie"}
{"word": ["Crown."], "author": "Hickory"}
{"word": ["Gold"], "author": "Dawnreader"}
{"word": ["doubloon"], "author": "Ardal"}
{"word": ["Treasure."], "author": "gixgox"}
{"word": ["island"], "author": "GabesterOne"}
{"word": ["Oasis."], "author": "Hickory"}
{"word": ["respite"], "author": "Dzsono"}
{"word": ["vacation"], "author": "GabesterOne"}
{"word": ["Recess."], "author": "REDVWIN"}
{"word": ["Hollow."], "author": "Hickory"}
{"word": ["Empty"], "author": "Yezemin"}
{"word": ["Bucket."], "author": "gixgox"}
{"word": ["flowers"], "author": "apehater"}
{"word": ["Funeral"], "author": "TARFU"}
{"word": ["Death."], "author": "ShadowPatriarch"}
{"word": ["Murderer."], "author": "Kleetus"}
{"word": ["Criminal"], "author": "agentcarr16"}
{"word": ["Smooth"], "author": "tinyE"}
{"word": ["Operator."], "author": "Kleetus"}
{"word": [], "author": "AndreaLebowski"}
{"word": ["Sex."], "author": "Kleetus"}
{"word": ["Expensive."], "author": "Tauto"}
{"word": ["Credit."], "author": "Kleetus"}
{"word": ["None."], "author": "Tauto"}
{"word": ["Steal."], "author": "Kleetus"}
{"word": ["Jail."], "author": "Tauto"}
{"word": ["showers"], "author": "GabesterOne"}
{"word": ["soap."], "author": "Tauto"}
{"word": ["Palmolive."], "author": "Kleetus"}
{"word": ["Sux."], "author": "Tauto"}
{"word": ["Dyson."], "author": "Kleetus"}
{"word": ["razor"], "author": "GabesterOne"}
{"word": ["Gang."], "author": "Kleetus"}
{"word": [" Blades"], "author": "gixgox"}
{"word": [" German."], "author": "Kleetus"}
{"word": ["nazi"], "author": "GabesterOne"}
{"word": [" Skates."], "author": "Hickory"}
{"word": ["Ice."], "author": "Kleetus"}
{"word": ["baby"], "author": "GabesterOne"}
{"word": ["Puppy."], "author": "Kleetus"}
{"word": ["Bite."], "author": "Tauto"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": [" Diaper."], "author": "gixgox"}
{"word": ["Change."], "author": "Hickory"}
{"word": ["revolution"], "author": "Dzsono"}
{"word": ["Russian"], "author": "GabesterOne"}
{"word": ["Walkin'"], "author": "Kleetus"}
{"word": [" Vodka"], "author": "TARFU"}
{"word": [], "author": "truhlik"}
{"word": ["Total"], "author": "park_84"}
{"word": ["Recall."], "author": "Kleetus"}
{"word": ["forgot."], "author": "Tauto"}
{"word": ["Dementia."], "author": "Kleetus"}
{"word": ["Demented."], "author": "xieliming"}
{"word": ["deranged"], "author": "Dzsono"}
{"word": ["range"], "author": "Ritualisto"}
{"word": [" ", " ", " Volume."], "author": "gixgox"}
{"word": ["cubic"], "author": "le_chevalier"}
{"word": ["reciprocity"], "author": "Ardal"}
{"word": ["Sharing."], "author": "ShadowPatriarch"}
{"word": ["Collaborating."], "author": "Narcia_"}
{"word": ["Collusion"], "author": "TDP"}
{"word": ["conspiracy"], "author": "GabesterOne"}
{"word": ["Theory"], "author": "Zoltan999"}
{"word": ["game"], "author": "GabesterOne"}
{"word": ["Poacher"], "author": "Allinstein"}
{"word": ["criminal"], "author": "le_chevalier"}
{"word": ["Villain"], "author": "Emob78"}
{"word": ["Steam."], "author": "Kleetus"}
{"word": [" Miscreant."], "author": "gixgox"}
{"word": ["Delinquent."], "author": "Hickory"}
{"word": ["Evildoer."], "author": "REDVWIN"}
{"word": ["Malfeasant. ", " ", " ", " Mornin' Hickory."], "author": "Kleetus"}
{"word": [" Criminal"], "author": "TARFU"}
{"word": ["Capone"], "author": "agentcarr16"}
{"word": ["Fedora"], "author": "Charon121"}
{"word": ["Linux."], "author": "Kleetus"}
{"word": [" Trilby."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Bowler."], "author": "gixgox"}
{"word": ["Linux."], "author": "Kleetus"}
{"word": [" Fez."], "author": "Hickory"}
{"word": ["Morrocco"], "author": "TARFU"}
{"word": ["Casablanca."], "author": "Kleetus"}
{"word": [" Maghreb."], "author": "gixgox"}
{"word": ["Berlin."], "author": "Kleetus"}
{"word": [" Sunset."], "author": "Hickory"}
{"word": [" Darkness"], "author": "LesterKnight99"}
{"word": ["The"], "author": "Cavenagh"}
{"word": ["Mask"], "author": "GabesterOne"}
{"word": ["concealment"], "author": "Dzsono"}
{"word": ["gun"], "author": "GabesterOne"}
{"word": ["weapon"], "author": "TARFU"}
{"word": ["War"], "author": "park_84"}
{"word": ["death"], "author": "JinKazaragi"}
{"word": ["Metal."], "author": "xieliming"}
{"word": ["forge"], "author": "Smogg"}
{"word": ["gold"], "author": "Ritualisto"}
{"word": ["Midas"], "author": "JDelekto"}
{"word": ["touch"], "author": "enurbenur"}
{"word": ["caress"], "author": "Dzsono"}
{"word": ["Stroke."], "author": "Hickory"}
{"word": ["pet"], "author": "ashwald"}
{"word": ["fur"], "author": "Ardal"}
{"word": ["bear"], "author": "camplify"}
{"word": ["Cub."], "author": "Narcia_"}
{"word": ["Chicago"], "author": "GabesterOne"}
{"word": ["city"], "author": "Ritualisto"}
{"word": ["Hunter."], "author": "Ikarugamesh"}
{"word": ["XYZ"], "author": "Narcia_"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": ["dog"], "author": "GabesterOne"}
{"word": [" "], "author": "gixgox"}
{"word": ["tempeh"], "author": "le_chevalier"}
{"word": ["Soy"], "author": "TDP"}
{"word": ["Sauce"], "author": "TARFU"}
{"word": ["tomato"], "author": "deathrabit"}
{"word": ["Fruit."], "author": "Hickory"}
{"word": ["pebbles"], "author": "GabesterOne"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": ["Flint. ", " "], "author": "gixgox"}
{"word": ["fire"], "author": "GabesterOne"}
{"word": ["Immolate."], "author": "Kleetus"}
{"word": [" Extinguisher."], "author": "gixgox"}
{"word": ["Douser."], "author": "Hickory"}
{"word": ["Immolate."], "author": "Kleetus"}
{"word": [" Doodlebug."], "author": "gixgox"}
{"word": ["Berlin."], "author": "Kleetus"}
{"word": ["Painting"], "author": "samuraigaiden"}
{"word": [" Woodlouse."], "author": "Hickory"}
{"word": ["Immolate."], "author": "Kleetus"}
{"word": [". ", " "], "author": "gixgox"}
{"word": ["king"], "author": "GabesterOne"}
{"word": ["Bradley."], "author": "Kleetus"}
{"word": ["Fuhrer."], "author": "Casval_Deikun"}
{"word": ["Kaiser"], "author": "le_chevalier"}
{"word": ["Emperor"], "author": "Yezemin"}
{"word": ["Last"], "author": "park_84"}
{"word": ["First"], "author": "deathrabit"}
{"word": ["Now."], "author": "Kleetus"}
{"word": [" Second."], "author": "gixgox"}
{"word": ["runner-up"], "author": "le_chevalier"}
{"word": ["Competition."], "author": "ShadowPatriarch"}
{"word": ["winner"], "author": "enurbenur"}
{"word": ["victory"], "author": "Yezemin"}
{"word": ["satisfaction"], "author": "Ardal"}
{"word": ["Pleasure."], "author": "xieliming"}
{"word": ["Dome."], "author": "Hickory"}
{"word": ["telescope"], "author": "GabesterOne"}
{"word": ["eye"], "author": "Ritualisto"}
{"word": ["glasses"], "author": "GabesterOne"}
{"word": ["Mugs."], "author": "Narcia_"}
{"word": ["Goblets."], "author": "Hickory"}
{"word": ["Grail"], "author": "Zoltan999"}
{"word": ["Chalice."], "author": "Hickory"}
{"word": ["Holy. ", " ", " ", " ", " ", " Cup."], "author": "ShadowPatriarch"}
{"word": ["Mug"], "author": "TARFU"}
{"word": ["mugwort"], "author": "ashwald"}
{"word": ["Wormwood."], "author": "Hickory"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": ["British"], "author": "GabesterOne"}
{"word": ["Terrier."], "author": "Kleetus"}
{"word": ["Puppy"], "author": "Pickle1477"}
{"word": ["Canine"], "author": "TARFU"}
{"word": ["Wormwood."], "author": "Hickory"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": ["Wormwood."], "author": "Hickory"}
{"word": ["Absinthe."], "author": "REDVWIN"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": [" Green"], "author": "TARFU"}
{"word": ["Pastures."], "author": "Hickory"}
{"word": ["Bovine."], "author": "Kleetus"}
{"word": [" Meadows."], "author": "gixgox"}
{"word": ["green"], "author": "Ritualisto"}
{"word": ["Lantern."], "author": "gixgox"}
{"word": ["light"], "author": "GabesterOne"}
{"word": ["flickering"], "author": "Ardal"}
{"word": ["Hickoring."], "author": "Kleetus"}
{"word": ["Kleetusoring"], "author": "Tauto"}
{"word": ["Dickoring."], "author": "Kleetus"}
{"word": [" Flare."], "author": "gixgox"}
{"word": ["Emergency"], "author": "TARFU"}
{"word": [" Fackel."], "author": "Kleetus"}
{"word": [" Beacon."], "author": "Hickory"}
{"word": [" Lighthouse"], "author": "TARFU"}
{"word": ["Keeper."], "author": "Hickory"}
{"word": ["sweeper"], "author": "apehater"}
{"word": ["Peeper."], "author": "Kleetus"}
{"word": [" Street"], "author": "TARFU"}
{"word": ["beat"], "author": "apehater"}
{"word": ["Masturbate."], "author": "Kleetus"}
{"word": [" Rhythm."], "author": "Hickory"}
{"word": ["Repetition."], "author": "REDVWIN"}
{"word": ["Masturbation."], "author": "Kleetus"}
{"word": [" Futility"], "author": "TARFU"}
{"word": [" Absurdity."], "author": "gixgox"}
{"word": [" Abstractity."], "author": "Kleetus"}
{"word": [" Folly."], "author": "Hickory"}
{"word": [" Follicle."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": [" Follicles."], "author": "Kleetus"}
{"word": ["Mr e."], "author": "Tauto"}
{"word": ["Hickoree."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Beatles"], "author": "GabesterOne"}
{"word": ["Dung."], "author": "Kleetus"}
{"word": ["fertilizer"], "author": "GabesterOne"}
{"word": ["Manure."], "author": "Kleetus"}
{"word": [" nitrate"], "author": "Dzsono"}
{"word": ["Potash."], "author": "Hickory"}
{"word": ["Manure."], "author": "Kleetus"}
{"word": ["ground"], "author": "deathrabit"}
{"word": ["sky"], "author": "camplify"}
{"word": ["Freedom"], "author": "Yezemin"}
{"word": ["Liberty"], "author": "park_84"}
{"word": ["independence"], "author": "le_chevalier"}
{"word": ["illusion"], "author": "doctorsinister"}
{"word": ["Trick."], "author": "Hickory"}
{"word": ["Edited."], "author": "Kleetus"}
{"word": ["post"], "author": "Ritualisto"}
{"word": ["Script"], "author": "PsyRabbit"}
{"word": ["Writer."], "author": "ShadowPatriarch"}
{"word": ["JerkMuter\u2122."], "author": "Kleetus"}
{"word": [" Author."], "author": "Hickory"}
{"word": ["works"], "author": "Ardal"}
{"word": ["Opus."], "author": "gixgox"}
{"word": ["Oeuvre."], "author": "Hickory"}
{"word": ["Chef."], "author": "Narcia_"}
{"word": ["cuisine"], "author": "skimmie"}
{"word": [], "author": "gixgox"}
{"word": ["Famished."], "author": "Hickory"}
{"word": [" Starving."], "author": "ShadowPatriarch"}
{"word": ["emaciation"], "author": "Dzsono"}
{"word": ["thinness"], "author": "Accatone"}
{"word": ["thickness"], "author": "apehater"}
{"word": ["Measurement"], "author": "TARFU"}
{"word": ["[Ninja'd] ", " ", " Size."], "author": "Hickory"}
{"word": ["matters"], "author": "GabesterOne"}
{"word": ["Girth"], "author": "Kleetus"}
{"word": ["geometry"], "author": "BlackDawn"}
{"word": ["Testicles."], "author": "Kleetus"}
{"word": [" Trigonometry."], "author": "Hickory"}
{"word": ["Testicles."], "author": "Kleetus"}
{"word": [" Trigonometry."], "author": "Hickory"}
{"word": ["calculus"], "author": "GabesterOne"}
{"word": ["Testiculus."], "author": "Kleetus"}
{"word": [" Algebra."], "author": "Hickory"}
{"word": ["Arithmetic."], "author": "gixgox"}
{"word": ["Testictic."], "author": "Kleetus"}
{"word": [" Quantity."], "author": "Hickory"}
{"word": ["Testity."], "author": "Kleetus"}
{"word": [" Quantity."], "author": "Hickory"}
{"word": ["Testity."], "author": "Kleetus"}
{"word": [" Measure."], "author": "gixgox"}
{"word": ["Testiture."], "author": "Kleetus"}
{"word": [" Quantify."], "author": "Hickory"}
{"word": ["Testitty."], "author": "Kleetus"}
{"word": [" Quantify."], "author": "Hickory"}
{"word": ["Hicktify."], "author": "Kleetus"}
{"word": [" Gauging."], "author": "gixgox"}
{"word": ["Hicking."], "author": "Kleetus"}
{"word": [" Calculating."], "author": "Hickory"}
{"word": [" Evaluating."], "author": "gixgox"}
{"word": ["Hickating."], "author": "Kleetus"}
{"word": [" Appraising."], "author": "Hickory"}
{"word": ["Hicksing."], "author": "Kleetus"}
{"word": [" Valuing"], "author": "gixgox"}
{"word": ["estimating"], "author": "le_chevalier"}
{"word": ["projecting"], "author": "Dzsono"}
{"word": ["Extrapolating."], "author": "Hickory"}
{"word": ["Approximation."], "author": "Casval_Deikun"}
{"word": ["Estimate"], "author": "Yezemin"}
{"word": ["Margin"], "author": "park_84"}
{"word": ["Border."], "author": "Hickory"}
{"word": [], "author": "AndreaLebowski"}
{"word": ["dog"], "author": "Ritualisto"}
{"word": ["Cat"], "author": "Azrael360"}
{"word": ["Flea."], "author": "Hickory"}
{"word": ["bass"], "author": "XYCat"}
{"word": ["fishing"], "author": "Ardal"}
{"word": ["rod"], "author": "cose_vecchie"}
{"word": ["pole"], "author": "skimmie"}
{"word": ["Vault."], "author": "Hickory"}
{"word": ["burial"], "author": "cose_vecchie"}
{"word": ["shoveling (", ")"], "author": "GabesterOne"}
{"word": [], "author": "Zoltan999"}
{"word": ["."], "author": "Hickory"}
{"word": ["Rangers"], "author": "Yezemin"}
{"word": ["Zordon"], "author": "ashwald"}
{"word": [" Keeper."], "author": "Hickory"}
{"word": ["bee ( :) )"], "author": "GabesterOne"}
{"word": ["Hive"], "author": "TARFU"}
{"word": ["Mind."], "author": "Hickory"}
{"word": ["Skull."], "author": "REDVWIN"}
{"word": ["Head"], "author": "PaterAlf"}
{"word": ["Hunter."], "author": "Hickory"}
{"word": ["Terrier."], "author": "Kleetus"}
{"word": ["Dog"], "author": "deathrabit"}
{"word": ["cat"], "author": "Ritualisto"}
{"word": ["Vermin."], "author": "Hickory"}
{"word": ["rodent"], "author": "Ardal"}
{"word": ["hedgehog"], "author": "GabesterOne"}
{"word": ["Shrubpig."], "author": "Kleetus"}
{"word": ["boar"], "author": "GabesterOne"}
{"word": ["Drillpig."], "author": "Kleetus"}
{"word": [" Incisor."], "author": "Hickory"}
{"word": ["Toothpig."], "author": "Kleetus"}
{"word": ["Toothbrush"], "author": "TDP"}
{"word": ["Toothpaste"], "author": "TARFU"}
{"word": ["Dentalpig."], "author": "Kleetus"}
{"word": [" Mint."], "author": "Hickory"}
{"word": ["Spearpig."], "author": "Kleetus"}
{"word": ["roasted"], "author": "GabesterOne"}
{"word": ["Pork"], "author": "agentcarr16"}
{"word": ["RoastedPorkPig."], "author": "Kleetus"}
{"word": ["Bacon"], "author": "coryrj1995"}
{"word": ["heavenly"], "author": "Dzsono"}
{"word": ["stellar"], "author": "le_chevalier"}
{"word": ["GalacticPig."], "author": "Kleetus"}
{"word": [" Galaxy"], "author": "TARFU"}
{"word": ["UniversalPig."], "author": "Kleetus"}
{"word": ["Cosmic"], "author": "park_84"}
{"word": ["Funeral"], "author": "Stooner"}
{"word": ["DeadPig."], "author": "Kleetus"}
{"word": ["Burial"], "author": "skimmie"}
{"word": ["Ground"], "author": "Yezemin"}
{"word": ["Pound"], "author": "drevo2"}
{"word": ["Tenderize"], "author": "Zoltan999"}
{"word": ["meat"], "author": "Ardal"}
{"word": ["Protein."], "author": "Hickory"}
{"word": ["muscle"], "author": "GabesterOne"}
{"word": ["Mass."], "author": "Narcia_"}
{"word": ["Effect."], "author": "Hickory"}
{"word": ["reaper"], "author": "GabesterOne"}
{"word": ["."], "author": "gixgox"}
{"word": ["Discordant."], "author": "Hickory"}
{"word": ["dissonant"], "author": "Dzsono"}
{"word": ["Inharmonious"], "author": "TARFU"}
{"word": ["Cacophonous."], "author": "agentcarr16"}
{"word": ["Jarring."], "author": "gixgox"}
{"word": ["Anal."], "author": "Kleetus"}
{"word": ["Plug"], "author": "Hardrada"}
{"word": ["charger"], "author": "GabesterOne"}
{"word": ["Dodge"], "author": "TARFU"}
{"word": [" Shocking."], "author": "Hickory"}
{"word": ["System."], "author": "xieliming"}
{"word": ["Analspasm."], "author": "Kleetus"}
{"word": ["butt"], "author": "camplify"}
{"word": ["rectum"], "author": "GabesterOne"}
{"word": ["exit"], "author": "Dzsono"}
{"word": ["door"], "author": "deathrabit"}
{"word": ["Stage"], "author": "Kleetus"}
{"word": ["building"], "author": "GabesterOne"}
{"word": ["House"], "author": "luter007"}
{"word": ["Erection."], "author": "Kleetus"}
{"word": ["hard"], "author": "Ritualisto"}
{"word": ["boiled"], "author": "Ardal"}
{"word": ["cabbage"], "author": "cose_vecchie"}
{"word": ["Sauerkraut."], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["Mash."], "author": "Narcia_"}
{"word": ["bash"], "author": "GabesterOne"}
{"word": ["dash"], "author": "DrakoPensulo"}
{"word": ["Hyphen."], "author": "Hickory"}
{"word": ["Semicolon."], "author": "gixgox"}
{"word": ["Punctuation"], "author": "TARFU"}
{"word": ["Exclamation!"], "author": "Kleetus"}
{"word": [], "author": "truhlik"}
{"word": ["Conflagration"], "author": "TARFU"}
{"word": ["Immolation."], "author": "Kleetus"}
{"word": ["scorch"], "author": "Dzsono"}
{"word": ["Borderlands."], "author": "Kleetus"}
{"word": ["Game."], "author": "xieliming"}
{"word": ["Willing."], "author": "Kleetus"}
{"word": ["Smithing"], "author": "park_84"}
{"word": ["forging"], "author": "Dzsono"}
{"word": ["Sword"], "author": "deathrabit"}
{"word": ["Draugr."], "author": "Antimateria"}
{"word": ["Undead."], "author": "xieliming"}
{"word": ["necromancer"], "author": "luter007"}
{"word": [], "author": "AndreaLebowski"}
{"word": ["Ghoul."], "author": "gixgox"}
{"word": ["Belmont."], "author": "Antimateria"}
{"word": ["city"], "author": "Ritualisto"}
{"word": ["crowded"], "author": "Smogg"}
{"word": ["places"], "author": "Ardal"}
{"word": ["Spaces."], "author": "Narcia_"}
{"word": ["Areas."], "author": "Hickory"}
{"word": ["spots"], "author": "ashwald"}
{"word": ["Sun"], "author": "Zoltan999"}
{"word": ["Flares."], "author": "gixgox"}
{"word": ["Signals."], "author": "Hickory"}
{"word": ["Beacon"], "author": "s_a"}
{"word": ["light"], "author": "Zordu"}
{"word": ["darkness"], "author": "SamMagel"}
{"word": ["night"], "author": "GabesterOne"}
{"word": [], "author": "gixgox"}
{"word": [], "author": "skimmie"}
{"word": ["Resin"], "author": "TARFU"}
{"word": ["Sperm."], "author": "Kleetus"}
{"word": [" Amber."], "author": "Hickory"}
{"word": ["Sperm."], "author": "Kleetus"}
{"word": [" Colophony."], "author": "gixgox"}
{"word": ["Varnish."], "author": "Hickory"}
{"word": ["Carpentry"], "author": "TARFU"}
{"word": ["Totem."], "author": "REDVWIN"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": [" Pole."], "author": "gixgox"}
{"word": ["Vault."], "author": "Hickory"}
{"word": ["Erection."], "author": "Kleetus"}
{"word": ["dead"], "author": "kmonster"}
{"word": ["walking"], "author": "Dzsono"}
{"word": ["Land."], "author": "Casval_Deikun"}
{"word": ["owner"], "author": "le_chevalier"}
{"word": ["Buyer"], "author": "TARFU"}
{"word": ["Customer"], "author": "park_84"}
{"word": ["Prostitute."], "author": "Kleetus"}
{"word": [" Patron."], "author": "Hickory"}
{"word": ["Saint"], "author": "TARFU"}
{"word": [" Prostitute."], "author": "Kleetus"}
{"word": [" Hallow."], "author": "gixgox"}
{"word": ["empty"], "author": "Ritualisto"}
{"word": [" Sanctify."], "author": "Hickory"}
{"word": ["Cleanse."], "author": "Narcia_"}
{"word": ["beatify ", " ", " ninja'd ", " ", " juice"], "author": "le_chevalier"}
{"word": [" Disinfect."], "author": "Hickory"}
{"word": ["Exterminate"], "author": "Zoltan999"}
{"word": ["roach"], "author": "Ardal"}
{"word": [" Annihilate."], "author": "Hickory"}
{"word": ["collide"], "author": "Dzsono"}
{"word": ["Impact"], "author": "TARFU"}
{"word": ["Crater."], "author": "semigroups"}
{"word": ["Volcano."], "author": "REDVWIN"}
{"word": ["lava"], "author": "Zordu"}
{"word": ["Spermatozoa."], "author": "Kleetus"}
{"word": ["seed"], "author": "deathrabit"}
{"word": [], "author": "BenKii"}
{"word": ["flower"], "author": "luter007"}
{"word": ["Rose"], "author": "TARFU"}
{"word": ["pink"], "author": "le_chevalier"}
{"word": ["Vagina."], "author": "Kleetus"}
{"word": [" Hot"], "author": "Dzsono"}
{"word": ["\u0421old."], "author": "Casval_Deikun"}
{"word": ["Ice"], "author": "TARFU"}
{"word": [" Vagina."], "author": "Kleetus"}
{"word": [" Winter"], "author": "deathrabit"}
{"word": ["Snow"], "author": "park_84"}
{"word": ["ColdVagina."], "author": "Kleetus"}
{"word": ["warm"], "author": "Ritualisto"}
{"word": [" White."], "author": "Hickory"}
{"word": ["Witch"], "author": "le_chevalier"}
{"word": ["Doctor"], "author": "litildivil"}
{"word": ["Who"], "author": "skimmie"}
{"word": ["edit because ninja'd ", " ", " Unknown"], "author": "Yezemin"}
{"word": ["Mystery."], "author": "Hickory"}
{"word": ["Rumor."], "author": "gixgox"}
{"word": ["hearsay"], "author": "le_chevalier"}
{"word": ["Gossip."], "author": "Narcia_"}
{"word": ["Grapevine."], "author": "gixgox"}
{"word": ["Wine."], "author": "ShadowPatriarch"}
{"word": ["Cellar"], "author": "Zoltan999"}
{"word": ["Cask."], "author": "REDVWIN"}
{"word": ["Coffin."], "author": "Hickory"}
{"word": ["Box"], "author": "koima57"}
{"word": ["boxing"], "author": "Accatone"}
{"word": ["Day."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["moon"], "author": "Ardal"}
{"word": ["Full"], "author": "TARFU"}
{"word": ["whole"], "author": "ashwald"}
{"word": ["Part."], "author": "Hickory"}
{"word": ["Component."], "author": "xieliming"}
{"word": ["Fragment"], "author": "TARFU"}
{"word": ["Piece"], "author": "Azrael360"}
{"word": ["Puzzle."], "author": "Hickory"}
{"word": ["Conundrum."], "author": "Kleetus"}
{"word": ["Riddle"], "author": "agentcarr16"}
{"word": ["Mystery"], "author": "TARFU"}
{"word": ["caper"], "author": "Dzsono"}
{"word": ["Escapade."], "author": "Narcia_"}
{"word": ["Antics"], "author": "TARFU"}
{"word": ["tomfoolery"], "author": "le_chevalier"}
{"word": ["Jewellery"], "author": "Cavenagh"}
{"word": ["Diamond"], "author": "park_84"}
{"word": ["Shiny"], "author": "Yezemin"}
{"word": ["Nickel"], "author": "HyperSuplex"}
{"word": [" ..."], "author": "gixgox"}
{"word": ["Side."], "author": "Hickory"}
{"word": ["up"], "author": "Ritualisto"}
{"word": ["Erect."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Erect."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Erect."], "author": "Kleetus"}
{"word": ["Begone!"], "author": "Chandoraa"}
{"word": [" Home."], "author": "Hickory"}
{"word": [" "], "author": "gixgox"}
{"word": ["dreams"], "author": "skimmie"}
{"word": ["Nightmare"], "author": "Azrael360"}
{"word": ["Surreal"], "author": "TDP"}
{"word": ["Bizarre."], "author": "Hickory"}
{"word": ["flabbergasted"], "author": "Ardal"}
{"word": ["Astonished"], "author": "TARFU"}
{"word": ["Surprised."], "author": "REDVWIN"}
{"word": ["Husband ", " ", " * When he see his wife + ......"], "author": "deathrabit"}
{"word": ["Cuckold."], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["Forgiving."], "author": "xieliming"}
{"word": ["Acceptance."], "author": "gixgox"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": [" Repentance"], "author": "SamMagel"}
{"word": ["Repenisance."], "author": "Kleetus"}
{"word": [" morals"], "author": "Dzsono"}
{"word": ["character"], "author": "JDelekto"}
{"word": ["Actor"], "author": "TARFU"}
{"word": ["goal"], "author": "kmonster"}
{"word": [" Thespian."], "author": "Hickory"}
{"word": [" Lesbian."], "author": "Kleetus"}
{"word": [" Thespian."], "author": "Hickory"}
{"word": ["histrionic"], "author": "park_84"}
{"word": [" Homosexual."], "author": "Kleetus"}
{"word": [" Melodramatic."], "author": "ShadowPatriarch"}
{"word": ["Homosexual."], "author": "Kleetus"}
{"word": [" Tragic"], "author": "Yezemin"}
{"word": ["feeling"], "author": "Ritualisto"}
{"word": ["Empathy."], "author": "Hickory"}
{"word": ["Sympathy"], "author": "Zoltan999"}
{"word": [], "author": "gixgox"}
{"word": ["Imp"], "author": "TARFU"}
{"word": ["Game"], "author": "JunglePredator"}
{"word": ["Play."], "author": "Narcia_"}
{"word": ["start"], "author": "Ardal"}
{"word": ["Finish"], "author": "Pickle1477"}
{"word": ["End"], "author": "JunglePredator"}
{"word": ["The."], "author": "xieliming"}
{"word": ["Definitive"], "author": "JunglePredator"}
{"word": ["Conclusive."], "author": "Hickory"}
{"word": ["valid"], "author": "Ritualisto"}
{"word": ["Dictionary"], "author": "JunglePredator"}
{"word": ["full"], "author": "kmonster"}
{"word": ["Shit."], "author": "Kleetus"}
{"word": [" Empty"], "author": "TARFU"}
{"word": [" Bowel."], "author": "Kleetus"}
{"word": [" ...- headed"], "author": "gixgox"}
{"word": [" Arrow"], "author": "JunglePredator"}
{"word": ["flight"], "author": "Dzsono"}
{"word": ["bumblebee"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": ["Nothing"], "author": "JunglePredator"}
{"word": ["Zero"], "author": "TARFU"}
{"word": ["love"], "author": "le_chevalier"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Vial"], "author": "Yezemin"}
{"word": ["Phial."], "author": "Hickory"}
{"word": ["quaff"], "author": "Dzsono"}
{"word": ["Potion."], "author": "Hickory"}
{"word": ["cauldron"], "author": "park_84"}
{"word": ["Kettle"], "author": "Zoltan999"}
{"word": ["Pot."], "author": "gixgox"}
{"word": ["plant"], "author": "ashwald"}
{"word": [" (it's recursive but I actually think Pot when I hear plant since we don't have a garden only potted plants here -.-;; So instead:) ", " ", " Allergies"], "author": "JunglePredator"}
{"word": ["Tears."], "author": "gixgox"}
{"word": [" Pain."], "author": "JunglePredator"}
{"word": ["Chronic :("], "author": "gixgox"}
{"word": ["Back ache"], "author": "JunglePredator"}
{"word": ["chiropractic"], "author": "le_chevalier"}
{"word": ["armstrong"], "author": "JunglePredator"}
{"word": ["space"], "author": "s_a"}
{"word": ["empty"], "author": "JunglePredator"}
{"word": ["full"], "author": "_brokensword_"}
{"word": ["Sated."], "author": "Hickory"}
{"word": ["Comfortable."], "author": "Narcia_"}
{"word": ["Lazy boy"], "author": "JunglePredator"}
{"word": [" ", " Fail."], "author": "Hickory"}
{"word": ["\u0421ollapse"], "author": "s_a"}
{"word": ["Downfall"], "author": "Yezemin"}
{"word": ["Plummet"], "author": "TARFU"}
{"word": ["Plunge."], "author": "Hickory"}
{"word": ["You"], "author": "Cavenagh"}
{"word": ["Plunge."], "author": "Hickory"}
{"word": ["You"], "author": "Cavenagh"}
{"word": ["Plunge."], "author": "Hickory"}
{"word": ["Plumber"], "author": "TARFU"}
{"word": ["Callout."], "author": "Hickory"}
{"word": ["loud"], "author": "Ritualisto"}
{"word": ["bang"], "author": "ashwald"}
{"word": ["Boom."], "author": "Hickory"}
{"word": [], "author": "cose_vecchie"}
{"word": ["Painful."], "author": "Hickory"}
{"word": ["Orgasm."], "author": "Kleetus"}
{"word": ["Painful."], "author": "Hickory"}
{"word": [" Movie"], "author": "JunglePredator"}
{"word": [" Anal."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["film"], "author": "kmonster"}
{"word": ["Classic ", " ", " :-)"], "author": "JunglePredator"}
{"word": ["Timeless"], "author": "TARFU"}
{"word": ["evergreen"], "author": "Dzsono"}
{"word": ["Green."], "author": "Casval_Deikun"}
{"word": ["rookie"], "author": "le_chevalier"}
{"word": ["Hockey"], "author": "JunglePredator"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": [" Ice."], "author": "ShadowPatriarch"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": [" Slippery"], "author": "Yezemin"}
{"word": [" Thief"], "author": "JunglePredator"}
{"word": ["stealth"], "author": "park_84"}
{"word": ["Fisher"], "author": "JunglePredator"}
{"word": ["Whaler."], "author": "gixgox"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": ["Dishonored."], "author": "JunglePredator"}
{"word": ["Assassin"], "author": "Zoltan999"}
{"word": ["Creed"], "author": "Cavenagh"}
{"word": ["Hitman.", " ", " ", " ", " Conviction."], "author": "gixgox"}
{"word": ["Guilt"], "author": "cose_vecchie"}
{"word": ["Judge"], "author": "JunglePredator"}
{"word": ["dredd"], "author": "XYCat"}
{"word": ["Shopping ", " ", " (homonym association)"], "author": "JunglePredator"}
{"word": ["spree"], "author": "Ardal"}
{"word": ["Berlin"], "author": "Yezemin"}
{"word": ["Wall"], "author": "TARFU"}
{"word": ["Street."], "author": "xieliming"}
{"word": ["Erection."], "author": "Kleetus"}
{"word": ["Trees"], "author": "JunglePredator"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": ["dog"], "author": "Ritualisto"}
{"word": [" Parkway."], "author": "gixgox"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": [" Promenade"], "author": "TARFU"}
{"word": ["Dance"], "author": "Hardrada"}
{"word": ["Gown"], "author": "JunglePredator"}
{"word": ["Attire."], "author": "REDVWIN"}
{"word": ["Garment."], "author": "LoboBlanco"}
{"word": ["Latex."], "author": "Kleetus"}
{"word": [" Factory"], "author": "JunglePredator"}
{"word": ["Worker."], "author": "Hickory"}
{"word": ["laborer"], "author": "le_chevalier"}
{"word": ["Latex."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["coolie"], "author": "le_chevalier"}
{"word": ["Serf"], "author": "TARFU"}
{"word": ["Surf"], "author": "TDP"}
{"word": ["Gnarly."], "author": "Kleetus"}
{"word": [" Waves."], "author": "Hickory"}
{"word": ["Beach"], "author": "park_84"}
{"word": ["Whale"], "author": "Dzsono"}
{"word": [" Hello."], "author": "Kleetus"}
{"word": [" Blubber."], "author": "Hickory"}
{"word": ["Whale."], "author": "xieliming"}
{"word": ["Watching."], "author": "gixgox"}
{"word": [" ...Dickery... ", " ", " You... ", " ...Dock... ", " mouse... ", " Up... ", " Clock...."], "author": "takezodunmer2005"}
{"word": ["Nursery."], "author": "Narcia_"}
{"word": ["Rhyme"], "author": "Yezemin"}
{"word": [" Observation."], "author": "Hickory"}
{"word": [" Poem"], "author": "JunglePredator"}
{"word": ["Ode"], "author": "Zoltan999"}
{"word": ["odor"], "author": "apehater"}
{"word": ["Stench"], "author": "TARFU"}
{"word": ["Anus."], "author": "Kleetus"}
{"word": [" Foul."], "author": "ShadowPatriarch"}
{"word": [" Smelliness."], "author": "gixgox"}
{"word": [" Anus."], "author": "Kleetus"}
{"word": [" Miasma."], "author": "Hickory"}
{"word": [" Anus."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Night court."], "author": "JunglePredator"}
{"word": ["Bull"], "author": "TARFU"}
{"word": ["Bald"], "author": "JunglePredator"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": ["boring"], "author": "kmonster"}
{"word": ["Dock."], "author": "Kleetus"}
{"word": [" Wharf-whore"], "author": "takezodunmer2005"}
{"word": [" Pier-slut."], "author": "Kleetus"}
{"word": [" ignoring"], "author": "Dzsono"}
{"word": ["Whoring."], "author": "Kleetus"}
{"word": [" Dismiss."], "author": "Casval_Deikun"}
{"word": ["Reject"], "author": "park_84"}
{"word": ["game"], "author": "Ritualisto"}
{"word": ["Theory."], "author": "ShadowPatriarch"}
{"word": ["Chaos"], "author": "JunglePredator"}
{"word": ["order"], "author": "skimmie"}
{"word": ["Dr. Fate"], "author": "JunglePredator"}
{"word": [" Command."], "author": "Hickory"}
{"word": ["Conquer."], "author": "Chandoraa"}
{"word": ["Empire."], "author": "Narcia_"}
{"word": ["Earth."], "author": "Casval_Deikun"}
{"word": ["Moon"], "author": "tinyE"}
{"word": ["."], "author": "gixgox"}
{"word": ["Waterfall."], "author": "Hickory"}
{"word": ["rainfall"], "author": "le_chevalier"}
{"word": ["Precipitation"], "author": "TARFU"}
{"word": ["Crystallization"], "author": "tort1234"}
{"word": ["Quartz"], "author": "TARFU"}
{"word": ["Amethyst."], "author": "Kleetus"}
{"word": [" Zinc"], "author": "tinyE"}
{"word": [" Everyone, please rise. ", " ", " Good Mornin' Mr e."], "author": "Kleetus"}
{"word": [" Gallium."], "author": "gixgox"}
{"word": [" Xenon"], "author": "TARFU"}
{"word": ["noble"], "author": "Dzsono"}
{"word": ["Titled."], "author": "Hickory"}
{"word": ["Titted."], "author": "Kleetus"}
{"word": [" Inscribed."], "author": "gixgox"}
{"word": ["Titted."], "author": "Kleetus"}
{"word": [" Chiseled"], "author": "TARFU"}
{"word": ["Carved."], "author": "Hickory"}
{"word": ["Titted."], "author": "Kleetus"}
{"word": [" Engraved."], "author": "gixgox"}
{"word": ["Titted."], "author": "Kleetus"}
{"word": [" Silver"], "author": "JunglePredator"}
{"word": [" Gold"], "author": "TARFU"}
{"word": ["Star"], "author": "JunglePredator"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Galaxy"], "author": "TARFU"}
{"word": ["Dickoraxy."], "author": "Kleetus"}
{"word": ["Cluster. ", " "], "author": "gixgox"}
{"word": ["Dickoruster."], "author": "Kleetus"}
{"word": [" Barnacles."], "author": "JunglePredator"}
{"word": ["Dickoricles."], "author": "Kleetus"}
{"word": [" Half-Life"], "author": "TARFU"}
{"word": ["Valve ", " ", " -.-;;"], "author": "JunglePredator"}
{"word": ["Steam."], "author": "Casval_Deikun"}
{"word": ["Newell."], "author": "Kleetus"}
{"word": ["human"], "author": "Ritualisto"}
{"word": ["anthropomorphic"], "author": "le_chevalier"}
{"word": ["Anthropoid."], "author": "Hickory"}
{"word": ["ape"], "author": "Ardal"}
{"word": ["Great"], "author": "Zoltan999"}
{"word": ["wall"], "author": "JunglePredator"}
{"word": ["Paper."], "author": "gixgox"}
{"word": ["hat"], "author": "JunglePredator"}
{"word": ["Head"], "author": "Yezemin"}
{"word": ["Skull"], "author": "flubbucket"}
{"word": [" ", " >It's a mystery why I always get ninjad...< ", " ", " ", " "], "author": "gixgox"}
{"word": ["Enigma."], "author": "Hickory"}
{"word": ["Riddle"], "author": "Yezemin"}
{"word": ["Adventure."], "author": "Casval_Deikun"}
{"word": ["Expedition."], "author": "Hickory"}
{"word": ["Journey."], "author": "Narcia_"}
{"word": ["trip."], "author": "skimmie"}
{"word": [], "author": "gixgox"}
{"word": ["Sail"], "author": "Pickle1477"}
{"word": ["Breeze."], "author": "Hickory"}
{"word": ["cool"], "author": "XYCat"}
{"word": ["Cat"], "author": "Yezemin"}
{"word": ["Evil."], "author": "Hickory"}
{"word": ["Neoliberal..."], "author": "GhostwriterDoF"}
{"word": ["Political"], "author": "TARFU"}
{"word": ["Partisan."], "author": "Hickory"}
{"word": [" Enema."], "author": "Kleetus"}
{"word": ["Partisan."], "author": "Hickory"}
{"word": ["Guerrilla"], "author": "TARFU"}
{"word": ["Gorilla."], "author": "Kleetus"}
{"word": [" Warfare."], "author": "gixgox"}
{"word": ["Gorilla."], "author": "Kleetus"}
{"word": [" Conflict."], "author": "Hickory"}
{"word": [" Battle"], "author": "TARFU"}
{"word": ["Gorilla."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Gorilla."], "author": "Kleetus"}
{"word": [" Weep."], "author": "Hickory"}
{"word": ["Sob"], "author": "TARFU"}
{"word": ["Hickup."], "author": "Kleetus"}
{"word": [" tantrum"], "author": "Dzsono"}
{"word": ["whining"], "author": "GabesterOne"}
{"word": ["Dining."], "author": "Kleetus"}
{"word": [" Whinging."], "author": "Hickory"}
{"word": ["protest"], "author": "motorkar"}
{"word": ["object"], "author": "le_chevalier"}
{"word": ["class"], "author": "park_84"}
{"word": ["lesson"], "author": "Ritualisto"}
{"word": [" School/Tutor"], "author": "JunglePredator"}
{"word": ["mentor"], "author": "le_chevalier"}
{"word": ["Old"], "author": "JunglePredator"}
{"word": ["Hickster."], "author": "Kleetus"}
{"word": ["Hipster."], "author": "xieliming"}
{"word": ["Glasses"], "author": "Yezemin"}
{"word": ["Dioptre."], "author": "gixgox"}
{"word": ["optician"], "author": "Ardal"}
{"word": ["Obstetrician"], "author": "Zoltan999"}
{"word": ["Labour."], "author": "ShadowPatriarch"}
{"word": ["Baby"], "author": "Azrael360"}
{"word": ["boom"], "author": "Accatone"}
{"word": ["Explosion."], "author": "Hickory"}
{"word": ["Blast."], "author": "gixgox"}
{"word": ["Past."], "author": "skimmie"}
{"word": ["Recorded."], "author": "GhostwriterDoF"}
{"word": ["Archived."], "author": "Hickory"}
{"word": ["chronicled"], "author": "le_chevalier"}
{"word": ["Written."], "author": "Narcia_"}
{"word": ["literary"], "author": "Dzsono"}
{"word": ["Travel."], "author": "xieliming"}
{"word": ["Expedition. ", " Expedition."], "author": "ShadowPatriarch"}
{"word": ["Safari"], "author": "TARFU"}
{"word": ["Webkit."], "author": "Casval_Deikun"}
{"word": [" engine"], "author": "deathrabit"}
{"word": ["Grease."], "author": "Hickory"}
{"word": ["Monkey."], "author": "Kleetus"}
{"word": ["thumbs"], "author": "Ardal"}
{"word": ["fingers"], "author": "SamMagel"}
{"word": ["Digits."], "author": "Kleetus"}
{"word": [" Toes."], "author": "gixgox"}
{"word": ["Feet"], "author": "TARFU"}
{"word": [" nails"], "author": "Dzsono"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": [" Spikes."], "author": "gixgox"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Vampires."], "author": "JunglePredator"}
{"word": ["bats"], "author": "le_chevalier"}
{"word": ["Base ball"], "author": "JunglePredator"}
{"word": ["fun"], "author": "Ritualisto"}
{"word": [" Run For Fun"], "author": "JunglePredator"}
{"word": ["Forrest"], "author": "park_84"}
{"word": ["brace"], "author": "Dzsono"}
{"word": ["Framing."], "author": "JunglePredator"}
{"word": [" Echo."], "author": "Hickory"}
{"word": ["returning"], "author": "Ardal"}
{"word": ["Recur."], "author": "Hickory"}
{"word": ["Occur"], "author": "truhlik"}
{"word": ["Happen"], "author": "Zoltan999"}
{"word": [], "author": "JunglePredator"}
{"word": ["Event."], "author": "Hickory"}
{"word": ["Situation."], "author": "REDVWIN"}
{"word": [" ", " ", " ", " ", " ", " "], "author": "gixgox"}
{"word": [" "], "author": "JunglePredator"}
{"word": [" Rank."], "author": "ShadowPatriarch"}
{"word": ["Army"], "author": "Cavenagh"}
{"word": ["Force."], "author": "Hickory"}
{"word": ["Jedi"], "author": "TARFU"}
{"word": ["knight"], "author": "camplify"}
{"word": ["Chivalry."], "author": "Hickory"}
{"word": ["Code"], "author": "TARFU"}
{"word": ["Secret."], "author": "Narcia_"}
{"word": ["Society."], "author": "Hickory"}
{"word": ["Culture"], "author": "TARFU"}
{"word": ["Tradition."], "author": "Hickory"}
{"word": ["conservatism"], "author": "Dzsono"}
{"word": [" gentleman"], "author": "deathrabit"}
{"word": ["Inexplicable."], "author": "Hickory"}
{"word": ["Mystery"], "author": "VeTrack"}
{"word": ["Enigma"], "author": "TARFU"}
{"word": [" Edward"], "author": "JunglePredator"}
{"word": ["Teach"], "author": "tinyE"}
{"word": ["Instruct"], "author": "TARFU"}
{"word": [" Construct."], "author": "JunglePredator"}
{"word": ["Deconstruct"], "author": "SamMagel"}
{"word": [" psychic"], "author": "JunglePredator"}
{"word": ["mental"], "author": "TARFU"}
{"word": ["Cerebral."], "author": "LoboBlanco"}
{"word": ["Instinctual"], "author": "Dzsono"}
{"word": ["Intentional."], "author": "gixgox"}
{"word": ["Premeditated."], "author": "REDVWIN"}
{"word": ["Minority Report."], "author": "JunglePredator"}
{"word": ["Port."], "author": "Casval_Deikun"}
{"word": ["Ship"], "author": "JunglePredator"}
{"word": ["Cruiser"], "author": "TARFU"}
{"word": ["Kerb-crawler."], "author": "Kleetus"}
{"word": [" Aggh! I've been wanting to shout out Robotech for ages now cause of your avatar... but Cruiser actually makes me think of: ", " ", " Yamato."], "author": "JunglePredator"}
{"word": ["ship"], "author": "Ritualisto"}
{"word": ["airplane"], "author": "le_chevalier"}
{"word": ["Ticket"], "author": "Cavenagh"}
{"word": ["Kiosk."], "author": "Hickory"}
{"word": ["Booth."], "author": "gixgox"}
{"word": ["Phone"], "author": "Zoltan999"}
{"word": ["call"], "author": "cose_vecchie"}
{"word": [], "author": "gixgox"}
{"word": ["Perhaps"], "author": "Jus69"}
{"word": ["possibly"], "author": "mariabarring"}
{"word": ["Chance"], "author": "TARFU"}
{"word": ["Undecided."], "author": "Hickory"}
{"word": ["Ambivalent."], "author": "gixgox"}
{"word": ["Ambient"], "author": "mariabarring"}
{"word": [" Light"], "author": "JunglePredator"}
{"word": [], "author": "gixgox"}
{"word": ["Shiny."], "author": "Ikarugamesh"}
{"word": ["Lustrous."], "author": "Hickory"}
{"word": ["Brilliant."], "author": "ShadowPatriarch"}
{"word": ["Smart"], "author": "QuantumLeapFrog"}
{"word": ["Genius."], "author": "xieliming"}
{"word": ["genie"], "author": "Ardal"}
{"word": ["Elemental."], "author": "Hickory"}
{"word": ["element"], "author": "Accatone"}
{"word": ["dark"], "author": "kmonster"}
{"word": ["night"], "author": "TARFU"}
{"word": ["Batman"], "author": "xalegra"}
{"word": ["RatGirl."], "author": "Kleetus"}
{"word": [" Superman."], "author": "gixgox"}
{"word": [" Dieselwoman."], "author": "Kleetus"}
{"word": [" Kryptonite"], "author": "TARFU"}
{"word": ["Green"], "author": "tinyE"}
{"word": [" Mr e."], "author": "Kleetus"}
{"word": [" Lantern."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": ["sconce"], "author": "Dzsono"}
{"word": ["Fixture"], "author": "TARFU"}
{"word": ["Screw."], "author": "Kleetus"}
{"word": ["Bolt"], "author": "Jus69"}
{"word": ["Andrew."], "author": "Kleetus"}
{"word": ["Apostle"], "author": "dm36"}
{"word": [" Retail."], "author": "JunglePredator"}
{"word": [" Believer."], "author": "Kleetus"}
{"word": ["Faith."], "author": "xieliming"}
{"word": [" Hope"], "author": "Nemesis44UK"}
{"word": ["expectation"], "author": "le_chevalier"}
{"word": ["Wish"], "author": "Azrael360"}
{"word": [" Market."], "author": "Hickory"}
{"word": ["Economy."], "author": "gixgox"}
{"word": ["Broken."], "author": "Chandoraa"}
{"word": ["Back"], "author": "Licurg"}
{"word": ["burner"], "author": "skimmie"}
{"word": ["cellphone"], "author": "XYCat"}
{"word": ["Android"], "author": "Zoltan999"}
{"word": ["Robot."], "author": "Narcia_"}
{"word": ["Automation."], "author": "Hickory"}
{"word": ["Factory"], "author": "TARFU"}
{"word": ["Worker."], "author": "Hickory"}
{"word": ["Slave."], "author": "gixgox"}
{"word": ["Peasant"], "author": "TARFU"}
{"word": ["Serf."], "author": "Hickory"}
{"word": ["Serf."], "author": "ShadowPatriarch"}
{"word": ["Thrall"], "author": "TARFU"}
{"word": ["Vampire"], "author": "JunglePredator"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Politician (another kind of bloodsucker)"], "author": "xalegra"}
{"word": ["Bureaucrat"], "author": "TARFU"}
{"word": ["."], "author": "JunglePredator"}
{"word": ["Bear."], "author": "Kleetus"}
{"word": [], "author": "gixgox"}
{"word": [" Casablanca"], "author": "TARFU"}
{"word": ["Port."], "author": "Hickory"}
{"word": [" Whiskey"], "author": "JunglePredator"}
{"word": ["X-Ray"], "author": "agentcarr16"}
{"word": [" I don't get how you got there? ", " ", " "], "author": "JunglePredator"}
{"word": [" Phonetic alphabet: ", " ", " ...,Victor, Whiskey, X-Ray, Yankee, Zulu ", " ", " Also: ", " ", " ", " Steam"], "author": "agentcarr16"}
{"word": [" Punk"], "author": "TARFU"}
{"word": [" Brother. (He's not anymore... now he's right stand up but still reminds me of teen days :-p)"], "author": "JunglePredator"}
{"word": ["Big"], "author": "agentcarr16"}
{"word": ["Bang"], "author": "Jus69"}
{"word": ["\"#\" ", " ", " (I couldn't post # by itself)"], "author": "JunglePredator"}
{"word": [" Theory."], "author": "Kleetus"}
{"word": ["Hypothesis ", " ", " ", " I am not crazy, my mother had me tested :)"], "author": "Jus69"}
{"word": ["Hypotenuse"], "author": "park_84"}
{"word": ["Hyppopotemus."], "author": "Kleetus"}
{"word": [], "author": "sanscript"}
{"word": [" Hyperthyroidism."], "author": "Kleetus"}
{"word": [" Thump."], "author": "Hickory"}
{"word": ["Bump."], "author": "Narcia_"}
{"word": ["Lump"], "author": "Yezemin"}
{"word": ["Cancer"], "author": "JDelekto"}
{"word": [], "author": "gixgox"}
{"word": ["sign"], "author": "JDelekto"}
{"word": ["Portent."], "author": "Hickory"}
{"word": ["Omen"], "author": "Yezemin"}
{"word": ["prophecy"], "author": "JDelekto"}
{"word": ["charlatan"], "author": "noir_7"}
{"word": ["U.K. (yes I know that's technically not a word but I used to love that band)"], "author": "tinyE"}
{"word": ["discombobulation"], "author": "noir_7"}
{"word": ["Discomfiture."], "author": "Hickory"}
{"word": ["Drubbing."], "author": "gixgox"}
{"word": ["Punching"], "author": "noir_7"}
{"word": [], "author": "gixgox"}
{"word": ["sack"], "author": "noir_7"}
{"word": ["Potato."], "author": "Hickory"}
{"word": ["head"], "author": "noir_7"}
{"word": [], "author": "gixgox"}
{"word": ["Football."], "author": "Hickory"}
{"word": ["Sport"], "author": "TARFU"}
{"word": ["Channel"], "author": "almabrds"}
{"word": ["censored"], "author": "noir_7"}
{"word": ["Mosaic."], "author": "Ikarugamesh"}
{"word": ["Jehovah"], "author": "SamMagel"}
{"word": ["Iehovah.. also persona 4"], "author": "Antimateria"}
{"word": ["Witness."], "author": "Hickory"}
{"word": ["Kleetus."], "author": "Tauto"}
{"word": ["Witness."], "author": "Hickory"}
{"word": ["Hickster."], "author": "Kleetus"}
{"word": [" ", " "], "author": "gixgox"}
{"word": ["Hickster."], "author": "Kleetus"}
{"word": [" Death"], "author": "TARFU"}
{"word": ["Decay."], "author": "Hickory"}
{"word": ["Penalty.", " ", " ", " Dissolution."], "author": "gixgox"}
{"word": ["Hickster."], "author": "Kleetus"}
{"word": [" Disintegration"], "author": "TARFU"}
{"word": ["Decomposition."], "author": "Hickory"}
{"word": ["Hickster. ", " ", " Posted at the exact same time, it's serendipity."], "author": "Kleetus"}
{"word": ["Decomposition."], "author": "Hickory"}
{"word": ["Hickster (missed you, Hicks \u2665)."], "author": "Kleetus"}
{"word": [" Composition"], "author": "agentcarr16"}
{"word": [" deconstruction"], "author": "Dzsono"}
{"word": ["position"], "author": "noir_7"}
{"word": [" Reduction."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" doc"], "author": "noir_7"}
{"word": ["Physician"], "author": "TARFU"}
{"word": ["Medic"], "author": "Azrael360"}
{"word": ["Paramedic"], "author": "park_84"}
{"word": ["Ambulance"], "author": "JunglePredator"}
{"word": ["Siren"], "author": "Jus69"}
{"word": ["Shriek"], "author": "Antimateria"}
{"word": ["Banshee."], "author": "xieliming"}
{"word": ["Spirit."], "author": "ShadowPatriarch"}
{"word": ["vengeful"], "author": "le_chevalier"}
{"word": ["Unforgiving."], "author": "gixgox"}
{"word": ["forgiving"], "author": "camplify"}
{"word": ["giving"], "author": "noir_7"}
{"word": ["charity"], "author": "enurbenur"}
{"word": ["pity"], "author": "Dzsono"}
{"word": [], "author": "cose_vecchie"}
{"word": ["jester"], "author": "Ardal"}
{"word": ["Buffoon."], "author": "Hickory"}
{"word": ["Moron"], "author": "Zoltan999"}
{"word": ["Ignoramus."], "author": "Narcia_"}
{"word": ["deprived"], "author": "Dzsono"}
{"word": ["Lacking"], "author": "TARFU"}
{"word": ["Dearth."], "author": "Hickory"}
{"word": ["Hunger."], "author": "Casval_Deikun"}
{"word": ["Famine"], "author": "VeTrack"}
{"word": ["Death"], "author": "Casval_Deikun"}
{"word": ["[Ninja'd] ", " ", ". ", " ", " Mask."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": ["Mask."], "author": "Hickory"}
{"word": [" "], "author": "gixgox"}
{"word": ["Military."], "author": "REDVWIN"}
{"word": ["idiots"], "author": "SamMagel"}
{"word": ["fool"], "author": "Accatone"}
{"word": ["jester"], "author": "TARFU"}
{"word": ["clown"], "author": "le_chevalier"}
{"word": ["confetti"], "author": "DavidOrion93"}
{"word": ["Spaghetti."], "author": "Kleetus"}
{"word": [" rice"], "author": "Dzsono"}
{"word": ["Spaghetti."], "author": "Kleetus"}
{"word": ["Food"], "author": "park_84"}
{"word": ["tastes"], "author": "Madshaker"}
{"word": ["Spicy"], "author": "Yezemin"}
{"word": ["hot"], "author": "le_chevalier"}
{"word": ["humid"], "author": "skimmie"}
{"word": ["Muggy."], "author": "semigroups"}
{"word": ["Fuggy."], "author": "gixgox"}
{"word": [" Armpit"], "author": "Nemesis44UK"}
{"word": ["Funk"], "author": "flubbucket"}
{"word": ["Punk."], "author": "xieliming"}
{"word": ["Rock"], "author": "Zoltan999"}
{"word": ["Hard"], "author": "Yezemin"}
{"word": [" ...ware"], "author": "gixgox"}
{"word": ["Punisher."], "author": "JunglePredator"}
{"word": ["Fare"], "author": "Azrael360"}
{"word": ["Ferry"], "author": "JunglePredator"}
{"word": ["Boat"], "author": "Jus69"}
{"word": ["Float."], "author": "Hickory"}
{"word": ["Sink"], "author": "coryrj1995"}
{"word": ["kitchen"], "author": "skimmie"}
{"word": ["Chef."], "author": "gixgox"}
{"word": ["Hat."], "author": "Narcia_"}
{"word": ["bowler"], "author": "Dzsono"}
{"word": ["cricket"], "author": "cose_vecchie"}
{"word": ["."], "author": "gixgox"}
{"word": ["Locust."], "author": "Hickory"}
{"word": ["plague"], "author": "deathrabit"}
{"word": ["pestilence"], "author": "le_chevalier"}
{"word": ["Disease."], "author": "Hickory"}
{"word": ["Deceased"], "author": "Crappynuker1"}
{"word": ["Dead"], "author": "Yezemin"}
{"word": ["Defunct."], "author": "Hickory"}
{"word": ["extinct"], "author": "DavidOrion93"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Erasement."], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": ["Erasement."], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Demolition."], "author": "Hickory"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Demolition."], "author": "Hickory"}
{"word": [" "], "author": "gixgox"}
{"word": ["Dickory (love you, Hickster \u2665)."], "author": "Kleetus"}
{"word": [" Police."], "author": "Hickory"}
{"word": [" "], "author": "JunglePredator"}
{"word": [" Mr e home videos."], "author": "Kleetus"}
{"word": [" temperance"], "author": "Dzsono"}
{"word": [" Sobriety"], "author": "TARFU"}
{"word": ["seriousness"], "author": "park_84"}
{"word": ["Hickoryness."], "author": "Kleetus"}
{"word": ["Geez Kleetus, you are now on -.rep. How many people have you ticked off recently?"], "author": "Jus69"}
{"word": ["I think some of them have it in for me. ", " ", " No idea why though, I'm always polite and friendly. ", " ", " I only wish to partake in meaningless banter with my fellow forumites."], "author": "Kleetus"}
{"word": [" Maybe they do not get the Aussie humour :P"], "author": "Jus69"}
{"word": ["Batman"], "author": "doronnorod"}
{"word": ["joker"], "author": "Jus69"}
{"word": [" Just wondering, are you scared of me more now that I'm in negative?"], "author": "Kleetus"}
{"word": [" Lol.. Nope..should I be? ", " scared of you more? That implies I was scared of you in the first instance...Hmmm"], "author": "Jus69"}
{"word": ["Comedian"], "author": "Zoltan999"}
{"word": ["Clown"], "author": "JasmineMcCoy"}
{"word": ["Coulrophobia"], "author": "cose_vecchie"}
{"word": [" Pragmatism."], "author": "Hickory"}
{"word": ["Practical"], "author": "Jus69"}
{"word": ["usability"], "author": "Ardal"}
{"word": ["Value."], "author": "Narcia_"}
{"word": ["money"], "author": "cose_vecchie"}
{"word": ["currency"], "author": "skimmie"}
{"word": ["Cash"], "author": "Jus69"}
{"word": ["Flow"], "author": "cose_vecchie"}
{"word": ["river"], "author": "Jus69"}
{"word": ["."], "author": "Hickory"}
{"word": ["Frame"], "author": "skimmie"}
{"word": ["window"], "author": "JasmineMcCoy"}
{"word": ["Portal."], "author": "Hickory"}
{"word": ["Cake"], "author": "cose_vecchie"}
{"word": ["lie"], "author": "le_chevalier"}
{"word": ["Ruse"], "author": "Yezemin"}
{"word": ["Subterfuge."], "author": "Hickory"}
{"word": ["Centrifuge"], "author": "agentcarr16"}
{"word": ["laundry"], "author": "JasmineMcCoy"}
{"word": ["Spotless."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": ["dalmatian (dog)"], "author": "xalegra"}
{"word": ["Spot."], "author": "xieliming"}
{"word": ["Melanoma."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Melanoma."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Automaton."], "author": "Hickory"}
{"word": ["Humanisation (missed you, Hicks \u2665)."], "author": "Kleetus"}
{"word": ["consciousness"], "author": "Jus69"}
{"word": ["Collective."], "author": "REDVWIN"}
{"word": ["Incorporated"], "author": "Jus69"}
{"word": ["unified"], "author": "Dzsono"}
{"word": ["Federation"], "author": "Jus69"}
{"word": ["Revolution."], "author": "Kleetus"}
{"word": ["French"], "author": "park_84"}
{"word": ["Napoleon"], "author": "Jus69"}
{"word": [" Headjob. ", " ", " EDIT: I can get one for $20.00 (includes complimentary dribble and swallow). ", " ", " Make sure you tell them Kleetus sent you for a free squishy toy."], "author": "Kleetus"}
{"word": [" "], "author": "TDP"}
{"word": ["Vesuvius"], "author": "Jus69"}
{"word": ["Mount."], "author": "xieliming"}
{"word": ["ride"], "author": "le_chevalier"}
{"word": ["Travel"], "author": "Zoltan999"}
{"word": ["speed"], "author": "XYCat"}
{"word": ["light"], "author": "skimmie"}
{"word": ["saber"], "author": "noir_7"}
{"word": ["Tooth"], "author": "Jus69"}
{"word": ["Fairy"], "author": "cose_vecchie"}
{"word": ["Dust"], "author": "Jus69"}
{"word": ["Particle."], "author": "Hickory"}
{"word": ["Accelerator."], "author": "gixgox"}
{"word": ["Shift"], "author": "Jus69"}
{"word": ["Gear."], "author": "Narcia_"}
{"word": ["Togs."], "author": "Hickory"}
{"word": ["cogs"], "author": "Treasure"}
{"word": ["Gears"], "author": "TARFU"}
{"word": ["grind"], "author": "Ardal"}
{"word": ["Powder."], "author": "Hickory"}
{"word": ["keg"], "author": "skimmie"}
{"word": ["Beer."], "author": "Hickory"}
{"word": ["Drink"], "author": "Azrael360"}
{"word": [], "author": "Zoltan999"}
{"word": ["Castle."], "author": "Hickory"}
{"word": ["rock"], "author": "BlackDawn"}
{"word": ["Cock."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Cock."], "author": "Kleetus"}
{"word": [" Companion."], "author": "Hickory"}
{"word": ["Cock."], "author": "Kleetus"}
{"word": [" Companion."], "author": "Hickory"}
{"word": [" Friend"], "author": "TARFU"}
{"word": ["fiend"], "author": "Dzsono"}
{"word": ["Fried"], "author": "park_84"}
{"word": [" Nemesis."], "author": "ShadowPatriarch"}
{"word": ["archenemy"], "author": "le_chevalier"}
{"word": ["Rival."], "author": "xieliming"}
{"word": ["Equal"], "author": "Jus69"}
{"word": ["first"], "author": "le_chevalier"}
{"word": ["Minus. ", " ", " Just like my rep, I'm a badarse."], "author": "Kleetus"}
{"word": [" post"], "author": "skimmie"}
{"word": ["Minus."], "author": "Kleetus"}
{"word": [" Mail."], "author": "Hickory"}
{"word": ["expedited"], "author": "Dzsono"}
{"word": ["Hustled"], "author": "Allinstein"}
{"word": ["Shoved."], "author": "Hickory"}
{"word": ["Push"], "author": "Zoltan999"}
{"word": ["Button"], "author": "cose_vecchie"}
{"word": ["press"], "author": "skimmie"}
{"word": ["Media."], "author": "gixgox"}
{"word": ["mass"], "author": "Ardal"}
{"word": ["Effect."], "author": "Hickory"}
{"word": ["Cause"], "author": "coryrj1995"}
{"word": ["Reason"], "author": "Pickle1477"}
{"word": ["Pretence."], "author": "gixgox"}
{"word": ["pretentious"], "author": "camplify"}
{"word": ["hypocrisy"], "author": "VeTrack"}
{"word": ["politician"], "author": "Accatone"}
{"word": ["Spin."], "author": "Narcia_"}
{"word": ["Spiraling."], "author": "GhostwriterDoF"}
{"word": ["Whorl."], "author": "Hickory"}
{"word": ["twister"], "author": "Dzsono"}
{"word": ["Tornado"], "author": "TARFU"}
{"word": ["Wind"], "author": "TDP"}
{"word": ["Gale"], "author": "Yezemin"}
{"word": ["Hurricane"], "author": "TARFU"}
{"word": ["Rust"], "author": "Casval_Deikun"}
{"word": [" Cyclone."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Cyclone."], "author": "Hickory"}
{"word": ["Storm."], "author": "VeTrack"}
{"word": ["."], "author": "Hickory"}
{"word": ["Saucer."], "author": "VeTrack"}
{"word": ["Flying"], "author": "Licurg"}
{"word": ["Spitfire"], "author": "TARFU"}
{"word": ["Spitroast."], "author": "Kleetus"}
{"word": ["Rocket:"], "author": "morrowslant"}
{"word": ["Booster."], "author": "gixgox"}
{"word": ["Immunisation."], "author": "Kleetus"}
{"word": ["Mr e."], "author": "Tauto"}
{"word": [" seat"], "author": "Dzsono"}
{"word": ["see"], "author": "le_chevalier"}
{"word": ["Ocean."], "author": "Kleetus"}
{"word": ["Reef."], "author": "xieliming"}
{"word": ["Barrier"], "author": "Yezemin"}
{"word": [], "author": "gixgox"}
{"word": ["shark"], "author": "Ardal"}
{"word": ["Tank"], "author": "Zoltan999"}
{"word": ["!!!"], "author": "Chandoraa"}
{"word": ["Brilliant"], "author": "skimmie"}
{"word": ["Phantasmagorical."], "author": "Hickory"}
{"word": ["Hyperbolic"], "author": "Dzsono"}
{"word": ["Exaggerated."], "author": "Narcia_"}
{"word": ["Embellished"], "author": "TARFU"}
{"word": ["Adorned"], "author": "Yezemin"}
{"word": ["Decorate."], "author": "ShadowPatriarch"}
{"word": ["Festoon."], "author": "Hickory"}
{"word": ["Pontoon."], "author": "Kleetus"}
{"word": ["Bridge."], "author": "Casval_Deikun"}
{"word": ["Chorus."], "author": "agentcarr16"}
{"word": ["Choir"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": [" Group."], "author": "Kleetus"}
{"word": ["supercalifragilisticexpialidocious"], "author": "morrowslant"}
{"word": [" Mary Poppins"], "author": "TARFU"}
{"word": [" Structure."], "author": "Hickory"}
{"word": ["emplacement"], "author": "le_chevalier"}
{"word": [" Sounds of Music."], "author": "Kleetus"}
{"word": [" Plinth."], "author": "Hickory"}
{"word": ["Base"], "author": "Hardrada"}
{"word": [" Location."], "author": "Kleetus"}
{"word": ["Belong"], "author": "park_84"}
{"word": ["Own"], "author": "Yezemin"}
{"word": [" Headquarters."], "author": "Hickory"}
{"word": ["hive"], "author": "Dzsono"}
{"word": ["nest"], "author": "skimmie"}
{"word": ["wasp"], "author": "Ardal"}
{"word": ["Sting."], "author": "Hickory"}
{"word": [" ", " ", " ", " edit: Ninja'd"], "author": "Zoltan999"}
{"word": ["Magic"], "author": "VeTrack"}
{"word": [], "author": "gixgox"}
{"word": ["Display."], "author": "Hickory"}
{"word": ["Case."], "author": "Narcia_"}
{"word": ["Brief"], "author": "Zoltan999"}
{"word": ["Ephemeral."], "author": "Hickory"}
{"word": ["Momentary."], "author": "xieliming"}
{"word": ["Illusory."], "author": "ShadowPatriarch"}
{"word": ["Temporary"], "author": "TARFU"}
{"word": ["everlasting"], "author": "Dzsono"}
{"word": ["endless"], "author": "Maxvorstadt"}
{"word": [], "author": "skimmie"}
{"word": ["Oubliette"], "author": "TARFU"}
{"word": ["Crypt."], "author": "Hickory"}
{"word": ["Tomb."], "author": "REDVWIN"}
{"word": ["raid"], "author": "kmonster"}
{"word": [" er."], "author": "Kleetus"}
{"word": ["gulf"], "author": "morrowslant"}
{"word": [" Mexico"], "author": "TARFU"}
{"word": ["profiling"], "author": "morrowslant"}
{"word": ["arbitrary"], "author": "Dzsono"}
{"word": ["Hickorary."], "author": "Kleetus"}
{"word": [" Random"], "author": "TARFU"}
{"word": ["Hickorom."], "author": "Kleetus"}
{"word": [" Aimless."], "author": "gixgox"}
{"word": ["Blind"], "author": "Zoltan999"}
{"word": ["Mice."], "author": "Narcia_"}
{"word": ["trap"], "author": "Ardal"}
{"word": ["Snare."], "author": "Hickory"}
{"word": ["Snake"], "author": "truhlik"}
{"word": ["Slither"], "author": "TDP"}
{"word": ["Hiss."], "author": "xieliming"}
{"word": ["gas"], "author": "le_chevalier"}
{"word": ["flame"], "author": "camplify"}
{"word": ["Bonfire."], "author": "Hickory"}
{"word": ["Conflagration"], "author": "TARFU"}
{"word": ["Napalm."], "author": "ShadowPatriarch"}
{"word": ["Flamethrower."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["hungry"], "author": "kmonster"}
{"word": ["Hungary"], "author": "Dzsono"}
{"word": ["Country."], "author": "Narcia_"}
{"word": ["Side"], "author": "Yezemin"}
{"word": ["Rear."], "author": "Kleetus"}
{"word": [" starboard"], "author": "Dzsono"}
{"word": ["Rear."], "author": "Kleetus"}
{"word": [" Port."], "author": "Hickory"}
{"word": ["Royale"], "author": "park_84"}
{"word": [], "author": "gixgox"}
{"word": ["Alcohol"], "author": "skimmie"}
{"word": ["disinfectant"], "author": "Ardal"}
{"word": ["[Ninja'd] ", " ", " Cleanser."], "author": "Hickory"}
{"word": ["purge"], "author": "Dzsono"}
{"word": ["purify"], "author": "le_chevalier"}
{"word": ["Wash"], "author": "TARFU"}
{"word": ["Car"], "author": "litildivil"}
{"word": ["Crash."], "author": "gixgox"}
{"word": ["Test"], "author": "cose_vecchie"}
{"word": ["Dummy."], "author": "Hickory"}
{"word": ["Mannequin"], "author": "TARFU"}
{"word": ["Model."], "author": "Hickory"}
{"word": ["Airplane"], "author": "Gerin"}
{"word": ["airport"], "author": "ashwald"}
{"word": ["Flight"], "author": "TARFU"}
{"word": ["Crash"], "author": "Licurg"}
{"word": ["Vista"], "author": "ryuutane"}
{"word": ["Panorama."], "author": "Hickory"}
{"word": ["Sweeping."], "author": "xieliming"}
{"word": ["Mopping"], "author": "SamMagel"}
{"word": ["Scullery."], "author": "Hickory"}
{"word": ["Crockery"], "author": "TARFU"}
{"word": [" Hickery."], "author": "Kleetus"}
{"word": [" Faience."], "author": "gixgox"}
{"word": ["Art"], "author": "almabrds"}
{"word": ["Gallery."], "author": "Hickory"}
{"word": [" Hickery."], "author": "Kleetus"}
{"word": ["Museum"], "author": "TDP"}
{"word": ["Hickoreum."], "author": "Kleetus"}
{"word": [" ", " Exhibition."], "author": "Hickory"}
{"word": [" Hickorition."], "author": "Kleetus"}
{"word": [" ", " "], "author": "gixgox"}
{"word": ["imagines"], "author": "Dzsono"}
{"word": ["Thinks"], "author": "TARFU"}
{"word": ["figures"], "author": "le_chevalier"}
{"word": ["Stick"], "author": "Yezemin"}
{"word": ["hockey"], "author": "park_84"}
{"word": ["canadian"], "author": "Ardal"}
{"word": ["maple"], "author": "skimmie"}
{"word": ["Ash."], "author": "Hickory"}
{"word": ["Cinder"], "author": "Zoltan999"}
{"word": ["Heat."], "author": "REDVWIN"}
{"word": ["Wave."], "author": "gixgox"}
{"word": ["Splash."], "author": "Narcia_"}
{"word": ["Damage."], "author": "Hickory"}
{"word": ["Control"], "author": "cose_vecchie"}
{"word": ["Command"], "author": "TARFU"}
{"word": ["Direct."], "author": "Hickory"}
{"word": ["Line"], "author": "cose_vecchie"}
{"word": ["Dance."], "author": "gixgox"}
{"word": ["revolution"], "author": "Dzsono"}
{"word": ["Societal..."], "author": "GhostwriterDoF"}
{"word": ["Community"], "author": "TARFU"}
{"word": ["Giveaway."], "author": "Casval_Deikun"}
{"word": ["Free"], "author": "Chad28_69"}
{"word": [" ...loader."], "author": "gixgox"}
{"word": [" Cake."], "author": "Kleetus"}
{"word": ["birthday"], "author": "camplify"}
{"word": ["cakes"], "author": "SamMagel"}
{"word": ["tempest"], "author": "morrowslant"}
{"word": [" Freighter."], "author": "Hickory"}
{"word": ["Fighter"], "author": "Azrael360"}
{"word": [" Storm."], "author": "Kleetus"}
{"word": [" Survivor."], "author": "Hickory"}
{"word": [" Sighter."], "author": "gixgox"}
{"word": ["spotter"], "author": "Dzsono"}
{"word": ["sniper"], "author": "le_chevalier"}
{"word": ["Marksman."], "author": "Hickory"}
{"word": ["grappa"], "author": "morrowslant"}
{"word": [","], "author": "TARFU"}
{"word": ["Hicksman."], "author": "Kleetus"}
{"word": [" Robin Hood"], "author": "TARFU"}
{"word": ["Hicksman."], "author": "Kleetus"}
{"word": ["Person."], "author": "xieliming"}
{"word": ["Human"], "author": "TARFU"}
{"word": ["alien"], "author": "park_84"}
{"word": ["Invasion"], "author": "Yezemin"}
{"word": ["Normandy"], "author": "TARFU"}
{"word": ["Vikings"], "author": "le_chevalier"}
{"word": ["beard"], "author": "Ardal"}
{"word": ["Barber"], "author": "KillerofGods"}
{"word": ["shop"], "author": "skimmie"}
{"word": ["."], "author": "gixgox"}
{"word": ["Refrain"], "author": "Zoltan999"}
{"word": ["Forbear."], "author": "Narcia_"}
{"word": ["Inheritors... :)"], "author": "GhostwriterDoF"}
{"word": ["Heirs"], "author": "TARFU"}
{"word": ["testament"], "author": "Ardal"}
{"word": ["New"], "author": "TARFU"}
{"word": [" "], "author": "gixgox"}
{"word": [" Game :)"], "author": "deathrabit"}
{"word": ["Playtime."], "author": "Hickory"}
{"word": ["Dinnertime."], "author": "gixgox"}
{"word": ["Aperitif."], "author": "Hickory"}
{"word": ["Digestif"], "author": "Yezemin"}
{"word": ["Stomach"], "author": "Chad28_69"}
{"word": ["Trouble"], "author": "Gerin"}
{"word": ["Problem."], "author": "ShadowPatriarch"}
{"word": ["maths"], "author": "park_84"}
{"word": ["equation"], "author": "TARFU"}
{"word": ["Formula."], "author": "xieliming"}
{"word": ["method"], "author": "Dzsono"}
{"word": ["procedure"], "author": "TARFU"}
{"word": ["function"], "author": "le_chevalier"}
{"word": ["Shindig."], "author": "Hickory"}
{"word": ["Calfexcavate."], "author": "Kleetus"}
{"word": [" Gathering"], "author": "TARFU"}
{"word": [" Hickoring."], "author": "Kleetus"}
{"word": [" Sit-in."], "author": "gixgox"}
{"word": [" Hickorin."], "author": "Kleetus"}
{"word": [" Sit-in."], "author": "gixgox"}
{"word": ["Sleep-over."], "author": "Hickory"}
{"word": [" Hickover."], "author": "Kleetus"}
{"word": [" Stay-at-home."], "author": "gixgox"}
{"word": ["Slouch."], "author": "Hickory"}
{"word": ["Couch"], "author": "Zoltan999"}
{"word": ["Potato"], "author": "Licurg"}
{"word": ["Chips."], "author": "Hickory"}
{"word": ["Fish."], "author": "gixgox"}
{"word": ["Tank"], "author": "cose_vecchie"}
{"word": ["Shell."], "author": "Hickory"}
{"word": ["conch"], "author": "skimmie"}
{"word": ["calcium"], "author": "Ardal"}
{"word": ["Milk"], "author": "TARFU"}
{"word": ["Mammary."], "author": "Hickory"}
{"word": ["Breasts"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": ["Coward"], "author": "Yezemin"}
{"word": ["Brave"], "author": "TARFU"}
{"word": ["Bold."], "author": "Hickory"}
{"word": ["BB-code."], "author": "Casval_Deikun"}
{"word": ["."], "author": "Hickory"}
{"word": ["font"], "author": "TARFU"}
{"word": ["haunt"], "author": "SamMagel"}
{"word": ["terrify"], "author": "Dzsono"}
{"word": ["petrify"], "author": "le_chevalier"}
{"word": ["horrify"], "author": "TARFU"}
{"word": ["Hickorify."], "author": "Kleetus"}
{"word": ["scare"], "author": "SamMagel"}
{"word": ["Spook"], "author": "Yezemin"}
{"word": ["ghost"], "author": "sluniq"}
{"word": [], "author": "skimmie"}
{"word": [], "author": "gixgox"}
{"word": ["Menace."], "author": "xieliming"}
{"word": ["tragedy"], "author": "Dzsono"}
{"word": ["Calamity"], "author": "Zoltan999"}
{"word": ["Jane"], "author": "cose_vecchie"}
{"word": ["doe"], "author": "Ardal"}
{"word": ["Buck"], "author": "Zoltan999"}
{"word": ["Quid"], "author": "cose_vecchie"}
{"word": ["reason"], "author": "park_84"}
{"word": ["Logic."], "author": "Narcia_"}
{"word": ["Rational"], "author": "Yezemin"}
{"word": ["Thinking"], "author": "TARFU"}
{"word": ["putty"], "author": "cose_vecchie"}
{"word": [" Analysing."], "author": "Hickory"}
{"word": [" influence"], "author": "Accatone"}
{"word": [" Analysing."], "author": "Hickory"}
{"word": ["Computing"], "author": "TARFU"}
{"word": ["Calculating."], "author": "Hickory"}
{"word": ["number"], "author": "BlackDawn"}
{"word": [" Power."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Capacitor."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["Influx"], "author": "SamMagel"}
{"word": ["Import"], "author": "TARFU"}
{"word": [" Arrival."], "author": "Kleetus"}
{"word": [" Introduce."], "author": "Hickory"}
{"word": [" Tariff."], "author": "gixgox"}
{"word": ["Taxes"], "author": "TARFU"}
{"word": ["Arrival."], "author": "Kleetus"}
{"word": [" Tithe."], "author": "ShadowPatriarch"}
{"word": ["percentage"], "author": "Dzsono"}
{"word": ["fraction"], "author": "DavidOrion93"}
{"word": ["portion"], "author": "TARFU"}
{"word": ["cut"], "author": "le_chevalier"}
{"word": ["Slice."], "author": "gixgox"}
{"word": [" Sever."], "author": "Kleetus"}
{"word": [" Pie"], "author": "TARFU"}
{"word": ["Chart."], "author": "gixgox"}
{"word": [" Perforate."], "author": "Kleetus"}
{"word": ["Data"], "author": "park_84"}
{"word": ["."], "author": "Hickory"}
{"word": ["Mining. ", " ", " Mining. >thank you Ninja> ", " ", " "], "author": "gixgox"}
{"word": ["Knowledge."], "author": "Hickory"}
{"word": [" Information."], "author": "Kleetus"}
{"word": [" Perception."], "author": "gixgox"}
{"word": ["Information."], "author": "Kleetus"}
{"word": [" Awareness."], "author": "Hickory"}
{"word": ["Alertness"], "author": "skimmie"}
{"word": ["DEFCON."], "author": "xieliming"}
{"word": ["four"], "author": "JDelekto"}
{"word": ["square"], "author": "BlackRedDead"}
{"word": ["Enix"], "author": "gixgox"}
{"word": ["fantasy"], "author": "JDelekto"}
{"word": ["Final."], "author": "Hickory"}
{"word": ["Onomatopeoia"], "author": "JDelekto"}
{"word": ["\"Clap\""], "author": "Zoltan999"}
{"word": ["snap"], "author": "JDelekto"}
{"word": [" ", " Wut!?"], "author": "Hickory"}
{"word": ["dictionary"], "author": "JDelekto"}
{"word": ["thesaurus"], "author": "Dzsono"}
{"word": ["Synonym"], "author": "TARFU"}
{"word": [" ", ". ", " ", " Equivalent."], "author": "Hickory"}
{"word": ["mockery"], "author": "JDelekto"}
{"word": ["ridicule"], "author": "Ardal"}
{"word": ["Laughter"], "author": "Licurg"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": ["Mirth"], "author": "TARFU"}
{"word": ["Merriment."], "author": "Hickory"}
{"word": [" Missed you, Hickster \u2665."], "author": "Kleetus"}
{"word": [" Gleefulness."], "author": "gixgox"}
{"word": ["Ebullience."], "author": "Hickory"}
{"word": ["Effusiveness. "], "author": "gixgox"}
{"word": ["Vivacity."], "author": "Hickory"}
{"word": ["Hickoracity."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["voice"], "author": "kmonster"}
{"word": ["."], "author": "gixgox"}
{"word": [" Vocal."], "author": "Kleetus"}
{"word": [" Opera."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": ["."], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Lavish."], "author": "Hickory"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" ", " ", " ", " Overabundant. ", " ", " "], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": ["Overabundant."], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Excess"], "author": "TARFU"}
{"word": ["Dearth"], "author": "Dzsono"}
{"word": ["Darth."], "author": "xieliming"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Vader"], "author": "TARFU"}
{"word": ["Dark"], "author": "park_84"}
{"word": ["Light"], "author": "Chad28_69"}
{"word": ["shadow"], "author": "Ardal"}
{"word": ["knows"], "author": "JDelekto"}
{"word": [" Silhouette."], "author": "Hickory"}
{"word": ["Shape"], "author": "Yezemin"}
{"word": ["form"], "author": "JDelekto"}
{"word": ["morph"], "author": "le_chevalier"}
{"word": [" Evolve ", " ", " ", " (I got your association bro..... ", ")"], "author": "Zoltan999"}
{"word": ["Develop."], "author": "Hickory"}
{"word": ["Film."], "author": "Narcia_"}
{"word": ["Camera"], "author": "TARFU"}
{"word": ["Lense"], "author": "Yezemin"}
{"word": ["Focus."], "author": "Hickory"}
{"word": ["Focal."], "author": "gixgox"}
{"word": ["point"], "author": "cose_vecchie"}
{"word": ["Match."], "author": "xieliming"}
{"word": ["Box"], "author": "Zoltan999"}
{"word": ["Carton"], "author": "TARFU"}
{"word": ["Container."], "author": "Hickory"}
{"word": ["Kennel."], "author": "Kleetus"}
{"word": ["Dog."], "author": "Casval_Deikun"}
{"word": ["Canine"], "author": "TARFU"}
{"word": ["Terrier."], "author": "Kleetus"}
{"word": ["Chihuahua"], "author": "park_84"}
{"word": ["Rodent."], "author": "Kleetus"}
{"word": [" Mexico."], "author": "gixgox"}
{"word": [" Burrito"], "author": "TARFU"}
{"word": ["Tortilla."], "author": "Hickory"}
{"word": ["Taco"], "author": "Yezemin"}
{"word": ["!"], "author": "gixgox"}
{"word": ["Muerta"], "author": "Zoltan999"}
{"word": ["Death"], "author": "TARFU"}
{"word": ["Blossom."], "author": "Narcia_"}
{"word": ["Starfighter"], "author": "TARFU"}
{"word": ["combat"], "author": "Dzsono"}
{"word": ["Arms"], "author": "litildivil"}
{"word": ["open"], "author": "cose_vecchie"}
{"word": ["Door"], "author": "TARFU"}
{"word": ["Handle"], "author": "cose_vecchie"}
{"word": ["metallic"], "author": "deathrabit"}
{"word": ["Ferrous"], "author": "TARFU"}
{"word": ["iron"], "author": "BlackRedDead"}
{"word": ["Rust."], "author": "Hickory"}
{"word": ["Trust"], "author": "doctorsinister"}
{"word": ["Crust."], "author": "gixgox"}
{"word": ["pizza"], "author": "Ardal"}
{"word": ["pepperoni"], "author": "cose_vecchie"}
{"word": ["Hickoroni."], "author": "Kleetus"}
{"word": [" Sausage."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Sausage."], "author": "Hickory"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Sausage."], "author": "Hickory"}
{"word": [" Salami."], "author": "gixgox"}
{"word": [" Hickorami."], "author": "Kleetus"}
{"word": [" Spicy."], "author": "Hickory"}
{"word": ["Tangy."], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": ["Tangy."], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": ["Tangerine"], "author": "Azrael360"}
{"word": ["."], "author": "gixgox"}
{"word": [" Imagine"], "author": "TARFU"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Radioactive"], "author": "TARFU"}
{"word": [], "author": "Azrael360"}
{"word": ["kind"], "author": "le_chevalier"}
{"word": ["superhero"], "author": "Dzsono"}
{"word": ["supervillain"], "author": "le_chevalier"}
{"word": ["SuperHickory."], "author": "Kleetus"}
{"word": [" Lex Luthor"], "author": "TARFU"}
{"word": ["Special."], "author": "xieliming"}
{"word": [" K."], "author": "Kleetus"}
{"word": [" Forces."], "author": "gixgox"}
{"word": ["Army"], "author": "Yezemin"}
{"word": ["Now"], "author": "park_84"}
{"word": [" Headquarters."], "author": "Hickory"}
{"word": ["strategic"], "author": "Ardal"}
{"word": ["Position"], "author": "Zoltan999"}
{"word": ["Missionary"], "author": "Gerin"}
{"word": ["Soixante-neuf."], "author": "Hickory"}
{"word": ["Counting."], "author": "Narcia_"}
{"word": ["Relying... :D"], "author": "GhostwriterDoF"}
{"word": ["Relaying"], "author": "skimmie"}
{"word": ["Rallying."], "author": "Hickory"}
{"word": ["Racing"], "author": "TARFU"}
{"word": ["Team"], "author": "cose_vecchie"}
{"word": ["."], "author": "gixgox"}
{"word": ["Castle"], "author": "TARFU"}
{"word": ["knight"], "author": "camplify"}
{"word": ["Hero"], "author": "Azrael360"}
{"word": ["Superman"], "author": "TARFU"}
{"word": [" Portmanteau."], "author": "Hickory"}
{"word": [" Portmanteau."], "author": "Hickory"}
{"word": ["Portfolio."], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": ["Portfolio."], "author": "gixgox"}
{"word": [" Briefcase"], "author": "TARFU"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Pocket."], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Navy"], "author": "TARFU"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" ", " ", " "], "author": "gixgox"}
{"word": [" Sailors"], "author": "TARFU"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" naval"], "author": "Dzsono"}
{"word": ["Maritime"], "author": "TARFU"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Oceanic."], "author": "gixgox"}
{"word": [" Sea-Dickory."], "author": "Kleetus"}
{"word": [" Oceanic."], "author": "gixgox"}
{"word": [" Cetacean"], "author": "TARFU"}
{"word": ["Dolphin."], "author": "Hickory"}
{"word": ["Emulator"], "author": "park_84"}
{"word": ["Virtual"], "author": "Yezemin"}
{"word": ["Reality"], "author": "TARFU"}
{"word": ["Perception"], "author": "jadegiant"}
{"word": ["Relativity."], "author": "Hickory"}
{"word": ["Subjectivity"], "author": "le_chevalier"}
{"word": ["Objectivity."], "author": "gixgox"}
{"word": ["Impartiality."], "author": "Hickory"}
{"word": ["judge"], "author": "Ardal"}
{"word": ["Jury"], "author": "skimmie"}
{"word": ["executioner"], "author": "ashwald"}
{"word": ["Dread."], "author": "xieliming"}
{"word": ["Death."], "author": "Narcia_"}
{"word": ["Fatality"], "author": "TARFU"}
{"word": ["mortality"], "author": "le_chevalier"}
{"word": ["Lethality."], "author": "gixgox"}
{"word": ["weapon"], "author": "deathrabit"}
{"word": ["Sword"], "author": "TARFU"}
{"word": ["Thrust"], "author": "cose_vecchie"}
{"word": ["Liftoff."], "author": "Hickory"}
{"word": ["Abort!"], "author": "Zoltan999"}
{"word": ["Eject!"], "author": "TARFU"}
{"word": ["Mayday!"], "author": "xieliming"}
{"word": ["Diet"], "author": "kmonster"}
{"word": ["Fad"], "author": "TARFU"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Whim."], "author": "Hickory"}
{"word": ["wurm"], "author": "Dzsono"}
{"word": ["Worms."], "author": "Casval_Deikun"}
{"word": ["Bazooka"], "author": "park_84"}
{"word": [" Bazickory."], "author": "Kleetus"}
{"word": [" Mortar."], "author": "Hickory"}
{"word": ["bullet"], "author": "TravorT"}
{"word": [], "author": "skimmie"}
{"word": ["Warp."], "author": "Hickory"}
{"word": ["speed"], "author": "cose_vecchie"}
{"word": ["Limit"], "author": "Zoltan999"}
{"word": ["barrier"], "author": "le_chevalier"}
{"word": ["Curb."], "author": "Narcia_"}
{"word": ["Restrict."], "author": "Hickory"}
{"word": ["Access"], "author": "ryuutane"}
{"word": ["Denied"], "author": "truhlik"}
{"word": ["Blocked"], "author": "TARFU"}
{"word": ["censored"], "author": "le_chevalier"}
{"word": ["Uncensored."], "author": "Casval_Deikun"}
{"word": ["open"], "author": "TARFU"}
{"word": ["."], "author": "gixgox"}
{"word": ["Law"], "author": "JeanChief22"}
{"word": ["Order"], "author": "Yezemin"}
{"word": ["Restaurant"], "author": "TARFU"}
{"word": ["Food :)"], "author": "deathrabit"}
{"word": ["Hunger"], "author": "JeanChief22"}
{"word": ["Thirst"], "author": "TARFU"}
{"word": ["Dehydration."], "author": "Hickory"}
{"word": ["Desert"], "author": "TARFU"}
{"word": ["Mirage."], "author": "Hickory"}
{"word": ["Illusion"], "author": "JeanChief22"}
{"word": ["Magic"], "author": "TARFU"}
{"word": ["Spell."], "author": "Hickory"}
{"word": ["Spickory."], "author": "Kleetus"}
{"word": ["Spell."], "author": "Hickory"}
{"word": [" Alphabet"], "author": "TARFU"}
{"word": ["Language."], "author": "Hickory"}
{"word": ["Barking."], "author": "Kleetus"}
{"word": ["Language."], "author": "Hickory"}
{"word": ["Barking."], "author": "Kleetus"}
{"word": ["Language."], "author": "Hickory"}
{"word": ["Barking."], "author": "Kleetus"}
{"word": [" Dialect"], "author": "Zoltan999"}
{"word": ["Vernacular."], "author": "Hickory"}
{"word": ["Barking."], "author": "Kleetus"}
{"word": [" Slang"], "author": "TARFU"}
{"word": ["gross"], "author": "koima57"}
{"word": ["Weight"], "author": "TARFU"}
{"word": ["Pressure."], "author": "REDVWIN"}
{"word": ["Cooker"], "author": "TARFU"}
{"word": ["Baker"], "author": "le_chevalier"}
{"word": ["Dough."], "author": "Hickory"}
{"word": ["knead"], "author": "Dzsono"}
{"word": ["Fold"], "author": "JeanChief22"}
{"word": ["Folder"], "author": "park_84"}
{"word": ["File"], "author": "Yezemin"}
{"word": ["Fickory."], "author": "Kleetus"}
{"word": ["System."], "author": "xieliming"}
{"word": ["shock"], "author": "skimmie"}
{"word": ["Wave."], "author": "gixgox"}
{"word": ["Ripple."], "author": "Hickory"}
{"word": ["Tide."], "author": "gixgox"}
{"word": ["tsunami"], "author": "le_chevalier"}
{"word": [], "author": "Zoltan999"}
{"word": ["Enthusiast."], "author": "Hickory"}
{"word": ["addict"], "author": "Dzsono"}
{"word": ["Drugs"], "author": "TARFU"}
{"word": ["prescription"], "author": "skimmie"}
{"word": ["description"], "author": "Accatone"}
{"word": ["Written."], "author": "Narcia_"}
{"word": ["Inscribed"], "author": "TARFU"}
{"word": ["[Ninja'd] ", " ", " Engraved."], "author": "Hickory"}
{"word": ["Laser"], "author": "JeanChief22"}
{"word": ["Beam"], "author": "Azrael360"}
{"word": ["Ray"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": ["Prince."], "author": "Hickory"}
{"word": ["Wales. <1:1>"], "author": "gixgox"}
{"word": ["Whales"], "author": "Zoltan999"}
{"word": ["[", "] ", " ", " Updated."], "author": "Hickory"}
{"word": ["new"], "author": "Ardal"}
{"word": ["Rugged"], "author": "Antimateria"}
{"word": ["Ragged"], "author": "TDP"}
{"word": ["Torn."], "author": "Hickory"}
{"word": ["Thumb"], "author": "TARFU"}
{"word": ["Terrier."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": [], "author": "Hickory"}
{"word": ["imperfect"], "author": "JDelekto"}
{"word": ["Flawed"], "author": "TARFU"}
{"word": ["Alpha."], "author": "REDVWIN"}
{"word": ["Dog"], "author": "TARFU"}
{"word": ["mutt"], "author": "Dzsono"}
{"word": ["stable"], "author": "JDelekto"}
{"word": ["Horse"], "author": "TARFU"}
{"word": ["game"], "author": "JDelekto"}
{"word": ["Video"], "author": "TARFU"}
{"word": ["Monitor."], "author": "Hickory"}
{"word": ["Lizard."], "author": "Kleetus"}
{"word": ["green"], "author": "park_84"}
{"word": ["grin"], "author": "le_chevalier"}
{"word": ["smile"], "author": "mariabarring"}
{"word": ["broad"], "author": "Ardal"}
{"word": ["slut"], "author": "Antimateria"}
{"word": ["tart"], "author": "azael2323"}
{"word": [" Wide."], "author": "Hickory"}
{"word": ["Width"], "author": "TARFU"}
{"word": [" Pastry"], "author": "Zoltan999"}
{"word": ["Danish."], "author": "Narcia_"}
{"word": [" Breadth."], "author": "Hickory"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Breadth."], "author": "Hickory"}
{"word": [" Hair's..."], "author": "gixgox"}
{"word": ["Coiffure."], "author": "Hickory"}
{"word": [" Fur."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Fur."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" Furry."], "author": "Kleetus"}
{"word": [" Sleazy."], "author": "gixgox"}
{"word": ["Furry."], "author": "Kleetus"}
{"word": [" Sleazy."], "author": "gixgox"}
{"word": ["Furry."], "author": "Kleetus"}
{"word": ["murry"], "author": "Madshaker"}
{"word": ["Hurry"], "author": "TARFU"}
{"word": ["Curry."], "author": "Kleetus"}
{"word": ["Powder"], "author": "JeanChief22"}
{"word": ["Dust"], "author": "TARFU"}
{"word": ["Chowder."], "author": "Kleetus"}
{"word": [" soup"], "author": "deathrabit"}
{"word": ["primordial"], "author": "Dzsono"}
{"word": ["Cordial."], "author": "Kleetus"}
{"word": ["Kind"], "author": "park_84"}
{"word": ["Congenial"], "author": "JDelekto"}
{"word": ["Congenital."], "author": "Kleetus"}
{"word": ["circumlocution"], "author": "JDelekto"}
{"word": [" Ancient."], "author": "Hickory"}
{"word": [" Evasion."], "author": "Kleetus"}
{"word": ["confrontation"], "author": "JDelekto"}
{"word": [], "author": "gixgox"}
{"word": [], "author": "JDelekto"}
{"word": ["argument"], "author": "Ardal"}
{"word": ["periods"], "author": "Antimateria"}
{"word": ["silence"], "author": "le_chevalier"}
{"word": ["Noisy"], "author": "jimmmmmo"}
{"word": ["Muffler"], "author": "Zoltan999"}
{"word": ["Subdued"], "author": "Yezemin"}
{"word": ["Quiet."], "author": "Narcia_"}
{"word": ["Sound"], "author": "deathrabit"}
{"word": ["Asleep."], "author": "Hickory"}
{"word": ["wakenings"], "author": "JDelekto"}
{"word": ["Refreshed"], "author": "jimmmmmo"}
{"word": ["Well-oiled."], "author": "gixgox"}
{"word": ["smooth"], "author": "skimmie"}
{"word": ["criminal"], "author": "JDelekto"}
{"word": ["crime"], "author": "Accatone"}
{"word": ["punishment"], "author": "cose_vecchie"}
{"word": ["masochism"], "author": "Chad28_69"}
{"word": ["Sadism"], "author": "TARFU"}
{"word": ["Sado-Masochism."], "author": "gixgox"}
{"word": ["Hickorism."], "author": "Kleetus"}
{"word": [" Torture"], "author": "TARFU"}
{"word": ["Hickorism."], "author": "Kleetus"}
{"word": [" violate"], "author": "Dzsono"}
{"word": [" Intrude"], "author": "TARFU"}
{"word": ["Hickorism."], "author": "Kleetus"}
{"word": [" bother"], "author": "truhlik"}
{"word": ["Disturb."], "author": "Hickory"}
{"word": ["startle"], "author": "Ardal"}
{"word": ["awaken"], "author": "jimmmmmo"}
{"word": ["Awareness."], "author": "xieliming"}
{"word": ["Cognizance."], "author": "Hickory"}
{"word": ["Gnosis."], "author": "gixgox"}
{"word": ["awareness"], "author": "Dzsono"}
{"word": [" ", " Double."], "author": "Hickory"}
{"word": ["Cream."], "author": "gixgox"}
{"word": [], "author": "cose_vecchie"}
{"word": [], "author": "Zoltan999"}
{"word": ["Helmet."], "author": "Narcia_"}
{"word": ["Hat"], "author": "TARFU"}
{"word": [], "author": "skimmie"}
{"word": ["Rock"], "author": "TDP"}
{"word": ["harsh ", " ", " ninja'd ", " ", " rough"], "author": "le_chevalier"}
{"word": ["Raspy"], "author": "TARFU"}
{"word": ["Hoarse."], "author": "Hickory"}
{"word": ["course"], "author": "doctorsinister"}
{"word": ["Race"], "author": "TARFU"}
{"word": ["Horse."], "author": "gixgox"}
{"word": ["Armor"], "author": "enurbenur"}
{"word": ["Plate"], "author": "Yezemin"}
{"word": ["Dish."], "author": "Hickory"}
{"word": ["Washer"], "author": "TARFU"}
{"word": ["Clean"], "author": "PaterAlf"}
{"word": ["Dirty"], "author": "agentcarr16"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Grubby."], "author": "Hickory"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Grubby."], "author": "Hickory"}
{"word": ["Blowsy."], "author": "gixgox"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": ["Blowsy."], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": ["Blowsy."], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Scruffy."], "author": "Hickory"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": ["Stalker"], "author": "Azrael360"}
{"word": ["Pursuer."], "author": "REDVWIN"}
{"word": ["Follower"], "author": "JeanChief22"}
{"word": ["Minion"], "author": "TARFU"}
{"word": ["Keeper."], "author": "Casval_Deikun"}
{"word": ["Citadel."], "author": "semigroups"}
{"word": ["Flying"], "author": "Yezemin"}
{"word": ["Saucer"], "author": "TARFU"}
{"word": ["UFO"], "author": "park_84"}
{"word": ["NRA."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["X-Files ", " ", " ", " edit: Ninja'd, but it remains the same :P"], "author": "Zoltan999"}
{"word": ["Scully"], "author": "janelee"}
{"word": ["Scullery"], "author": "Yezemin"}
{"word": ["Cup"], "author": "TARFU"}
{"word": ["Plate."], "author": "gixgox"}
{"word": ["Dinner."], "author": "Narcia_"}
{"word": ["served"], "author": "Ardal"}
{"word": ["date ", " ", " ninja'd ", " ", " tasted"], "author": "le_chevalier"}
{"word": ["Ate"], "author": "TARFU"}
{"word": ["tea"], "author": "Accatone"}
{"word": ["Mint"], "author": "Licurg"}
{"word": ["Breath"], "author": "TARFU"}
{"word": ["halitosis"], "author": "Dzsono"}
{"word": ["odour"], "author": "azael2323"}
{"word": ["Stench"], "author": "TARFU"}
{"word": ["Manure"], "author": "cose_vecchie"}
{"word": ["Fertilizer"], "author": "TARFU"}
{"word": ["Crop."], "author": "Hickory"}
{"word": ["Farm"], "author": "TARFU"}
{"word": ["Barn."], "author": "gixgox"}
{"word": ["Stable"], "author": "TARFU"}
{"word": ["release"], "author": "cose_vecchie"}
{"word": ["Freedom."], "author": "Hickory"}
{"word": ["Roaming"], "author": "TARFU"}
{"word": ["stray"], "author": "Pickle1477"}
{"word": ["Cat"], "author": "TARFU"}
{"word": ["Feline"], "author": "JeanChief22"}
{"word": ["Grimalkin."], "author": "Hickory"}
{"word": ["cute"], "author": "ashwald"}
{"word": ["cuddly"], "author": "skimmie"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Tender."], "author": "REDVWIN"}
{"word": ["Chicken"], "author": "TARFU"}
{"word": ["Soup."], "author": "gixgox"}
{"word": ["Stew"], "author": "TARFU"}
{"word": ["Broth."], "author": "Hickory"}
{"word": ["Beef"], "author": "TARFU"}
{"word": ["Joint."], "author": "Hickory"}
{"word": ["hock"], "author": "Dzsono"}
{"word": ["Pawn"], "author": "TARFU"}
{"word": [" Chess."], "author": "civaddict"}
{"word": ["Strategy"], "author": "VampiroAlhazred"}
{"word": ["Management"], "author": "park_84"}
{"word": ["Ressource"], "author": "Yezemin"}
{"word": ["Exhaustion"], "author": "JeanChief22"}
{"word": [" Asset."], "author": "Hickory"}
{"word": ["frozen"], "author": "Ardal"}
{"word": ["Tundra."], "author": "Hickory"}
{"word": ["Polar"], "author": "TARFU"}
{"word": ["Cap."], "author": "Hickory"}
{"word": ["Beret"], "author": "TARFU"}
{"word": ["."], "author": "gixgox"}
{"word": ["Trilby."], "author": "Hickory"}
{"word": ["Deerstalker"], "author": "TARFU"}
{"word": ["Hunter"], "author": "Zoltan999"}
{"word": ["Game"], "author": "TARFU"}
{"word": ["On."], "author": "xieliming"}
{"word": ["Reboot!"], "author": "Narcia_"}
{"word": ["Crash"], "author": "TARFU"}
{"word": ["Burn."], "author": "Hickory"}
{"word": ["Turn"], "author": "SamMagel"}
{"word": ["Churn."], "author": "gixgox"}
{"word": ["Urn."], "author": "Hickory"}
{"word": ["Burial"], "author": "JeanChief22"}
{"word": ["Tomb."], "author": "gixgox"}
{"word": ["mausoleum"], "author": "le_chevalier"}
{"word": ["Dolmen."], "author": "gixgox"}
{"word": ["afterlife"], "author": "Dzsono"}
{"word": ["Paradise"], "author": "TARFU"}
{"word": ["Birds."], "author": "xieliming"}
{"word": ["Chicks."], "author": "Kleetus"}
{"word": [" Avian."], "author": "Hickory"}
{"word": ["Chicks."], "author": "Kleetus"}
{"word": [" Icarus."], "author": "gixgox"}
{"word": [" Hickorus."], "author": "Kleetus"}
{"word": [" Icarus."], "author": "gixgox"}
{"word": ["Wings"], "author": "Yezemin"}
{"word": ["Paws."], "author": "Kleetus"}
{"word": [" Feathers."], "author": "gixgox"}
{"word": ["flock"], "author": "Ardal"}
{"word": ["seagulls"], "author": "HunchBluntley"}
{"word": [" Dawg."], "author": "kleetusJR"}
{"word": [" "], "author": "gixgox"}
{"word": [], "author": "Lifthrasil"}
{"word": ["Muppet."], "author": "Hickory"}
{"word": ["Puppet"], "author": "TARFU"}
{"word": ["Doll"], "author": "Yezemin"}
{"word": ["Figurine"], "author": "TARFU"}
{"word": [], "author": "Zoltan999"}
{"word": ["Dakka"], "author": "TARFU"}
{"word": ["More!"], "author": "Zoltan999"}
{"word": ["Extra."], "author": "Narcia_"}
{"word": ["Bonus"], "author": "TARFU"}
{"word": ["points"], "author": "cose_vecchie"}
{"word": ["Compass"], "author": "TARFU"}
{"word": ["encompass"], "author": "Dzsono"}
{"word": ["Circumscribe"], "author": "TARFU"}
{"word": ["circumcircle"], "author": "le_chevalier"}
{"word": [" Vampire"], "author": "kleetusJR"}
{"word": ["Night"], "author": "jimmmmmo"}
{"word": [" Restrict."], "author": "Hickory"}
{"word": ["constrict"], "author": "Ardal"}
{"word": ["."], "author": "gixgox"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Hickoring."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["King"], "author": "Azrael360"}
{"word": ["dead"], "author": "kmonster"}
{"word": [], "author": "gixgox"}
{"word": [" Deceased."], "author": "Kleetus"}
{"word": [" Appreciative."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Collective"], "author": "doctorsinister"}
{"word": [" Borg"], "author": "TARFU"}
{"word": ["cyborg"], "author": "Dzsono"}
{"word": ["Android."], "author": "Hickory"}
{"word": [" Hickoroid."], "author": "Kleetus"}
{"word": ["Android."], "author": "Hickory"}
{"word": ["Phone."], "author": "xieliming"}
{"word": ["...."], "author": "mistermumbles"}
{"word": [" Call."], "author": "Hickory"}
{"word": [" hold"], "author": "GabesterOne"}
{"word": ["Grab"], "author": "park_84"}
{"word": ["Reach"], "author": "Yezemin"}
{"word": ["Attain."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": [], "author": "cose_vecchie"}
{"word": [], "author": "gixgox"}
{"word": ["nose"], "author": "Ardal"}
{"word": ["Tip"], "author": "cose_vecchie"}
{"word": ["Iceberg"], "author": "Zoltan999"}
{"word": ["Water"], "author": "TARFU"}
{"word": ["hose"], "author": "le_chevalier"}
{"word": ["Rose."], "author": "gixgox"}
{"word": ["Bloom"], "author": "TARFU"}
{"word": ["Garden."], "author": "Narcia_"}
{"word": [], "author": "cose_vecchie"}
{"word": ["Diversity"], "author": "Yezemin"}
{"word": ["Omnifariousness."], "author": "gixgox"}
{"word": ["versatility"], "author": "Ardal"}
{"word": ["jack-of-all-trades"], "author": "cose_vecchie"}
{"word": ["Handyman."], "author": "REDVWIN"}
{"word": ["Hammer"], "author": "TARFU"}
{"word": ["Time."], "author": "Kleetus"}
{"word": [" pound"], "author": "Dzsono"}
{"word": ["Time."], "author": "Kleetus"}
{"word": [" Cake"], "author": "TARFU"}
{"word": ["pie"], "author": "park_84"}
{"word": ["Cherry"], "author": "TARFU"}
{"word": ["Blossom."], "author": "Hickory"}
{"word": ["Time."], "author": "Kleetus"}
{"word": ["Blossom."], "author": "Hickory"}
{"word": [], "author": "park_84"}
{"word": ["beauty"], "author": "truhlik"}
{"word": ["Alluring"], "author": "jadegiant"}
{"word": ["Lure"], "author": "Chad28_69"}
{"word": ["Bait."], "author": "gixgox"}
{"word": [], "author": "skimmie"}
{"word": ["Light."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["Evening."], "author": "Narcia_"}
{"word": ["Twilight."], "author": "Hickory"}
{"word": ["Zone"], "author": "TARFU"}
{"word": ["mysterious"], "author": "jimmmmmo"}
{"word": ["stranger"], "author": "Ardal"}
{"word": ["curious ", " ", " ninja'd ", " ", " welcome"], "author": "le_chevalier"}
{"word": ["gracious"], "author": "Dzsono"}
{"word": ["Polite."], "author": "Hickory"}
{"word": ["Sincere"], "author": "Zoltan999"}
{"word": ["Apologies"], "author": "JeanChief22"}
{"word": ["Accepted."], "author": "gixgox"}
{"word": ["Endorsed."], "author": "Hickory"}
{"word": ["Acknowledged."], "author": "REDVWIN"}
{"word": ["Understood"], "author": "SamMagel"}
{"word": ["understand ", " ", " \"Please Understand.......\" Iwata (great developer, mediocre ceo)"], "author": "GabesterOne"}
{"word": ["Knowledge"], "author": "TARFU"}
{"word": ["ignorance"], "author": "Dzsono"}
{"word": ["Stupidity"], "author": "TARFU"}
{"word": ["Bold"], "author": "park_84"}
{"word": [], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["emphasize"], "author": "Ardal"}
{"word": ["Accentuate"], "author": "TARFU"}
{"word": ["Enhance"], "author": "Zoltan999"}
{"word": ["Improve."], "author": "Narcia_"}
{"word": ["Upgrade"], "author": "TARFU"}
{"word": ["sausage"], "author": "apehater"}
{"word": [" "], "author": "ashwald"}
{"word": ["Brave"], "author": "Yezemin"}
{"word": [" Improve."], "author": "Hickory"}
{"word": ["Renovate"], "author": "TARFU"}
{"word": ["scaffolding"], "author": "Dzsono"}
{"word": ["platform"], "author": "le_chevalier"}
{"word": ["form"], "author": "Accatone"}
{"word": [], "author": "gixgox"}
{"word": ["Abuse"], "author": "JeanChief22"}
{"word": ["Mental"], "author": "TDP"}
{"word": ["Psychological"], "author": "TARFU"}
{"word": [" Insane."], "author": "Kleetus"}
{"word": [" Cerebral."], "author": "Hickory"}
{"word": [" Hickoral."], "author": "Kleetus"}
{"word": [" Cerebral."], "author": "Hickory"}
{"word": [" Been missing you, Hickster \u2665."], "author": "Kleetus"}
{"word": [" Cerebral."], "author": "Hickory"}
{"word": [" Still missing you."], "author": "Kleetus"}
{"word": [" Cerebral."], "author": "Hickory"}
{"word": [" Love you, Hicky \u2665."], "author": "Kleetus"}
{"word": ["^creeper"], "author": "GabesterOne"}
{"word": [" Cereal."], "author": "gixgox"}
{"word": [" Corn"], "author": "TARFU"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Symbolic."], "author": "Casval_Deikun"}
{"word": ["iconic"], "author": "le_chevalier"}
{"word": ["Prime."], "author": "xieliming"}
{"word": ["Amazon"], "author": "TARFU"}
{"word": ["Jungle!"], "author": "GabesterOne"}
{"word": ["Fever"], "author": "jadegiant"}
{"word": ["Temperature"], "author": "Yezemin"}
{"word": ["Mercury"], "author": "park_84"}
{"word": ["Rising"], "author": "le_chevalier"}
{"word": ["Dead"], "author": "koima57"}
{"word": [], "author": "gixgox"}
{"word": ["red bull"], "author": "BlackDawn"}
{"word": [" Vigorous"], "author": "TARFU"}
{"word": ["Exercise"], "author": "Zoltan999"}
{"word": [" Heart Attack"], "author": "Lord_Kane"}
{"word": [" Bike."], "author": "Hickory"}
{"word": ["Helmet."], "author": "Narcia_"}
{"word": ["safety"], "author": "Ardal"}
{"word": ["Caution"], "author": "JeanChief22"}
{"word": ["slippery"], "author": "Dzsono"}
{"word": ["Eel."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["guitar!"], "author": "GabesterOne"}
{"word": ["chord"], "author": "Accatone"}
{"word": ["progression"], "author": "cose_vecchie"}
{"word": ["retrogression"], "author": "apehater"}
{"word": [" Advancement"], "author": "TARFU"}
{"word": [" Degeneration."], "author": "Kleetus"}
{"word": [" relentless"], "author": "Dzsono"}
{"word": ["Degeneration."], "author": "Kleetus"}
{"word": [" Incessant."], "author": "Hickory"}
{"word": ["repetitive"], "author": "le_chevalier"}
{"word": ["grind"], "author": "skimmie"}
{"word": ["Powder."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["Story"], "author": "Yezemin"}
{"word": ["Tale"], "author": "Zoltan999"}
{"word": ["Dale."], "author": "xieliming"}
{"word": ["Bale."], "author": "Hickory"}
{"word": ["Hay."], "author": "Narcia_"}
{"word": ["Heyday."], "author": "gixgox"}
{"word": ["Apex"], "author": "TARFU"}
{"word": [" Epitome... :)"], "author": "GhostwriterDoF"}
{"word": ["Embodiment."], "author": "Hickory"}
{"word": ["Essence"], "author": "TARFU"}
{"word": ["Extract."], "author": "gixgox"}
{"word": ["Extrude."], "author": "Hickory"}
{"word": ["Bevel."], "author": "LoboBlanco"}
{"word": ["Slope"], "author": "TARFU"}
{"word": [" Angle."], "author": "Kleetus"}
{"word": [" Incline."], "author": "Hickory"}
{"word": ["ramp"], "author": "le_chevalier"}
{"word": ["Wedge"], "author": "TARFU"}
{"word": ["Wedgy."], "author": "Hickory"}
{"word": ["underwear"], "author": "skimmie"}
{"word": ["Thong"], "author": "Zoltan999"}
{"word": [" :)"], "author": "skimmie"}
{"word": ["Modesty"], "author": "TARFU"}
{"word": ["Humble."], "author": "xieliming"}
{"word": ["wise"], "author": "AnnaBrown"}
{"word": ["Worldly."], "author": "Narcia_"}
{"word": ["earthly"], "author": "GabesterOne"}
{"word": ["Terran."], "author": "Hickory"}
{"word": ["Microbial..."], "author": "GhostwriterDoF"}
{"word": ["Fungal"], "author": "TARFU"}
{"word": ["Hickoral."], "author": "Kleetus"}
{"word": [" Mildew."], "author": "gixgox"}
{"word": [" Mold"], "author": "TARFU"}
{"word": ["Mould."], "author": "Hickory"}
{"word": ["Hickery."], "author": "Kleetus"}
{"word": ["Mould."], "author": "Hickory"}
{"word": [" Form"], "author": "TARFU"}
{"word": ["Fickory."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Fickory."], "author": "Kleetus"}
{"word": [" Echelon"], "author": "TARFU"}
{"word": ["surveillance ", " "], "author": "GabesterOne"}
{"word": ["Espionage"], "author": "Azrael360"}
{"word": ["Stealth."], "author": "xieliming"}
{"word": ["Bomber"], "author": "TARFU"}
{"word": ["jacket"], "author": "Dzsono"}
{"word": ["Strait"], "author": "Yezemin"}
{"word": ["Dire"], "author": "park_84"}
{"word": ["wolf"], "author": "le_chevalier"}
{"word": ["Sniper"], "author": "Antimateria"}
{"word": [" Pack."], "author": "Hickory"}
{"word": ["Group"], "author": "doctorsinister"}
{"word": ["Gang."], "author": "gixgox"}
{"word": ["outlaws"], "author": "GabesterOne"}
{"word": ["Renegade"], "author": "Pickle1477"}
{"word": ["Paragon."], "author": "Hickory"}
{"word": ["Model"], "author": "TARFU"}
{"word": ["Miniature."], "author": "VampiroAlhazred"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": [" ", "."], "author": "gixgox"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": [" ", "."], "author": "gixgox"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": [" Large"], "author": "TARFU"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Hickory. ", " Hickory."], "author": "Kleetus"}
{"word": ["wood"], "author": "GabesterOne"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Insect."], "author": "REDVWIN"}
{"word": ["inspect"], "author": "Dzsono"}
{"word": ["inept"], "author": "Agrilla"}
{"word": ["lacking"], "author": "GabesterOne"}
{"word": ["Insufficient"], "author": "Yezemin"}
{"word": ["Enough"], "author": "park_84"}
{"word": ["adequate"], "author": "le_chevalier"}
{"word": ["sufficient"], "author": "skimmie"}
{"word": ["Fair."], "author": "gixgox"}
{"word": ["Game."], "author": "Hickory"}
{"word": ["meat"], "author": "le_chevalier"}
{"word": ["Steak."], "author": "xieliming"}
{"word": ["Sandwich"], "author": "Zoltan999"}
{"word": [], "author": "skimmie"}
{"word": ["Grey."], "author": "gixgox"}
{"word": ["Goo"], "author": "truhlik"}
{"word": [], "author": "Zoltan999"}
{"word": ["Splotch."], "author": "Hickory"}
{"word": ["Paint."], "author": "Narcia_"}
{"word": ["Brush"], "author": "cose_vecchie"}
{"word": ["Tooth"], "author": "Yezemin"}
{"word": ["paste"], "author": "GabesterOne"}
{"word": ["grind"], "author": "Ardal"}
{"word": ["Pestle... :)"], "author": "GhostwriterDoF"}
{"word": ["Nestle."], "author": "Kleetus"}
{"word": ["chocolade"], "author": "Agrilla"}
{"word": ["bistro"], "author": "JDelekto"}
{"word": ["Buffet"], "author": "Dzsono"}
{"word": [" Warren."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Meze."], "author": "Hickory"}
{"word": ["mezzanine"], "author": "park_84"}
{"word": [". ", " ", " <Sorry>"], "author": "gixgox"}
{"word": ["apologetic"], "author": "JDelekto"}
{"word": ["Contrite"], "author": "Zoltan999"}
{"word": ["Honest."], "author": "Narcia_"}
{"word": ["natural"], "author": "JDelekto"}
{"word": ["causes"], "author": "skimmie"}
{"word": ["effects"], "author": "JDelekto"}
{"word": ["Reactions."], "author": "Hickory"}
{"word": ["animated"], "author": "Dzsono"}
{"word": ["Anime"], "author": "SamMagel"}
{"word": ["weeabos"], "author": "GabesterOne"}
{"word": ["gaijin"], "author": "Dzsono"}
{"word": ["foreigner"], "author": "GabesterOne"}
{"word": ["Kaching."], "author": "Kleetus"}
{"word": [" Non-native."], "author": "gixgox"}
{"word": ["alien"], "author": "park_84"}
{"word": ["Racism"], "author": "Antimateria"}
{"word": ["Bias."], "author": "Hickory"}
{"word": ["Tendency"], "author": "Zoltan999"}
{"word": ["Leaning."], "author": "Hickory"}
{"word": ["curve"], "author": "BlackDawn"}
{"word": ["line"], "author": "GabesterOne"}
{"word": ["Red"], "author": "PaterAlf"}
{"word": ["Emergency."], "author": "REDVWIN"}
{"word": ["State."], "author": "xieliming"}
{"word": ["city"], "author": "le_chevalier"}
{"word": ["Metropolis."], "author": "Hickory"}
{"word": ["gotham"], "author": "GabesterOne"}
{"word": ["City"], "author": "Yezemin"}
{"word": ["Cosmopolitan"], "author": "park_84"}
{"word": ["magazine"], "author": "skimmie"}
{"word": ["firearm"], "author": "Dzsono"}
{"word": ["law"], "author": "Ardal"}
{"word": ["Outlaw."], "author": "Hickory"}
{"word": ["Fugitive"], "author": "Zoltan999"}
{"word": ["Wanted"], "author": "Yezemin"}
{"word": ["Poster."], "author": "Narcia_"}
{"word": ["Flyer."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["Will"], "author": "almabrds"}
{"word": ["Power"], "author": "Madshaker"}
{"word": ["outage"], "author": "Zordu"}
{"word": ["Interruption."], "author": "Hickory"}
{"word": ["OBJECTION!"], "author": "GabesterOne"}
{"word": ["Overruled"], "author": "flubbucket"}
{"word": ["vetoed"], "author": "le_chevalier"}
{"word": ["bill"], "author": "semigroups"}
{"word": ["Invoice"], "author": "Yezemin"}
{"word": ["receipt"], "author": "le_chevalier"}
{"word": ["surcharge"], "author": "Dzsono"}
{"word": ["Levy."], "author": "Hickory"}
{"word": ["Tax."], "author": "xieliming"}
{"word": ["taxi"], "author": "park_84"}
{"word": ["."], "author": "gixgox"}
{"word": [" Ha! Those were interesting, to say the least ", " ", " ", " Stuffed"], "author": "Zoltan999"}
{"word": ["Bloated."], "author": "Hickory"}
{"word": ["Carcass"], "author": "brouer"}
{"word": ["Turkey."], "author": "Narcia_"}
{"word": ["dinner"], "author": "semigroups"}
{"word": ["Guest."], "author": "Hickory"}
{"word": ["Seventh"], "author": "VampiroAlhazred"}
{"word": ["Heaven"], "author": "GabesterOne"}
{"word": ["Outlandish."], "author": "Hickory"}
{"word": ["Ethereal."], "author": "REDVWIN"}
{"word": ["wisp"], "author": "Densetsu"}
{"word": [], "author": "skimmie"}
{"word": ["Resolve."], "author": "Hickory"}
{"word": ["resolution"], "author": "GabesterOne"}
{"word": ["Determination"], "author": "koima57"}
{"word": ["fatalism"], "author": "Dzsono"}
{"word": ["Pessimism"], "author": "Yezemin"}
{"word": ["doom"], "author": "le_chevalier"}
{"word": ["Carmack"], "author": "park_84"}
{"word": ["famous"], "author": "Ardal"}
{"word": [], "author": "gixgox"}
{"word": ["Magnificent."], "author": "Hickory"}
{"word": ["resplendent"], "author": "skimmie"}
{"word": ["Attire"], "author": "Zoltan999"}
{"word": ["Tailoring."], "author": "Narcia_"}
{"word": ["Tinker. :P"], "author": "GhostwriterDoF"}
{"word": ["Mechanic"], "author": "GabesterOne"}
{"word": ["Spanner."], "author": "Hickory"}
{"word": ["Spotter."], "author": "gixgox"}
{"word": ["Lunatic."], "author": "Hickory"}
{"word": ["freakazoid"], "author": "GabesterOne"}
{"word": ["crackpot"], "author": "cose_vecchie"}
{"word": ["nutter"], "author": "Dzsono"}
{"word": ["wacko"], "author": "cose_vecchie"}
{"word": ["Crazy."], "author": "xieliming"}
{"word": ["Braindead."], "author": "gixgox"}
{"word": ["lummox"], "author": "Dzsono"}
{"word": [], "author": "park_84"}
{"word": ["Lemming."], "author": "Hickory"}
{"word": ["Cliff"], "author": "Yezemin"}
{"word": ["Hanger"], "author": "flubbucket"}
{"word": ["Coat."], "author": "Hickory"}
{"word": ["Sugar- ", " "], "author": "gixgox"}
{"word": [" fix"], "author": "Densetsu"}
{"word": ["Heroin"], "author": "Zoltan999"}
{"word": ["Poppy."], "author": "Hickory"}
{"word": ["Red."], "author": "Narcia_"}
{"word": ["Alert."], "author": "gixgox"}
{"word": ["Alarm!"], "author": "le_chevalier"}
{"word": ["Bell."], "author": "Hickory"}
{"word": ["hunchback"], "author": "Densetsu"}
{"word": ["Deformity."], "author": "Hickory"}
{"word": ["Irregular..."], "author": "GhostwriterDoF"}
{"word": ["Asymmetrical."], "author": "VampiroAlhazred"}
{"word": ["Lopsided."], "author": "Hickory"}
{"word": ["Unilateral."], "author": "gixgox"}
{"word": ["Unitesticular."], "author": "Kleetus"}
{"word": ["penis"], "author": "Emachine9643"}
{"word": [" Solo."], "author": "Hickory"}
{"word": ["Han"], "author": "agentcarr16"}
{"word": ["Chinese."], "author": "xieliming"}
{"word": ["Mandarin"], "author": "le_chevalier"}
{"word": ["Ethnic."], "author": "GhostwriterDoF"}
{"word": ["Magic"], "author": "almabrds"}
{"word": ["Summer"], "author": "park_84"}
{"word": ["chakra"], "author": "Dzsono"}
{"word": ["Energy"], "author": "Yezemin"}
{"word": [" Khan."], "author": "Kleetus"}
{"word": [" Dissipation."], "author": "gixgox"}
{"word": ["O-bahn"], "author": "jimmmmmo"}
{"word": [" O-bama."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["O-bama."], "author": "Kleetus"}
{"word": [" Streetcar"], "author": "Yezemin"}
{"word": ["O-bama."], "author": "Kleetus"}
{"word": [" "], "author": "skimmie"}
{"word": [], "author": "gixgox"}
{"word": ["passion"], "author": "Densetsu"}
{"word": ["Fruit."], "author": "Hickory"}
{"word": ["Fruit ", " ", " Damn you Hicks, you Ninja ;) ", " ", " Edit: Cake"], "author": "Zoltan999"}
{"word": [" "], "author": "gixgox"}
{"word": ["stooges"], "author": "Densetsu"}
{"word": ["Three."], "author": "Narcia_"}
{"word": ["Triumvirate."], "author": "Hickory"}
{"word": ["Threesome."], "author": "VampiroAlhazred"}
{"word": ["SEX :DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD"], "author": "GabesterOne"}
{"word": [" Triplets"], "author": "agentcarr16"}
{"word": ["Siblings."], "author": "Hickory"}
{"word": [" Hickorings."], "author": "Kleetus"}
{"word": [" Family"], "author": "Azrael360"}
{"word": ["Godfather"], "author": "JDelekto"}
{"word": ["mafia (can't wait for mafia 3 :) )"], "author": "GabesterOne"}
{"word": ["Hitman"], "author": "JDelekto"}
{"word": ["bald"], "author": "park_84"}
{"word": [], "author": "truhlik"}
{"word": ["bolden"], "author": "le_chevalier"}
{"word": ["Courage."], "author": "xieliming"}
{"word": [], "author": "Dzsono"}
{"word": ["Cromulent."], "author": "gixgox"}
{"word": ["defenestrate"], "author": "JDelekto"}
{"word": [], "author": "gixgox"}
{"word": [" Neologism."], "author": "Hickory"}
{"word": ["Regicide."], "author": "Narcia_"}
{"word": ["guillotine"], "author": "Ardal"}
{"word": ["Decapitate"], "author": "Zoltan999"}
{"word": ["."], "author": "gixgox"}
{"word": ["Cruelty."], "author": "Hickory"}
{"word": ["mankind"], "author": "Densetsu"}
{"word": ["Unconvincible."], "author": "gixgox"}
{"word": ["Invincible."], "author": "Casval_Deikun"}
{"word": ["Inconvincible."], "author": "Hickory"}
{"word": ["Inconceivable"], "author": "TDP"}
{"word": ["Inconsequential."], "author": "Hickory"}
{"word": ["Inconhickoral."], "author": "Kleetus"}
{"word": ["Inconsequential."], "author": "Hickory"}
{"word": ["consequences"], "author": "JDelekto"}
{"word": ["Repercussions."], "author": "Hickory"}
{"word": ["answers"], "author": "JDelekto"}
{"word": ["Library"], "author": "almabrds"}
{"word": ["."], "author": "gixgox"}
{"word": ["Glasses"], "author": "Hardrada"}
{"word": ["goggles"], "author": "JDelekto"}
{"word": ["safety"], "author": "Zordu"}
{"word": ["first"], "author": "GabesterOne"}
{"word": ["second"], "author": "Emachine9643"}
{"word": ["Third."], "author": "xieliming"}
{"word": ["Number."], "author": "Casval_Deikun"}
{"word": ["Numero."], "author": "Kleetus"}
{"word": ["count"], "author": "GabesterOne"}
{"word": ["Dracula"], "author": "park_84"}
{"word": ["Sucks."], "author": "Kleetus"}
{"word": [" Transylvania"], "author": "Dzsono"}
{"word": ["."], "author": "gixgox"}
{"word": ["romania"], "author": "Ardal"}
{"word": ["."], "author": "gixgox"}
{"word": ["Balkans."], "author": "Hickory"}
{"word": ["poverty"], "author": "Densetsu"}
{"word": ["Squalor"], "author": "Zoltan999"}
{"word": ["Dirt."], "author": "Narcia_"}
{"word": ["soil"], "author": "Densetsu"}
{"word": ["native"], "author": "cose_vecchie"}
{"word": [" Land"], "author": "almabrds"}
{"word": [], "author": "Densetsu"}
{"word": ["View."], "author": "Hickory"}
{"word": ["vision"], "author": "Densetsu"}
{"word": ["Tele- "], "author": "gixgox"}
{"word": ["radio"], "author": "BlackDawn"}
{"word": ["Frequency."], "author": "Hickory"}
{"word": ["period"], "author": "le_chevalier"}
{"word": ["comma"], "author": "cose_vecchie"}
{"word": ["intermission"], "author": "Densetsu"}
{"word": ["Respite."], "author": "Hickory"}
{"word": ["Moratorium."], "author": "gixgox"}
{"word": ["Embargo."], "author": "Hickory"}
{"word": ["pirates"], "author": "JDelekto"}
{"word": ["Caribbean"], "author": "GabesterOne"}
{"word": ["Island."], "author": "Hickory"}
{"word": ["Queen"], "author": "JDelekto"}
{"word": ["Mercury"], "author": "park_84"}
{"word": ["Liquid."], "author": "Hickory"}
{"word": ["Metal"], "author": "JDelekto"}
{"word": ["Band."], "author": "Kleetus"}
{"word": ["Rocks."], "author": "JDelekto"}
{"word": ["Stone."], "author": "xieliming"}
{"word": ["golem"], "author": "le_chevalier"}
{"word": ["Elemental."], "author": "LoboBlanco"}
{"word": ["Air."], "author": "semigroups"}
{"word": [], "author": "gixgox"}
{"word": ["Hickoriel."], "author": "Kleetus"}
{"word": [], "author": "gixgox"}
{"word": ["Hickoriel."], "author": "Kleetus"}
{"word": [" Tempest"], "author": "Yezemin"}
{"word": ["Storm"], "author": "koima57"}
{"word": ["torrent"], "author": "Dzsono"}
{"word": ["P2P"], "author": "deathrabit"}
{"word": ["F2P"], "author": "gixgox"}
{"word": ["Monetization"], "author": "park_84"}
{"word": ["Conversion."], "author": "Hickory"}
{"word": ["change"], "author": "Densetsu"}
{"word": ["Modify"], "author": "almabrds"}
{"word": ["improve"], "author": "Densetsu"}
{"word": ["Upgrade."], "author": "gixgox"}
{"word": ["Evolve."], "author": "Hickory"}
{"word": ["antientropize"], "author": "Densetsu"}
{"word": ["Solecism."], "author": "Hickory"}
{"word": ["Soledad"], "author": "XYCat"}
{"word": ["Seclusion."], "author": "Hickory"}
{"word": ["elusion"], "author": "apehater"}
{"word": ["Illusion."], "author": "gixgox"}
{"word": ["Trickory."], "author": "Kleetus"}
{"word": ["Illusion."], "author": "gixgox"}
{"word": ["Hickory smoked salmon"], "author": "Emachine9643"}
{"word": [" hallucination"], "author": "ashwald"}
{"word": ["trance"], "author": "le_chevalier"}
{"word": ["Pythia."], "author": "VampiroAlhazred"}
{"word": [" Catalepsy."], "author": "Hickory"}
{"word": ["immobile"], "author": "Dzsono"}
{"word": ["static"], "author": "park_84"}
{"word": ["Signal"], "author": "Yezemin"}
{"word": ["Flag"], "author": "PaterAlf"}
{"word": ["division"], "author": "Densetsu"}
{"word": ["troop"], "author": "Zoltan999"}
{"word": [". ", " ", " "], "author": "gixgox"}
{"word": ["marching"], "author": "le_chevalier"}
{"word": ["Forward."], "author": "Narcia_"}
{"word": ["Directional."], "author": "GhostwriterDoF"}
{"word": ["Orientated."], "author": "Hickory"}
{"word": ["unerring"], "author": "Dzsono"}
{"word": ["."], "author": "gixgox"}
{"word": ["Direct."], "author": "Hickory"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": ["Dock"], "author": "motorkar"}
{"word": [" Blunt."], "author": "gixgox"}
{"word": ["Bludgeon."], "author": "xieliming"}
{"word": ["Pound."], "author": "Hickory"}
{"word": ["what?"], "author": "qwaffler"}
{"word": ["Pound."], "author": "Hickory"}
{"word": ["Sterling."], "author": "gixgox"}
{"word": ["Outstanding."], "author": "Hickory"}
{"word": ["remarkable"], "author": "Dzsono"}
{"word": ["Overhyped"], "author": "PaterAlf"}
{"word": ["Conference"], "author": "park_84"}
{"word": ["press"], "author": "le_chevalier"}
{"word": ["Button"], "author": "Casval_Deikun"}
{"word": ["shirt"], "author": "Ardal"}
{"word": ["Under"], "author": "Zoltan999"}
{"word": ["Over."], "author": "Narcia_"}
{"word": ["Through."], "author": "Hickory"}
{"word": ["Mirror"], "author": "PaterAlf"}
{"word": ["wonderland"], "author": "GabesterOne"}
{"word": ["."], "author": "gixgox"}
{"word": ["\"Tear down that Wall\""], "author": "Emachine9643"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" "], "author": "gixgox"}
{"word": [" "], "author": "gixgox"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Lesson"], "author": "PaterAlf"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Shcool."], "author": "Casval_Deikun"}
{"word": [" What do you shtudy when you go to shcool, is it shience?"], "author": "Kleetus"}
{"word": [" Teacher"], "author": "Yezemin"}
{"word": ["Student."], "author": "Hardrada"}
{"word": ["study"], "author": "GabesterOne"}
{"word": [" That was hilarious LOL, anyway back onto topic: ", " ", " "], "author": "jimmmmmo"}
{"word": ["trial"], "author": "le_chevalier"}
{"word": ["demo"], "author": "park_84"}
{"word": ["Version"], "author": "Zoltan999"}
{"word": ["alpha"], "author": "Ardal"}
{"word": ["topmost"], "author": "Densetsu"}
{"word": ["Least."], "author": "Narcia_"}
{"word": ["Apogee"], "author": "Dzsono"}
{"word": ["Perigee."], "author": "Hickory"}
{"word": ["orbit"], "author": "Dzsono"}
{"word": ["Path"], "author": "Cavenagh"}
{"word": ["reason"], "author": "Ardal"}
{"word": ["Logic"], "author": "jadegiant"}
{"word": [" Mr. Spock * Star Trek ;)"], "author": "deathrabit"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Bill."], "author": "Kleetus"}
{"word": ["transaction"], "author": "Densetsu"}
{"word": ["Atomic."], "author": "xieliming"}
{"word": ["Kittens."], "author": "Kleetus"}
{"word": [" Fundamental."], "author": "Hickory"}
{"word": [" Kitten."], "author": "Kleetus"}
{"word": [" Fundamental."], "author": "Hickory"}
{"word": ["core"], "author": "le_chevalier"}
{"word": ["Science. ", " ", " "], "author": "Casval_Deikun"}
{"word": ["Transistor"], "author": "Dzsono"}
{"word": [" Radio"], "author": "PaterAlf"}
{"word": ["Silence"], "author": "Yezemin"}
{"word": ["lambs"], "author": "Ardal"}
{"word": ["wolves"], "author": "ashwald"}
{"word": ["pack"], "author": "Densetsu"}
{"word": ["Bundle"], "author": "Zoltan999"}
{"word": ["Collection."], "author": "Narcia_"}
{"word": ["stacking"], "author": "Densetsu"}
{"word": ["Lacking."], "author": "Hickory"}
{"word": ["Hickoring."], "author": "Kleetus"}
{"word": [" laxity"], "author": "Dzsono"}
{"word": ["Lenience."], "author": "Hickory"}
{"word": ["Forbearance."], "author": "gixgox"}
{"word": ["Fortitude"], "author": "TARFU"}
{"word": ["Strength"], "author": "park_84"}
{"word": ["honor"], "author": "le_chevalier"}
{"word": ["principle"], "author": "JDelekto"}
{"word": ["Concept."], "author": "Hickory"}
{"word": ["Spark."], "author": "JDelekto"}
{"word": ["igniting"], "author": "Ardal"}
{"word": ["Volatile"], "author": "Zoltan999"}
{"word": ["Gas"], "author": "Yezemin"}
{"word": ["beans"], "author": "JDelekto"}
{"word": ["Rice"], "author": "TARFU"}
{"word": ["staple"], "author": "JDelekto"}
{"word": [" Standard"], "author": "TARFU"}
{"word": ["Banner."], "author": "Hickory"}
{"word": ["Bruce"], "author": "Maxvorstadt"}
{"word": ["Lee"], "author": "Madshaker"}
{"word": ["S\u0336p\u0336r\u0336u\u0336c\u0336e\u0336. ", " [Ninja'd] ", " ", " Lea."], "author": "Hickory"}
{"word": ["Princess"], "author": "JDelekto"}
{"word": ["Crown."], "author": "Narcia_"}
{"word": ["Temple."], "author": "xieliming"}
{"word": ["Priest"], "author": "GabesterOne"}
{"word": ["."], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["moon"], "author": "le_chevalier"}
{"word": ["Orbit"], "author": "TARFU"}
{"word": ["Kepler."], "author": "VampiroAlhazred"}
{"word": ["Astronomer"], "author": "TARFU"}
{"word": ["scientist"], "author": "GabesterOne"}
{"word": ["Empirical"], "author": "park_84"}
{"word": ["formula"], "author": "le_chevalier"}
{"word": ["one"], "author": "Ardal"}
{"word": ["Two"], "author": "PaterAlf"}
{"word": ["binary"], "author": "Dzsono"}
{"word": ["star"], "author": "le_chevalier"}
{"word": [], "author": "Zoltan999"}
{"word": ["tasty"], "author": "apehater"}
{"word": ["Food."], "author": "Narcia_"}
{"word": ["Nutriments."], "author": "REDVWIN"}
{"word": ["Sustenance."], "author": "Hickory"}
{"word": ["Food"], "author": "TARFU"}
{"word": ["agriculture"], "author": "Densetsu"}
{"word": ["Aquaculture."], "author": "gixgox"}
{"word": ["Horticulture"], "author": "JDelekto"}
{"word": ["Agriculture"], "author": "Dzsono"}
{"word": ["viniculture"], "author": "JDelekto"}
{"word": ["Wine"], "author": "TARFU"}
{"word": ["bottle"], "author": "JDelekto"}
{"word": ["Jar"], "author": "TARFU"}
{"word": ["glass"], "author": "JDelekto"}
{"word": ["Drinking"], "author": "TARFU"}
{"word": ["imbibing"], "author": "JDelekto"}
{"word": ["Quaffing."], "author": "Hickory"}
{"word": [" Hickoring."], "author": "Kleetus"}
{"word": ["Quaffing."], "author": "Hickory"}
{"word": ["Hickoring."], "author": "Kleetus"}
{"word": ["Quaffing."], "author": "Hickory"}
{"word": ["Hickoring."], "author": "Kleetus"}
{"word": ["Quaffing."], "author": "Hickory"}
{"word": ["Swigging."], "author": "gixgox"}
{"word": ["Hickoring."], "author": "Kleetus"}
{"word": ["Swigging."], "author": "gixgox"}
{"word": ["Swigging."], "author": "gixgox"}
{"word": [" Guzzling."], "author": "Hickory"}
{"word": [" imbibing"], "author": "Dzsono"}
{"word": [" Drinking"], "author": "TARFU"}
{"word": ["Alcohol"], "author": "Yezemin"}
{"word": ["Shot"], "author": "park_84"}
{"word": ["injection"], "author": "le_chevalier"}
{"word": ["Manifold."], "author": "Hickory"}
{"word": ["Manifold."], "author": "Hickory"}
{"word": ["Topology."], "author": "xieliming"}
{"word": ["space"], "author": "ashwald"}
{"word": ["Frontier"], "author": "Zoltan999"}
{"word": ["Final"], "author": "Lifthrasil"}
{"word": ["."], "author": "gixgox"}
{"word": ["Finish."], "author": "Narcia_"}
{"word": ["Line."], "author": "HypersomniacLive"}
{"word": ["Astern."], "author": "Hickory"}
{"word": ["Behind"], "author": "TARFU"}
{"word": ["."], "author": "gixgox"}
{"word": ["Retreat"], "author": "TARFU"}
{"word": ["escape"], "author": "Dzsono"}
{"word": ["route"], "author": "Ardal"}
{"word": ["Path"], "author": "GabesterOne"}
{"word": ["Trail."], "author": "Hickory"}
{"word": [" Trickory."], "author": "Kleetus"}
{"word": ["Trail."], "author": "Hickory"}
{"word": [" Track"], "author": "TARFU"}
{"word": ["Sound"], "author": "viperfdl"}
{"word": ["pound"], "author": "apehater"}
{"word": [" Cake"], "author": "TARFU"}
{"word": ["Cheese."], "author": "HypersomniacLive"}
{"word": ["Onion."], "author": "Hickory"}
{"word": ["Vegetable"], "author": "PaterAlf"}
{"word": ["Produce."], "author": "pearnon"}
{"word": ["Cultivate."], "author": "gixgox"}
{"word": ["Nurture."], "author": "Hickory"}
{"word": ["raise"], "author": "TARFU"}
{"word": ["Erect."], "author": "Kleetus"}
{"word": [" Elevate."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Elevate."], "author": "Hickory"}
{"word": [" Erect."], "author": "Kleetus"}
{"word": [" Soar"], "author": "TARFU"}
{"word": ["Erect."], "author": "Kleetus"}
{"word": [" Climb."], "author": "gixgox"}
{"word": ["Erect."], "author": "Kleetus"}
{"word": [" Lifting."], "author": "Casval_Deikun"}
{"word": ["Weights"], "author": "TARFU"}
{"word": ["Mass."], "author": "xieliming"}
{"word": ["Energy"], "author": "Dzsono"}
{"word": ["Synergy"], "author": "Yezemin"}
{"word": ["force"], "author": "park_84"}
{"word": ["awakens"], "author": "gixgox"}
{"word": ["Rises."], "author": "Hickory"}
{"word": ["upward"], "author": "le_chevalier"}
{"word": ["Skywards."], "author": "gixgox"}
{"word": ["atmosphere"], "author": "Fillary"}
{"word": ["Oxygen"], "author": "Maxvorstadt"}
{"word": ["Element"], "author": "Zoltan999"}
{"word": ["fifth"], "author": "Ardal"}
{"word": ["Phalanges. :P"], "author": "GhostwriterDoF"}
{"word": ["Fingers"], "author": "TARFU"}
{"word": ["Clutch..."], "author": "GhostwriterDoF"}
{"word": ["Pedal"], "author": "TARFU"}
{"word": ["Metal"], "author": "viperfdl"}
{"word": ["alchemy"], "author": "Dzsono"}
{"word": ["Mysticism"], "author": "TARFU"}
{"word": ["Destruction."], "author": "Hickory"}
{"word": ["Demolition"], "author": "TARFU"}
{"word": ["Mayhem."], "author": "Hickory"}
{"word": ["Doomsday."], "author": "gixgox"}
{"word": ["Armageddon"], "author": "TARFU"}
{"word": ["Annihilation"], "author": "jadegiant"}
{"word": ["Jeff VanderMeer"], "author": "pearnon"}
{"word": [" Obliteration."], "author": "Hickory"}
{"word": [" Hickory Dickory."], "author": "Kleetus"}
{"word": [" Obliteration."], "author": "Hickory"}
{"word": ["total"], "author": "GabesterOne"}
{"word": ["Complete"], "author": "TARFU"}
{"word": ["Entire."], "author": "VampiroAlhazred"}
{"word": ["Whole."], "author": "Hickory"}
{"word": [" Whickory."], "author": "Kleetus"}
{"word": [" Full."], "author": "gixgox"}
{"word": ["Empty."], "author": "Narcia_"}
{"word": ["Gone"], "author": "codyaj1995"}
{"word": ["Home."], "author": "semigroups"}
{"word": ["Abode"], "author": "TARFU"}
{"word": ["Adobe"], "author": "coryrj1995"}
{"word": ["Acrobat."], "author": "xieliming"}
{"word": ["Gymnast"], "author": "TARFU"}
{"word": ["Athlete."], "author": "Hickory"}
{"word": ["Canine."], "author": "Kleetus"}
{"word": ["Athlete."], "author": "Hickory"}
{"word": ["Terrier."], "author": "Kleetus"}
{"word": ["wofford (college mascot terriers)"], "author": "GabesterOne"}
{"word": [" Jock."], "author": "gixgox"}
{"word": ["support"], "author": "le_chevalier"}
{"word": ["Problem"], "author": "Maxvorstadt"}
{"word": ["blame"], "author": "le_chevalier"}
{"word": ["guilt"], "author": "park_84"}
{"word": ["conscientious"], "author": "le_chevalier"}
{"word": ["fastidious"], "author": "Dzsono"}
{"word": ["baby"], "author": "Fillary"}
{"word": ["shower"], "author": "Ardal"}
{"word": ["Cap."], "author": "gixgox"}
{"word": ["level"], "author": "ashwald"}
{"word": ["bug"], "author": "apehater"}
{"word": ["Feature"], "author": "TARFU"}
{"word": ["attribute"], "author": "GabesterOne"}
{"word": ["Trait."], "author": "Hickory"}
{"word": ["Terrier."], "author": "Kleetus"}
{"word": [" Character"], "author": "PaterAlf"}
{"word": ["Terrier."], "author": "Kleetus"}
{"word": [" Actor"], "author": "TARFU"}
{"word": ["Terrier."], "author": "Kleetus"}
{"word": [" Thespian."], "author": "Hickory"}
{"word": [" Terrier."], "author": "Kleetus"}
{"word": ["bite"], "author": "kmonster"}
{"word": [" Thespian."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["Stage"], "author": "TDP"}
{"word": [" Bonus"], "author": "almabrds"}
{"word": ["Extra"], "author": "TARFU"}
{"word": ["Cameo."], "author": "xieliming"}
{"word": ["Camel."], "author": "semigroups"}
{"word": ["Desert."], "author": "Hickory"}
{"word": ["Wasteland"], "author": "TARFU"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Badlands."], "author": "gixgox"}
{"word": [" Toe."], "author": "Kleetus"}
{"word": [" Desolation"], "author": "TARFU"}
{"word": ["Toe."], "author": "Kleetus"}
{"word": [" Pod (", ")"], "author": "almabrds"}
{"word": ["pea"], "author": "Dzsono"}
{"word": ["Soup"], "author": "Yezemin"}
{"word": ["Broth"], "author": "park_84"}
{"word": ["Beef"], "author": "TARFU"}
{"word": ["stew"], "author": "Ardal"}
{"word": ["bawdyhouse"], "author": "le_chevalier"}
{"word": ["fullhouse"], "author": "XYCat"}
{"word": ["Slaughterhouse."], "author": "gixgox"}
{"word": ["Lighthouse."], "author": "Hickory"}
{"word": ["Beacon"], "author": "TARFU"}
{"word": ["attraction"], "author": "Ardal"}
{"word": ["repulsion"], "author": "Dzsono"}
{"word": ["distasteful"], "author": "GabesterOne"}
{"word": ["Putrid."], "author": "Hickory"}
{"word": ["decaying (just like Kleetus rep, hue hue hue)"], "author": "GabesterOne"}
{"word": ["degenerating"], "author": "le_chevalier"}
{"word": [" Rotten."], "author": "gixgox"}
{"word": [" Rotten."], "author": "Kleetus"}
{"word": [" Decayed"], "author": "TARFU"}
{"word": ["Rotten."], "author": "Kleetus"}
{"word": [" Decomposed."], "author": "Hickory"}
{"word": ["Rotten."], "author": "Kleetus"}
{"word": [" Decomposed."], "author": "Hickory"}
{"word": ["Rotten."], "author": "Kleetus"}
{"word": [" Compost"], "author": "TARFU"}
{"word": ["Rotten."], "author": "Kleetus"}
{"word": ["tomatoes"], "author": "Ardal"}
{"word": ["Attack."], "author": "xieliming"}
{"word": [" Heap."], "author": "Hickory"}
{"word": ["sort ( i am a nerd :) )"], "author": "GabesterOne"}
{"word": ["Kind"], "author": "park_84"}
{"word": ["Category"], "author": "Yezemin"}
{"word": ["Definition"], "author": "Dzsono"}
{"word": ["dictionary"], "author": "Ardal"}
{"word": ["Lexicon."], "author": "gixgox"}
{"word": ["Book"], "author": "Yezemin"}
{"word": ["Library"], "author": "Zoltan999"}
{"word": ["Archive."], "author": "Narcia_"}
{"word": ["Storage"], "author": "TARFU"}
{"word": ["Shed"], "author": "GabesterOne"}
{"word": ["depot"], "author": "le_chevalier"}
{"word": ["Train"], "author": "TARFU"}
{"word": ["Locomotive."], "author": "gixgox"}
{"word": ["Transitory."], "author": "Hickory"}
{"word": ["momentary"], "author": "GabesterOne"}
{"word": ["Ephemeral"], "author": "TARFU"}
{"word": [" Evanescent."], "author": "Hickory"}
{"word": [" Vanished"], "author": "PaterAlf"}
{"word": ["Evaporated."], "author": "Hickory"}
{"word": ["Clouds"], "author": "GabesterOne"}
{"word": [" "], "author": "Hickory"}
{"word": ["Contrails."], "author": "gixgox"}
{"word": ["Vapour."], "author": "Hickory"}
{"word": ["water"], "author": "GabesterOne"}
{"word": ["Liquid"], "author": "PaterAlf"}
{"word": ["Liqueur."], "author": "gixgox"}
{"word": ["Booze"], "author": "TARFU"}
{"word": ["Alcohol."], "author": "xieliming"}
{"word": ["Whiskey"], "author": "TARFU"}
{"word": [" Spirits."], "author": "Kleetus"}
{"word": [" Bartender"], "author": "almabrds"}
{"word": ["Spirits."], "author": "Kleetus"}
{"word": ["Rum"], "author": "GabesterOne"}
{"word": [" Tapster."], "author": "Hickory"}
{"word": ["barkeep"], "author": "Dzsono"}
{"word": ["liscnesed"], "author": "GabesterOne"}
{"word": ["Moonshine."], "author": "gixgox"}
{"word": ["Starglow"], "author": "JDelekto"}
{"word": ["stardust"], "author": "park_84"}
{"word": ["moon dirt"], "author": "JDelekto"}
{"word": ["minerals"], "author": "GabesterOne"}
{"word": ["Materials"], "author": "le_chevalier"}
{"word": ["palpable"], "author": "Densetsu"}
{"word": ["haptic"], "author": "Ardal"}
{"word": ["feedback"], "author": "JDelekto"}
{"word": [], "author": "Zoltan999"}
{"word": ["resonance"], "author": "Densetsu"}
{"word": ["Echo."], "author": "Narcia_"}
{"word": ["Repeat"], "author": "TARFU"}
{"word": ["retreat"], "author": "apehater"}
{"word": ["Forfeit."], "author": "REDVWIN"}
{"word": [" Loss"], "author": "almabrds"}
{"word": ["Deficit."], "author": "Hickory"}
{"word": ["Budgeted"], "author": "GabesterOne"}
{"word": ["accounting"], "author": "JDelekto"}
{"word": ["finical"], "author": "GabesterOne"}
{"word": [" debt"], "author": "mm324"}
{"word": [" Usury"], "author": "TARFU"}
{"word": ["vig"], "author": "JDelekto"}
{"word": ["Vigilante."], "author": "HypersomniacLive"}
{"word": ["justice"], "author": "JDelekto"}
{"word": ["just"], "author": "Accatone"}
{"word": ["us"], "author": "JDelekto"}
{"word": ["cuz"], "author": "Accatone"}
{"word": ["Vernacular."], "author": "Hickory"}
{"word": [" Way."], "author": "Kleetus"}
{"word": [" lexicon"], "author": "Dzsono"}
{"word": ["Language"], "author": "TARFU"}
{"word": ["Native"], "author": "PaterAlf"}
{"word": ["aboriginal"], "author": "le_chevalier"}
{"word": ["Indigenous."], "author": "Hickory"}
{"word": ["Indigenous."], "author": "Hickory"}
{"word": [" People"], "author": "PaterAlf"}
{"word": [" Folk."], "author": "Hickory"}
{"word": [" Terriers."], "author": "Kleetus"}
{"word": [" Folk."], "author": "Hickory"}
{"word": ["Folklore"], "author": "Azrael360"}
{"word": [" Fable"], "author": "TARFU"}
{"word": ["Terriers."], "author": "Kleetus"}
{"word": ["Boston (The Boston Terriers are dogs from the past and many elderly people recognize them from their ... Fable, my Boston Terrier was born November 22, 1999; I have.)"], "author": "GabesterOne"}
{"word": [" Parable."], "author": "Hickory"}
{"word": [" Verse (and why did u skip me like that)"], "author": "GabesterOne"}
{"word": [" [Because you're a troll enabler.] ", " ", " Parable."], "author": "Hickory"}
{"word": ["Prose (because I follow the rules on this game, instead of ignoring them when I please?)"], "author": "GabesterOne"}
{"word": [" [No, because you're a troll enabler.] ", " ", " Parable."], "author": "Hickory"}
{"word": [" Legend"], "author": "TARFU"}
{"word": ["Myth."], "author": "Hickory"}
{"word": ["Story"], "author": "GabesterOne"}
{"word": ["Tale"], "author": "TARFU"}
{"word": ["Duck"], "author": "park_84"}
{"word": [" cover"], "author": "Dzsono"}
{"word": [" Lid"], "author": "TARFU"}
{"word": [" Eye."], "author": "Hickory"}
{"word": [" Eye."], "author": "Hickory"}
{"word": ["Nose"], "author": "Hardrada"}
{"word": ["Mustache."], "author": "Hickory"}
{"word": [" Whiskers."], "author": "Kleetus"}
{"word": ["Mustache."], "author": "Hickory"}
{"word": ["Goatee."], "author": "gixgox"}
{"word": ["style"], "author": "Densetsu"}
{"word": ["Panache"], "author": "Zoltan999"}
{"word": ["Trendy."], "author": "Narcia_"}
{"word": ["fad"], "author": "GabesterOne"}
{"word": ["Hipster"], "author": "brouer"}
{"word": ["Pretentious"], "author": "TARFU"}
{"word": ["Highfalutin."], "author": "Hickory"}
{"word": ["haughty"], "author": "Dzsono"}
{"word": ["aspiring"], "author": "JDelekto"}
{"word": ["Acolyte"], "author": "TARFU"}
{"word": ["follower"], "author": "GabesterOne"}
{"word": ["Apocalypse."], "author": "xieliming"}
{"word": [" Henchman."], "author": "Hickory"}
{"word": ["Minion"], "author": "TARFU"}
{"word": ["Puppy."], "author": "Kleetus"}
{"word": ["underling"], "author": "GabesterOne"}
{"word": [" Employee"], "author": "TARFU"}
{"word": ["staff"], "author": "le_chevalier"}
{"word": ["Wand."], "author": "Hickory"}
{"word": ["wave"], "author": "Dzsono"}
{"word": ["Ocean"], "author": "TARFU"}
{"word": ["depths"], "author": "GabesterOne"}
{"word": ["Hidden"], "author": "Yezemin"}
{"word": ["invisible"], "author": "le_chevalier"}
{"word": ["Unseen"], "author": "TARFU"}
{"word": ["Novelty"], "author": "park_84"}
{"word": [" Concealed."], "author": "Hickory"}
{"word": [" Kenneled."], "author": "Kleetus"}
{"word": [" Concealed."], "author": "Hickory"}
{"word": ["Truth."], "author": "Narcia_"}
{"word": ["Simple"], "author": "Zoltan999"}
{"word": ["Easy"], "author": "TARFU"}
{"word": ["Severe."], "author": "gixgox"}
{"word": ["Harsh"], "author": "TARFU"}
{"word": ["mellow"], "author": "le_chevalier"}
{"word": [], "author": "gixgox"}
{"word": ["submarine"], "author": "Ardal"}
{"word": ["Torpedo"], "author": "TARFU"}
{"word": ["missile"], "author": "GabesterOne"}
{"word": ["projectile"], "author": "TARFU"}
{"word": ["parabola"], "author": "park_84"}
{"word": ["Arc"], "author": "TARFU"}
{"word": ["tangent"], "author": "park_84"}
{"word": ["Contiguous."], "author": "Hickory"}
{"word": ["contact"], "author": "GabesterOne"}
{"word": ["lens"], "author": "cose_vecchie"}
{"word": ["Flare"], "author": "viperfdl"}
{"word": ["Gun."], "author": "xieliming"}
{"word": ["musket"], "author": "Dzsono"}
{"word": [" "], "author": "gixgox"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" Oasis"], "author": "TARFU"}
{"word": ["Haven."], "author": "Hickory"}
{"word": ["Refuge"], "author": "TARFU"}
{"word": ["Heaven"], "author": "SamMagel"}
{"word": ["paradise"], "author": "Emachine9643"}
{"word": [], "author": "gixgox"}
{"word": ["Adrift."], "author": "Hickory"}
{"word": [" "], "author": "Hickory"}
{"word": ["Castaway."], "author": "REDVWIN"}
{"word": ["Shipwrecked."], "author": "Hickory"}
{"word": ["sunk"], "author": "GabesterOne"}
{"word": [" Shipwrecked."], "author": "Hickory"}
{"word": [" Shipwrecked."], "author": "Hickory"}
{"word": [" Shipwrecked."], "author": "Hickory"}
{"word": ["crashed"], "author": "GabesterOne"}
{"word": ["impacted"], "author": "TARFU"}
{"word": ["meteorite"], "author": "park_84"}
{"word": ["precious"], "author": "le_chevalier"}
{"word": ["Gem"], "author": "Yezemin"}
{"word": ["emerald"], "author": "GabesterOne"}
{"word": ["green"], "author": "Ardal"}
{"word": ["Verdant."], "author": "Hickory"}
{"word": ["rural"], "author": "GabesterOne"}
{"word": ["Rustic"], "author": "TARFU"}
{"word": ["simple"], "author": "GabesterOne"}
{"word": ["ton"], "author": "Zjeraar"}
{"word": ["Pound."], "author": "gixgox"}
{"word": ["batter"], "author": "Dzsono"}
{"word": ["Baseball"], "author": "TARFU"}
{"word": ["[Ninja'd] ", " ", ". ", " ", " League."], "author": "Hickory"}
{"word": ["Corps."], "author": "REDVWIN"}
{"word": ["regiments"], "author": "GabesterOne"}
{"word": ["Battalion"], "author": "TARFU"}
{"word": ["Pack."], "author": "Kleetus"}
{"word": ["wolf"], "author": "GabesterOne"}
{"word": ["Pack"], "author": "TARFU"}
{"word": ["Rat"], "author": "viperfdl"}
{"word": ["Terrier."], "author": "Kleetus"}
{"word": [" Mouse."], "author": "gixgox"}
{"word": ["Mickey"], "author": "Licurg"}
{"word": ["Rourke"], "author": "viperfdl"}
{"word": ["Actor."], "author": "gixgox"}
{"word": ["Method"], "author": "Zoltan999"}
{"word": ["Procedure."], "author": "Narcia_"}
{"word": ["Procedural..."], "author": "GhostwriterDoF"}
{"word": ["algorithmic"], "author": "Dzsono"}
{"word": ["Mathematic"], "author": "TARFU"}
{"word": ["exact"], "author": "le_chevalier"}
{"word": ["Logic"], "author": "Azrael360"}
{"word": ["Reason"], "author": "TARFU"}
{"word": ["Rhyme"], "author": "Yezemin"}
{"word": ["Thyme."], "author": "Hickory"}
{"word": ["Herb"], "author": "TARFU"}
{"word": ["Hickory-infused."], "author": "Kleetus"}
{"word": [" Garden."], "author": "Hickory"}
{"word": ["Green"], "author": "kmonster"}
{"word": ["White."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" Leash."], "author": "Kleetus"}
{"word": [" sprawl"], "author": "Dzsono"}
{"word": ["Spread."], "author": "Hickory"}
{"word": ["Leash."], "author": "Kleetus"}
{"word": [" Vegemite."], "author": "gixgox"}
{"word": ["Leash."], "author": "Kleetus"}
{"word": [" Vegemite."], "author": "gixgox"}
{"word": ["Leash."], "author": "Kleetus"}
{"word": [" Yeast."], "author": "Hickory"}
{"word": [" Fleas."], "author": "Kleetus"}
{"word": [" Dough."], "author": "gixgox"}
{"word": ["Fleas."], "author": "Kleetus"}
{"word": [" Oven."], "author": "Hickory"}
{"word": [" Pizza"], "author": "TARFU"}
{"word": ["Fleas."], "author": "Kleetus"}
{"word": [" Cheese."], "author": "Hickory"}
{"word": ["Bones."], "author": "Kleetus"}
{"word": [" Cheese."], "author": "Hickory"}
{"word": ["Bones."], "author": "Kleetus"}
{"word": [" Cheese."], "author": "Hickory"}
{"word": ["Bones."], "author": "Kleetus"}
{"word": [" Cheese."], "author": "Hickory"}
{"word": ["Bones."], "author": "Kleetus"}
{"word": [" Cheddar"], "author": "TARFU"}
{"word": ["Bones."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" Canyon"], "author": "TARFU"}
{"word": ["Bones."], "author": "Kleetus"}
{"word": [" Ravine."], "author": "Hickory"}
{"word": ["Rabbi"], "author": "park_84"}
{"word": ["clergy"], "author": "Dzsono"}
{"word": ["corruption"], "author": "Ardal"}
{"word": ["abuse"], "author": "le_chevalier"}
{"word": ["Substance."], "author": "Hickory"}
{"word": ["Material"], "author": "TARFU"}
{"word": ["Girl"], "author": "le_chevalier"}
{"word": ["Power."], "author": "Hickory"}
{"word": ["Force"], "author": "Lifthrasil"}
{"word": ["Push"], "author": "Zoltan999"}
{"word": ["pull"], "author": "le_chevalier"}
{"word": ["Shove."], "author": "Narcia_"}
{"word": ["."], "author": "Hickory"}
{"word": ["Coin"], "author": "TARFU"}
{"word": ["Dubloon"], "author": "Yezemin"}
{"word": ["Gold"], "author": "TARFU"}
{"word": ["hold"], "author": "apehater"}
{"word": ["shit"], "author": "swatkat"}
{"word": ["gypsy"], "author": "apehater"}
{"word": ["Curse. (I had to think how can someone get from shit to gypsy but whatever, rules are rules)"], "author": "Antimateria"}
{"word": ["witch"], "author": "BlackDawn"}
{"word": ["Witcher."], "author": "Hickory"}
{"word": ["game"], "author": "SamMagel"}
{"word": ["Diversity. (nowadays)"], "author": "Antimateria"}
{"word": ["Multiplicity."], "author": "Hickory"}
{"word": [" Hickoricity."], "author": "Kleetus"}
{"word": ["Multiplicity."], "author": "Hickory"}
{"word": [" Intercity."], "author": "gixgox"}
{"word": [" Hickoricity."], "author": "Kleetus"}
{"word": [" Intercity."], "author": "gixgox"}
{"word": [" Urban"], "author": "TARFU"}
{"word": [" Keith."], "author": "Kleetus"}
{"word": [" urbane"], "author": "Dzsono"}
{"word": ["Tribe"], "author": "PaterAlf"}
{"word": ["Clan"], "author": "TARFU"}
{"word": ["Chief."], "author": "Hickory"}
{"word": ["Thief."], "author": "Fantasysci5"}
{"word": [" Robber (missed you, Fantasia)."], "author": "Kleetus"}
{"word": [" Fief."], "author": "gixgox"}
{"word": ["Allegiance"], "author": "TDP"}
{"word": ["Fealty."], "author": "Hickory"}
{"word": [" Loyalty."], "author": "Kleetus"}
{"word": [" Oath"], "author": "TARFU"}
{"word": ["Loyalty."], "author": "Kleetus"}
{"word": [" Pledge."], "author": "Hickory"}
{"word": ["bond"], "author": "le_chevalier"}
{"word": ["Word"], "author": "TARFU"}
{"word": ["Phrase."], "author": "Hickory"}
{"word": ["Sentence"], "author": "park_84"}
{"word": ["Structure"], "author": "TARFU"}
{"word": [" Kennel."], "author": "Kleetus"}
{"word": ["Fennel"], "author": "brouer"}
{"word": [" Vegetable"], "author": "koima57"}
{"word": ["Green"], "author": "Yezemin"}
{"word": ["Grass"], "author": "enurbenur"}
{"word": [" Design."], "author": "Hickory"}
{"word": ["Draft."], "author": "Narcia_"}
{"word": ["Draught."], "author": "Hickory"}
{"word": ["Cold"], "author": "Yezemin"}
{"word": ["Shiver"], "author": "Zoltan999"}
{"word": ["Goosebumps."], "author": "Hickory"}
{"word": ["Gooseberries."], "author": "gixgox"}
{"word": ["Pie"], "author": "TARFU"}
{"word": [". [Ninja'd] ", " ", " Crust."], "author": "Hickory"}
{"word": ["Crumbling."], "author": "GhostwriterDoF"}
{"word": ["Ancient."], "author": "Hickory"}
{"word": ["relic"], "author": "GabesterOne"}
{"word": ["Antique"], "author": "TARFU"}
{"word": ["Auction."], "author": "Hickory"}
{"word": ["bid ", " ", " Edit: ninja'd!"], "author": "Dzsono"}
{"word": ["Offer"], "author": "TARFU"}
{"word": ["officer"], "author": "apehater"}
{"word": ["Captain"], "author": "TARFU"}
{"word": ["Ship"], "author": "Hardrada"}
{"word": ["Vessel"], "author": "TARFU"}
{"word": ["Bowl"], "author": "GabesterOne"}
{"word": ["Fruit."], "author": "Hickory"}
{"word": ["Meat."], "author": "Kleetus"}
{"word": [" Pulp."], "author": "gixgox"}
{"word": ["Fiction"], "author": "VampiroAlhazred"}
{"word": ["Fabrication."], "author": "Hickory"}
{"word": ["production"], "author": "Dzsono"}
{"word": ["Company."], "author": "Hickory"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": [" Company."], "author": "Hickory"}
{"word": ["corporation"], "author": "GabesterOne"}
{"word": ["Business"], "author": "TARFU"}
{"word": ["Tax."], "author": "Hickory"}
{"word": ["levy"], "author": "le_chevalier"}
{"word": ["Tariff"], "author": "TARFU"}
{"word": [], "author": "park_84"}
{"word": ["Spain"], "author": "TARFU"}
{"word": ["Europe"], "author": "PaterAlf"}
{"word": ["Zeus"], "author": "Yezemin"}
{"word": ["Hera."], "author": "gixgox"}
{"word": ["Gods."], "author": "Narcia_"}
{"word": ["Figments."], "author": "Hickory"}
{"word": ["Imagination"], "author": "Yezemin"}
{"word": ["creativity"], "author": "GabesterOne"}
{"word": ["Artistic"], "author": "TARFU"}
{"word": ["drawing"], "author": "park_84"}
{"word": ["Sketch."], "author": "Hickory"}
{"word": ["carbon"], "author": "park_84"}
{"word": ["Dioxide."], "author": "gixgox"}
{"word": ["Chemistry"], "author": "TARFU"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": ["Science"], "author": "GabesterOne"}
{"word": ["methodology"], "author": "Dzsono"}
{"word": ["scientology"], "author": "apehater"}
{"word": ["Hickorology."], "author": "Kleetus"}
{"word": [" Cult."], "author": "gixgox"}
{"word": [" Pack."], "author": "Kleetus"}
{"word": [" Brainless."], "author": "Hickory"}
{"word": [" Hairless."], "author": "Kleetus"}
{"word": [" Brainless."], "author": "Hickory"}
{"word": ["Hairless."], "author": "Kleetus"}
{"word": ["toothless"], "author": "JDelekto"}
{"word": ["Senseless"], "author": "Maxvorstadt"}
{"word": ["careless"], "author": "JDelekto"}
{"word": ["whisper"], "author": "Maxvorstadt"}
{"word": ["Quiet"], "author": "TARFU"}
{"word": ["Dead"], "author": "Maxvorstadt"}
{"word": ["expired"], "author": "le_chevalier"}
{"word": ["used"], "author": "TARFU"}
{"word": ["Petted."], "author": "Kleetus"}
{"word": [" utilised"], "author": "Dzsono"}
{"word": ["item"], "author": "Ardal"}
{"word": ["Inventory"], "author": "PaterAlf"}
{"word": ["Count"], "author": "Yezemin"}
{"word": [" -"], "author": "gixgox"}
{"word": ["Feathers"], "author": "Zoltan999"}
{"word": ["Wings."], "author": "Narcia_"}
{"word": ["bird"], "author": "Smogg"}
{"word": ["Parakeet"], "author": "TARFU"}
{"word": ["parrot"], "author": "GabesterOne"}
{"word": ["Pirate"], "author": "TARFU"}
{"word": ["Ship"], "author": "TDP"}
{"word": ["Sailing"], "author": "TARFU"}
{"word": ["cruising"], "author": "le_chevalier"}
{"word": ["altitude"], "author": "Dzsono"}
{"word": ["Height"], "author": "TARFU"}
{"word": ["volume"], "author": "GabesterOne"}
{"word": ["Tone"], "author": "TARFU"}
{"word": ["Bark."], "author": "Kleetus"}
{"word": [" bone"], "author": "apehater"}
{"word": [" Jaw"], "author": "TARFU"}
{"word": [" Dog."], "author": "Kleetus"}
{"word": ["uppercut"], "author": "GabesterOne"}
{"word": ["Boxing"], "author": "TARFU"}
{"word": ["box"], "author": "kmonster"}
{"word": ["Pugilist."], "author": "REDVWIN"}
{"word": [" Pug."], "author": "Kleetus"}
{"word": ["professional"], "author": "GabesterOne"}
{"word": ["Businessman"], "author": "TARFU"}
{"word": ["entrepreneur"], "author": "Dzsono"}
{"word": ["stocks"], "author": "GabesterOne"}
{"word": ["Pillory"], "author": "TARFU"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": ["Dickory"], "author": "Allinstein"}
{"word": ["Ivory."], "author": "Ikarugamesh"}
{"word": ["tower"], "author": "park_84"}
{"word": ["Defense."], "author": "gixgox"}
{"word": ["Shield."], "author": "Narcia_"}
{"word": ["Protect"], "author": "Yezemin"}
{"word": ["Barrier."], "author": "Hickory"}
{"word": ["Barricade"], "author": "PaterAlf"}
{"word": ["blocking"], "author": "GabesterOne"}
{"word": ["Impeding"], "author": "TARFU"}
{"word": ["Hindering."], "author": "Hickory"}
{"word": ["delays"], "author": "GabesterOne"}
{"word": ["Airport"], "author": "TARFU"}
{"word": ["searches"], "author": "GabesterOne"}
{"word": [" Hickoring."], "author": "Kleetus"}
{"word": [" intrusions"], "author": "Dzsono"}
{"word": ["force"], "author": "GabesterOne"}
{"word": [" Looks."], "author": "Kleetus"}
{"word": [" Power"], "author": "TARFU"}
{"word": ["Strength"], "author": "GabesterOne"}
{"word": ["durability"], "author": "le_chevalier"}
{"word": ["deterioration"], "author": "Dzsono"}
{"word": ["Looks."], "author": "Kleetus"}
{"word": [" degradation"], "author": "TARFU"}
{"word": ["weathering"], "author": "GabesterOne"}
{"word": ["weather-beaten"], "author": "TARFU"}
{"word": [" Hickoring."], "author": "Kleetus"}
{"word": [" Threadbare."], "author": "Hickory"}
{"word": ["rags"], "author": "park_84"}
{"word": ["Fur."], "author": "Kleetus"}
{"word": [" lint"], "author": "Dzsono"}
{"word": [" Fur."], "author": "Kleetus"}
{"word": [" Dryer"], "author": "Zoltan999"}
{"word": [" Airflow."], "author": "Hickory"}
{"word": ["Fan."], "author": "Narcia_"}
{"word": ["Enthusiast"], "author": "Lifthrasil"}
{"word": ["hobby"], "author": "GabesterOne"}
{"word": ["Leisure"], "author": "Yezemin"}
{"word": ["Recreation"], "author": "TARFU"}
{"word": ["Party."], "author": "gixgox"}
{"word": ["hard"], "author": "park_84"}
{"word": ["Multifarious... :P"], "author": "GhostwriterDoF"}
{"word": ["Various"], "author": "TARFU"}
{"word": ["Breeds."], "author": "Kleetus"}
{"word": [" Eclectic."], "author": "Hickory"}
{"word": [" Terrier."], "author": "Kleetus"}
{"word": [" Eclectic."], "author": "Hickory"}
{"word": ["Oddity"], "author": "TARFU"}
{"word": ["Bizarre"], "author": "Allinstein"}
{"word": ["Extreme"], "author": "Zoltan999"}
{"word": ["Outrageous"], "author": "TARFU"}
{"word": ["infuriating"], "author": "GabesterOne"}
{"word": ["scary"], "author": "kmonster"}
{"word": ["wolf"], "author": "Dzsono"}
{"word": [" Terrier."], "author": "Kleetus"}
{"word": [" Pack."], "author": "Hickory"}
{"word": [" Dog."], "author": "Kleetus"}
{"word": [" Pack."], "author": "Hickory"}
{"word": ["Dog."], "author": "Kleetus"}
{"word": [" Pack."], "author": "Hickory"}
{"word": ["Dog."], "author": "Kleetus"}
{"word": ["back"], "author": "GabesterOne"}
{"word": ["Tail."], "author": "Kleetus"}
{"word": [" Backpacker."], "author": "gixgox"}
{"word": [" Ridgeback."], "author": "Kleetus"}
{"word": [" Hiking"], "author": "TARFU"}
{"word": ["mountain"], "author": "Ardal"}
{"word": ["Husky."], "author": "Kleetus"}
{"word": [" ", "."], "author": "gixgox"}
{"word": ["Casserole."], "author": "Hickory"}
{"word": ["Tuna"], "author": "TARFU"}
{"word": [" Dew."], "author": "Kleetus"}
{"word": [" Salad."], "author": "Hickory"}
{"word": ["Nicoise."], "author": "gixgox"}
{"word": ["Starter."], "author": "Hickory"}
{"word": ["sports"], "author": "GabesterOne"}
{"word": ["Hound."], "author": "Kleetus"}
{"word": ["Games"], "author": "TARFU"}
{"word": ["Olympics"], "author": "GabesterOne"}
{"word": ["Doping"], "author": "TARFU"}
{"word": ["Cheaters."], "author": "Narcia_"}
{"word": ["Adultery"], "author": "Yezemin"}
{"word": ["sin"], "author": "GabesterOne"}
{"word": ["Se7en"], "author": "park_84"}
{"word": ["Movie"], "author": "TARFU"}
{"word": [" Hello there, I've never met a Saint Pierre and Miquelonian before. ", " ", " Parlez vous Fran\u00e7ais?"], "author": "Kleetus"}
{"word": [" Cinema."], "author": "Hickory"}
{"word": ["Film."], "author": "gixgox"}
{"word": ["celluloid"], "author": "park_84"}
{"word": ["Synthetic"], "author": "Zoltan999"}
{"word": ["Organic."], "author": "Hickory"}
{"word": ["carbon"], "author": "Dzsono"}
{"word": ["graphite"], "author": "Ardal"}
{"word": ["crystalline"], "author": "le_chevalier"}
{"word": ["Amorphous."], "author": "Hickory"}
{"word": ["Blob"], "author": "Yezemin"}
{"word": ["horror"], "author": "XYCat"}
{"word": ["story"], "author": "AnnaBrown"}
{"word": ["imagination"], "author": "Densetsu"}
{"word": ["Creativity"], "author": "TARFU"}
{"word": ["originality"], "author": "GabesterOne"}
{"word": ["novelty"], "author": "TARFU"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": ["Dock"], "author": "motorkar"}
{"word": ["port"], "author": "GabesterOne"}
{"word": ["Hub."], "author": "REDVWIN"}
{"word": [], "author": "almabrds"}
{"word": ["mud"], "author": "GabesterOne"}
{"word": ["Crab."], "author": "Kleetus"}
{"word": [" Squish..."], "author": "GhostwriterDoF"}
{"word": [" Crab."], "author": "Kleetus"}
{"word": ["squelching"], "author": "GabesterOne"}
{"word": [" Crushing"], "author": "TARFU"}
{"word": ["dead"], "author": "kmonster"}
{"word": ["Deceased"], "author": "TARFU"}
{"word": [" Departed."], "author": "Kleetus"}
{"word": [" Expired."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Expired."], "author": "Hickory"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": [" Expired."], "author": "Hickory"}
{"word": ["Dickory."], "author": "Kleetus"}
{"word": ["old"], "author": "GabesterOne"}
{"word": ["Ancient"], "author": "Zoltan999"}
{"word": ["Texts."], "author": "Narcia_"}
{"word": ["messages"], "author": "Ardal"}
{"word": ["Communications"], "author": "TARFU"}
{"word": ["Chat."], "author": "gixgox"}
{"word": ["Talk"], "author": "TARFU"}
{"word": ["Converse."], "author": "Hickory"}
{"word": ["Speak"], "author": "TARFU"}
{"word": ["Sermon."], "author": "gixgox"}
{"word": ["Homily."], "author": "Hickory"}
{"word": ["Lecture"], "author": "TARFU"}
{"word": ["Lesson"], "author": "PaterAlf"}
{"word": ["School"], "author": "TARFU"}
{"word": ["students"], "author": "ashwald"}
{"word": ["Scholars"], "author": "TARFU"}
{"word": ["Academics."], "author": "Hickory"}
{"word": ["Studies"], "author": "TARFU"}
{"word": ["exciting"], "author": "doctorsinister"}
{"word": ["Exhilaration."], "author": "Kleetus"}
{"word": [" Interesting"], "author": "TARFU"}
{"word": [" Fascinating."], "author": "Hickory"}
{"word": [" Exhilaration."], "author": "Kleetus"}
{"word": [" Radiating"], "author": "tort1234"}
{"word": [" Uranium"], "author": "TARFU"}
{"word": ["Exhilaration."], "author": "Kleetus"}
{"word": [" Isotope."], "author": "Hickory"}
{"word": ["Exhilaration."], "author": "Kleetus"}
{"word": [" Isotope."], "author": "Hickory"}
{"word": ["Exhilaration."], "author": "Kleetus"}
{"word": [" Element"], "author": "TARFU"}
{"word": ["Exhilaration."], "author": "Kleetus"}
{"word": [" Ingredient."], "author": "Hickory"}
{"word": [" Recipe"], "author": "TARFU"}
{"word": [" Formula."], "author": "Hickory"}
{"word": ["Exhilaration."], "author": "Kleetus"}
{"word": [" Mathematics"], "author": "TARFU"}
{"word": [" Geometry."], "author": "Hickory"}
{"word": ["Exhilaration."], "author": "Kleetus"}
{"word": [" Geometry."], "author": "Hickory"}
{"word": [" Exhilaration."], "author": "Kleetus"}
{"word": [" Pythagoras"], "author": "TARFU"}
{"word": [" Theory."], "author": "Hickory"}
{"word": ["Exhilaration."], "author": "Kleetus"}
{"word": ["evolution (Creationism is fact folks :P)"], "author": "GabesterOne"}
{"word": [" Theory."], "author": "Hickory"}
{"word": [" Development."], "author": "Kleetus"}
{"word": [" Theory."], "author": "Hickory"}
{"word": [" Idea"], "author": "TARFU"}
{"word": [" Concept."], "author": "Hickory"}
{"word": [" Abstraction"], "author": "TARFU"}
{"word": [" Conjecture."], "author": "Hickory"}
{"word": [" Speculation"], "author": "TARFU"}
{"word": ["assumption"], "author": "GabesterOne"}
{"word": [" Exhilaration."], "author": "Kleetus"}
{"word": [" Supposition."], "author": "Hickory"}
{"word": ["hunch"], "author": "GabesterOne"}
{"word": ["Presumptive..."], "author": "GhostwriterDoF"}
{"word": ["Hypothetical."], "author": "Hickory"}
{"word": ["hypothesis"], "author": "GabesterOne"}
{"word": ["Question"], "author": "TARFU"}
{"word": [" Theory."], "author": "Kleetus"}
{"word": [" enquiry"], "author": "Dzsono"}
{"word": [" Investigation"], "author": "TARFU"}
{"word": ["Theory."], "author": "Kleetus"}
{"word": [" Survey."], "author": "gixgox"}
{"word": ["enquiry"], "author": "Densetsu"}
{"word": [" Study."], "author": "Hickory"}
{"word": ["research"], "author": "ashwald"}
{"word": ["experiment"], "author": "le_chevalier"}
{"word": ["Trial."], "author": "Hickory"}
{"word": [" venture"], "author": "Densetsu"}
{"word": ["Capital"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": ["Sprawling."], "author": "Narcia_"}
{"word": ["Rambling."], "author": "Hickory"}
{"word": ["Gobbledegook"], "author": "Yezemin"}
{"word": ["mumble"], "author": "Madshaker"}
{"word": ["Incoherent."], "author": "Hickory"}
{"word": ["disjointed"], "author": "GabesterOne"}
{"word": ["Dismantled."], "author": "gixgox"}
{"word": ["Disassembled"], "author": "TARFU"}
{"word": ["Piecemeal."], "author": "Hickory"}
{"word": ["Microcosm..."], "author": "GhostwriterDoF"}
{"word": ["Microscopic"], "author": "TARFU"}
{"word": [" Example."], "author": "Kleetus"}
{"word": [" Miniscule."], "author": "Hickory"}
{"word": [" Confused."], "author": "Kleetus"}
{"word": [" Small"], "author": "TARFU"}
{"word": ["size"], "author": "SamMagel"}
{"word": ["Dimentions."], "author": "Hickory"}
{"word": ["mental"], "author": "kmonster"}
{"word": ["Psychic"], "author": "TARFU"}
{"word": ["Powers"], "author": "doctorsinister"}
{"word": ["Austin."], "author": "Kleetus"}
{"word": ["Martin"], "author": "mm324"}
{"word": [" Mariner ", " ", " "], "author": "TARFU"}
{"word": ["seaman"], "author": "le_chevalier"}
{"word": ["Sailor"], "author": "TARFU"}
{"word": [" Spermatozoa."], "author": "Kleetus"}
{"word": [" soldier"], "author": "Dzsono"}
{"word": ["Spermatozoa."], "author": "Kleetus"}
{"word": ["Ovulum"], "author": "JDelekto"}
{"word": ["Snail."], "author": "Kleetus"}
{"word": ["shell"], "author": "GabesterOne"}
{"word": ["oyster"], "author": "park_84"}
{"word": [" Military."], "author": "Hickory"}
{"word": ["Peacekeeper."], "author": "gixgox"}
{"word": ["Guardian."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["Green."], "author": "xieliming"}
{"word": ["Thumb."], "author": "Narcia_"}
{"word": ["nail"], "author": "le_chevalier"}
{"word": ["hammer"], "author": "doctorsinister"}
{"word": ["Anvil"], "author": "GabesterOne"}
{"word": ["Blacksmith"], "author": "TARFU"}
{"word": ["dawn"], "author": "doronnorod"}
{"word": ["scumbag"], "author": "apehater"}
{"word": ["miscreant"], "author": "Dzsono"}
{"word": ["apostate"], "author": "Ardal"}
{"word": ["apostle"], "author": "doronnorod"}
{"word": ["supper"], "author": "park_84"}
{"word": ["dinner"], "author": "doctorsinister"}
{"word": ["lunch"], "author": "Ardal"}
{"word": ["snack"], "author": "JDelekto"}
{"word": ["nibble"], "author": "Dzsono"}
{"word": ["Kibble."], "author": "Kleetus"}
{"word": ["bite"], "author": "le_chevalier"}
{"word": ["Dog."], "author": "Kleetus"}
{"word": [" Sandwich"], "author": "TARFU"}
{"word": [" Dog."], "author": "Kleetus"}
{"word": [" Crudit\u00e9s."], "author": "gixgox"}
{"word": ["Dog."], "author": "Kleetus"}
{"word": [" Appetizer"], "author": "TARFU"}
{"word": [" Bone."], "author": "Kleetus"}
{"word": [" Starter."], "author": "gixgox"}
{"word": [" Engine"], "author": "TARFU"}
{"word": [" Dog."], "author": "Kleetus"}
{"word": [" Oil"], "author": "doronnorod"}
{"word": ["Fur."], "author": "Kleetus"}
{"word": [" Slick."], "author": "Hickory"}
{"word": ["hair"], "author": "BlackDawn"}
{"word": ["musical"], "author": "Ardal"}
{"word": ["Songs"], "author": "TARFU"}
{"word": ["Score."], "author": "Narcia_"}
{"word": ["core"], "author": "apehater"}
{"word": ["clock"], "author": "le_chevalier"}
{"word": ["Atomic."], "author": "Hickory"}
{"word": ["Nuclear"], "author": "TARFU"}
{"word": ["Nukem."], "author": "gixgox"}
{"word": [" Duke"], "author": "mm324"}
{"word": ["Grandiose..."], "author": "GhostwriterDoF"}
{"word": ["Ostentatious."], "author": "Hickory"}
{"word": [" Hickorlicious."], "author": "Kleetus"}
{"word": [" Pretentious"], "author": "TARFU"}
{"word": [" Pompous."], "author": "Hickory"}
{"word": [" Regal"], "author": "TARFU"}
{"word": ["William"], "author": "Emob78"}
{"word": ["Billy"], "author": "TARFU"}
{"word": ["Goat."], "author": "Hickory"}
{"word": ["Ram"], "author": "TARFU"}
{"word": ["mar"], "author": "Accatone"}
{"word": ["disfigure"], "author": "Dzsono"}
{"word": [" Spoil."], "author": "Kleetus"}
{"word": [" Maim"], "author": "TARFU"}
{"word": [" Ruin."], "author": "Kleetus"}
{"word": ["deform"], "author": "GabesterOne"}
{"word": [" Twist"], "author": "TARFU"}
{"word": ["Contort"], "author": "Dzsono"}
{"word": [" Alter."], "author": "Kleetus"}
{"word": [" Mod"], "author": "ronigog"}
{"word": [" Mutilate."], "author": "Hickory"}
{"word": [" Change."], "author": "Kleetus"}
{"word": [" Mutilate."], "author": "Hickory"}
{"word": ["limb"], "author": "park_84"}
{"word": ["Appendage."], "author": "Hickory"}
{"word": [" Tail."], "author": "Kleetus"}
{"word": [" Appendage."], "author": "Hickory"}
{"word": ["Supplement"], "author": "Zoltan999"}
{"word": ["extra"], "author": "le_chevalier"}
{"word": ["surplus"], "author": "mm324"}
{"word": ["Upgrade."], "author": "gixgox"}
{"word": ["Improvement"], "author": "TARFU"}
{"word": ["Progress."], "author": "Hickory"}
{"word": ["Construction"], "author": "TARFU"}
{"word": ["growth"], "author": "Densetsu"}
{"word": [" ", " ", " ninja'd ", " ", " hormone"], "author": "le_chevalier"}
{"word": [" Gland"], "author": "TARFU"}
{"word": ["Organ."], "author": "Hickory"}
{"word": ["transplant"], "author": "Smogg"}
{"word": ["surgery"], "author": "le_chevalier"}
{"word": ["Surgeon"], "author": "TARFU"}
{"word": ["orthopedic"], "author": "mm324"}
{"word": ["Bones"], "author": "TARFU"}
{"word": ["marrow"], "author": "Dzsono"}
{"word": ["Broth"], "author": "TARFU"}
{"word": ["soup"], "author": "mm324"}
{"word": ["Stew."], "author": "gixgox"}
{"word": ["Beef"], "author": "TARFU"}
{"word": ["steak"], "author": "mm324"}
{"word": ["Sauce"], "author": "TARFU"}
{"word": [" Meat."], "author": "Kleetus"}
{"word": ["Chicken"], "author": "tort1234"}
{"word": ["fearful"], "author": "Dzsono"}
{"word": [" Garnish."], "author": "Hickory"}
{"word": [" Bird."], "author": "Kleetus"}
{"word": [" Garnish."], "author": "Hickory"}
{"word": ["Bird."], "author": "Kleetus"}
{"word": [" Garnish."], "author": "Hickory"}
{"word": ["Bird."], "author": "Kleetus"}
{"word": [" Garnish."], "author": "Hickory"}
{"word": ["_____________ ", " ", " ", " ", " ", " reset"], "author": "Densetsu"}
{"word": ["Reboot."], "author": "gixgox"}
{"word": ["Quickstart."], "author": "Hickory"}
{"word": ["Boot."], "author": "Narcia_"}
{"word": ["camp"], "author": "le_chevalier"}
{"word": [], "author": "gixgox"}
{"word": [" Bruce"], "author": "TARFU"}
{"word": ["Spruce."], "author": "Hickory"}
{"word": ["Cedar"], "author": "TARFU"}
{"word": ["Wood."], "author": "Hickory"}
{"word": ["Lumber"], "author": "TARFU"}
{"word": [" ...", " ", " ", " "], "author": "gixgox"}
{"word": ["cheese"], "author": "TARFU"}
{"word": ["Toastie."], "author": "Hickory"}
{"word": ["bread"], "author": "TARFU"}
{"word": ["dough"], "author": "mm324"}
{"word": ["flour"], "author": "TARFU"}
{"word": ["cake"], "author": "mm324"}
{"word": ["Lie"], "author": "Azrael360"}
{"word": ["Falsehood"], "author": "TARFU"}
{"word": ["Fib..."], "author": "GhostwriterDoF"}
{"word": ["Truth"], "author": "tort1234"}
{"word": ["fact"], "author": "TARFU"}
{"word": ["Empirical."], "author": "Hickory"}
{"word": [" Verity."], "author": "Kleetus"}
{"word": ["Veritas"], "author": "SamMagel"}
{"word": ["justice"], "author": "mm324"}
{"word": ["blindness"], "author": "Dzsono"}
{"word": ["Sight."], "author": "xieliming"}
{"word": ["I."], "author": "Kleetus"}
{"word": ["Robot"], "author": "mm324"}
{"word": ["Android"], "author": "TARFU"}
{"word": ["Data"], "author": "mm324"}
{"word": ["base"], "author": "le_chevalier"}
{"word": ["Platform"], "author": "TARFU"}
{"word": ["Mario!"], "author": "park_84"}
{"word": ["Milano."], "author": "Kleetus"}
{"word": ["mafia"], "author": "Densetsu"}
{"word": ["Criminal"], "author": "Zoltan999"}
{"word": ["Element."], "author": "Narcia_"}
{"word": ["essence"], "author": "Densetsu"}
{"word": ["Perfume"], "author": "TARFU"}
{"word": ["Fragrance"], "author": "Yezemin"}
{"word": ["Scent"], "author": "TARFU"}
{"word": ["Malodorousness."], "author": "gixgox"}
{"word": ["repulse"], "author": "Densetsu"}
{"word": ["Disgusted"], "author": "almabrds"}
{"word": ["Disguised"], "author": "PaterAlf"}
{"word": ["Camouflaged"], "author": "TARFU"}
{"word": ["colourblind"], "author": "Dzsono"}
{"word": ["disability"], "author": "TARFU"}
{"word": ["handicap"], "author": "le_chevalier"}
{"word": ["golf"], "author": "TARFU"}
{"word": ["club"], "author": "mm324"}
{"word": ["sandwich"], "author": "TARFU"}
{"word": ["lunch"], "author": "mm324"}
{"word": ["Break"], "author": "TARFU"}
{"word": ["dance"], "author": "mm324"}
{"word": ["Death"], "author": "le_chevalier"}
{"word": ["Reaper"], "author": "Yezemin"}
{"word": ["Harvest."], "author": "xieliming"}
{"word": ["Moon."], "author": "gixgox"}
{"word": ["calmness"], "author": "Densetsu"}
{"word": ["serenity"], "author": "Dzsono"}
{"word": [], "author": "gixgox"}
{"word": [], "author": "Zoltan999"}
{"word": ["Pirates."], "author": "Narcia_"}
{"word": ["Treasure"], "author": "TARFU"}
{"word": ["map"], "author": "mm324"}
{"word": ["Geography"], "author": "TARFU"}
{"word": ["school"], "author": "mm324"}
{"word": ["University"], "author": "TARFU"}
{"word": ["diploma"], "author": "mm324"}
{"word": ["Degree"], "author": "TARFU"}
{"word": ["fahrenheit"], "author": "mm324"}
{"word": ["Celsius"], "author": "TARFU"}
{"word": ["metric"], "author": "mm324"}
{"word": ["System"], "author": "TARFU"}
{"word": ["solar"], "author": "mm324"}
{"word": ["Lunar."], "author": "gixgox"}
{"word": ["warewolf"], "author": "mm324"}
{"word": ["Vampire"], "author": "TARFU"}
{"word": ["garlic"], "author": "mm324"}
{"word": ["Superstition"], "author": "Dzsono"}
{"word": ["thirteen"], "author": "Accatone"}
{"word": [], "author": "Zoltan999"}
{"word": ["Apparition"], "author": "TARFU"}
{"word": ["specter"], "author": "mm324"}
{"word": ["spirit"], "author": "TARFU"}
{"word": ["alcohol"], "author": "mm324"}
{"word": ["Bourbon"], "author": "TARFU"}
{"word": ["headache"], "author": "mm324"}
{"word": ["aspirin"], "author": "TARFU"}
{"word": ["drugs"], "author": "mm324"}
{"word": ["addiction"], "author": "TARFU"}
{"word": ["recovery"], "author": "mm324"}
{"word": ["rehabilitation"], "author": "TARFU"}
{"word": ["renewal"], "author": "mm324"}
{"word": ["revival"], "author": "Accatone"}
{"word": ["growth"], "author": "mm324"}
{"word": ["youth"], "author": "Accatone"}
{"word": ["youngster"], "author": "TARFU"}
{"word": [" Pup."], "author": "Kleetus"}
{"word": ["dog"], "author": "mm324"}
{"word": ["cat"], "author": "TARFU"}
{"word": ["buddy."], "author": "Tauto"}
{"word": ["pal"], "author": "mm324"}
{"word": ["buddy"], "author": "TARFU"}
{"word": ["friend"], "author": "mm324"}
{"word": ["Dog."], "author": "Kleetus"}
{"word": [" Companion"], "author": "TARFU"}
{"word": [" Dog."], "author": "Kleetus"}
{"word": [" Team."], "author": "Casval_Deikun"}
{"word": [" Sports"], "author": "TARFU"}
{"word": ["Dog."], "author": "Kleetus"}
{"word": ["warmth"], "author": "Densetsu"}
{"word": ["Fur."], "author": "Kleetus"}
{"word": [" embrace"], "author": "Dzsono"}
{"word": [" Competition."], "author": "Hickory"}
{"word": ["race"], "author": "Ardal"}
{"word": ["Winner"], "author": "flubbucket"}
{"word": ["Best"], "author": "Zoltan999"}
{"word": ["Doping."], "author": "gixgox"}
{"word": ["steroid"], "author": "le_chevalier"}
{"word": ["bodybuilding"], "author": "park_84"}
{"word": ["Weights"], "author": "TARFU"}
{"word": ["Lift."], "author": "Narcia_"}
{"word": ["elevator"], "author": "ashwald"}
{"word": ["Freight"], "author": "TARFU"}
{"word": [" Escalator."], "author": "Kleetus"}
{"word": [" train"], "author": "mm324"}
{"word": ["Escalator."], "author": "Kleetus"}
{"word": [" Locomotive"], "author": "TARFU"}
{"word": ["steam"], "author": "mm324"}
{"word": ["Escalator."], "author": "Kleetus"}
{"word": [" Store"], "author": "almabrds"}
{"word": ["Market"], "author": "TARFU"}
{"word": [" Keep."], "author": "Kleetus"}
{"word": [" Value."], "author": "Hickory"}
{"word": ["worth"], "author": "mm324"}
{"word": [" Shop."], "author": "Kleetus"}
{"word": [" Price"], "author": "TARFU"}
{"word": ["Shop."], "author": "Kleetus"}
{"word": [" Cut."], "author": "Hickory"}
{"word": ["Pat."], "author": "Kleetus"}
{"word": [" Cutlery."], "author": "gixgox"}
{"word": ["silverware"], "author": "Dzsono"}
{"word": ["fork"], "author": "mm324"}
{"word": ["spoon"], "author": "TARFU"}
{"word": ["knife"], "author": "mm324"}
{"word": ["cleaver"], "author": "TARFU"}
{"word": [" Fur."], "author": "Kleetus"}
{"word": [" butcher"], "author": "mm324"}
{"word": [" meat"], "author": "TARFU"}
{"word": ["grinder"], "author": "le_chevalier"}
{"word": ["pork ", " ninja'd"], "author": "mm324"}
{"word": ["chops"], "author": "TARFU"}
{"word": ["karate"], "author": "mm324"}
{"word": [" Grindr."], "author": "Kleetus"}
{"word": [" Kung Fu"], "author": "TARFU"}
{"word": ["Tae Kwon Do"], "author": "mm324"}
{"word": ["Korea"], "author": "TARFU"}
{"word": ["kimchi"], "author": "mm324"}
{"word": ["Grindr."], "author": "Kleetus"}
{"word": [" Cabbage"], "author": "TARFU"}
{"word": ["garbage"], "author": "park_84"}
{"word": ["Forage."], "author": "gixgox"}
{"word": ["Footage."], "author": "Casval_Deikun"}
{"word": ["Foliage."], "author": "Hickory"}
{"word": ["forest"], "author": "Smogg"}
{"word": ["Rain"], "author": "Zoltan999"}
{"word": ["Storm"], "author": "TARFU"}
{"word": ["Thunder."], "author": "gixgox"}
{"word": ["Cloud."], "author": "Narcia_"}
{"word": ["data"], "author": "le_chevalier"}
{"word": ["Information"], "author": "TARFU"}
{"word": ["storage"], "author": "Smogg"}
{"word": ["Warehouse"], "author": "TARFU"}
{"word": ["operation"], "author": "JDelekto"}
{"word": ["Surgery."], "author": "Hickory"}
{"word": ["Surgeon"], "author": "TARFU"}
{"word": ["stoic"], "author": "JDelekto"}
{"word": ["Steadfast"], "author": "TARFU"}
{"word": ["Unyielding"], "author": "Madshaker"}
{"word": ["Unbending"], "author": "TARFU"}
{"word": ["Rigid."], "author": "Hickory"}
{"word": ["Firm"], "author": "TARFU"}
{"word": ["tight"], "author": "GabesterOne"}
{"word": ["stern"], "author": "mm324"}
{"word": ["rearward"], "author": "TARFU"}
{"word": ["forward"], "author": "mm324"}
{"word": ["Ahead"], "author": "TARFU"}
{"word": ["lead"], "author": "mm324"}
{"word": ["frontier"], "author": "JDelekto"}
{"word": ["pioneer"], "author": "TARFU"}
{"word": ["explore"], "author": "mm324"}
{"word": ["visionary"], "author": "JDelekto"}
{"word": [" Hickornary."], "author": "Kleetus"}
{"word": [" revolutionary"], "author": "TARFU"}
{"word": ["change"], "author": "mm324"}
{"word": ["coins"], "author": "TARFU"}
{"word": [" Alter."], "author": "Kleetus"}
{"word": [" gold"], "author": "mm324"}
{"word": ["Alter."], "author": "Kleetus"}
{"word": [" Nugget."], "author": "Hickory"}
{"word": ["value"], "author": "JDelekto"}
{"word": [" Fur."], "author": "Kleetus"}
{"word": [" bargain"], "author": "TARFU"}
{"word": ["sale"], "author": "JDelekto"}
{"word": ["Insomnia"], "author": "enurbenur"}
{"word": ["Restless."], "author": "Hickory"}
{"word": ["Nervous"], "author": "enurbenur"}
{"word": ["RESTful"], "author": "JDelekto"}
{"word": ["Services"], "author": "enurbenur"}
{"word": ["Goods"], "author": "TARFU"}
{"word": ["service"], "author": "JDelekto"}
{"word": ["Kiosk."], "author": "Hickory"}
{"word": ["france"], "author": "JDelekto"}
{"word": ["Europe"], "author": "TARFU"}
{"word": ["Obscure."], "author": "Hickory"}
{"word": ["reference"], "author": "JDelekto"}
{"word": ["quote"], "author": "Accatone"}
{"word": ["anecdote"], "author": "JDelekto"}
{"word": ["Narrative."], "author": "Hickory"}
{"word": ["epilogue"], "author": "JDelekto"}
{"word": ["Story"], "author": "TARFU"}
{"word": [" Story."], "author": "Kleetus"}
{"word": ["novel"], "author": "JDelekto"}
{"word": ["New."], "author": "Kleetus"}
{"word": [" Paperback"], "author": "TARFU"}
{"word": ["writer"], "author": "JDelekto"}
{"word": [" New."], "author": "Kleetus"}
{"word": ["experience"], "author": "JDelekto"}
{"word": ["wisdom"], "author": "mm324"}
{"word": ["points"], "author": "XYCat"}
{"word": [" Tale."], "author": "Hickory"}
{"word": [" Elements."], "author": "Kleetus"}
{"word": ["Words."], "author": "REDVWIN"}
{"word": ["Grammar"], "author": "TARFU"}
{"word": ["punctuation"], "author": "mm324"}
{"word": ["apitalisation."], "author": "Hickory"}
{"word": ["liquidation"], "author": "Dzsono"}
{"word": ["Extermination."], "author": "Casval_Deikun"}
{"word": ["removal"], "author": "TARFU"}
{"word": ["deletion"], "author": "park_84"}
{"word": ["erasure"], "author": "TARFU"}
{"word": [" Removal."], "author": "Kleetus"}
{"word": [" Excision."], "author": "Hickory"}
{"word": ["Incision"], "author": "Zoltan999"}
{"word": ["Surgery."], "author": "Narcia_"}
{"word": ["Amputation."], "author": "gixgox"}
{"word": ["loss"], "author": "mm324"}
{"word": ["Gain"], "author": "TARFU"}
{"word": ["revenue"], "author": "park_84"}
{"word": ["Income"], "author": "TARFU"}
{"word": ["Negligible"], "author": "Moonbeam"}
{"word": ["Minor"], "author": "TARFU"}
{"word": ["insignificant"], "author": "le_chevalier"}
{"word": ["useless"], "author": "GabesterOne"}
{"word": ["nothing"], "author": "almabrds"}
{"word": ["Nowt."], "author": "Hickory"}
{"word": ["Zero"], "author": "TARFU"}
{"word": ["minus"], "author": "Accatone"}
{"word": ["plus"], "author": "mm324"}
{"word": ["addition"], "author": "Zordu"}
{"word": ["subtraction"], "author": "mm324"}
{"word": ["division"], "author": "TARFU"}
{"word": [" Plus."], "author": "Kleetus"}
{"word": [" Joy"], "author": "PaterAlf"}
{"word": [" Happiness"], "author": "TARFU"}
{"word": ["Felicity."], "author": "gixgox"}
{"word": [" Increase."], "author": "Kleetus"}
{"word": [" Euphoria."], "author": "Hickory"}
{"word": [" Hallucination"], "author": "TARFU"}
{"word": ["delusion"], "author": "mm324"}
{"word": [" Component."], "author": "Kleetus"}
{"word": ["Part."], "author": "Casval_Deikun"}
{"word": [" Fantasy."], "author": "Hickory"}
{"word": ["Imagination"], "author": "TARFU"}
{"word": ["creation"], "author": "le_chevalier"}
{"word": ["invention"], "author": "TARFU"}
{"word": ["Edison"], "author": "park_84"}
{"word": ["Ohio"], "author": "Licurg"}
{"word": ["Othello"], "author": "Dzsono"}
{"word": [], "author": "gixgox"}
{"word": ["Magnum."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["Prelude."], "author": "Hickory"}
{"word": ["Introduction"], "author": "Zoltan999"}
{"word": ["Opening."], "author": "REDVWIN"}
{"word": ["Closing"], "author": "Tocran"}
{"word": ["Time"], "author": "TARFU"}
{"word": ["Stamp."], "author": "Narcia_"}
{"word": ["Postage"], "author": "TARFU"}
{"word": ["Letter."], "author": "gixgox"}
{"word": ["Envelope"], "author": "TARFU"}
{"word": ["paper"], "author": "Smogg"}
{"word": ["Tiger."], "author": "Hickory"}
{"word": ["regift (sort of a palindrome for tiger)"], "author": "Accatone"}
{"word": ["christmas"], "author": "Ardal"}
{"word": ["snow"], "author": "mm324"}
{"word": ["Mobile."], "author": "Hickory"}
{"word": ["Home"], "author": "mm324"}
{"word": ["Sweet."], "author": "gixgox"}
{"word": ["Tooth."], "author": "Hickory"}
{"word": ["Fairy"], "author": "mm324"}
{"word": ["Elves"], "author": "Tocran"}
{"word": ["Woodlands"], "author": "mm324"}
{"word": ["forest"], "author": "TARFU"}
{"word": ["swamp"], "author": "mm324"}
{"word": [" Dwarves."], "author": "Kleetus"}
{"word": [" gator"], "author": "TARFU"}
{"word": ["Contraction."], "author": "Hickory"}
{"word": ["Dwarves."], "author": "Kleetus"}
{"word": [" Contraction."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" extension"], "author": "mm324"}
{"word": [" Tail."], "author": "Kleetus"}
{"word": ["follow"], "author": "mm324"}
{"word": ["Fellow"], "author": "PaterAlf"}
{"word": ["Mellow"], "author": "richlind33"}
{"word": ["Yellow"], "author": "mm324"}
{"word": ["Bellow"], "author": "richlind33"}
{"word": ["Blacksmith"], "author": "TARFU"}
{"word": ["hammer"], "author": "mm324"}
{"word": ["Time."], "author": "Kleetus"}
{"word": ["Temporality"], "author": "richlind33"}
{"word": ["unidirectional"], "author": "Dzsono"}
{"word": ["Lopsided."], "author": "Casval_Deikun"}
{"word": ["Asymmetrical"], "author": "TARFU"}
{"word": ["ADSL"], "author": "Tocran"}
{"word": ["ISP"], "author": "park_84"}
{"word": ["Leech"], "author": "richlind33"}
{"word": ["King"], "author": "Tocran"}
{"word": ["Kong."], "author": "gixgox"}
{"word": [], "author": "le_chevalier"}
{"word": ["down!"], "author": "Tocran"}
{"word": ["town"], "author": "flubbucket"}
{"word": ["simcity"], "author": "Tocran"}
{"word": ["Artificial"], "author": "Zoltan999"}
{"word": ["Intelligence."], "author": "Hickory"}
{"word": ["Study."], "author": "Narcia_"}
{"word": ["essay"], "author": "Ardal"}
{"word": ["Composition"], "author": "TARFU"}
{"word": ["composer"], "author": "Accatone"}
{"word": ["songwriter"], "author": "le_chevalier"}
{"word": ["mixer"], "author": "Accatone"}
{"word": ["Cement"], "author": "TARFU"}
{"word": ["Bond."], "author": "Hickory"}
{"word": ["friendship"], "author": "mm324"}
{"word": ["friendlist"], "author": "Tocran"}
{"word": ["Gifting... :D"], "author": "GhostwriterDoF"}
{"word": ["Benefactor"], "author": "Zoltan999"}
{"word": ["Patron"], "author": "TARFU"}
{"word": ["Customer."], "author": "Hickory"}
{"word": ["consumer"], "author": "TARFU"}
{"word": ["User."], "author": "gixgox"}
{"word": ["addict"], "author": "mm324"}
{"word": ["opium"], "author": "TARFU"}
{"word": ["hashish"], "author": "mm324"}
{"word": ["Rajneesh"], "author": "richlind33"}
{"word": ["India"], "author": "TARFU"}
{"word": ["Hinduism."], "author": "Casval_Deikun"}
{"word": ["caste"], "author": "le_chevalier"}
{"word": ["Fish."], "author": "Kleetus"}
{"word": [" Outcast"], "author": "TARFU"}
{"word": [" Fish."], "author": "Kleetus"}
{"word": [" Inbred"], "author": "richlind33"}
{"word": ["Fish."], "author": "Kleetus"}
{"word": [" Related."], "author": "Hickory"}
{"word": ["Family"], "author": "Azrael360"}
{"word": ["Unit"], "author": "Zoltan999"}
{"word": ["Element."], "author": "Hickory"}
{"word": ["quark"], "author": "Dzsono"}
{"word": ["Proton."], "author": "Narcia_"}
{"word": ["Atom"], "author": "TARFU"}
{"word": [], "author": "Zoltan999"}
{"word": [" Show"], "author": "Zjeraar"}
{"word": ["Stopper."], "author": "Hickory"}
{"word": ["sink"], "author": "mm324"}
{"word": ["Faucet."], "author": "GhostwriterDoF"}
{"word": ["water"], "author": "mm324"}
{"word": ["Hydration..."], "author": "GhostwriterDoF"}
{"word": ["thirst"], "author": "mm324"}
{"word": ["Desert"], "author": "TARFU"}
{"word": ["Sand."], "author": "Hickory"}
{"word": ["glass"], "author": "mm324"}
{"word": ["Crystal."], "author": "Hickory"}
{"word": ["goblet"], "author": "mm324"}
{"word": ["chalice"], "author": "Ardal"}
{"word": ["Beer"], "author": "TARFU"}
{"word": ["Ale"], "author": "mm324"}
{"word": ["Pale"], "author": "TARFU"}
{"word": ["faded"], "author": "mm324"}
{"word": ["transparent"], "author": "Tocran"}
{"word": ["glass"], "author": "mm324"}
{"word": ["stained"], "author": "TARFU"}
{"word": [" Cup."], "author": "Kleetus"}
{"word": [" Marked."], "author": "Hickory"}
{"word": [" Marker"], "author": "TARFU"}
{"word": ["Pen."], "author": "Hickory"}
{"word": ["Ink"], "author": "TARFU"}
{"word": ["Squid"], "author": "PaterAlf"}
{"word": ["Cuttlefish."], "author": "Hickory"}
{"word": ["Octopus"], "author": "TARFU"}
{"word": ["."], "author": "Hickory"}
{"word": ["crab"], "author": "Accatone"}
{"word": ["mud"], "author": "litildivil"}
{"word": ["Crabs"], "author": "richlind33"}
{"word": ["Lice."], "author": "Kleetus"}
{"word": [" Lobsters"], "author": "TARFU"}
{"word": ["shrimp"], "author": "mm324"}
{"word": ["seafood"], "author": "TARFU"}
{"word": [" Prawns."], "author": "Kleetus"}
{"word": [" Sushi"], "author": "richlind33"}
{"word": ["raw"], "author": "Dzsono"}
{"word": ["meat"], "author": "mm324"}
{"word": [" Prawn."], "author": "Kleetus"}
{"word": [" Puppet"], "author": "richlind33"}
{"word": ["doll"], "author": "mm324"}
{"word": ["[Ninja'd] ", " ", " Pram."], "author": "Hickory"}
{"word": [" Prawns."], "author": "Kleetus"}
{"word": [" Pram."], "author": "Hickory"}
{"word": [" Prawn."], "author": "Kleetus"}
{"word": [" Pram."], "author": "Hickory"}
{"word": ["Prawn."], "author": "Kleetus"}
{"word": [" Pram."], "author": "Hickory"}
{"word": ["buggy"], "author": "mm324"}
{"word": ["Beach."], "author": "Hickory"}
{"word": ["bum"], "author": "mm324"}
{"word": [" Prawn."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Prawn."], "author": "Kleetus"}
{"word": [" twerk"], "author": "mm324"}
{"word": ["Prawn."], "author": "Kleetus"}
{"word": [" Provocative."], "author": "Hickory"}
{"word": ["flirty"], "author": "mm324"}
{"word": ["Coquettish."], "author": "Hickory"}
{"word": ["playful"], "author": "mm324"}
{"word": ["Amicable."], "author": "REDVWIN"}
{"word": ["nice"], "author": "mm324"}
{"word": ["Friendly"], "author": "TARFU"}
{"word": ["neighborly"], "author": "mm324"}
{"word": ["neighborhood"], "author": "TARFU"}
{"word": ["district"], "author": "mm324"}
{"word": ["quarter"], "author": "TARFU"}
{"word": ["horse"], "author": "mm324"}
{"word": ["cowboy"], "author": "TARFU"}
{"word": ["hat"], "author": "mm324"}
{"word": [" Friendly."], "author": "Kleetus"}
{"word": [" fedora"], "author": "TARFU"}
{"word": [" Fedora."], "author": "Kleetus"}
{"word": ["Linux."], "author": "Casval_Deikun"}
{"word": ["Computer"], "author": "TARFU"}
{"word": ["Application"], "author": "almabrds"}
{"word": ["Program"], "author": "TARFU"}
{"word": ["brainwash"], "author": "Dzsono"}
{"word": ["indoctrinate"], "author": "mm324"}
{"word": ["Torture"], "author": "TARFU"}
{"word": ["pain"], "author": "mm324"}
{"word": ["Hurt."], "author": "Kleetus"}
{"word": ["pleasure"], "author": "le_chevalier"}
{"word": ["Delight."], "author": "Kleetus"}
{"word": [" Joy"], "author": "TARFU"}
{"word": [" Delight."], "author": "Kleetus"}
{"word": ["happy"], "author": "Tocran"}
{"word": ["Shiny"], "author": "park_84"}
{"word": ["Gold ;)"], "author": "deathrabit"}
{"word": ["."], "author": "gixgox"}
{"word": ["trinket"], "author": "Ardal"}
{"word": ["Bling."], "author": "Hickory"}
{"word": ["Glitter"], "author": "PaterAlf"}
{"word": ["Sparkle"], "author": "Yezemin"}
{"word": [], "author": "gixgox"}
{"word": ["Light."], "author": "Narcia_"}
{"word": ["glow"], "author": "ashwald"}
{"word": ["ghost"], "author": "Tocran"}
{"word": ["death"], "author": "Slyzeroth"}
{"word": [], "author": "Dzsono"}
{"word": ["superstition"], "author": "mm324"}
{"word": ["Fear"], "author": "TARFU"}
{"word": ["terror"], "author": "mm324"}
{"word": ["Suspence"], "author": "Madshaker"}
{"word": ["mystery"], "author": "mm324"}
{"word": ["enigma"], "author": "TARFU"}
{"word": ["riddle"], "author": "mm324"}
{"word": ["question"], "author": "TARFU"}
{"word": ["Answer"], "author": "Yezemin"}
{"word": ["confirmation"], "author": "TARFU"}
{"word": ["point"], "author": "kmonster"}
{"word": ["spear"], "author": "TARFU"}
{"word": [" Reply."], "author": "Kleetus"}
{"word": [" Thrower."], "author": "gixgox"}
{"word": [" Pitcher"], "author": "TARFU"}
{"word": ["catcher"], "author": "mm324"}
{"word": ["baseball"], "author": "TARFU"}
{"word": [" Player."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Player."], "author": "Kleetus"}
{"word": [" dancing"], "author": "TARFU"}
{"word": ["drinking"], "author": "mm324"}
{"word": ["Alcohol"], "author": "PaterAlf"}
{"word": ["PARTY"], "author": "mm324"}
{"word": ["Often!"], "author": "Stryder2931"}
{"word": ["Time."], "author": "REDVWIN"}
{"word": ["linearity"], "author": "Dzsono"}
{"word": ["Straight"], "author": "TARFU"}
{"word": ["Crooked."], "author": "Hickory"}
{"word": [" Machine."], "author": "Kleetus"}
{"word": [" Man."], "author": "Casval_Deikun"}
{"word": ["Machine."], "author": "Kleetus"}
{"word": ["Tech"], "author": "Madshaker"}
{"word": ["Cog"], "author": "park_84"}
{"word": [" Male."], "author": "Hickory"}
{"word": [" Gear."], "author": "Kleetus"}
{"word": [" Male."], "author": "Hickory"}
{"word": ["man"], "author": "le_chevalier"}
{"word": [" Human"], "author": "TARFU"}
{"word": ["mankind"], "author": "le_chevalier"}
{"word": ["Humanity."], "author": "Hickory"}
{"word": ["Xenos"], "author": "Zoltan999"}
{"word": ["Aliens"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": [" 'Exopolitics'? What next?"], "author": "Hickory"}
{"word": ["Exoskeletal."], "author": "Narcia_"}
{"word": ["skeleton"], "author": "Accatone"}
{"word": ["ribs"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": ["tire"], "author": "ashwald"}
{"word": ["Flat."], "author": "gixgox"}
{"word": ["earth"], "author": "Dzsono"}
{"word": ["soil"], "author": "mm324"}
{"word": ["Dirt"], "author": "TARFU"}
{"word": ["Particulate..."], "author": "GhostwriterDoF"}
{"word": ["dust"], "author": "mm324"}
{"word": ["Particle."], "author": "Hickory"}
{"word": ["particles"], "author": "TARFU"}
{"word": ["Ion"], "author": "mm324"}
{"word": ["cannon"], "author": "TARFU"}
{"word": ["ball"], "author": "mm324"}
{"word": ["lightning"], "author": "motorkar"}
{"word": ["electricity"], "author": "TARFU"}
{"word": [" Thunder."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": [" Powerless."], "author": "Hickory"}
{"word": [" Weak"], "author": "TARFU"}
{"word": [" Material."], "author": "Kleetus"}
{"word": [" Puny."], "author": "Hickory"}
{"word": ["small"], "author": "mm324"}
{"word": [" Bones."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": [" talented"], "author": "mm324"}
{"word": ["Gifted."], "author": "gixgox"}
{"word": ["bequeathed"], "author": "Dzsono"}
{"word": ["will"], "author": "mm324"}
{"word": ["Bones."], "author": "Kleetus"}
{"word": [" Mettle."], "author": "Hickory"}
{"word": ["Audacity."], "author": "gixgox"}
{"word": [" Smith."], "author": "Kleetus"}
{"word": [" Impertinence."], "author": "Hickory"}
{"word": [" Bones."], "author": "Kleetus"}
{"word": [" Impertinence."], "author": "Hickory"}
{"word": ["Bones."], "author": "Kleetus"}
{"word": [" Impertinence."], "author": "Hickory"}
{"word": ["Bones."], "author": "Kleetus"}
{"word": [" Impertinence."], "author": "Hickory"}
{"word": ["disrespect"], "author": "mm324"}
{"word": ["Contempt."], "author": "Hickory"}
{"word": ["disdain"], "author": "mm324"}
{"word": [" Distemper."], "author": "Kleetus"}
{"word": [" dismissal"], "author": "TARFU"}
{"word": [" Distemper."], "author": "Kleetus"}
{"word": ["aixelsyd"], "author": "flubbucket"}
{"word": [" Disorder ", " ", " (I see what you did there :P)"], "author": "Zoltan999"}
{"word": ["disoriented"], "author": "le_chevalier"}
{"word": ["woozy"], "author": "Dzsono"}
{"word": ["Boozy."], "author": "gixgox"}
{"word": ["Tavern"], "author": "TARFU"}
{"word": ["Brawl."], "author": "gixgox"}
{"word": ["Arena"], "author": "Tocran"}
{"word": [], "author": "gixgox"}
{"word": ["Name."], "author": "Hickory"}
{"word": ["moniker"], "author": "TARFU"}
{"word": ["title"], "author": "mm324"}
{"word": ["sequence"], "author": "cose_vecchie"}
{"word": ["pattern"], "author": "mm324"}
{"word": ["recognition"], "author": "le_chevalier"}
{"word": ["Realisation."], "author": "Hickory"}
{"word": ["understanding"], "author": "mm324"}
{"word": ["Sense."], "author": "Narcia_"}
{"word": ["feel"], "author": "mm324"}
{"word": ["Tactile."], "author": "Hickory"}
{"word": ["touch"], "author": "mm324"}
{"word": ["Pat."], "author": "Kleetus"}
{"word": [" Typing."], "author": "gixgox"}
{"word": [" Keyboard"], "author": "TARFU"}
{"word": [" Pat."], "author": "Kleetus"}
{"word": [" Layout."], "author": "Hickory"}
{"word": ["Blueprint"], "author": "TARFU"}
{"word": ["Diagram."], "author": "Hickory"}
{"word": ["Plan"], "author": "park_84"}
{"word": ["schematic"], "author": "Dzsono"}
{"word": ["Blueprint"], "author": "Yezemin"}
{"word": ["design"], "author": "ashwald"}
{"word": ["Layout."], "author": "gixgox"}
{"word": ["Arrangement."], "author": "Hickory"}
{"word": ["Musical."], "author": "Narcia_"}
{"word": [], "author": "Zoltan999"}
{"word": ["drama ", " ", " ninja'd ", " ", " okay (the OK state)"], "author": "le_chevalier"}
{"word": ["Righto."], "author": "Hickory"}
{"word": ["cool"], "author": "mm324"}
{"word": ["cold"], "author": "TARFU"}
{"word": ["winter"], "author": "Smogg"}
{"word": ["thrones"], "author": "almabrds"}
{"word": ["king"], "author": "mm324"}
{"word": ["expensive"], "author": "Hierosclito"}
{"word": ["costly"], "author": "mm324"}
{"word": ["effort"], "author": "Hierosclito"}
{"word": ["life"], "author": "Accatone"}
{"word": ["time"], "author": "Hierosclito"}
{"word": ["Space."], "author": "Hickory"}
{"word": ["flies"], "author": "Gerin"}
{"word": ["pests"], "author": "mm324"}
{"word": ["Bothersome."], "author": "Hickory"}
{"word": ["nephews (LOL)"], "author": "mm324"}
{"word": ["annoying"], "author": "TARFU"}
{"word": ["irritating"], "author": "mm324"}
{"word": ["calculate ^^"], "author": "Hierosclito"}
{"word": ["operation"], "author": "park_84"}
{"word": ["surgery"], "author": "mm324"}
{"word": ["procedure"], "author": "TARFU"}
{"word": [" Theatre."], "author": "Kleetus"}
{"word": [" Task."], "author": "Hickory"}
{"word": [" Job"], "author": "TARFU"}
{"word": ["Interview."], "author": "Hickory"}
{"word": ["Theatre."], "author": "Kleetus"}
{"word": [" Interview."], "author": "Hickory"}
{"word": [" Assessment"], "author": "TARFU"}
{"word": ["Appraisal."], "author": "Hickory"}
{"word": ["Inspection"], "author": "TARFU"}
{"word": ["Theatre."], "author": "Kleetus"}
{"word": [" Examination."], "author": "Hickory"}
{"word": ["doctor"], "author": "mm324"}
{"word": ["Prescription."], "author": "Hickory"}
{"word": ["pharmacy"], "author": "mm324"}
{"word": ["Chemist."], "author": "Hickory"}
{"word": [" Medicine."], "author": "Kleetus"}
{"word": [" Chemist."], "author": "Hickory"}
{"word": ["Medicine."], "author": "Kleetus"}
{"word": [" Chemistry"], "author": "TARFU"}
{"word": ["Medicine."], "author": "Kleetus"}
{"word": [" Reactions."], "author": "Hickory"}
{"word": [" Bark."], "author": "Kleetus"}
{"word": [" Reactions."], "author": "Hickory"}
{"word": ["Bark."], "author": "Kleetus"}
{"word": [" Reactions."], "author": "Hickory"}
{"word": ["Bark."], "author": "Kleetus"}
{"word": [" Reactions."], "author": "Hickory"}
{"word": [" chain"], "author": "TARFU"}
{"word": ["Link."], "author": "Hickory"}
{"word": ["Dog ", " ", " ", " missing"], "author": "mm324"}
{"word": [" Leash."], "author": "Kleetus"}
{"word": [" Beagle"], "author": "TARFU"}
{"word": ["doberman"], "author": "mm324"}
{"word": ["Terrier."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": [" Peanuts"], "author": "mm324"}
{"word": ["Terrier."], "author": "Kleetus"}
{"word": ["Border"], "author": "Tocran"}
{"word": ["Collie."], "author": "Kleetus"}
{"word": ["Brollie."], "author": "Tauto"}
{"word": [" "], "author": "gixgox"}
{"word": ["evil =o ", " "], "author": "mm324"}
{"word": ["Collie."], "author": "Kleetus"}
{"word": ["Dollie."], "author": "Tauto"}
{"word": ["Doggie."], "author": "Kleetus"}
{"word": [" Visage."], "author": "Hickory"}
{"word": [" Doggie."], "author": "Kleetus"}
{"word": [" appearance"], "author": "mm324"}
{"word": [" Aspect."], "author": "Hickory"}
{"word": ["Doggie."], "author": "Kleetus"}
{"word": [" Aspect."], "author": "Hickory"}
{"word": ["Doggie."], "author": "Kleetus"}
{"word": [" Ratio"], "author": "TARFU"}
{"word": ["Doggie."], "author": "Kleetus"}
{"word": [" Proportion."], "author": "Hickory"}
{"word": ["Doggie."], "author": "Kleetus"}
{"word": [" Proportion."], "author": "Hickory"}
{"word": ["Doggie."], "author": "Kleetus"}
{"word": [" Proportion."], "author": "Hickory"}
{"word": ["Doggie."], "author": "Kleetus"}
{"word": [" Proportion."], "author": "Hickory"}
{"word": ["Doggie."], "author": "Kleetus"}
{"word": ["Gentle."], "author": "Hierosclito"}
{"word": ["...man"], "author": "park_84"}
{"word": ["sperm :D"], "author": "EPurpl3"}
{"word": ["chivalrous"], "author": "Dzsono"}
{"word": ["Hat."], "author": "Hierosclito"}
{"word": ["Pat."], "author": "Kleetus"}
{"word": ["Laziness."], "author": "Hierosclito"}
{"word": ["Virtue"], "author": "drevo2"}
{"word": ["Challenge"], "author": "Hierosclito"}
{"word": ["Adventurous."], "author": "GhostwriterDoF"}
{"word": ["Exploration"], "author": "TARFU"}
{"word": ["darwin"], "author": "Ardal"}
{"word": ["evolution"], "author": "mm324"}
{"word": ["evolution ", " ", " --- ", " ", " ouch, I've been ninja'd... ", " ", " progress"], "author": "park_84"}
{"word": ["entropy"], "author": "Hierosclito"}
{"word": ["chaos"], "author": "TARFU"}
{"word": ["theory"], "author": "mm324"}
{"word": ["expectation"], "author": "Hierosclito"}
{"word": ["anticipation"], "author": "TARFU"}
{"word": ["tension"], "author": "Hierosclito"}
{"word": ["eruption"], "author": "le_chevalier"}
{"word": ["Lava"], "author": "Licurg"}
{"word": ["untameable"], "author": "Hierosclito"}
{"word": ["Monster"], "author": "PaterAlf"}
{"word": ["remorse"], "author": "Hierosclito"}
{"word": ["regret"], "author": "TARFU"}
{"word": ["voices"], "author": "Hierosclito"}
{"word": ["speech"], "author": "TARFU"}
{"word": [" Sound."], "author": "Kleetus"}
{"word": [" lawyer"], "author": "Hierosclito"}
{"word": [" crime"], "author": "TARFU"}
{"word": [" Solicitor."], "author": "Kleetus"}
{"word": [" unforgiven"], "author": "Hierosclito"}
{"word": [" Volcano."], "author": "Kleetus"}
{"word": [" remorseless"], "author": "TARFU"}
{"word": ["lightweight"], "author": "Hierosclito"}
{"word": ["Volcano."], "author": "Kleetus"}
{"word": ["Magma."], "author": "xieliming"}
{"word": [" molten"], "author": "TARFU"}
{"word": [" Lava."], "author": "Kleetus"}
{"word": [" gold"], "author": "Hierosclito"}
{"word": ["Lava."], "author": "Kleetus"}
{"word": [" metal"], "author": "TARFU"}
{"word": ["Lava."], "author": "Kleetus"}
{"word": [" prosthesis"], "author": "Hierosclito"}
{"word": ["Lava."], "author": "Kleetus"}
{"word": [" pirate"], "author": "TARFU"}
{"word": ["Lava."], "author": "Kleetus"}
{"word": [" treason"], "author": "Hierosclito"}
{"word": ["Execute"], "author": "Zoltan999"}
{"word": ["Sociopath"], "author": "Allinstein"}
{"word": ["Psychosis."], "author": "Narcia_"}
{"word": ["Crazy"], "author": "TARFU"}
{"word": ["AXE"], "author": "ashwald"}
{"word": ["Wood"], "author": "TARFU"}
{"word": ["would"], "author": "Dzsono"}
{"word": ["could"], "author": "mm324"}
{"word": ["Cloud"], "author": "Yezemin"}
{"word": ["fog"], "author": "mm324"}
{"word": ["Horn"], "author": "Cavenagh"}
{"word": [" Knee."], "author": "Kleetus"}
{"word": [" Gondor ", " ", " "], "author": "TARFU"}
{"word": ["Knee."], "author": "Kleetus"}
{"word": [" Mordor"], "author": "Zoltan999"}
{"word": ["Journey"], "author": "park_84"}
{"word": ["Longest."], "author": "Narcia_"}
{"word": ["shortest"], "author": "TARFU"}
{"word": ["tallest"], "author": "mm324"}
{"word": ["Pinnacle."], "author": "GhostwriterDoF"}
{"word": ["top"], "author": "mm324"}
{"word": ["apex"], "author": "Dzsono"}
{"word": ["summit"], "author": "mm324"}
{"word": ["meeting"], "author": "le_chevalier"}
{"word": ["Business"], "author": "mm324"}
{"word": ["Affair."], "author": "gixgox"}
{"word": ["incorporation"], "author": "TARFU"}
{"word": ["seperation"], "author": "ashwald"}
{"word": ["gap"], "author": "mm324"}
{"word": ["Trench"], "author": "TARFU"}
{"word": ["Foot"], "author": "mm324"}
{"word": [" Split."], "author": "Kleetus"}
{"word": [" Ankle"], "author": "TARFU"}
{"word": ["Split."], "author": "Kleetus"}
{"word": [" shin"], "author": "mm324"}
{"word": ["canary."], "author": "Tauto"}
{"word": [" Bone"], "author": "TARFU"}
{"word": [" muscle"], "author": "mm324"}
{"word": ["sparrow."], "author": "Tauto"}
{"word": [" Bird."], "author": "Kleetus"}
{"word": ["dollie."], "author": "Tauto"}
{"word": [" Strength"], "author": "TARFU"}
{"word": [" power"], "author": "mm324"}
{"word": [" Force"], "author": "TARFU"}
{"word": ["budgerigar."], "author": "Tauto"}
{"word": [" Bird."], "author": "Kleetus"}
{"word": ["shoe."], "author": "Tauto"}
{"word": ["Poo."], "author": "Kleetus"}
{"word": ["chocolate."], "author": "Tauto"}
{"word": ["Diarrhea."], "author": "Kleetus"}
{"word": ["spaghetti."], "author": "Tauto"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["jam."], "author": "Tauto"}
{"word": ["Space"], "author": "VampiroAlhazred"}
{"word": ["eternity"], "author": "Dzsono"}
{"word": [" infinity"], "author": "TARFU"}
{"word": ["immortality"], "author": "Maxvorstadt"}
{"word": ["invulnerability"], "author": "le_chevalier"}
{"word": ["Potion"], "author": "park_84"}
{"word": ["Alchemist"], "author": "truhlik"}
{"word": ["chemist"], "author": "le_chevalier"}
{"word": ["Walter"], "author": "pokooj"}
{"word": ["watlz"], "author": "Dzsono"}
{"word": ["dance"], "author": "Ardal"}
{"word": ["Rain"], "author": "Zoltan999"}
{"word": ["Storm"], "author": "pokooj"}
{"word": ["Thunder."], "author": "gixgox"}
{"word": ["lightning"], "author": "mm324"}
{"word": ["speed"], "author": "apehater"}
{"word": ["racer"], "author": "mm324"}
{"word": ["driver"], "author": "TARFU"}
{"word": ["Screw"], "author": "mm324"}
{"word": ["nail"], "author": "TARFU"}
{"word": ["hammer"], "author": "mm324"}
{"word": ["nostalgy"], "author": "Antimateria"}
{"word": ["past"], "author": "ashwald"}
{"word": ["Future"], "author": "Yezemin"}
{"word": ["Present."], "author": "Narcia_"}
{"word": ["Birthday"], "author": "PaterAlf"}
{"word": ["cake"], "author": "mm324"}
{"word": ["Pie"], "author": "TARFU"}
{"word": [" Party."], "author": "Kleetus"}
{"word": ["dollie."], "author": "Tauto"}
{"word": ["Blow-up."], "author": "Kleetus"}
{"word": ["house."], "author": "Tauto"}
{"word": [" Pi."], "author": "gixgox"}
{"word": [" Home."], "author": "Kleetus"}
{"word": ["Pi."], "author": "gixgox"}
{"word": [" Mathematics"], "author": "TARFU"}
{"word": ["proof"], "author": "Dzsono"}
{"word": ["Theorem."], "author": "xieliming"}
{"word": ["Speculation"], "author": "TARFU"}
{"word": [" Proposition."], "author": "Kleetus"}
{"word": [" Broker."], "author": "gixgox"}
{"word": ["middle-man"], "author": "le_chevalier"}
{"word": ["Manager."], "author": "Narcia_"}
{"word": ["Boss"], "author": "Zoltan999"}
{"word": [" "], "author": "gixgox"}
{"word": ["Musician"], "author": "TARFU"}
{"word": ["Impressive."], "author": "GhostwriterDoF"}
{"word": ["Artist."], "author": "gixgox"}
{"word": ["Sculptor"], "author": "TARFU"}
{"word": ["painter"], "author": "mm324"}
{"word": ["Photographer."], "author": "gixgox"}
{"word": ["camera"], "author": "mm324"}
{"word": ["film"], "author": "TARFU"}
{"word": ["silent"], "author": "park_84"}
{"word": ["hill"], "author": "BlackDawn"}
{"word": ["mountain"], "author": "TARFU"}
{"word": ["Vulcano"], "author": "PaterAlf"}
{"word": ["Crater."], "author": "gixgox"}
{"word": ["meteor"], "author": "TARFU"}
{"word": [" Island."], "author": "Kleetus"}
{"word": [" Trail."], "author": "gixgox"}
{"word": ["Island."], "author": "Kleetus"}
{"word": [" Path"], "author": "TARFU"}
{"word": ["Island."], "author": "Kleetus"}
{"word": ["Japan"], "author": "Gerin"}
{"word": ["volcanic"], "author": "Dzsono"}
{"word": ["infernal"], "author": "le_chevalier"}
{"word": ["machine"], "author": "park_84"}
{"word": ["gun"], "author": "Tocran"}
{"word": ["bullet"], "author": "ashwald"}
{"word": ["missile"], "author": "le_chevalier"}
{"word": ["Rocket"], "author": "TARFU"}
{"word": ["Launch."], "author": "Narcia_"}
{"word": ["Missile"], "author": "Zoltan999"}
{"word": ["rack"], "author": "Ardal"}
{"word": ["Billiards"], "author": "TARFU"}
{"word": ["Table"], "author": "enurbenur"}
{"word": ["Tabletop."], "author": "gixgox"}
{"word": [" Desk."], "author": "Kleetus"}
{"word": ["desktop"], "author": "DrakoPensulo"}
{"word": ["computer"], "author": "TARFU"}
{"word": ["Apple"], "author": "Zoltan999"}
{"word": ["rotten"], "author": "TARFU"}
{"word": ["Teeth."], "author": "gixgox"}
{"word": ["Julia Roberts"], "author": "Gerin"}
{"word": ["^ idiot."], "author": "Tauto"}
{"word": [" Fruit."], "author": "Kleetus"}
{"word": ["Dollie."], "author": "Tauto"}
{"word": ["Teeth."], "author": "gixgox"}
{"word": ["milk"], "author": "Dzsono"}
{"word": ["Calcium."], "author": "Hickory"}
{"word": ["Bones"], "author": "le_chevalier"}
{"word": ["Dogs."], "author": "Kleetus"}
{"word": [" Ulna."], "author": "gixgox"}
{"word": ["radius"], "author": "park_84"}
{"word": ["pi"], "author": "Zoltan999"}
{"word": ["PIE"], "author": "ashwald"}
{"word": [" ", " ", " "], "author": "gixgox"}
{"word": ["Cranberries."], "author": "Narcia_"}
{"word": ["Raspberries."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["sand"], "author": "Smogg"}
{"word": ["Beach"], "author": "PaterAlf"}
{"word": ["waves"], "author": "TARFU"}
{"word": ["surf"], "author": "Zordu"}
{"word": ["web"], "author": "Kookies"}
{"word": ["intrigue"], "author": "Dzsono"}
{"word": ["mystery"], "author": "TARFU"}
{"word": [" Spider."], "author": "Kleetus"}
{"word": ["Man"], "author": "motorkar"}
{"word": ["Penis."], "author": "Kleetus"}
{"word": ["Vagina :)"], "author": "deathrabit"}
{"word": [" "], "author": "gixgox"}
{"word": ["mouse"], "author": "park_84"}
{"word": ["Scurry... :)"], "author": "GhostwriterDoF"}
{"word": ["hurry"], "author": "le_chevalier"}
{"word": ["Rabbit"], "author": "enurbenur"}
{"word": ["Hare."], "author": "Narcia_"}
{"word": ["Tortoise"], "author": "enurbenur"}
{"word": ["Ninja."], "author": "VampiroAlhazred"}
{"word": ["tuna"], "author": "Tauto"}
{"word": ["Fish."], "author": "Kleetus"}
{"word": [" sword"], "author": "TARFU"}
{"word": [" Fish."], "author": "Kleetus"}
{"word": ["Dollie."], "author": "Tauto"}
{"word": ["Sheep."], "author": "Kleetus"}
{"word": ["Lollie."], "author": "Tauto"}
{"word": [" Katana."], "author": "gixgox"}
{"word": [" samurai"], "author": "TARFU"}
{"word": ["stealth"], "author": "Dzsono"}
{"word": [" Sweet."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Sweet."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Sweet."], "author": "Kleetus"}
{"word": [" paper"], "author": "TARFU"}
{"word": ["pen"], "author": "le_chevalier"}
{"word": ["Ink"], "author": "TARFU"}
{"word": [" Write."], "author": "Kleetus"}
{"word": [" Inkling."], "author": "gixgox"}
{"word": ["hint"], "author": "park_84"}
{"word": ["Indirect"], "author": "Zoltan999"}
{"word": ["Discreet."], "author": "gixgox"}
{"word": ["Private."], "author": "Narcia_"}
{"word": ["tutor"], "author": "le_chevalier"}
{"word": ["Teacher"], "author": "TARFU"}
{"word": ["impart"], "author": "Dzsono"}
{"word": ["Inherit."], "author": "GhostwriterDoF"}
{"word": ["Bequeath."], "author": "Hickory"}
{"word": [" Receive."], "author": "Kleetus"}
{"word": [" Pass."], "author": "gixgox"}
{"word": ["baton"], "author": "GabesterOne"}
{"word": ["Cop"], "author": "almabrds"}
{"word": ["Catch."], "author": "Hickory"}
{"word": [" Police."], "author": "Kleetus"}
{"word": [" Catch."], "author": "Hickory"}
{"word": ["Police."], "author": "Kleetus"}
{"word": [" Baseball"], "author": "almabrds"}
{"word": ["Police."], "author": "Kleetus"}
{"word": [" Playoffs."], "author": "gixgox"}
{"word": ["Police."], "author": "Kleetus"}
{"word": [" Championship"], "author": "TARFU"}
{"word": ["Police."], "author": "Kleetus"}
{"word": [" League,"], "author": "gixgox"}
{"word": ["Police."], "author": "Kleetus"}
{"word": ["Dollie."], "author": "Tauto"}
{"word": ["Tuna."], "author": "Kleetus"}
{"word": ["hat."], "author": "Tauto"}
{"word": [" Association."], "author": "Hickory"}
{"word": [" Cap."], "author": "Kleetus"}
{"word": [" Association."], "author": "Hickory"}
{"word": [" incorporation"], "author": "TARFU"}
{"word": ["Business."], "author": "xieliming"}
{"word": ["Goods."], "author": "REDVWIN"}
{"word": ["services"], "author": "TARFU"}
{"word": [" Products."], "author": "Kleetus"}
{"word": ["Dollie."], "author": "Tauto"}
{"word": ["Tuna."], "author": "Kleetus"}
{"word": ["Bike."], "author": "Tauto"}
{"word": [" Support."], "author": "gixgox"}
{"word": ["Structure."], "author": "Hickory"}
{"word": ["anatomy"], "author": "le_chevalier"}
{"word": ["Formation."], "author": "gixgox"}
{"word": ["inception"], "author": "le_chevalier"}
{"word": ["Start"], "author": "Zoltan999"}
{"word": ["Kick-off."], "author": "Hickory"}
{"word": ["Versus."], "author": "Narcia_"}
{"word": ["clash"], "author": "Dzsono"}
{"word": ["titans"], "author": "Ardal"}
{"word": ["Myth"], "author": "almabrds"}
{"word": ["legend"], "author": "TARFU"}
{"word": [" Atlantis"], "author": "Ian"}
{"word": [" Behemoth."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" Travel"], "author": "Ian"}
{"word": [" journey"], "author": "TARFU"}
{"word": ["Adventure"], "author": "GabesterOne"}
{"word": [" Trip."], "author": "Kleetus"}
{"word": [" expedition"], "author": "TARFU"}
{"word": [" Escapade."], "author": "Kleetus"}
{"word": ["turn"], "author": "kmonster"}
{"word": ["jerkmuter"], "author": "Tauto"}
{"word": ["deleted"], "author": "Tauto"}
{"word": [" into"], "author": "almabrds"}
{"word": [" doorway"], "author": "TARFU"}
{"word": [" Forever."], "author": "Kleetus"}
{"word": [" Exit"], "author": "almabrds"}
{"word": ["Forever."], "author": "Kleetus"}
{"word": [" egress"], "author": "TARFU"}
{"word": ["Forever."], "author": "Kleetus"}
{"word": ["Escape"], "author": "TDP"}
{"word": ["Retire."], "author": "gixgox"}
{"word": ["end"], "author": "GabesterOne"}
{"word": ["Rest."], "author": "Narcia_"}
{"word": ["Peace."], "author": "gixgox"}
{"word": ["serenity"], "author": "le_chevalier"}
{"word": ["calmness"], "author": "GabesterOne"}
{"word": [" Meditation"], "author": "almabrds"}
{"word": ["Insight."], "author": "REDVWIN"}
{"word": ["Forethought."], "author": "Hickory"}
{"word": ["pondering"], "author": "GabesterOne"}
{"word": ["thinking"], "author": "TARFU"}
{"word": [" brain ;)"], "author": "deathrabit"}
{"word": ["Cerebral."], "author": "Hickory"}
{"word": [" Mind."], "author": "Kleetus"}
{"word": [" Cerebral."], "author": "Hickory"}
{"word": ["neural"], "author": "park_84"}
{"word": ["Network."], "author": "xieliming"}
{"word": ["Link."], "author": "Hickory"}
{"word": [" Web."], "author": "Kleetus"}
{"word": ["Clique."], "author": "gixgox"}
{"word": [" Link."], "author": "Hickory"}
{"word": ["Web."], "author": "Kleetus"}
{"word": [" Link."], "author": "Hickory"}
{"word": ["Web."], "author": "Kleetus"}
{"word": [" Link."], "author": "Hickory"}
{"word": [" Ocarina"], "author": "almabrds"}
{"word": ["Web."], "author": "Kleetus"}
{"word": [" Connection."], "author": "gixgox"}
{"word": ["Joint."], "author": "Hickory"}
{"word": ["Pixel ", " "], "author": "almabrds"}
{"word": ["Web."], "author": "Kleetus"}
{"word": ["Dollie."], "author": "Tauto"}
{"word": ["Tuna."], "author": "Kleetus"}
{"word": ["spider."], "author": "Tauto"}
{"word": ["Web."], "author": "Kleetus"}
{"word": ["jerkmuter"], "author": "Tauto"}
{"word": ["Pixel ", " "], "author": "almabrds"}
{"word": [" Deleted."], "author": "Kleetus"}
{"word": ["wipeout"], "author": "Tauto"}
{"word": ["Pixel"], "author": "almabrds"}
{"word": [" screen"], "author": "TARFU"}
{"word": ["display"], "author": "le_chevalier"}
{"word": ["Monitor."], "author": "Hickory"}
{"word": [" Show."], "author": "Kleetus"}
{"word": [" Monitor."], "author": "Hickory"}
{"word": ["Show."], "author": "Kleetus"}
{"word": ["Apparatus."], "author": "REDVWIN"}
{"word": ["Equipment."], "author": "Kleetus"}
{"word": [" Monitor."], "author": "Hickory"}
{"word": [" "], "author": "gixgox"}
{"word": ["gecko"], "author": "mm324"}
{"word": ["Skink."], "author": "Narcia_"}
{"word": ["monotreme"], "author": "Dzsono"}
{"word": ["Platypus"], "author": "almabrds"}
{"word": [" Lizard."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" stew"], "author": "TARFU"}
{"word": ["Troll"], "author": "almabrds"}
{"word": ["Bridge"], "author": "Kookies"}
{"word": ["Toll."], "author": "Hickory"}
{"word": ["death"], "author": "le_chevalier"}
{"word": ["scythe"], "author": "clisair"}
{"word": ["wheat"], "author": "TARFU"}
{"word": [" Mow."], "author": "Kleetus"}
{"word": ["Dollie."], "author": "Tauto"}
{"word": ["Tuna."], "author": "Kleetus"}
{"word": ["House."], "author": "Tauto"}
{"word": [" Grass."], "author": "Hickory"}
{"word": [" turf"], "author": "TARFU"}
{"word": [" Kennel."], "author": "Kleetus"}
{"word": ["Dollie."], "author": "Tauto"}
{"word": [" Lawn."], "author": "Hickory"}
{"word": [" Doggie."], "author": "Kleetus"}
{"word": [" Meadow."], "author": "gixgox"}
{"word": [" sheep"], "author": "TARFU"}
{"word": ["wool"], "author": "mm324"}
{"word": ["Pullover."], "author": "Hickory"}
{"word": ["eyes"], "author": "Dzsono"}
{"word": ["Eyelashes"], "author": "park_84"}
{"word": ["Iris."], "author": "Narcia_"}
{"word": ["Pupil"], "author": "Zoltan999"}
{"word": ["disciple"], "author": "le_chevalier"}
{"word": [" Proselyte"], "author": "almabrds"}
{"word": ["Neophyte."], "author": "Hickory"}
{"word": ["beginner"], "author": "mm324"}
{"word": ["Practice."], "author": "Casval_Deikun"}
{"word": ["Training"], "author": "TARFU"}
{"word": [" Follower."], "author": "Kleetus"}
{"word": [" Regimen."], "author": "Hickory"}
{"word": [" tactics"], "author": "TARFU"}
{"word": ["Follower."], "author": "Kleetus"}
{"word": [" Battlefield."], "author": "Hickory"}
{"word": ["Follower."], "author": "Kleetus"}
{"word": ["I would say regimen."], "author": "Antimateria"}
{"word": [" wasteland"], "author": "TARFU"}
{"word": ["Follower."], "author": "Kleetus"}
{"word": [" Game"], "author": "almabrds"}
{"word": ["play"], "author": "Ardal"}
{"word": ["time"], "author": "Niggles"}
{"word": ["machine"], "author": "TARFU"}
{"word": [" ", " ", " <Sorry>"], "author": "gixgox"}
{"word": [" Period."], "author": "Kleetus"}
{"word": [" Emotion."], "author": "Hickory"}
{"word": ["drama"], "author": "mm324"}
{"word": ["movie"], "author": "TARFU"}
{"word": ["theater"], "author": "mm324"}
{"word": [" Period."], "author": "Kleetus"}
{"word": [" Ticket."], "author": "Hickory"}
{"word": ["Golden"], "author": "mm324"}
{"word": ["Axe"], "author": "almabrds"}
{"word": ["arcade"], "author": "mm324"}
{"word": ["game"], "author": "TARFU"}
{"word": ["Industry."], "author": "Casval_Deikun"}
{"word": ["Period."], "author": "Kleetus"}
{"word": [" Labour."], "author": "Hickory"}
{"word": ["day"], "author": "park_84"}
{"word": ["date"], "author": "le_chevalier"}
{"word": ["Rendezvous"], "author": "Yezemin"}
{"word": ["me."], "author": "Tauto"}
{"word": ["Dollie."], "author": "Kleetus"}
{"word": [" Soir\u00e9e."], "author": "Hickory"}
{"word": [" Tryst."], "author": "gixgox"}
{"word": ["Affair."], "author": "Narcia_"}
{"word": ["adultery"], "author": "le_chevalier"}
{"word": ["One-nighter."], "author": "gixgox"}
{"word": ["fling"], "author": "mm324"}
{"word": ["Hurl"], "author": "TARFU"}
{"word": ["javelin"], "author": "mm324"}
{"word": ["target"], "author": "ashwald"}
{"word": ["bull's-eye"], "author": "mm324"}
{"word": ["Center"], "author": "TARFU"}
{"word": ["epicenter"], "author": "park_84"}
{"word": ["earthquake"], "author": "mm324"}
{"word": ["tsunami"], "author": "BlackDawn"}
{"word": ["flow"], "author": "kmonster"}
{"word": ["Tensor."], "author": "xieliming"}
{"word": ["shoe."], "author": "Tauto"}
{"word": [" Current."], "author": "Hickory"}
{"word": ["Currant."], "author": "gixgox"}
{"word": ["Jam"], "author": "Zoltan999"}
{"word": ["Strawberry"], "author": "TARFU"}
{"word": [" Orange."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" pastry"], "author": "TARFU"}
{"word": ["baker"], "author": "mm324"}
{"word": ["Orange."], "author": "Kleetus"}
{"word": ["\u0421itrus."], "author": "Casval_Deikun"}
{"word": ["lime"], "author": "TARFU"}
{"word": ["green"], "author": "Ardal"}
{"word": ["emerald"], "author": "le_chevalier"}
{"word": ["Gem"], "author": "Yezemin"}
{"word": ["freemium"], "author": "Tocran"}
{"word": ["Premium"], "author": "PaterAlf"}
{"word": ["Superior"], "author": "Zoltan999"}
{"word": ["best"], "author": "mm324"}
{"word": ["Bet."], "author": "Narcia_"}
{"word": ["Wager"], "author": "TARFU"}
{"word": ["blackjack"], "author": "mm324"}
{"word": ["casino"], "author": "Smogg"}
{"word": [" shoe."], "author": "Tauto"}
{"word": ["chouchou !"], "author": "Tocran"}
{"word": ["gypsy !"], "author": "apehater"}
{"word": ["Romania"], "author": "TARFU"}
{"word": ["Rome"], "author": "kmonster"}
{"word": ["Italy"], "author": "mm324"}
{"word": ["pasta"], "author": "TARFU"}
{"word": ["sauce"], "author": "mm324"}
{"word": ["Gravy."], "author": "gixgox"}
{"word": ["Wavy"], "author": "mm324"}
{"word": ["crooked"], "author": "TARFU"}
{"word": ["Criminal."], "author": "xieliming"}
{"word": ["politician"], "author": "richlind33"}
{"word": ["bureaucrat"], "author": "TARFU"}
{"word": ["."], "author": "Hickory"}
{"word": ["stickler"], "author": "Ardal"}
{"word": ["advocate"], "author": "Dzsono"}
{"word": ["trial"], "author": "Tocran"}
{"word": ["test"], "author": "le_chevalier"}
{"word": ["Paper."], "author": "Hickory"}
{"word": ["origami"], "author": "park_84"}
{"word": ["Crane"], "author": "PaterAlf"}
{"word": ["Lift."], "author": "Hickory"}
{"word": ["Face"], "author": "Zoltan999"}
{"word": ["Visage."], "author": "gixgox"}
{"word": ["appearance"], "author": "mm324"}
{"word": ["visual"], "author": "le_chevalier"}
{"word": ["eye"], "author": "mm324"}
{"word": ["Catcher."], "author": "gixgox"}
{"word": ["Rye"], "author": "Yezemin"}
{"word": ["Whiskey."], "author": "Hickory"}
{"word": ["Scotch."], "author": "Narcia_"}
{"word": ["Golf"], "author": "TARFU"}
{"word": ["Ball"], "author": "Azrael360"}
{"word": ["Testicle."], "author": "Kleetus"}
{"word": ["meandering"], "author": "Stryder2931"}
{"word": ["aimless"], "author": "Dzsono"}
{"word": ["Witless."], "author": "gixgox"}
{"word": [" Adrift."], "author": "Kleetus"}
{"word": [" Cretinous."], "author": "Hickory"}
{"word": ["Adrift."], "author": "Kleetus"}
{"word": [" Cretinous."], "author": "Hickory"}
{"word": ["Adrift."], "author": "Kleetus"}
{"word": [" Cretinous."], "author": "Hickory"}
{"word": ["Adrift."], "author": "Kleetus"}
{"word": [" Cretinous."], "author": "Hickory"}
{"word": ["cynical"], "author": "park_84"}
{"word": ["Skeptical"], "author": "Zoltan999"}
{"word": ["understanding"], "author": "Ardal"}
{"word": ["Thoughtful."], "author": "Narcia_"}
{"word": ["considerate"], "author": "TARFU"}
{"word": ["polite"], "author": "mm324"}
{"word": ["friendly"], "author": "TARFU"}
{"word": ["casual"], "author": "tort1234"}
{"word": ["fortuitous"], "author": "Dogmaus"}
{"word": ["drank"], "author": "kmonster"}
{"word": ["thirsty"], "author": "TARFU"}
{"word": ["beer"], "author": "mm324"}
{"word": ["ale"], "author": "TARFU"}
{"word": ["mead"], "author": "mm324"}
{"word": ["honey"], "author": "TARFU"}
{"word": ["bee"], "author": "mm324"}
{"word": ["Farm"], "author": "almabrds"}
{"word": ["Body ", " "], "author": "gixgox"}
{"word": ["human"], "author": "TARFU"}
{"word": ["Almost."], "author": "Hickory"}
{"word": ["nearly"], "author": "le_chevalier"}
{"word": ["whisker"], "author": "Dzsono"}
{"word": ["Whiskey"], "author": "PaterAlf"}
{"word": ["Scottish"], "author": "park_84"}
{"word": ["Highland."], "author": "Hickory"}
{"word": ["Highlander."], "author": "VampiroAlhazred"}
{"word": ["Highlanders."], "author": "Kleetus"}
{"word": ["Scottish"], "author": "Zoltan999"}
{"word": ["Teleportation"], "author": "koima57"}
{"word": ["future"], "author": "mm324"}
{"word": ["Invention."], "author": "Narcia_"}
{"word": ["innovation"], "author": "mm324"}
{"word": ["renovation"], "author": "Tocran"}
{"word": ["alteration"], "author": "Dzsono"}
{"word": ["Change"], "author": "Yezemin"}
{"word": ["fluctuation"], "author": "TARFU"}
{"word": ["Oscillation."], "author": "gixgox"}
{"word": [" oscillator"], "author": "deathrabit"}
{"word": ["frequency"], "author": "mm324"}
{"word": ["radio"], "author": "TARFU"}
{"word": ["Waves"], "author": "mm324"}
{"word": [], "author": "gixgox"}
{"word": ["safari"], "author": "TARFU"}
{"word": ["fox"], "author": "Tocran"}
{"word": ["hounds"], "author": "TARFU"}
{"word": ["."], "author": "gixgox"}
{"word": [" Terriers."], "author": "Kleetus"}
{"word": ["Weimaraner"], "author": "almabrds"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" Pointer."], "author": "Kleetus"}
{"word": ["hint"], "author": "Ardal"}
{"word": ["Clue"], "author": "Cavenagh"}
{"word": ["glue"], "author": "Tocran"}
{"word": ["Sticky"], "author": "Licurg"}
{"word": ["Tape."], "author": "Narcia_"}
{"word": ["Weimaraner"], "author": "almabrds"}
{"word": [" Terrier."], "author": "Kleetus"}
{"word": [" dachshund"], "author": "TARFU"}
{"word": ["meat"], "author": "kmonster"}
{"word": ["beef"], "author": "mm324"}
{"word": ["Iron"], "author": "Dzsono"}
{"word": ["steel"], "author": "mm324"}
{"word": ["brotherhood"], "author": "enurbenur"}
{"word": ["alliance"], "author": "mm324"}
{"word": ["Dollie."], "author": "Tauto"}
{"word": [" League."], "author": "gixgox"}
{"word": [" Team"], "author": "TARFU"}
{"word": ["Football"], "author": "mm324"}
{"word": ["Ovoid."], "author": "REDVWIN"}
{"word": ["handball ", " ", " correction: it's ", " ", " "], "author": "le_chevalier"}
{"word": ["football"], "author": "Tocran"}
{"word": [" ", " Duplicate"], "author": "Zoltan999"}
{"word": ["Redux?"], "author": "gixgox"}
{"word": ["Necromancer"], "author": "PaterAlf"}
{"word": ["Politician"], "author": "viperfdl"}
{"word": ["Popularity."], "author": "Narcia_"}
{"word": ["adulation"], "author": "Dzsono"}
{"word": ["Flattery"], "author": "TDP"}
{"word": ["Manipulation"], "author": "viperfdl"}
{"word": ["Masturbation."], "author": "Kleetus"}
{"word": [" compliment"], "author": "TARFU"}
{"word": ["polite"], "author": "park_84"}
{"word": ["congenial"], "author": "TARFU"}
{"word": ["friendly"], "author": "mm324"}
{"word": [" Gracious."], "author": "Kleetus"}
{"word": [" neighborly"], "author": "TARFU"}
{"word": ["Gracious."], "author": "Kleetus"}
{"word": [" genial"], "author": "mm324"}
{"word": ["Gracious."], "author": "Kleetus"}
{"word": [" Courteous"], "author": "TARFU"}
{"word": [" please"], "author": "mm324"}
{"word": [], "author": "gixgox"}
{"word": ["Gracious."], "author": "Kleetus"}
{"word": [" ecstasy"], "author": "TARFU"}
{"word": ["nirvana"], "author": "mm324"}
{"word": ["suicide"], "author": "TARFU"}
{"word": ["Death"], "author": "PaterAlf"}
{"word": ["coffin"], "author": "Accatone"}
{"word": ["vampire"], "author": "mm324"}
{"word": ["Slayer"], "author": "TARFU"}
{"word": ["stake"], "author": "mm324"}
{"word": [" Casket."], "author": "Kleetus"}
{"word": [" Garlic."], "author": "gixgox"}
{"word": ["Chicken"], "author": "mm324"}
{"word": ["rooster"], "author": "TARFU"}
{"word": ["hen"], "author": "mm324"}
{"word": ["Casket."], "author": "Kleetus"}
{"word": ["Egg."], "author": "gixgox"}
{"word": ["scrambled"], "author": "TARFU"}
{"word": ["omelet"], "author": "mm324"}
{"word": ["diner"], "author": "TARFU"}
{"word": ["menu"], "author": "mm324"}
{"word": ["Casket."], "author": "Kleetus"}
{"word": [" entree"], "author": "TARFU"}
{"word": ["Appetiser."], "author": "gixgox"}
{"word": ["Casket."], "author": "Kleetus"}
{"word": [" dessert"], "author": "mm324"}
{"word": ["Casket."], "author": "Kleetus"}
{"word": [" cake"], "author": "TARFU"}
{"word": ["Casket."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Casket."], "author": "Kleetus"}
{"word": [" Jello"], "author": "TARFU"}
{"word": ["Casket."], "author": "Kleetus"}
{"word": [" byproduct"], "author": "Dzsono"}
{"word": ["Casket."], "author": "Kleetus"}
{"word": [" Vampire"], "author": "deathrabit"}
{"word": ["bloodsucker"], "author": "Ardal"}
{"word": ["Mosquito."], "author": "Narcia_"}
{"word": ["Insect."], "author": "gixgox"}
{"word": ["AntMan"], "author": "clisair"}
{"word": ["Wasp"], "author": "mm324"}
{"word": ["sting"], "author": "park_84"}
{"word": ["Bee"], "author": "mm324"}
{"word": [" ", " xD"], "author": "almabrds"}
{"word": [" sadistic ;)"], "author": "mm324"}
{"word": [" Barbarous"], "author": "almabrds"}
{"word": ["barbarian"], "author": "TARFU"}
{"word": ["Conan"], "author": "mm324"}
{"word": ["Holmes"], "author": "TARFU"}
{"word": [" Brutal."], "author": "Kleetus"}
{"word": ["boxing ", " ", " "], "author": "mm324"}
{"word": ["Brutal."], "author": "Kleetus"}
{"word": [" gloves"], "author": "TARFU"}
{"word": ["Brutal."], "author": "Kleetus"}
{"word": [" hats"], "author": "mm324"}
{"word": ["Shade."], "author": "xieliming"}
{"word": ["Brutal"], "author": "Kleetus"}
{"word": [" Tree"], "author": "mm324"}
{"word": [" Colour."], "author": "Kleetus"}
{"word": [" trunk"], "author": "TARFU"}
{"word": ["voyage"], "author": "mm324"}
{"word": ["Colour."], "author": "Kleetus"}
{"word": [" fantastic"], "author": "TARFU"}
{"word": [" incredible"], "author": "mm324"}
{"word": ["Colour."], "author": "Kleetus"}
{"word": ["Dollie."], "author": "Tauto"}
{"word": [" amazing"], "author": "TARFU"}
{"word": [" Tuna."], "author": "Kleetus"}
{"word": ["women"], "author": "Tauto"}
{"word": [" ", " ", " ", " <sorry I forgot to reload> ", " ", " "], "author": "gixgox"}
{"word": [" confusing"], "author": "TARFU"}
{"word": ["Difficult."], "author": "REDVWIN"}
{"word": ["different"], "author": "truhlik"}
{"word": ["weird"], "author": "le_chevalier"}
{"word": ["uncanny"], "author": "Dzsono"}
{"word": ["valley"], "author": "ashwald"}
{"word": [], "author": "Zoltan999"}
{"word": ["Funeral."], "author": "Narcia_"}
{"word": ["requiem"], "author": "park_84"}
{"word": ["dirge"], "author": "mm324"}
{"word": ["Sadness"], "author": "TDP"}
{"word": ["grief"], "author": "mm324"}
{"word": ["stages"], "author": "le_chevalier"}
{"word": ["theater"], "author": "mm324"}
{"word": ["broken"], "author": "apehater"}
{"word": ["repair"], "author": "TARFU"}
{"word": ["mend"], "author": "mm324"}
{"word": ["sew"], "author": "TARFU"}
{"word": ["needle"], "author": "mm324"}
{"word": ["thread"], "author": "TARFU"}
{"word": [" Damaged."], "author": "Kleetus"}
{"word": [" spool"], "author": "mm324"}
{"word": [" wooden"], "author": "TARFU"}
{"word": ["Damaged."], "author": "Kleetus"}
{"word": [" stiff"], "author": "mm324"}
{"word": ["Damaged."], "author": "Kleetus"}
{"word": [" firm"], "author": "TARFU"}
{"word": [" mattress"], "author": "mm324"}
{"word": [" blanket"], "author": "TARFU"}
{"word": [" pillow"], "author": "mm324"}
{"word": ["Damaged."], "author": "Kleetus"}
{"word": [" cushion"], "author": "TARFU"}
{"word": ["Damaged."], "author": "Kleetus"}
{"word": [" Divided"], "author": "koima57"}
{"word": ["Zero"], "author": "viperfdl"}
{"word": ["sum"], "author": "ashwald"}
{"word": ["Game."], "author": "Narcia_"}
{"word": ["osama"], "author": "apehater"}
{"word": ["amason"], "author": "Tocran"}
{"word": ["gypsy"], "author": "apehater"}
{"word": [" nomads"], "author": "deathrabit"}
{"word": [" Wanderers"], "author": "TARFU"}
{"word": [" Drifters."], "author": "Kleetus"}
{"word": ["Dollie."], "author": "Tauto"}
{"word": [" Wayfarer."], "author": "gixgox"}
{"word": [" Tuna."], "author": "Kleetus"}
{"word": [" Sunglasses ", " "], "author": "TARFU"}
{"word": ["Tuna."], "author": "Kleetus"}
{"word": [" WOMEN!"], "author": "Tauto"}
{"word": [" Broken. :("], "author": "gixgox"}
{"word": [" ruined"], "author": "TARFU"}
{"word": ["destroyed"], "author": "Dzsono"}
{"word": ["Annihilated"], "author": "park_84"}
{"word": [" matter"], "author": "deathrabit"}
{"word": ["substance"], "author": "le_chevalier"}
{"word": ["abuse"], "author": "Ardal"}
{"word": ["Emotional"], "author": "Zoltan999"}
{"word": ["Teary-eyed."], "author": "Hickory"}
{"word": ["onions"], "author": "ashwald"}
{"word": ["Cheese."], "author": "Hickory"}
{"word": ["moon"], "author": "Dzsono"}
{"word": ["Mooning"], "author": "viperfdl"}
{"word": ["Prank."], "author": "Hickory"}
{"word": ["Plank."], "author": "Narcia_"}
{"word": ["Shank."], "author": "Hickory"}
{"word": ["Shark."], "author": "ashwald"}
{"word": ["Tiger"], "author": "mm324"}
{"word": ["stripes"], "author": "apehater"}
{"word": ["Parallel."], "author": "Hickory"}
{"word": ["Parking"], "author": "mm324"}
{"word": ["ticket"], "author": "le_chevalier"}
{"word": ["master ", " ", "/"], "author": "mm324"}
{"word": [" Commander ", " ", " ", "/"], "author": "TARFU"}
{"word": [" general"], "author": "mm324"}
{"word": [" Captain"], "author": "TARFU"}
{"word": ["leader"], "author": "Dzsono"}
{"word": ["boss"], "author": "mm324"}
{"word": ["Employee"], "author": "TARFU"}
{"word": ["hireling"], "author": "mm324"}
{"word": [" Receipt."], "author": "Kleetus"}
{"word": ["Proof"], "author": "Azrael360"}
{"word": ["Pudding."], "author": "gixgox"}
{"word": ["chocolate"], "author": "TARFU"}
{"word": ["cacao"], "author": "le_chevalier"}
{"word": ["America"], "author": "park_84"}
{"word": ["Empire"], "author": "viperfdl"}
{"word": ["."], "author": "Hickory"}
{"word": ["soil"], "author": "Ardal"}
{"word": ["Sample"], "author": "Zoltan999"}
{"word": ["Size"], "author": "mm324"}
{"word": ["Quantity."], "author": "Narcia_"}
{"word": ["amount"], "author": "mm324"}
{"word": ["dismount"], "author": "Dzsono"}
{"word": ["horse"], "author": "mm324"}
{"word": ["gallop"], "author": "ashwald"}
{"word": ["Poll"], "author": "mm324"}
{"word": ["boycotting"], "author": "eksasol"}
{"word": ["protesting"], "author": "mm324"}
{"word": ["refusing"], "author": "Tocran"}
{"word": [], "author": "gixgox"}
{"word": ["Change"], "author": "GabesterOne"}
{"word": ["Money"], "author": "PaterAlf"}
{"word": ["Pocket."], "author": "Hickory"}
{"word": ["Rocket"], "author": "tort1234"}
{"word": ["Queen"], "author": "eksasol"}
{"word": ["science"], "author": "park_84"}
{"word": ["lab"], "author": "mm324"}
{"word": ["Lap."], "author": "gixgox"}
{"word": ["dance"], "author": "kmonster"}
{"word": ["Conniption... :P"], "author": "GhostwriterDoF"}
{"word": ["convulse"], "author": "Dzsono"}
{"word": ["shake"], "author": "mm324"}
{"word": ["Baby"], "author": "viperfdl"}
{"word": ["Puppy."], "author": "Kleetus"}
{"word": [" Nappy."], "author": "gixgox"}
{"word": ["Rash"], "author": "mm324"}
{"word": [" Puppy."], "author": "Kleetus"}
{"word": [" Ointment"], "author": "TARFU"}
{"word": ["salve"], "author": "mm324"}
{"word": ["salvation"], "author": "JDelekto"}
{"word": ["deliverance"], "author": "TARFU"}
{"word": ["birth"], "author": "JDelekto"}
{"word": ["beginning"], "author": "TARFU"}
{"word": ["again"], "author": "JDelekto"}
{"word": ["Relive"], "author": "park_84"}
{"word": ["revisit"], "author": "le_chevalier"}
{"word": ["analyse"], "author": "Dzsono"}
{"word": ["data"], "author": "Ardal"}
{"word": ["Information."], "author": "Hickory"}
{"word": ["Disclosure."], "author": "gixgox"}
{"word": ["Full"], "author": "Zoltan999"}
{"word": [], "author": "gixgox"}
{"word": ["Tackle"], "author": "VWood"}
{"word": ["Dummy"], "author": "JDelekto"}
{"word": ["mannequin"], "author": "mm324"}
{"word": ["harlequin"], "author": "JDelekto"}
{"word": ["Corny."], "author": "GhostwriterDoF"}
{"word": ["Horny"], "author": "eksasol"}
{"word": ["Toad ", " "], "author": "mm324"}
{"word": ["Frog."], "author": "Narcia_"}
{"word": ["Grog"], "author": "viperfdl"}
{"word": ["Dog."], "author": "Kleetus"}
{"word": [" salamander"], "author": "TARFU"}
{"word": ["newt"], "author": "mm324"}
{"word": ["Ellen Ripely"], "author": "Allinstein"}
{"word": ["facehuggers"], "author": "ashwald"}
{"word": ["alien"], "author": "TARFU"}
{"word": [" Crabs."], "author": "Kleetus"}
{"word": ["legs"], "author": "ashwald"}
{"word": [" walking"], "author": "TARFU"}
{"word": ["Boots"], "author": "park_84"}
{"word": ["Laces."], "author": "Hickory"}
{"word": ["aglet"], "author": "Ardal"}
{"word": ["Sheath."], "author": "Hickory"}
{"word": ["Sword."], "author": "viperfdl"}
{"word": ["Rapier."], "author": "gixgox"}
{"word": ["pointy"], "author": "ashwald"}
{"word": ["Stick."], "author": "Narcia_"}
{"word": ["club"], "author": "mm324"}
{"word": ["Fraternity"], "author": "Zoltan999"}
{"word": ["brotherhood"], "author": "mm324"}
{"word": ["Sisterhood."], "author": "GhostwriterDoF"}
{"word": ["fellowship"], "author": "le_chevalier"}
{"word": [], "author": "gixgox"}
{"word": ["Fanaticism"], "author": "Azrael360"}
{"word": ["zealot"], "author": "mm324"}
{"word": ["zealots"], "author": "TARFU"}
{"word": [" Intolerance."], "author": "Kleetus"}
{"word": [" devotees"], "author": "mm324"}
{"word": ["Intolerance."], "author": "Kleetus"}
{"word": ["acceptance"], "author": "mm324"}
{"word": [" belief"], "author": "TARFU"}
{"word": ["creed"], "author": "mm324"}
{"word": ["Intolerance."], "author": "Kleetus"}
{"word": [" Assassin's"], "author": "gixgox"}
{"word": [" Killer"], "author": "TARFU"}
{"word": ["Whales"], "author": "mm324"}
{"word": ["down"], "author": "kmonster"}
{"word": ["feeling"], "author": "le_chevalier"}
{"word": ["."], "author": "gixgox"}
{"word": [" Notion."], "author": "Kleetus"}
{"word": [" attitude"], "author": "TARFU"}
{"word": ["Notion."], "author": "Kleetus"}
{"word": [" Approach."], "author": "gixgox"}
{"word": ["Notion."], "author": "Kleetus"}
{"word": [" arrive"], "author": "Dzsono"}
{"word": ["appear"], "author": "le_chevalier"}
{"word": ["flight"], "author": "park_84"}
{"word": ["aviation"], "author": "GabesterOne"}
{"word": ["Flightsimulator."], "author": "viperfdl"}
{"word": ["Nonexistent."], "author": "Hickory"}
{"word": ["imaginary"], "author": "TARFU"}
{"word": ["unit"], "author": "BlackDawn"}
{"word": ["Quantified."], "author": "GhostwriterDoF"}
{"word": ["calculated"], "author": "mm324"}
{"word": ["operation"], "author": "park_84"}
{"word": ["function"], "author": "Dzsono"}
{"word": ["purpose"], "author": "mm324"}
{"word": ["purse"], "author": "kmonster"}
{"word": ["Empty."], "author": "gixgox"}
{"word": ["Void"], "author": "Stooner"}
{"word": ["space"], "author": "mm324"}
{"word": ["cowboy"], "author": "ashwald"}
{"word": ["Brokeback."], "author": "Kleetus"}
{"word": ["Mountain"], "author": "GandalftheCool"}
{"word": [" "], "author": "gixgox"}
{"word": [" Hill."], "author": "Kleetus"}
{"word": ["Silent"], "author": "GandalftheCool"}
{"word": ["sneaking"], "author": "ashwald"}
{"word": ["Peaking"], "author": "GandalftheCool"}
{"word": ["duck"], "author": "Dzsono"}
{"word": ["Peking."], "author": "Kleetus"}
{"word": ["Chicken"], "author": "GandalftheCool"}
{"word": ["beak"], "author": "TARFU"}
{"word": [" Poulet."], "author": "Kleetus"}
{"word": ["Lifeform."], "author": "REDVWIN"}
{"word": ["cell"], "author": "park_84"}
{"word": ["splinter"], "author": "TARFU"}
{"word": ["shard"], "author": "le_chevalier"}
{"word": ["Fragment."], "author": "Hickory"}
{"word": ["D\u00e9bris."], "author": "gixgox"}
{"word": ["Detritus"], "author": "Zoltan999"}
{"word": ["Remains"], "author": "TDP"}
{"word": ["carcass"], "author": "GabesterOne"}
{"word": ["Leftovers."], "author": "Narcia_"}
{"word": ["remains"], "author": "ashwald"}
{"word": ["corpse"], "author": "mm324"}
{"word": ["bride"], "author": "eksasol"}
{"word": ["isle"], "author": "Dzsono"}
{"word": ["Robinson."], "author": "viperfdl"}
{"word": ["helicopter ", " ", "/"], "author": "mm324"}
{"word": ["Rotor."], "author": "Hickory"}
{"word": ["Motor."], "author": "gixgox"}
{"word": ["Truck"], "author": "GandalftheCool"}
{"word": ["Driver"], "author": "mm324"}
{"word": [" Semi."], "author": "Kleetus"}
{"word": [" motorist"], "author": "TARFU"}
{"word": ["Semi."], "author": "Kleetus"}
{"word": ["pro"], "author": "kmonster"}
{"word": ["Athlete"], "author": "GandalftheCool"}
{"word": ["Me."], "author": "Tauto"}
{"word": [" sportsman"], "author": "TARFU"}
{"word": [" hunter"], "author": "mm324"}
{"word": [" deer"], "author": "TARFU"}
{"word": ["buck"], "author": "mm324"}
{"word": ["Bug."], "author": "gixgox"}
{"word": ["Volkswagen"], "author": "TARFU"}
{"word": ["German"], "author": "Dzsono"}
{"word": ["beer"], "author": "TARFU"}
{"word": [" Contestant."], "author": "Kleetus"}
{"word": [" Champagne."], "author": "gixgox"}
{"word": ["Contestant."], "author": "Kleetus"}
{"word": [" bubbles"], "author": "TARFU"}
{"word": ["Bobble"], "author": "park_84"}
{"word": ["Dragon"], "author": "PaterAlf"}
{"word": ["ninja"], "author": "Emob78"}
{"word": ["Pirate."], "author": "viperfdl"}
{"word": ["Buccaneer."], "author": "Hickory"}
{"word": ["Privateer."], "author": "viperfdl"}
{"word": ["Treasure"], "author": "Zoltan999"}
{"word": ["map"], "author": "le_chevalier"}
{"word": ["Island ", " ", " ninja'd ", " ", " helper ", " ", " nijnja'd again ", " ", " coordinates"], "author": "mm324"}
{"word": ["Direction."], "author": "Narcia_"}
{"word": ["bearing ", " ", " ", " I was ninja'd too :D"], "author": "le_chevalier"}
{"word": [" Ball ", " ", " (LOL I'm glad I'm not the only one who's slow today)"], "author": "mm324"}
{"word": ["balance"], "author": "Dzsono"}
{"word": ["Beam"], "author": "mm324"}
{"word": ["laser"], "author": "Vehdra"}
{"word": ["."], "author": "gixgox"}
{"word": ["Particle-beam."], "author": "Hickory"}
{"word": ["Photon torpedo."], "author": "codefenix"}
{"word": ["Intermingle..."], "author": "GhostwriterDoF"}
{"word": ["Conflatulation!"], "author": "eksasol"}
{"word": ["."], "author": "Hickory"}
{"word": ["disavow"], "author": "mm324"}
{"word": ["Disembowel."], "author": "codefenix"}
{"word": ["gut"], "author": "Dzsono"}
{"word": ["Blood"], "author": "GandalftheCool"}
{"word": ["gore"], "author": "mm324"}
{"word": [" Plasma."], "author": "Kleetus"}
{"word": ["Dollie."], "author": "Tauto"}
{"word": [" Bleach."], "author": "gixgox"}
{"word": ["Hypochlorite"], "author": "HisDudeness3008"}
{"word": [" Sodium"], "author": "TARFU"}
{"word": ["melodeon"], "author": "richlind33"}
{"word": ["midi-chlorian"], "author": "eksasol"}
{"word": [], "author": "gixgox"}
{"word": ["Floridian"], "author": "richlind33"}
{"word": ["^ assholes"], "author": "eksasol"}
{"word": ["Massachusetts"], "author": "TARFU"}
{"word": [" Rectums."], "author": "Kleetus"}
{"word": ["prostates"], "author": "richlind33"}
{"word": ["Glands."], "author": "Kleetus"}
{"word": ["Sweat."], "author": "codefenix"}
{"word": ["Blood."], "author": "viperfdl"}
{"word": ["tears"], "author": "mm324"}
{"word": [], "author": "Zoltan999"}
{"word": ["Crocodile ", " ", " -- ", " ", " ninja'd... ", " ", " "], "author": "park_84"}
{"word": ["Later"], "author": "mm324"}
{"word": ["Tater."], "author": "codefenix"}
{"word": ["Chip"], "author": "mm324"}
{"word": ["Chop."], "author": "codefenix"}
{"word": ["karate"], "author": "Ardal"}
{"word": ["."], "author": "eksasol"}
{"word": ["tae kwon do ", " ninja'd ", " ", " ", " belt"], "author": "mm324"}
{"word": ["Orion"], "author": "richlind33"}
{"word": ["stars"], "author": "mm324"}
{"word": ["Galaxies"], "author": "TDP"}
{"word": ["gravity"], "author": "Dzsono"}
{"word": ["Falls."], "author": "codefenix"}
{"word": ["Niagara"], "author": "mm324"}
{"word": ["Spectacle."], "author": "Hickory"}
{"word": ["sextacular"], "author": "eksasol"}
{"word": ["Spectacle."], "author": "Hickory"}
{"word": ["Breathtaking."], "author": "gixgox"}
{"word": ["Suffocation."], "author": "codefenix"}
{"word": ["constriction"], "author": "le_chevalier"}
{"word": ["Squeeze ", " ", " Edit: (firstly was here Vacuum as next word to Suffocation)"], "author": "motorkar"}
{"word": ["Hug."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["candy"], "author": "mm324"}
{"word": ["Halloween"], "author": "GabesterOne"}
{"word": ["jack-o-lantern"], "author": "mm324"}
{"word": ["Pumpkin"], "author": "TARFU"}
{"word": ["Pie"], "author": "mm324"}
{"word": ["Sky."], "author": "xieliming"}
{"word": ["Fly."], "author": "gixgox"}
{"word": ["soar"], "author": "TARFU"}
{"word": ["aloft"], "author": "le_chevalier"}
{"word": ["heightened"], "author": "Dzsono"}
{"word": ["shortened"], "author": "mm324"}
{"word": ["Brief"], "author": "park_84"}
{"word": ["case"], "author": "richlind33"}
{"word": ["silver"], "author": "ashwald"}
{"word": ["gold"], "author": "Accatone"}
{"word": ["Transmutation."], "author": "VampiroAlhazred"}
{"word": ["Magic."], "author": "viperfdl"}
{"word": ["kingdom"], "author": "Ardal"}
{"word": ["Come."], "author": "codefenix"}
{"word": ["Comely"], "author": "Zoltan999"}
{"word": ["comedy"], "author": "park_84"}
{"word": ["Tragedy."], "author": "codefenix"}
{"word": ["Armageddon."], "author": "gixgox"}
{"word": ["Apocalypse."], "author": "codefenix"}
{"word": ["aftermath"], "author": "le_chevalier"}
{"word": ["Ramification."], "author": "Hickory"}
{"word": ["fallout"], "author": "le_chevalier"}
{"word": ["devastation"], "author": "Dzsono"}
{"word": ["Apocalypse"], "author": "GandalftheCool"}
{"word": ["Judgement"], "author": "Azrael360"}
{"word": ["day"], "author": "park_84"}
{"word": ["night"], "author": "mm324"}
{"word": ["Dark"], "author": "Yezemin"}
{"word": ["Knight"], "author": "mm324"}
{"word": [" Chocolate."], "author": "Kleetus"}
{"word": [" armor"], "author": "TARFU"}
{"word": ["Plate."], "author": "Hickory"}
{"word": ["Chocolate."], "author": "Kleetus"}
{"word": [" Tableware."], "author": "gixgox"}
{"word": ["Chocolate."], "author": "Kleetus"}
{"word": [" silverware"], "author": "TARFU"}
{"word": ["Chocolate."], "author": "Kleetus"}
{"word": [" China."], "author": "gixgox"}
{"word": ["Porcelain"], "author": "Zoltan999"}
{"word": ["penicillin"], "author": "richlind33"}
{"word": ["mold"], "author": "mm324"}
{"word": ["Fungus."], "author": "Hickory"}
{"word": ["Mushroom"], "author": "codefenix"}
{"word": ["Cap"], "author": "mm324"}
{"word": ["Bonnet."], "author": "Hickory"}
{"word": ["hat"], "author": "mm324"}
{"word": ["."], "author": "Hickory"}
{"word": ["clever"], "author": "mm324"}
{"word": ["Clogs."], "author": "Narcia_"}
{"word": ["Sandals."], "author": "Hickory"}
{"word": ["boots"], "author": "mm324"}
{"word": ["Gum."], "author": "viperfdl"}
{"word": ["Chewable."], "author": "GhostwriterDoF"}
{"word": ["Food"], "author": "TARFU"}
{"word": ["Sustenance."], "author": "Hickory"}
{"word": ["Substance."], "author": "codefenix"}
{"word": ["powder"], "author": "Dzsono"}
{"word": ["chalk"], "author": "TARFU"}
{"word": ["Crayon."], "author": "Hickory"}
{"word": ["wax"], "author": "TARFU"}
{"word": ["Ear"], "author": "GandalftheCool"}
{"word": ["-plugs."], "author": "gixgox"}
{"word": ["Stopper."], "author": "Hickory"}
{"word": ["plunger"], "author": "TARFU"}
{"word": ["plumber"], "author": "toothsaber"}
{"word": ["Overcharge."], "author": "Hickory"}
{"word": ["Do-it-yourself."], "author": "gixgox"}
{"word": ["repair"], "author": "TARFU"}
{"word": ["Broken"], "author": "GandalftheCool"}
{"word": ["Heart"], "author": "mm324"}
{"word": ["Love"], "author": "GandalftheCool"}
{"word": ["Songs ", " "], "author": "mm324"}
{"word": ["music"], "author": "TARFU"}
{"word": ["Symphony"], "author": "tort1234"}
{"word": ["orchestra"], "author": "le_chevalier"}
{"word": ["Soundtrack"], "author": "park_84"}
{"word": ["Movie"], "author": "PaterAlf"}
{"word": ["Blockbuster."], "author": "viperfdl"}
{"word": ["Overhyped."], "author": "gixgox"}
{"word": ["Exaggerated."], "author": "Hickory"}
{"word": ["overrated"], "author": "le_chevalier"}
{"word": ["Disappointment"], "author": "Zoltan999"}
{"word": ["frustration"], "author": "mm324"}
{"word": ["Suicide :("], "author": "gixgox"}
{"word": ["Hope."], "author": "Narcia_"}
{"word": [], "author": "gixgox"}
{"word": ["Gloom"], "author": "TDP"}
{"word": ["Doom ", " ", " Doom"], "author": "SamMagel"}
{"word": ["Fate."], "author": "Hickory"}
{"word": ["future"], "author": "mm324"}
{"word": ["foresight"], "author": "Dzsono"}
{"word": [], "author": "gixgox"}
{"word": [" Bond"], "author": "mm324"}
{"word": ["James"], "author": "park_84"}
{"word": ["Bond"], "author": "mm324"}
{"word": ["Blonde"], "author": "SamMagel"}
{"word": ["Bombshell"], "author": "mm324"}
{"word": ["Shocking."], "author": "Hickory"}
{"word": ["electricity"], "author": "TARFU"}
{"word": ["Bill :("], "author": "mm324"}
{"word": [" Bullet ", " ", " "], "author": "TARFU"}
{"word": [" Proof"], "author": "mm324"}
{"word": ["liquor"], "author": "TARFU"}
{"word": ["beer"], "author": "mm324"}
{"word": ["Duff"], "author": "park_84"}
{"word": [" Man"], "author": "mm324"}
{"word": ["Boy"], "author": "GandalftheCool"}
{"word": ["son"], "author": "mm324"}
{"word": ["Offspring"], "author": "GandalftheCool"}
{"word": [" ", " ", " "], "author": "gixgox"}
{"word": ["Granny."], "author": "Kleetus"}
{"word": [" Beam"], "author": "TARFU"}
{"word": ["Granny."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Granny."], "author": "Kleetus"}
{"word": [" Under"], "author": "GandalftheCool"}
{"word": [], "author": "gixgox"}
{"word": ["Around"], "author": "GandalftheCool"}
{"word": [], "author": "gixgox"}
{"word": ["time"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": ["Shelob"], "author": "GandalftheCool"}
{"word": ["Spider."], "author": "gixgox"}
{"word": ["Granny."], "author": "Kleetus"}
{"word": [" scorpion"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": ["police"], "author": "park_84"}
{"word": ["brutality"], "author": "flubbucket"}
{"word": ["Fatality."], "author": "Hickory"}
{"word": ["deadly"], "author": "mm324"}
{"word": ["mortal"], "author": "park_84"}
{"word": ["Kombat"], "author": "mm324"}
{"word": [], "author": "gixgox"}
{"word": ["Sample."], "author": "Narcia_"}
{"word": ["Pack"], "author": "Zoltan999"}
{"word": [], "author": "gixgox"}
{"word": ["catacomb"], "author": "park_84"}
{"word": ["tomb"], "author": "le_chevalier"}
{"word": ["stone"], "author": "gixgox"}
{"word": ["Rock"], "author": "tort1234"}
{"word": ["Boulder"], "author": "TARFU"}
{"word": ["Dash"], "author": "ashwald"}
{"word": ["Hyphen."], "author": "gixgox"}
{"word": ["punctuation"], "author": "Dzsono"}
{"word": ["ending"], "author": "Ardal"}
{"word": ["death"], "author": "park_84"}
{"word": ["corpse"], "author": "TARFU"}
{"word": ["body"], "author": "le_chevalier"}
{"word": ["stretch"], "author": "kmonster"}
{"word": ["taffy"], "author": "TARFU"}
{"word": ["Laughy"], "author": "GandalftheCool"}
{"word": ["giggly"], "author": "mm324"}
{"word": ["Jiggly"], "author": "GandalftheCool"}
{"word": ["Puff"], "author": "mm324"}
{"word": ["Cream"], "author": "GandalftheCool"}
{"word": ["."], "author": "gixgox"}
{"word": ["snow"], "author": "le_chevalier"}
{"word": ["Flake."], "author": "xieliming"}
{"word": ["Corn"], "author": "GandalftheCool"}
{"word": ["Syrup."], "author": "gixgox"}
{"word": ["Pancakes"], "author": "GandalftheCool"}
{"word": ["Hungry..."], "author": "gixgox"}
{"word": ["Stomach"], "author": "GandalftheCool"}
{"word": ["Collywobbles."], "author": "gixgox"}
{"word": ["Cauldron"], "author": "tort1234"}
{"word": ["hag"], "author": "Dzsono"}
{"word": ["Witch"], "author": "Yezemin"}
{"word": ["pagan"], "author": "Ardal"}
{"word": ["Ultima"], "author": "park_84"}
{"word": ["Underworld."], "author": "viperfdl"}
{"word": ["Outerworld."], "author": "gixgox"}
{"word": ["Outer-space"], "author": "Narcia_"}
{"word": ["Frontier"], "author": "Zoltan999"}
{"word": ["wilderness"], "author": "mm324"}
{"word": ["Hiking."], "author": "codefenix"}
{"word": ["Trailblazer..."], "author": "GhostwriterDoF"}
{"word": ["."], "author": "gixgox"}
{"word": ["scout"], "author": "mm324"}
{"word": ["Boy"], "author": "GandalftheCool"}
{"word": ["honest"], "author": "mm324"}
{"word": ["truthful"], "author": "le_chevalier"}
{"word": ["candid"], "author": "mm324"}
{"word": ["transparent"], "author": "Dzsono"}
{"word": ["Invisible"], "author": "GandalftheCool"}
{"word": ["clear"], "author": "TARFU"}
{"word": [" Hidden."], "author": "Kleetus"}
{"word": ["Cloak"], "author": "GandalftheCool"}
{"word": ["Invisible"], "author": "doronnorod"}
{"word": ["untouchable"], "author": "le_chevalier"}
{"word": [" Limpid."], "author": "Hickory"}
{"word": ["Diaphanously."], "author": "gixgox"}
{"word": ["insubstantial"], "author": "mm324"}
{"word": ["Minor."], "author": "xieliming"}
{"word": ["major"], "author": "Treasure"}
{"word": ["Officer"], "author": "Yezemin"}
{"word": ["Sheriff"], "author": "park_84"}
{"word": ["deputy"], "author": "Ardal"}
{"word": ["Commissioner."], "author": "gixgox"}
{"word": ["Gordon"], "author": "Mr.Caine"}
{"word": [" Administrator."], "author": "Hickory"}
{"word": ["Privileges"], "author": "Zoltan999"}
{"word": ["Entitlement."], "author": "codefenix"}
{"word": ["Earnings."], "author": "Narcia_"}
{"word": ["Millennials"], "author": "eksasol"}
{"word": ["Idiots"], "author": "doronnorod"}
{"word": [" Salary."], "author": "Hickory"}
{"word": ["paycheck"], "author": "mm324"}
{"word": ["Wages."], "author": "gixgox"}
{"word": ["Dough"], "author": "GandalftheCool"}
{"word": ["Pizzaaaaaaaaaaaaaaaaaaaah!"], "author": "gixgox"}
{"word": ["Pepperoni"], "author": "GandalftheCool"}
{"word": ["Topping... :)"], "author": "GhostwriterDoF"}
{"word": ["Icing."], "author": "Hickory"}
{"word": ["cake"], "author": "mm324"}
{"word": ["Birthday"], "author": "GandalftheCool"}
{"word": ["Anniversary."], "author": "Hickory"}
{"word": ["Celebration"], "author": "Azrael360"}
{"word": ["Party"], "author": "GandalftheCool"}
{"word": ["politics"], "author": "park_84"}
{"word": ["Trump"], "author": "GandalftheCool"}
{"word": ["Dumb."], "author": "gixgox"}
{"word": [" What's with the new look and title Granny, you're kinda scaring me now?"], "author": "Kleetus"}
{"word": ["Dollie."], "author": "Tauto"}
{"word": ["Doll"], "author": "doronnorod"}
{"word": ["Kleetus."], "author": "Tauto"}
{"word": [" house"], "author": "TARFU"}
{"word": [" Rocks."], "author": "Kleetus"}
{"word": ["Woman."], "author": "Tauto"}
{"word": ["Mother."], "author": "Casval_Deikun"}
{"word": ["Madonna"], "author": "park_84"}
{"word": ["virgin"], "author": "le_chevalier"}
{"word": ["Airlines"], "author": "Zoltan999"}
{"word": ["Passenger."], "author": "Hickory"}
{"word": ["Guest."], "author": "xieliming"}
{"word": ["Quest."], "author": "codefenix"}
{"word": ["Hero."], "author": "Narcia_"}
{"word": ["character"], "author": "le_chevalier"}
{"word": ["Temperament."], "author": "Hickory"}
{"word": ["attitude"], "author": "mm324"}
{"word": ["Bossy"], "author": "GandalftheCool"}
{"word": ["Appearance."], "author": "gixgox"}
{"word": ["sister (LOLLOL)"], "author": "mm324"}
{"word": ["sibling"], "author": "SamMagel"}
{"word": ["Rivalry"], "author": "mm324"}
{"word": ["Family"], "author": "Azrael360"}
{"word": ["Guy"], "author": "mm324"}
{"word": ["inconsistent"], "author": "Dzsono"}
{"word": ["volatile"], "author": "le_chevalier"}
{"word": ["alcohol"], "author": "park_84"}
{"word": ["disinfectant"], "author": "TARFU"}
{"word": ["cleanser"], "author": "Dzsono"}
{"word": ["Soap."], "author": "gixgox"}
{"word": ["bubbles"], "author": "ashwald"}
{"word": ["speech"], "author": "le_chevalier"}
{"word": ["synthesis"], "author": "cose_vecchie"}
{"word": ["Photosynthesis."], "author": "codefenix"}
{"word": ["botany"], "author": "park_84"}
{"word": ["Bonsai."], "author": "Narcia_"}
{"word": ["dwarf"], "author": "eksasol"}
{"word": ["Nova"], "author": "mm324"}
{"word": [" ", " ", " "], "author": "gixgox"}
{"word": ["Jazz"], "author": "Zoltan999"}
{"word": ["Quartet"], "author": "mm324"}
{"word": ["."], "author": "Hickory"}
{"word": ["Datatype."], "author": "codefenix"}
{"word": ["program"], "author": "TARFU"}
{"word": ["app"], "author": "park_84"}
{"word": ["Ape."], "author": "gixgox"}
{"word": ["planet"], "author": "le_chevalier"}
{"word": ["orbit"], "author": "Dzsono"}
{"word": ["Circumgyration."], "author": "Hickory"}
{"word": ["Circumcision."], "author": "Kleetus"}
{"word": ["barbaric"], "author": "eksasol"}
{"word": ["Vikings"], "author": "GandalftheCool"}
{"word": [], "author": "gixgox"}
{"word": ["myth"], "author": "sanscript"}
{"word": ["Busters"], "author": "park_84"}
{"word": ["Ghost."], "author": "Kleetus"}
{"word": ["Rider."], "author": "viperfdl"}
{"word": ["Easy."], "author": "codefenix"}
{"word": ["Simple"], "author": "Zoltan999"}
{"word": ["Mind."], "author": "viperfdl"}
{"word": ["Body."], "author": "codefenix"}
{"word": ["Health."], "author": "viperfdl"}
{"word": ["Heart"], "author": "TDP"}
{"word": ["Cardio"], "author": "GabesterOne"}
{"word": ["Vascular."], "author": "Narcia_"}
{"word": ["Muscular."], "author": "gixgox"}
{"word": ["Popeye"], "author": "park_84"}
{"word": ["Bluto"], "author": "mm324"}
{"word": ["Blotto... :)"], "author": "GhostwriterDoF"}
{"word": [" PARTY =O"], "author": "mm324"}
{"word": ["Animal."], "author": "Hickory"}
{"word": ["Pet."], "author": "viperfdl"}
{"word": ["Hyena."], "author": "eksasol"}
{"word": ["Dogs"], "author": "doronnorod"}
{"word": ["Pirates!"], "author": "advancedhero"}
{"word": ["Pittsburgh."], "author": "codefenix"}
{"word": ["Fallout"], "author": "tlfotjak"}
{"word": ["wasteland"], "author": "mm324"}
{"word": ["Dune."], "author": "gixgox"}
{"word": ["spice"], "author": "TARFU"}
{"word": ["sugar"], "author": "kmonster"}
{"word": ["honey"], "author": "park_84"}
{"word": ["Bee."], "author": "gixgox"}
{"word": ["hive"], "author": "le_chevalier"}
{"word": ["buzz"], "author": "eksasol"}
{"word": ["Saw."], "author": "Hickory"}
{"word": ["Watched."], "author": "gixgox"}
{"word": ["timed"], "author": "Dzsono"}
{"word": ["spaced"], "author": "richlind33"}
{"word": ["Delimited."], "author": "REDVWIN"}
{"word": ["delineated"], "author": "richlind33"}
{"word": ["marked"], "author": "TARFU"}
{"word": ["tracked"], "author": "le_chevalier"}
{"word": ["drone"], "author": "sanscript"}
{"word": ["automatic"], "author": "XYCat"}
{"word": ["Manual."], "author": "viperfdl"}
{"word": ["labor"], "author": "le_chevalier"}
{"word": ["Party."], "author": "gixgox"}
{"word": ["Favor"], "author": "Zoltan999"}
{"word": ["preference"], "author": "park_84"}
{"word": ["Choice."], "author": "Hickory"}
{"word": ["Freedom"], "author": "doronnorod"}
{"word": ["Rights"], "author": "SamMagel"}
{"word": ["Rites."], "author": "gixgox"}
{"word": ["site"], "author": "Accatone"}
{"word": ["Rituals."], "author": "Hickory"}
{"word": ["sacrifice"], "author": "Ardal"}
{"word": ["Licurg"], "author": "park_84"}
{"word": ["Liturgist."], "author": "gixgox"}
{"word": ["revivalist"], "author": "mm324"}
{"word": ["Aptitude."], "author": "REDVWIN"}
{"word": [" Test"], "author": "mm324"}
{"word": ["failure"], "author": "drevo2"}
{"word": ["Disappointment."], "author": "Hickory"}
{"word": ["parenthood"], "author": "Dzsono"}
{"word": ["responsibility"], "author": "mm324"}
{"word": ["Maturity."], "author": "Hickory"}
{"word": ["wisdom"], "author": "mm324"}
{"word": ["Falacy."], "author": "Hickory"}
{"word": ["delusion"], "author": "mm324"}
{"word": ["Grandeur"], "author": "GandalftheCool"}
{"word": ["majesty"], "author": "mm324"}
{"word": ["Royals."], "author": "gixgox"}
{"word": ["king"], "author": "mm324"}
{"word": [" Splendour."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": [" lively"], "author": "mm324"}
{"word": ["Frisky."], "author": "Hickory"}
{"word": ["Risk."], "author": "Casval_Deikun"}
{"word": ["Game"], "author": "TARFU"}
{"word": ["Thrones"], "author": "Licurg"}
{"word": ["crowns"], "author": "le_chevalier"}
{"word": [], "author": "park_84"}
{"word": ["knight-clowns"], "author": "sanscript"}
{"word": ["Comedy."], "author": "Narcia_"}
{"word": ["Funny"], "author": "PaterAlf"}
{"word": [], "author": "gixgox"}
{"word": ["smelly ", " ", " ninja'd ", " ", " good-looking"], "author": "le_chevalier"}
{"word": ["handsome"], "author": "mm324"}
{"word": ["Cutie."], "author": "gixgox"}
{"word": ["beautiful"], "author": "mm324"}
{"word": ["Stunning"], "author": "Zoltan999"}
{"word": ["Shocking."], "author": "codefenix"}
{"word": ["Ghastly."], "author": "gixgox"}
{"word": ["horrible"], "author": "mm324"}
{"word": ["Disgusting"], "author": "GandalftheCool"}
{"word": ["Revolting."], "author": "Hickory"}
{"word": ["horrifying"], "author": "TARFU"}
{"word": ["Election"], "author": "tlfotjak"}
{"word": ["voting"], "author": "TARFU"}
{"word": ["Hunt-and-peck."], "author": "gixgox"}
{"word": ["finally"], "author": "kmonster"}
{"word": ["eventually"], "author": "Dzsono"}
{"word": ["ultimately"], "author": "le_chevalier"}
{"word": ["supremely"], "author": "mm324"}
{"word": ["Omnipotent."], "author": "REDVWIN"}
{"word": ["powerful"], "author": "TARFU"}
{"word": ["Colorful."], "author": "Casval_Deikun"}
{"word": ["Rainbow."], "author": "xieliming"}
{"word": ["Precipitation"], "author": "doctorsinister"}
{"word": ["rain"], "author": "TARFU"}
{"word": ["purple"], "author": "truhlik"}
{"word": ["Violet"], "author": "park_84"}
{"word": ["tint"], "author": "Ardal"}
{"word": ["colouration"], "author": "Dzsono"}
{"word": ["pigmentation"], "author": "le_chevalier"}
{"word": ["Pygmalion"], "author": "park_84"}
{"word": ["Pygmy."], "author": "codefenix"}
{"word": ["Dwarf."], "author": "Hickory"}
{"word": [" Star"], "author": "mm324"}
{"word": ["neutron"], "author": "eksasol"}
{"word": [" Jimmy"], "author": "mm324"}
{"word": ["Lockpick."], "author": "codefenix"}
{"word": ["stealth"], "author": "mm324"}
{"word": ["Fighter."], "author": "viperfdl"}
{"word": ["gladiator"], "author": "mm324"}
{"word": ["Scott"], "author": "park_84"}
{"word": ["Competitor."], "author": "Hickory"}
{"word": ["adversary"], "author": "mm324"}
{"word": ["Rival."], "author": "Narcia_"}
{"word": ["Enemy"], "author": "GandalftheCool"}
{"word": ["opponent"], "author": "TARFU"}
{"word": ["foe"], "author": "mm324"}
{"word": ["toe"], "author": "apehater"}
{"word": ["foot"], "author": "TARFU"}
{"word": ["Yard."], "author": "Hickory"}
{"word": ["lawn"], "author": "TARFU"}
{"word": ["grass"], "author": "mm324"}
{"word": ["Sod."], "author": "Hickory"}
{"word": ["soda"], "author": "park_84"}
{"word": [" pop"], "author": "mm324"}
{"word": ["music"], "author": "TARFU"}
{"word": ["Tune"], "author": "GandalftheCool"}
{"word": ["tone"], "author": "Dzsono"}
{"word": ["."], "author": "gixgox"}
{"word": ["galaxy"], "author": "TARFU"}
{"word": ["milky"], "author": "le_chevalier"}
{"word": [], "author": "gixgox"}
{"word": ["Pollen."], "author": "Hickory"}
{"word": ["Bee"], "author": "GandalftheCool"}
{"word": ["."], "author": "gixgox"}
{"word": ["Tragedy."], "author": "Hickory"}
{"word": ["comedy"], "author": "TARFU"}
{"word": ["errors"], "author": "Dzsono"}
{"word": ["Warnings"], "author": "park_84"}
{"word": ["production"], "author": "Emob78"}
{"word": ["Capacity."], "author": "viperfdl"}
{"word": ["tons"], "author": "Ardal"}
{"word": ["Weight"], "author": "PaterAlf"}
{"word": ["Mass."], "author": "Hickory"}
{"word": ["Effect."], "author": "gixgox"}
{"word": ["Cause."], "author": "Hickory"}
{"word": ["Causeway"], "author": "Zoltan999"}
{"word": [], "author": "gixgox"}
{"word": ["Stop."], "author": "Narcia_"}
{"word": ["go"], "author": "mm324"}
{"word": ["figure"], "author": "cose_vecchie"}
{"word": ["Eight."], "author": "codefenix"}
{"word": [" Ball"], "author": "mm324"}
{"word": ["."], "author": "gixgox"}
{"word": ["snake"], "author": "mm324"}
{"word": ["Bite."], "author": "Hickory"}
{"word": ["Chew."], "author": "gixgox"}
{"word": ["gum"], "author": "park_84"}
{"word": ["Ball"], "author": "GandalftheCool"}
{"word": ["Gown."], "author": "Hickory"}
{"word": ["night"], "author": "Ardal"}
{"word": ["dark"], "author": "enurbenur"}
{"word": ["alone"], "author": "park_84"}
{"word": ["home"], "author": "enurbenur"}
{"word": ["travel"], "author": "Carradice"}
{"word": ["Permit."], "author": "Hickory"}
{"word": ["passport"], "author": "TARFU"}
{"word": ["papers"], "author": "park_84"}
{"word": ["."], "author": "gixgox"}
{"word": ["tyranny"], "author": "Dzsono"}
{"word": ["oppression"], "author": "le_chevalier"}
{"word": ["socialism"], "author": "TARFU"}
{"word": ["failed"], "author": "mm324"}
{"word": ["Unfortunate."], "author": "Casval_Deikun"}
{"word": ["fortunate"], "author": "TARFU"}
{"word": ["Luck."], "author": "xieliming"}
{"word": ["Serendipity."], "author": "Hickory"}
{"word": ["fortuitousness"], "author": "Dzsono"}
{"word": ["randomness"], "author": "Ardal"}
{"word": ["chance"], "author": "le_chevalier"}
{"word": ["Coincidence."], "author": "Hickory"}
{"word": ["Happenstance."], "author": "codefenix"}
{"word": ["Americanism."], "author": "Hickory"}
{"word": ["patriotism"], "author": "mm324"}
{"word": ["flag"], "author": "park_84"}
{"word": [" pole"], "author": "mm324"}
{"word": ["Dance."], "author": "gixgox"}
{"word": ["Jig"], "author": "mm324"}
{"word": ["Jigsaw."], "author": "Narcia_"}
{"word": [], "author": "gixgox"}
{"word": ["Doom"], "author": "park_84"}
{"word": ["Quake"], "author": "Carradice"}
{"word": ["Wolfenstein"], "author": "GandalftheCool"}
{"word": ["."], "author": "codefenix"}
{"word": [], "author": "gixgox"}
{"word": ["Banal."], "author": "Hickory"}
{"word": ["Boring"], "author": "TARFU"}
{"word": ["yawn"], "author": "Dzsono"}
{"word": ["Reflex."], "author": "Hickory"}
{"word": ["cat"], "author": "le_chevalier"}
{"word": ["."], "author": "gixgox"}
{"word": ["Mathematics"], "author": "TARFU"}
{"word": ["language"], "author": "Dzsono"}
{"word": ["Communication"], "author": "park_84"}
{"word": ["Message."], "author": "Casval_Deikun"}
{"word": ["media"], "author": "le_chevalier"}
{"word": ["Outlet"], "author": "Zoltan999"}
{"word": ["Power"], "author": "mm324"}
{"word": ["Force"], "author": "Yezemin"}
{"word": ["Pressure."], "author": "Narcia_"}
{"word": [" Washer"], "author": "mm324"}
{"word": ["Dish."], "author": "codefenix"}
{"word": ["Soup."], "author": "Hickory"}
{"word": ["FOOOOOOOOOOOOOOD"], "author": "ashwald"}
{"word": ["Nourish."], "author": "GhostwriterDoF"}
{"word": ["growing"], "author": "Ardal"}
{"word": ["expanding"], "author": "mm324"}
{"word": ["Contracting."], "author": "codefenix"}
{"word": ["Shrinking."], "author": "gixgox"}
{"word": ["Shrek"], "author": "park_84"}
{"word": ["eats"], "author": "kmonster"}
{"word": ["masticates"], "author": "Dzsono"}
{"word": ["Chews"], "author": "TARFU"}
{"word": ["Edit."], "author": "Kleetus"}
{"word": ["Fix"], "author": "GandalftheCool"}
{"word": ["Patch"], "author": "Zoltan999"}
{"word": [], "author": "codefenix"}
{"word": ["doctor"], "author": "Dzsono"}
{"word": ["nurse"], "author": "mm324"}
{"word": ["care"], "author": "park_84"}
{"word": ["Palliative."], "author": "Narcia_"}
{"word": ["alleviate"], "author": "mm324"}
{"word": ["Relieve."], "author": "codefenix"}
{"word": ["relax"], "author": "mm324"}
{"word": [" Rest"], "author": "almabrds"}
{"word": [" Home"], "author": "mm324"}
{"word": ["Sweet."], "author": "gixgox"}
{"word": ["Sour."], "author": "codefenix"}
{"word": ["salty"], "author": "mm324"}
{"word": [], "author": "gixgox"}
{"word": ["hilarious"], "author": "mm324"}
{"word": ["Tattyfilarious"], "author": "Hickory"}
{"word": ["slang"], "author": "park_84"}
{"word": ["subculture"], "author": "BlackDawn"}
{"word": ["Minorities."], "author": "viperfdl"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["INCONCEIVABLE"], "author": "GandalftheCool"}
{"word": ["unthinkable"], "author": "mm324"}
{"word": ["unimaginable"], "author": "TARFU"}
{"word": ["implausible"], "author": "mm324"}
{"word": ["."], "author": "gixgox"}
{"word": ["space"], "author": "mm324"}
{"word": ["circular"], "author": "Emob78"}
{"word": ["motion"], "author": "park_84"}
{"word": ["centrifuge"], "author": "Dzsono"}
{"word": ["science"], "author": "Ardal"}
{"word": ["universe"], "author": "le_chevalier"}
{"word": ["Multiverse."], "author": "xieliming"}
{"word": ["Several"], "author": "Zoltan999"}
{"word": ["Uncountable."], "author": "gixgox"}
{"word": ["Accountant."], "author": "Narcia_"}
{"word": ["Ripoff."], "author": "Hickory"}
{"word": ["Wallet."], "author": "Carradice"}
{"word": ["Goldpouch."], "author": "viperfdl"}
{"word": ["Heavy"], "author": "Dzsono"}
{"word": ["Metal"], "author": "GandalftheCool"}
{"word": [" Thrash"], "author": "mm324"}
{"word": ["trash"], "author": "park_84"}
{"word": [" can"], "author": "mm324"}
{"word": ["tin"], "author": "Hardrada"}
{"word": ["Cup"], "author": "mm324"}
{"word": ["Coffee."], "author": "gixgox"}
{"word": ["Tea"], "author": "flubbucket"}
{"word": ["."], "author": "gixgox"}
{"word": ["Kitten"], "author": "TARFU"}
{"word": ["weak"], "author": "Dzsono"}
{"word": ["fragile"], "author": "park_84"}
{"word": ["glass."], "author": "camplify"}
{"word": [" Jar"], "author": "mm324"}
{"word": ["urn"], "author": "le_chevalier"}
{"word": ["ashes"], "author": "mm324"}
{"word": [], "author": "gixgox"}
{"word": ["Quantum."], "author": "Hickory"}
{"word": ["mechanics"], "author": "le_chevalier"}
{"word": [" Physics ", " ", " ninja'd ", " ", " ", " greasemonkeys"], "author": "mm324"}
{"word": ["."], "author": "gixgox"}
{"word": ["convenient"], "author": "mm324"}
{"word": ["handy"], "author": "TARFU"}
{"word": ["Candy."], "author": "Casval_Deikun"}
{"word": ["crush"], "author": "park_84"}
{"word": ["Orange."], "author": "Narcia_"}
{"word": ["*headache*"], "author": "ashwald"}
{"word": ["Allergy?"], "author": "Hickory"}
{"word": ["Reaction"], "author": "Zoltan999"}
{"word": ["Cause."], "author": "viperfdl"}
{"word": ["lost"], "author": "le_chevalier"}
{"word": ["Found"], "author": "GandalftheCool"}
{"word": ["discovered"], "author": "mm324"}
{"word": ["Destroyed."], "author": "gixgox"}
{"word": ["annihilate"], "author": "mm324"}
{"word": ["void"], "author": "park_84"}
{"word": ["space"], "author": "mm324"}
{"word": ["Volume."], "author": "Hickory"}
{"word": ["amplitude"], "author": "Dzsono"}
{"word": ["frequency"], "author": "TARFU"}
{"word": [" generator"], "author": "mm324"}
{"word": ["Dynamo."], "author": "gixgox"}
{"word": ["motor"], "author": "le_chevalier"}
{"word": ["Mechanic."], "author": "Hickory"}
{"word": ["automobile"], "author": "TARFU"}
{"word": ["traffic"], "author": "Ardal"}
{"word": ["motorway"], "author": "motorkar"}
{"word": ["speedway"], "author": "flubbucket"}
{"word": ["railroad"], "author": "park_84"}
{"word": ["Runway."], "author": "gixgox"}
{"word": ["Strip"], "author": "Dzsono"}
{"word": ["Poker"], "author": "Gog8"}
{"word": ["Prod."], "author": "codefenix"}
{"word": ["Cattle"], "author": "Zoltan999"}
{"word": ["Pasture."], "author": "Narcia_"}
{"word": ["Green."], "author": "viperfdl"}
{"word": ["Potion."], "author": "gixgox"}
{"word": ["mana"], "author": "Smogg"}
{"word": ["spell"], "author": "le_chevalier"}
{"word": ["Bound."], "author": "codefenix"}
{"word": ["Entrap."], "author": "GhostwriterDoF"}
{"word": ["snare"], "author": "mm324"}
{"word": ["Garrotte."], "author": "gixgox"}
{"word": ["spy"], "author": "mm324"}
{"word": ["versus"], "author": "park_84"}
{"word": [" spy ;)"], "author": "mm324"}
{"word": ["Glass."], "author": "codefenix"}
{"word": ["Wine"], "author": "GandalftheCool"}
{"word": ["Grapes."], "author": "Hickory"}
{"word": ["Sour."], "author": "codefenix"}
{"word": ["sweet"], "author": "mm324"}
{"word": ["dreams"], "author": "park_84"}
{"word": ["imagination"], "author": "TARFU"}
{"word": ["creativity"], "author": "le_chevalier"}
{"word": ["Inventiveness."], "author": "gixgox"}
{"word": ["ingenuity"], "author": "Dzsono"}
{"word": ["Science."], "author": "Casval_Deikun"}
{"word": ["empiricism"], "author": "park_84"}
{"word": ["Experience."], "author": "Hickory"}
{"word": ["Points"], "author": "Zoltan999"}
{"word": ["EDIT: numbers"], "author": "sanscript"}
{"word": ["equations"], "author": "ashwald"}
{"word": ["variables"], "author": "pokooj"}
{"word": ["Unknowns."], "author": "gixgox"}
{"word": ["Mysteries"], "author": "Gog8"}
{"word": ["Investigate."], "author": "xieliming"}
{"word": ["Police"], "author": "T.Hodd"}
{"word": ["Sting"], "author": "pokooj"}
{"word": ["Bite."], "author": "codefenix"}
{"word": [], "author": "gixgox"}
{"word": ["ash"], "author": "le_chevalier"}
{"word": ["Tree."], "author": "Narcia_"}
{"word": ["Limb"], "author": "mm324"}
{"word": ["Limbo"], "author": "pokooj"}
{"word": ["uncertain"], "author": "mm324"}
{"word": ["Waver..."], "author": "GhostwriterDoF"}
{"word": ["flip-flop"], "author": "mm324"}
{"word": ["Shoes"], "author": "GandalftheCool"}
{"word": ["noooooooo"], "author": "kmonster"}
{"word": ["Scream"], "author": "GandalftheCool"}
{"word": ["."], "author": "Hickory"}
{"word": [], "author": "codefenix"}
{"word": ["donkey"], "author": "park_84"}
{"word": ["Ass"], "author": "GandalftheCool"}
{"word": ["Fool."], "author": "Hickory"}
{"word": ["stupid"], "author": "camplify"}
{"word": ["gypsy"], "author": "apehater"}
{"word": [" Cow. ", " ", " <a long time ago I called my teacher a stupid cow... deservedly>"], "author": "gixgox"}
{"word": ["milk"], "author": "le_chevalier"}
{"word": ["Cereal"], "author": "TARFU"}
{"word": ["Spoon"], "author": "mm324"}
{"word": ["soup"], "author": "TARFU"}
{"word": [" bowl"], "author": "mm324"}
{"word": ["Cup."], "author": "xieliming"}
{"word": ["Tea"], "author": "mm324"}
{"word": ["... ninja'd again.. ", " ", " Leaves."], "author": "gixgox"}
{"word": ["Coffee"], "author": "tort1234"}
{"word": ["java"], "author": "le_chevalier"}
{"word": [" script"], "author": "mm324"}
{"word": ["Cursive."], "author": "Hickory"}
{"word": ["expletive"], "author": "Dzsono"}
{"word": ["Explosive"], "author": "park_84"}
{"word": ["Diarrhoea."], "author": "viperfdl"}
{"word": ["runny"], "author": "Ardal"}
{"word": ["Nose."], "author": "Hickory"}
{"word": ["Stinky"], "author": "gixgox"}
{"word": ["Skunk"], "author": "Zoltan999"}
{"word": ["Stripe."], "author": "codefenix"}
{"word": ["Chevron."], "author": "Hickory"}
{"word": ["Check."], "author": "Narcia_"}
{"word": ["Mate."], "author": "codefenix"}
{"word": ["friend"], "author": "mm324"}
{"word": ["Foe."], "author": "gixgox"}
{"word": ["Enemy"], "author": "SupinicHatesMe"}
{"word": [" Mine"], "author": "mm324"}
{"word": ["ownership"], "author": "nativemexican"}
{"word": ["possession"], "author": "mm324"}
{"word": ["Have"], "author": "GandalftheCool"}
{"word": ["wealthy"], "author": "mm324"}
{"word": ["Millionaire"], "author": "GandalftheCool"}
{"word": ["Billionaire"], "author": "TARFU"}
{"word": ["Trillionaire"], "author": "GandalftheCool"}
{"word": ["zillionaire"], "author": "park_84"}
{"word": ["Capitalist."], "author": "gixgox"}
{"word": ["Greedy."], "author": "Hickory"}
{"word": ["Filthy."], "author": "gixgox"}
{"word": ["Rich"], "author": "GandalftheCool"}
{"word": ["wealthy"], "author": "le_chevalier"}
{"word": ["Opulent."], "author": "Hickory"}
{"word": ["luxurious"], "author": "camplify"}
{"word": ["Extravagant"], "author": "TARFU"}
{"word": ["Uncommon."], "author": "REDVWIN"}
{"word": ["Rare."], "author": "LoboBlanco"}
{"word": [], "author": "gixgox"}
{"word": ["Ground."], "author": "Hickory"}
{"word": ["pepper"], "author": "Dzsono"}
{"word": [], "author": "Zoltan999"}
{"word": ["Drill."], "author": "Hickory"}
{"word": ["Oil"], "author": "Yezemin"}
{"word": ["Slick."], "author": "Hickory"}
{"word": ["Nickname."], "author": "Narcia_"}
{"word": ["Alias."], "author": "codefenix"}
{"word": ["anti-aliasing"], "author": "le_chevalier"}
{"word": ["options"], "author": "Ardal"}
{"word": ["Settings."], "author": "codefenix"}
{"word": ["Environs."], "author": "Hickory"}
{"word": ["surroundings"], "author": "mm324"}
{"word": ["environment"], "author": "camplify"}
{"word": ["atmosphere"], "author": "mm324"}
{"word": ["hot"], "author": "kmonster"}
{"word": ["cold"], "author": "mm324"}
{"word": ["Warm"], "author": "GandalftheCool"}
{"word": ["cool"], "author": "mm324"}
{"word": ["tepid"], "author": "le_chevalier"}
{"word": ["intrepid"], "author": "park_84"}
{"word": ["spaceship"], "author": "mm324"}
{"word": ["Space-trip."], "author": "gixgox"}
{"word": ["catapult"], "author": "Dzsono"}
{"word": ["Trebuchet"], "author": "GandalftheCool"}
{"word": ["Onager"], "author": "TARFU"}
{"word": ["mangonel"], "author": "le_chevalier"}
{"word": ["Artillery."], "author": "Hickory"}
{"word": ["Shell"], "author": "Zoltan999"}
{"word": ["fish"], "author": "gixgox"}
{"word": ["Broiled."], "author": "Narcia_"}
{"word": ["fried"], "author": "mm324"}
{"word": ["Incinerated."], "author": "gixgox"}
{"word": ["garbage"], "author": "ashwald"}
{"word": ["goggers!"], "author": "comboplayer"}
{"word": [" Trash"], "author": "Yezemin"}
{"word": [" Disposal. ", " ", " "], "author": "gixgox"}
{"word": ["discard"], "author": "mm324"}
{"word": ["Reject."], "author": "Hickory"}
{"word": ["castoff"], "author": "mm324"}
{"word": ["loser"], "author": "camplify"}
{"word": ["match"], "author": "Ardal"}
{"word": ["Strike."], "author": "Hickory"}
{"word": ["union"], "author": "mm324"}
{"word": ["Jack."], "author": "gixgox"}
{"word": [" Black"], "author": "mm324"}
{"word": ["Dark"], "author": "GandalftheCool"}
{"word": ["Ethereal"], "author": "Dzsono"}
{"word": ["ephemeral"], "author": "TARFU"}
{"word": ["eternal"], "author": "le_chevalier"}
{"word": ["Everlasting"], "author": "GandalftheCool"}
{"word": ["forever"], "author": "camplify"}
{"word": ["Endless."], "author": "Hickory"}
{"word": ["Never-ending"], "author": "park_84"}
{"word": ["story"], "author": "Ardal"}
{"word": ["Book."], "author": "Narcia_"}
{"word": [], "author": "gixgox"}
{"word": ["[Hard to associate fictional names.] ", " ", " Tome."], "author": "Hickory"}
{"word": ["scholar"], "author": "mm324"}
{"word": ["Erudite"], "author": "park_84"}
{"word": ["Polymath"], "author": "sanscript"}
{"word": ["know-it-all"], "author": "mm324"}
{"word": ["Omnipotent"], "author": "tort1234"}
{"word": ["omnipresent"], "author": "mm324"}
{"word": ["Omnibus."], "author": "gixgox"}
{"word": ["Encompassing"], "author": "TARFU"}
{"word": ["surrounding"], "author": "mm324"}
{"word": ["Wreathed."], "author": "Hickory"}
{"word": ["encircled"], "author": "le_chevalier"}
{"word": ["Encompassed."], "author": "LoboBlanco"}
{"word": ["Contained."], "author": "Hickory"}
{"word": ["restricted"], "author": "Dzsono"}
{"word": ["Area."], "author": "gixgox"}
{"word": ["zone"], "author": "park_84"}
{"word": ["Quadrant."], "author": "Narcia_"}
{"word": ["Space"], "author": "clisair"}
{"word": ["empty"], "author": "le_chevalier"}
{"word": ["Wallet."], "author": "gixgox"}
{"word": [" Leather"], "author": "mm324"}
{"word": ["Crocodile."], "author": "gixgox"}
{"word": [" Tears."], "author": "mm324"}
{"word": [], "author": "gixgox"}
{"word": ["nostalgia :)"], "author": "mm324"}
{"word": ["memories"], "author": "Madshaker"}
{"word": ["photographs"], "author": "mm324"}
{"word": ["Selfies."], "author": "gixgox"}
{"word": [" Stick."], "author": "mm324"}
{"word": [" ", "."], "author": "gixgox"}
{"word": ["[Ninja'd] ", " ", " Number."], "author": "Hickory"}
{"word": ["digit"], "author": "mm324"}
{"word": ["input"], "author": "ToasterBox"}
{"word": ["output"], "author": "mm324"}
{"word": [], "author": "gixgox"}
{"word": ["Hole"], "author": "GandalftheCool"}
{"word": [" Black"], "author": "mm324"}
{"word": ["white"], "author": "park_84"}
{"word": [" Snow"], "author": "mm324"}
{"word": ["Water"], "author": "SamMagel"}
{"word": ["Fire"], "author": "tort1234"}
{"word": ["Earth"], "author": "doctorsinister"}
{"word": ["rinse"], "author": "Dzsono"}
{"word": ["Air"], "author": "doronnorod"}
{"word": ["Oxygen"], "author": "GandalftheCool"}
{"word": ["Nitrogen"], "author": "TARFU"}
{"word": ["gaseous"], "author": "Ardal"}
{"word": ["Air"], "author": "LesterKnight99"}
{"word": ["flight"], "author": "le_chevalier"}
{"word": ["soar"], "author": "mm324"}
{"word": ["Glide."], "author": "Hickory"}
{"word": ["float"], "author": "mm324"}
{"word": ["levitate"], "author": "coryrj1995"}
{"word": ["suspend"], "author": "TARFU"}
{"word": ["hang"], "author": "mm324"}
{"word": ["Die."], "author": "xieliming"}
{"word": ["dye"], "author": "Dzsono"}
{"word": ["Color"], "author": "park_84"}
{"word": ["crayon"], "author": "mm324"}
{"word": ["Wax."], "author": "Hickory"}
{"word": ["Wane"], "author": "Hardrada"}
{"word": ["Wayne."], "author": "viperfdl"}
{"word": ["Ebb."], "author": "Hickory"}
{"word": ["flow"], "author": "ashwald"}
{"word": ["Aunt."], "author": "codefenix"}
{"word": ["uncle"], "author": "mm324"}
{"word": ["Beard."], "author": "Narcia_"}
{"word": ["moustache"], "author": "mm324"}
{"word": ["Villain"], "author": "Yezemin"}
{"word": [" Magneto"], "author": "mm324"}
{"word": ["(edit: ninja'd) ", " ", " ", "."], "author": "codefenix"}
{"word": ["magnetic"], "author": "mm324"}
{"word": ["electricity"], "author": "le_chevalier"}
{"word": [" Bzzt!"], "author": "almabrds"}
{"word": ["Zap!"], "author": "codefenix"}
{"word": ["Destroy."], "author": "Hickory"}
{"word": ["Shorted."], "author": "gixgox"}
{"word": ["Circuit"], "author": "GandalftheCool"}
{"word": ["loop"], "author": "TARFU"}
{"word": ["Hole"], "author": "doronnorod"}
{"word": ["hoop ", " ninja'd ", " ", " pole"], "author": "mm324"}
{"word": ["fishing"], "author": "TARFU"}
{"word": ["hook"], "author": "mm324"}
{"word": ["line"], "author": "TARFU"}
{"word": ["(and) sinker"], "author": "mm324"}
{"word": ["Anchor"], "author": "TDP"}
{"word": ["Mooring."], "author": "Hickory"}
{"word": ["pier"], "author": "TARFU"}
{"word": ["wharf"], "author": "Dzsono"}
{"word": ["landing"], "author": "le_chevalier"}
{"word": ["Haven."], "author": "Hickory"}
{"word": ["refuge"], "author": "TARFU"}
{"word": ["Outcast."], "author": "REDVWIN"}
{"word": ["Shunned"], "author": "GandalftheCool"}
{"word": ["Pariah."], "author": "Hickory"}
{"word": ["Maverick."], "author": "gixgox"}
{"word": [" Unorthodox."], "author": "almabrds"}
{"word": ["impalpable"], "author": "sanscript"}
{"word": ["untouchable"], "author": "park_84"}
{"word": ["tactile"], "author": "Ardal"}
{"word": ["visual"], "author": "mm324"}
{"word": ["Audible."], "author": "Narcia_"}
{"word": ["olfactory"], "author": "mm324"}
{"word": ["Refractory."], "author": "codefenix"}
{"word": ["prismatic"], "author": "Dzsono"}
{"word": ["multihued"], "author": "mm324"}
{"word": ["Colorful"], "author": "TARFU"}
{"word": ["rainbow"], "author": "park_84"}
{"word": ["Colors"], "author": "doronnorod"}
{"word": ["Paint"], "author": "TARFU"}
{"word": ["Thinner."], "author": "Hickory"}
{"word": [" ", " ", " ", " <sorry Ninja...> ", " ", " Sniffing."], "author": "gixgox"}
{"word": ["ill"], "author": "Dzsono"}
{"word": ["sick"], "author": "mm324"}
{"word": ["Viral"], "author": "almabrds"}
{"word": ["infection"], "author": "mm324"}
{"word": ["contagion"], "author": "le_chevalier"}
{"word": ["."], "author": "gixgox"}
{"word": ["Epidemic."], "author": "Hickory"}
{"word": ["illness"], "author": "camplify"}
{"word": ["fever"], "author": "park_84"}
{"word": ["Yellow."], "author": "xieliming"}
{"word": ["Pus."], "author": "viperfdl"}
{"word": ["Infection"], "author": "Zoltan999"}
{"word": ["disease"], "author": "mm324"}
{"word": ["Deceased."], "author": "codefenix"}
{"word": ["defunct"], "author": "mm324"}
{"word": ["Braindead,"], "author": "gixgox"}
{"word": ["Expired."], "author": "Hickory"}
{"word": ["Spoiled."], "author": "codefenix"}
{"word": ["Milk."], "author": "Narcia_"}
{"word": ["Cream."], "author": "REDVWIN"}
{"word": ["butter"], "author": "mm324"}
{"word": ["Bread."], "author": "codefenix"}
{"word": ["Bun."], "author": "gixgox"}
{"word": ["Oven"], "author": "Ultimatum"}
{"word": ["Stove"], "author": "GandalftheCool"}
{"word": ["oven"], "author": "mm324"}
{"word": ["fresh"], "author": "le_chevalier"}
{"word": ["clean"], "author": "mm324"}
{"word": ["Mr."], "author": "GandalftheCool"}
{"word": ["smith"], "author": "BlackDawn"}
{"word": ["Jones"], "author": "GandalftheCool"}
{"word": [" Osmosis"], "author": "mm324"}
{"word": ["membrane"], "author": "TARFU"}
{"word": [" Insane (in the)"], "author": "mm324"}
{"word": ["crazy"], "author": "TARFU"}
{"word": ["Psycho"], "author": "GandalftheCool"}
{"word": ["demented ", " ", " ninja'd but it works"], "author": "mm324"}
{"word": ["Unhinged"], "author": "almabrds"}
{"word": ["loon"], "author": "le_chevalier"}
{"word": ["Moon"], "author": "doronnorod"}
{"word": ["pale"], "author": "park_84"}
{"word": ["pail"], "author": "Dzsono"}
{"word": ["Well."], "author": "codefenix"}
{"word": ["Water"], "author": "Zoltan999"}
{"word": ["Drench."], "author": "GhostwriterDoF"}
{"word": ["Trench."], "author": "codefenix"}
{"word": ["coat"], "author": "ashwald"}
{"word": ["hat"], "author": "mm324"}
{"word": [" "], "author": "almabrds"}
{"word": [" Evil (valve/steam) :P"], "author": "mm324"}
{"word": ["Enemy."], "author": "Narcia_"}
{"word": ["opponent"], "author": "mm324"}
{"word": ["adversary"], "author": "le_chevalier"}
{"word": ["Foe."], "author": "gixgox"}
{"word": ["antagonist"], "author": "mm324"}
{"word": ["rival"], "author": "GabesterOne"}
{"word": ["Competition"], "author": "Zoltan999"}
{"word": ["league"], "author": "Dzsono"}
{"word": ["Team"], "author": "TARFU"}
{"word": ["Spirit."], "author": "Hickory"}
{"word": ["spectre"], "author": "le_chevalier"}
{"word": ["Spectate"], "author": "coryrj1995"}
{"word": ["Watch"], "author": "Cavenagh"}
{"word": ["Observe."], "author": "gixgox"}
{"word": ["Espy."], "author": "Hickory"}
{"word": ["Spy"], "author": "park_84"}
{"word": ["glass"], "author": "gixgox"}
{"word": ["cannon"], "author": "le_chevalier"}
{"word": ["ball"], "author": "mm324"}
{"word": ["Bag."], "author": "codefenix"}
{"word": ["sack"], "author": "mm324"}
{"word": ["Pillage"], "author": "Zoltan999"}
{"word": ["Plunder"], "author": "Yezemin"}
{"word": ["booty"], "author": "mm324"}
{"word": ["Loot."], "author": "gixgox"}
{"word": ["pirate"], "author": "mm324"}
{"word": ["treasure"], "author": "camplify"}
{"word": ["gold"], "author": "mm324"}
{"word": ["Finger"], "author": "Cavenagh"}
{"word": ["Print."], "author": "gixgox"}
{"word": ["type"], "author": "mm324"}
{"word": ["writer"], "author": "TARFU"}
{"word": ["paperback"], "author": "Dzsono"}
{"word": ["novel"], "author": "TARFU"}
{"word": ["fresh"], "author": "mm324"}
{"word": ["prince"], "author": "park_84"}
{"word": ["persia"], "author": "truhlik"}
{"word": ["Sands"], "author": "tort1234"}
{"word": ["Time"], "author": "le_chevalier"}
{"word": ["epoch"], "author": "TARFU"}
{"word": ["space"], "author": "Plasmablaster"}
{"word": [" Ace"], "author": "mm324"}
{"word": ["... craft ", " ", " ", " ", " Spades."], "author": "gixgox"}
{"word": ["clubs"], "author": "mm324"}
{"word": ["Golf."], "author": "Hickory"}
{"word": ["tee"], "author": "mm324"}
{"word": [], "author": "gixgox"}
{"word": ["flag"], "author": "mm324"}
{"word": ["Wilt."], "author": "Hickory"}
{"word": ["Wither"], "author": "GandalftheCool"}
{"word": ["die"], "author": "mm324"}
{"word": ["Deceased"], "author": "GandalftheCool"}
{"word": ["decayed"], "author": "Dzsono"}
{"word": ["rotted"], "author": "park_84"}
{"word": ["decomposed"], "author": "le_chevalier"}
{"word": ["compost"], "author": "mm324"}
{"word": ["Garden."], "author": "Narcia_"}
{"word": ["Eden."], "author": "gixgox"}
{"word": ["serpent"], "author": "mm324"}
{"word": ["Lucifer."], "author": "viperfdl"}
{"word": ["hell"], "author": "mm324"}
{"word": ["Superstition."], "author": "Hickory"}
{"word": ["Rider. ", " ", " ", " ", " ", " Cult."], "author": "gixgox"}
{"word": ["Fiction."], "author": "Hickory"}
{"word": ["Fabricate."], "author": "GhostwriterDoF"}
{"word": [], "author": "gixgox"}
{"word": ["juggling"], "author": "GabesterOne"}
{"word": ["Balls."], "author": "viperfdl"}
{"word": ["steel"], "author": "park_84"}
{"word": ["Alloy."], "author": "Hickory"}
{"word": ["Amalgam"], "author": "almabrds"}
{"word": ["blender"], "author": "camplify"}
{"word": ["mixer"], "author": "le_chevalier"}
{"word": [" cement"], "author": "mm324"}
{"word": ["Glue"], "author": "TARFU"}
{"word": ["Less ^"], "author": "Tauto"}
{"word": [" Super"], "author": "mm324"}
{"word": ["Hero"], "author": "GandalftheCool"}
{"word": [" sandwich"], "author": "mm324"}
{"word": ["Ham"], "author": "GandalftheCool"}
{"word": ["hamburger"], "author": "le_chevalier"}
{"word": [" bun"], "author": "mm324"}
{"word": ["Oven."], "author": "Hickory"}
{"word": ["burner"], "author": "mm324"}
{"word": ["Kettle"], "author": "GandalftheCool"}
{"word": [" Tea"], "author": "mm324"}
{"word": ["Pot"], "author": "GandalftheCool"}
{"word": ["buzz ;)"], "author": "mm324"}
{"word": ["Bee"], "author": "GandalftheCool"}
{"word": [" hive"], "author": "mm324"}
{"word": ["Activity."], "author": "Hickory"}
{"word": ["five"], "author": "gixgox"}
{"word": [" High"], "author": "mm324"}
{"word": ["Stoned."], "author": "gixgox"}
{"word": ["wasted"], "author": "mm324"}
{"word": ["intoxicated"], "author": "le_chevalier"}
{"word": ["Sedated."], "author": "viperfdl"}
{"word": ["Restrained"], "author": "Zoltan999"}
{"word": ["Narcotised."], "author": "gixgox"}
{"word": ["sedative"], "author": "mm324"}
{"word": ["tranquilliser"], "author": "Cavenagh"}
{"word": [" dart"], "author": "mm324"}
{"word": ["art"], "author": "Accatone"}
{"word": ["painting"], "author": "mm324"}
{"word": ["Print."], "author": "gixgox"}
{"word": ["toner"], "author": "Ardal"}
{"word": ["ink"], "author": "mm324"}
{"word": ["jet"], "author": "le_chevalier"}
{"word": ["pack"], "author": "enurbenur"}
{"word": ["rat"], "author": "mm324"}
{"word": ["rodent"], "author": "enurbenur"}
{"word": ["Incisor."], "author": "Hickory"}
{"word": ["pair"], "author": "kmonster"}
{"word": ["shoes"], "author": "mm324"}
{"word": ["heels"], "author": "ashwald"}
{"word": ["laces"], "author": "mm324"}
{"word": ["Frills."], "author": "Hickory"}
{"word": ["ruffled"], "author": "TARFU"}
{"word": ["Feathers"], "author": "GandalftheCool"}
{"word": ["Eiderdown."], "author": "Hickory"}
{"word": ["stuffing"], "author": "mm324"}
{"word": ["dressing"], "author": "TARFU"}
{"word": ["Salad ", " "], "author": "mm324"}
{"word": ["toss"], "author": "camplify"}
{"word": [" across"], "author": "mm324"}
{"word": ["."], "author": "gixgox"}
{"word": ["Deep"], "author": "park_84"}
{"word": ["music"], "author": "Bass47"}
{"word": ["rhythm"], "author": "Dzsono"}
{"word": ["Drums."], "author": "viperfdl"}
{"word": ["War"], "author": "cose_vecchie"}
{"word": ["Child"], "author": "Rinsvind"}
{"word": ["Kid"], "author": "Accatone"}
{"word": ["Baby."], "author": "xieliming"}
{"word": ["Progeny"], "author": "Zoltan999"}
{"word": ["Merchandise"], "author": "sanscript"}
{"word": ["Goods."], "author": "Narcia_"}
{"word": ["products"], "author": "mm324"}
{"word": ["Produce"], "author": "Yezemin"}
{"word": ["vegetables"], "author": "mm324"}
{"word": ["Ecological."], "author": "gixgox"}
{"word": ["Illogical."], "author": "codefenix"}
{"word": ["reasonless"], "author": "mm324"}
{"word": ["Senseless."], "author": "Hickory"}
{"word": ["Mess"], "author": "almabrds"}
{"word": ["trash"], "author": "mm324"}
{"word": ["garbage"], "author": "GabesterOne"}
{"word": ["waste"], "author": "mm324"}
{"word": ["Bin."], "author": "gixgox"}
{"word": [" Storage"], "author": "mm324"}
{"word": ["Chest"], "author": "koima57"}
{"word": ["lock"], "author": "mm324"}
{"word": ["Key"], "author": "GandalftheCool"}
{"word": [" West"], "author": "mm324"}
{"word": ["Kanye"], "author": "GandalftheCool"}
{"word": ["Kim"], "author": "mm324"}
{"word": ["Kardashian"], "author": "GandalftheCool"}
{"word": ["Trashy ;D"], "author": "mm324"}
{"word": ["bin"], "author": "kmonster"}
{"word": ["container"], "author": "TARFU"}
{"word": ["locker"], "author": "le_chevalier"}
{"word": ["squeezed"], "author": "ToasterBox"}
{"word": ["Juice."], "author": "gixgox"}
{"word": ["orange"], "author": "TARFU"}
{"word": ["Fruit"], "author": "GandalftheCool"}
{"word": ["salad"], "author": "Dzsono"}
{"word": ["Green"], "author": "Yezemin"}
{"word": ["beret"], "author": "park_84"}
{"word": ["Cap."], "author": "Hickory"}
{"word": ["Capital"], "author": "Zoltan999"}
{"word": ["wasteland"], "author": "ashwald"}
{"word": ["landwaste"], "author": "apehater"}
{"word": ["Dump."], "author": "Narcia_"}
{"word": ["Reject."], "author": "codefenix"}
{"word": ["outcast"], "author": "Accatone"}
{"word": ["Castaway."], "author": "gixgox"}
{"word": ["shipwreck"], "author": "mm324"}
{"word": ["."], "author": "codefenix"}
{"word": ["Venture"], "author": "mm324"}
{"word": ["Forth"], "author": "GandalftheCool"}
{"word": ["onward"], "author": "mm324"}
{"word": ["Advance."], "author": "Hickory"}
{"word": ["charge"], "author": "mm324"}
{"word": ["Fencing"], "author": "park_84"}
{"word": ["Rapier"], "author": "GandalftheCool"}
{"word": ["wit"], "author": "le_chevalier"}
{"word": ["Humor"], "author": "GandalftheCool"}
{"word": ["laughter"], "author": "mm324"}
{"word": ["Funny"], "author": "GandalftheCool"}
{"word": ["bone"], "author": "mm324"}
{"word": ["marrow"], "author": "Dzsono"}
{"word": ["china"], "author": "gixgox"}
{"word": ["Russia"], "author": "GandalftheCool"}
{"word": ["Ukraine"], "author": "TARFU"}
{"word": ["Suriname"], "author": "almabrds"}
{"word": ["Nation."], "author": "Hickory"}
{"word": ["Union."], "author": "chibi23"}
{"word": ["Confederate"], "author": "Zoltan999"}
{"word": ["Accomplice."], "author": "Hickory"}
{"word": ["lackey"], "author": "mm324"}
{"word": ["Stooge."], "author": "Narcia_"}
{"word": ["Curly"], "author": "mm324"}
{"word": ["hair"], "author": "Accatone"}
{"word": ["Style."], "author": "Hickory"}
{"word": ["Fashion."], "author": "gixgox"}
{"word": ["fad"], "author": "mm324"}
{"word": ["Trend."], "author": "codefenix"}
{"word": ["prediction"], "author": "Ardal"}
{"word": ["Seer."], "author": "Hickory"}
{"word": ["Blind"], "author": "Licurg"}
{"word": ["spot"], "author": "park_84"}
{"word": ["spy"], "author": "kmonster"}
{"word": ["Stealth"], "author": "GandalftheCool"}
{"word": ["sneaky"], "author": "le_chevalier"}
{"word": [], "author": "gixgox"}
{"word": ["Shadows"], "author": "TARFU"}
{"word": ["Thief"], "author": "GandalftheCool"}
{"word": ["Larceny."], "author": "Hickory"}
{"word": ["grand"], "author": "Dzsono"}
{"word": ["thousand"], "author": "camplify"}
{"word": ["kilo"], "author": "le_chevalier"}
{"word": ["Metric."], "author": "Hickory"}
{"word": ["international"], "author": "le_chevalier"}
{"word": ["national"], "author": "Accatone"}
{"word": ["Pride"], "author": "Zoltan999"}
{"word": ["Lions."], "author": "Hickory"}
{"word": ["Africa"], "author": "Yezemin"}
{"word": ["Nile"], "author": "mm324"}
{"word": ["River."], "author": "codefenix"}
{"word": ["pond"], "author": "mm324"}
{"word": ["Series"], "author": "almabrds"}
{"word": ["Continuation..."], "author": "GhostwriterDoF"}
{"word": ["ongoing"], "author": "mm324"}
{"word": ["running"], "author": "park_84"}
{"word": ["jogging"], "author": "mm324"}
{"word": ["sweat"], "author": "xemmy"}
{"word": ["odor"], "author": "mm324"}
{"word": ["body"], "author": "clisair"}
{"word": ["Dead"], "author": "almabrds"}
{"word": ["Walking ", " "], "author": "mm324"}
{"word": ["."], "author": "gixgox"}
{"word": ["Drydrowning"], "author": "sanscript"}
{"word": ["what?"], "author": "ashwald"}
{"word": ["Question"], "author": "Azrael360"}
{"word": [" "], "author": "gixgox"}
{"word": ["Set..."], "author": "flubbucket"}
{"word": ["... go !"], "author": "kmonster"}
{"word": ["Finish"], "author": "SamMagel"}
{"word": ["End"], "author": "park_84"}
{"word": ["Restart."], "author": "gixgox"}
{"word": ["Beginning"], "author": "almabrds"}
{"word": ["introduction"], "author": "le_chevalier"}
{"word": ["greeting"], "author": "Dzsono"}
{"word": ["Card"], "author": "GandalftheCool"}
{"word": ["Poker"], "author": "TARFU"}
{"word": ["Hands."], "author": "gixgox"}
{"word": ["arms"], "author": "le_chevalier"}
{"word": ["Weapons."], "author": "gixgox"}
{"word": ["knives"], "author": "mm324"}
{"word": ["Let's keep it CIVIL."], "author": "Tauto"}
{"word": [" Cutlery."], "author": "Hickory"}
{"word": ["Restaurant"], "author": "almabrds"}
{"word": ["cuisine"], "author": "park_84"}
{"word": ["Fine"], "author": "Zoltan999"}
{"word": ["Divine."], "author": "codefenix"}
{"word": ["wine"], "author": "Accatone"}
{"word": ["Heavenly. ", " >hi,soccer ninja< ", " ", " Barrel."], "author": "gixgox"}
{"word": ["Keg."], "author": "Narcia_"}
{"word": ["Pony."], "author": "codefenix"}
{"word": ["Magical?"], "author": "almabrds"}
{"word": ["enchantment"], "author": "mm324"}
{"word": ["Illusion."], "author": "Hickory"}
{"word": ["confabulation"], "author": "Dzsono"}
{"word": ["discuss"], "author": "mm324"}
{"word": ["Discus."], "author": "Hickory"}
{"word": ["Discobolus"], "author": "truhlik"}
{"word": ["Myron."], "author": "VampiroAlhazred"}
{"word": ["Sculptor."], "author": "Hickory"}
{"word": ["marble"], "author": "mm324"}
{"word": ["Madness"], "author": "toxicTom"}
{"word": ["Suggs"], "author": "Cavenagh"}
{"word": ["What?"], "author": "toxicTom"}
{"word": ["exactly"], "author": "le_chevalier"}
{"word": ["Off-key."], "author": "gixgox"}
{"word": ["harmonic"], "author": "Dzsono"}
{"word": ["melodic"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": ["TON"], "author": "almabrds"}
{"word": [" ", ". ", " ", " Tonne."], "author": "Hickory"}
{"word": ["tune"], "author": "park_84"}
{"word": ["whistle"], "author": "ashwald"}
{"word": ["dog (dog whistle)"], "author": "xemmy"}
{"word": ["Buoy. ", " <may new users ninja me?> ", " ", " (Dog-) Ear."], "author": "gixgox"}
{"word": ["hearing"], "author": "Ardal"}
{"word": [" Aids"], "author": "kinofhera"}
{"word": ["A\u0336u\u0336r\u0336a\u0336l\u0336 [Ninja'd] ", " ", " Supports."], "author": "Hickory"}
{"word": ["I-beam."], "author": "Narcia_"}
{"word": ["metal"], "author": "park_84"}
{"word": ["."], "author": "codefenix"}
{"word": ["Ape."], "author": "Hickory"}
{"word": ["Great"], "author": "Zoltan999"}
{"word": ["Magnificent"], "author": "GandalftheCool"}
{"word": [" Seven"], "author": "kinofhera"}
{"word": ["Sins."], "author": "gixgox"}
{"word": ["Lust"], "author": "mm324"}
{"word": ["Love"], "author": "tort1234"}
{"word": ["Heart"], "author": "GandalftheCool"}
{"word": ["feelings"], "author": "mm324"}
{"word": ["Emotions."], "author": "Hickory"}
{"word": ["Happiness"], "author": "mm324"}
{"word": ["bliss"], "author": "Accatone"}
{"word": ["joy"], "author": "park_84"}
{"word": ["Beer"], "author": "chibi23"}
{"word": ["Whiskey"], "author": "GandalftheCool"}
{"word": ["Tango"], "author": "ashwald"}
{"word": ["Foxtrot"], "author": "mm324"}
{"word": [" dance"], "author": "TARFU"}
{"word": ["Floor"], "author": "GandalftheCool"}
{"word": ["elevator"], "author": "TARFU"}
{"word": [" music"], "author": "mm324"}
{"word": ["Download,"], "author": "gixgox"}
{"word": ["games"], "author": "mm324"}
{"word": ["gone"], "author": "kmonster"}
{"word": ["Home"], "author": "GandalftheCool"}
{"word": ["."], "author": "gixgox"}
{"word": ["Alleviated."], "author": "REDVWIN"}
{"word": ["High"], "author": "Madshaker"}
{"word": ["above"], "author": "le_chevalier"}
{"word": ["Below"], "author": "park_84"}
{"word": ["Underneath."], "author": "Hickory"}
{"word": ["Surface."], "author": "chibi23"}
{"word": ["tension"], "author": "XYCat"}
{"word": ["tense"], "author": "Accatone"}
{"word": ["past"], "author": "ashwald"}
{"word": ["Future."], "author": "gixgox"}
{"word": ["Proof."], "author": "Hickory"}
{"word": [" Bullet"], "author": "kinofhera"}
{"word": ["Hole."], "author": "Narcia_"}
{"word": [" Hell."], "author": "gixgox"}
{"word": ["fire"], "author": "mm324"}
{"word": [" Dragon"], "author": "kinofhera"}
{"word": ["Wyrm."], "author": "Hickory"}
{"word": ["garbageman"], "author": "motorkar"}
{"word": ["Treasure"], "author": "tort1234"}
{"word": ["national"], "author": "camplify"}
{"word": ["Park"], "author": "xalegra"}
{"word": ["me"], "author": "park_84"}
{"word": ["mine"], "author": "mm324"}
{"word": ["Coal."], "author": "Hickory"}
{"word": ["dust"], "author": "BlackDawn"}
{"word": ["Broom"], "author": "TARFU"}
{"word": ["mop"], "author": "le_chevalier"}
{"word": ["Floor"], "author": "GandalftheCool"}
{"word": ["wax"], "author": "mm324"}
{"word": ["Bees"], "author": "GandalftheCool"}
{"word": ["Knees."], "author": "Hickory"}
{"word": ["elbows"], "author": "mm324"}
{"word": ["forearm"], "author": "TARFU"}
{"word": ["hand"], "author": "mm324"}
{"word": ["fist"], "author": "TARFU"}
{"word": ["over"], "author": "Dzsono"}
{"word": ["Under"], "author": "GandalftheCool"}
{"word": ["around"], "author": "mm324"}
{"word": ["Through"], "author": "GandalftheCool"}
{"word": ["Middle"], "author": "S.Garffsky"}
{"word": ["center"], "author": "le_chevalier"}
{"word": ["Epicenter"], "author": "park_84"}
{"word": ["Earthquake."], "author": "viperfdl"}
{"word": ["Disaster."], "author": "Hickory"}
{"word": ["Epic"], "author": "Zoltan999"}
{"word": ["massive"], "author": "mm324"}
{"word": ["Colossal."], "author": "codefenix"}
{"word": [], "author": "mm324"}
{"word": ["Colosseum"], "author": "Accatone"}
{"word": ["Rome"], "author": "mm324"}
{"word": ["day"], "author": "Ardal"}
{"word": ["Evening."], "author": "Narcia_"}
{"word": ["dusk"], "author": "mm324"}
{"word": ["Dawn."], "author": "codefenix"}
{"word": ["sunrise"], "author": "mm324"}
{"word": ["Super-Supermoon."], "author": "gixgox"}
{"word": ["Spectacular"], "author": "mm324"}
{"word": ["Spectacles."], "author": "codefenix"}
{"word": ["Spectator."], "author": "Hickory"}
{"word": ["bystander"], "author": "mm324"}
{"word": ["witness"], "author": "Dzsono"}
{"word": ["informer"], "author": "mm324"}
{"word": [], "author": "park_84"}
{"word": ["Canada"], "author": "TARFU"}
{"word": ["Moose."], "author": "Hickory"}
{"word": ["Beaver"], "author": "TARFU"}
{"word": ["Dam"], "author": "GandalftheCool"}
{"word": ["obstruction"], "author": "Madshaker"}
{"word": ["destruction"], "author": "DrakoPensulo"}
{"word": ["reconstruction"], "author": "le_chevalier"}
{"word": ["deconstruction"], "author": "S.Garffsky"}
{"word": ["demolish"], "author": "camplify"}
{"word": [], "author": "gixgox"}
{"word": ["Annihilate"], "author": "park_84"}
{"word": ["antimatter"], "author": "Dzsono"}
{"word": ["Black hole."], "author": "chibi23"}
{"word": ["Universe."], "author": "fables22"}
{"word": ["Stargate."], "author": "Hickory"}
{"word": ["Portal"], "author": "Zoltan999"}
{"word": ["Cake"], "author": "plagren"}
{"word": [" Donut."], "author": "fables22"}
{"word": ["Doughnut."], "author": "Hickory"}
{"word": ["nuts"], "author": "Accatone"}
{"word": ["Squirrels."], "author": "Hickory"}
{"word": ["Chipmunks."], "author": "codefenix"}
{"word": ["hedgehogs"], "author": "mm324"}
{"word": [], "author": "gixgox"}
{"word": ["Badger."], "author": "Narcia_"}
{"word": ["lynx"], "author": "mm324"}
{"word": ["Ocelot."], "author": "Hickory"}
{"word": ["cougar"], "author": "mm324"}
{"word": ["Jaguar."], "author": "Hickory"}
{"word": ["tiger"], "author": "mm324"}
{"word": ["."], "author": "codefenix"}
{"word": ["lion"], "author": "mm324"}
{"word": ["Pride."], "author": "Hickory"}
{"word": ["Wrath."], "author": "codefenix"}
{"word": ["anger"], "author": "mm324"}
{"word": ["Revenge."], "author": "viperfdl"}
{"word": ["retribution"], "author": "mm324"}
{"word": ["distribution"], "author": "Accatone"}
{"word": ["Contribution."], "author": "Hickory"}
{"word": ["Partaking"], "author": "toxicTom"}
{"word": ["parkour"], "author": "mm324"}
{"word": ["Athletics"], "author": "GandalftheCool"}
{"word": ["gliding"], "author": "Dzsono"}
{"word": ["Hang"], "author": "GandalftheCool"}
{"word": ["Noose."], "author": "Hickory"}
{"word": ["rope"], "author": "mm324"}
{"word": ["Gallows."], "author": "gixgox"}
{"word": ["Crows"], "author": "GandalftheCool"}
{"word": ["murder"], "author": "mm324"}
{"word": ["Suspect."], "author": "Hickory"}
{"word": ["wrongdoer"], "author": "le_chevalier"}
{"word": ["Delinquent."], "author": "gixgox"}
{"word": ["Paper!"], "author": "ChesHatter"}
{"word": ["Scissors"], "author": "TARFU"}
{"word": [" Hooligan."], "author": "Hickory"}
{"word": ["Football"], "author": "PaterAlf"}
{"word": ["association"], "author": "le_chevalier"}
{"word": ["Federation"], "author": "park_84"}
{"word": ["League."], "author": "Hickory"}
{"word": [], "author": "Zoltan999"}
{"word": ["ATTENTION!!"], "author": "Ian"}
{"word": ["attend"], "author": "Accatone"}
{"word": ["meetings :/"], "author": "ashwald"}
{"word": ["sleep :)"], "author": "mm324"}
{"word": ["Deprived."], "author": "codefenix"}
{"word": ["Destitute."], "author": "Hickory"}
{"word": ["Penniless."], "author": "Narcia_"}
{"word": ["broke"], "author": "mm324"}
{"word": ["Mended."], "author": "Hickory"}
{"word": ["sewn"], "author": "mm324"}
{"word": ["Thread"], "author": "chibi23"}
{"word": ["topic"], "author": "park_84"}
{"word": ["Tropic"], "author": "SamMagel"}
{"word": ["subject"], "author": "mm324"}
{"word": ["."], "author": "gixgox"}
{"word": ["."], "author": "codefenix"}
{"word": ["Style."], "author": "Hickory"}
{"word": ["Flair."], "author": "HypersomniacLive"}
{"word": ["gift"], "author": "park_84"}
{"word": ["attribute"], "author": "sanscript"}
{"word": ["Property."], "author": "codefenix"}
{"word": ["Owner"], "author": "Azrael360"}
{"word": ["Keeper."], "author": "Hickory"}
{"word": ["dungeon"], "author": "park_84"}
{"word": ["dragons"], "author": "TARFU"}
{"word": [], "author": "le_chevalier"}
{"word": ["Clerks"], "author": "TARFU"}
{"word": ["Clerics."], "author": "gixgox"}
{"word": ["healers"], "author": "Dzsono"}
{"word": ["medics"], "author": "le_chevalier"}
{"word": ["Bandages."], "author": "Hickory"}
{"word": ["Syringe."], "author": "gixgox"}
{"word": ["cringe"], "author": "le_chevalier"}
{"word": ["cry"], "author": "Accatone"}
{"word": ["far"], "author": "park_84"}
{"word": ["Manager."], "author": "Casval_Deikun"}
{"word": ["Boss."], "author": "Hickory"}
{"word": [], "author": "Zoltan999"}
{"word": ["Hogweed."], "author": "gixgox"}
{"word": ["Fennel."], "author": "Hickory"}
{"word": ["basil"], "author": "mm324"}
{"word": ["Herb"], "author": "GandalftheCool"}
{"word": ["parsley"], "author": "ashwald"}
{"word": ["chives"], "author": "mm324"}
{"word": ["Hives."], "author": "codefenix"}
{"word": ["Cluster."], "author": "gixgox"}
{"word": [], "author": "mm324"}
{"word": ["Nut"], "author": "GandalftheCool"}
{"word": ["crazy"], "author": "mm324"}
{"word": ["taxi!"], "author": "park_84"}
{"word": ["Fare."], "author": "Hickory"}
{"word": ["tariff"], "author": "Dzsono"}
{"word": ["Government"], "author": "tort1234"}
{"word": ["do-nothings"], "author": "mm324"}
{"word": ["lazy"], "author": "TARFU"}
{"word": ["apathetic"], "author": "mm324"}
{"word": ["Indifferent."], "author": "LoboBlanco"}
{"word": ["unconcerned"], "author": "le_chevalier"}
{"word": ["flat"], "author": "Dzsono"}
{"word": ["boobs"], "author": "camplify"}
{"word": [" Aloof."], "author": "Hickory"}
{"word": ["Derailed."], "author": "codefenix"}
{"word": ["Train."], "author": "Narcia_"}
{"word": ["Steam"], "author": "Cavenagh"}
{"word": ["engine"], "author": "ashwald"}
{"word": ["."], "author": "gixgox"}
{"word": ["mortar"], "author": "Accatone"}
{"word": ["Bazooka"], "author": "toothsaber"}
{"word": ["RPG"], "author": "GandalftheCool"}
{"word": ["Fallout"], "author": "mm324"}
{"word": ["Skyrim"], "author": "GandalftheCool"}
{"word": ["Skyfall."], "author": "codefenix"}
{"word": ["Dragons"], "author": "doctorsinister"}
{"word": ["Knight"], "author": "mm324"}
{"word": [" Bond."], "author": "Hickory"}
{"word": ["Friendship"], "author": "GandalftheCool"}
{"word": ["Magic."], "author": "codefenix"}
{"word": ["Gathering"], "author": "toxicTom"}
{"word": ["Rally."], "author": "Hickory"}
{"word": ["Car."], "author": "codefenix"}
{"word": ["Truck"], "author": "GandalftheCool"}
{"word": ["highway"], "author": "mm324"}
{"word": ["Life"], "author": "GandalftheCool"}
{"word": ["death"], "author": "mm324"}
{"word": ["Birth"], "author": "GandalftheCool"}
{"word": ["beginning"], "author": "mm324"}
{"word": ["ending"], "author": "doronnorod"}
{"word": ["finale"], "author": "mm324"}
{"word": ["Finish."], "author": "gixgox"}
{"word": ["Swedish"], "author": "Maxvorstadt"}
{"word": [" Meatballs"], "author": "mm324"}
{"word": ["Feldman"], "author": "ChesHatter"}
{"word": [" spaghetti ", " ", " ninja'd"], "author": "le_chevalier"}
{"word": ["Marty"], "author": "Maxvorstadt"}
{"word": ["Mcfly"], "author": "TARFU"}
{"word": ["Biff"], "author": "GandalftheCool"}
{"word": [], "author": "mm324"}
{"word": ["Joker"], "author": "GandalftheCool"}
{"word": ["Catwoman"], "author": "mm324"}
{"word": ["centaur"], "author": "Dzsono"}
{"word": ["Centipede."], "author": "gixgox"}
{"word": ["millipede"], "author": "mm324"}
{"word": ["Centipede"], "author": "TARFU"}
{"word": ["pedicure ", " ", " (or \"pede-icure\")"], "author": "lz8"}
{"word": ["spa"], "author": "mm324"}
{"word": ["sauna"], "author": "lz8"}
{"word": ["steam"], "author": "mm324"}
{"word": ["minx"], "author": "lz8"}
{"word": ["punk"], "author": "gixgox"}
{"word": ["rock"], "author": "TARFU"}
{"word": ["roll"], "author": "mm324"}
{"word": ["."], "author": "gixgox"}
{"word": ["skeleton"], "author": "le_chevalier"}
{"word": ["Undead."], "author": "xieliming"}
{"word": ["corpse"], "author": "park_84"}
{"word": ["corps"], "author": "Accatone"}
{"word": ["Marine"], "author": "Zoltan999"}
{"word": ["exercises"], "author": "JDelekto"}
{"word": ["Aerobics."], "author": "Hickory"}
{"word": ["Acrobatics."], "author": "Narcia_"}
{"word": ["tiring"], "author": "ashwald"}
{"word": ["healthy"], "author": "JDelekto"}
{"word": ["wholesome"], "author": "mm324"}
{"word": ["Nutritious."], "author": "Hickory"}
{"word": ["Pizzaaaaaaaaaaaa"], "author": "gixgox"}
{"word": ["turtles"], "author": "park_84"}
{"word": ["snapping"], "author": "Ardal"}
{"word": ["Twigs."], "author": "Hickory"}
{"word": ["Trees"], "author": "doronnorod"}
{"word": ["leaves"], "author": "mm324"}
{"word": ["tea"], "author": "TARFU"}
{"word": ["pot"], "author": "mm324"}
{"word": ["Kettle."], "author": "gixgox"}
{"word": [" bell"], "author": "mm324"}
{"word": ["ring"], "author": "TARFU"}
{"word": ["cock"], "author": "Regals"}
{"word": ["Diamond ", " "], "author": "mm324"}
{"word": ["carbon"], "author": "TARFU"}
{"word": ["steel"], "author": "mm324"}
{"word": ["Girder."], "author": "Hickory"}
{"word": ["building"], "author": "mm324"}
{"word": ["edifice"], "author": "Dzsono"}
{"word": ["complex"], "author": "le_chevalier"}
{"word": ["Simple."], "author": "Hickory"}
{"word": ["Mind"], "author": "park_84"}
{"word": [], "author": "truhlik"}
{"word": ["mast"], "author": "Accatone"}
{"word": ["must"], "author": "gixgox"}
{"word": ["force"], "author": "Silverhawk170485"}
{"word": ["Compelling"], "author": "Zoltan999"}
{"word": ["demanding"], "author": "mm324"}
{"word": ["Entitlement."], "author": "viperfdl"}
{"word": ["spoiled"], "author": "mm324"}
{"word": ["rotten"], "author": "ashwald"}
{"word": ["Tomatos"], "author": "GandalftheCool"}
{"word": ["Sauce."], "author": "Narcia_"}
{"word": ["Pizza"], "author": "GandalftheCool"}
{"word": ["Source."], "author": "gixgox"}
{"word": ["Code."], "author": "viperfdl"}
{"word": ["Enigma"], "author": "park_84"}
{"word": ["Riddler"], "author": "GandalftheCool"}
{"word": ["puzzle"], "author": "TARFU"}
{"word": ["solution"], "author": "tort1234"}
{"word": ["Eureka!"], "author": "park_84"}
{"word": ["Archimedes"], "author": "mm324"}
{"word": ["screw"], "author": "TARFU"}
{"word": ["ball"], "author": "mm324"}
{"word": ["dance"], "author": "le_chevalier"}
{"word": ["party"], "author": "TARFU"}
{"word": ["Drink"], "author": "GandalftheCool"}
{"word": ["Smoke."], "author": "gixgox"}
{"word": ["snort"], "author": "Dzsono"}
{"word": ["hangover"], "author": "mm324"}
{"word": ["Overhang."], "author": "gixgox"}
{"word": ["view"], "author": "camplify"}
{"word": ["vista"], "author": "TARFU"}
{"word": ["Windows"], "author": "doctorsinister"}
{"word": ["Attraction."], "author": "REDVWIN"}
{"word": ["Fatal"], "author": "Yezemin"}
{"word": ["Error"], "author": "motorkar"}
{"word": ["mistake"], "author": "park_84"}
{"word": ["Abort"], "author": "Zoltan999"}
{"word": ["Closedown."], "author": "gixgox"}
{"word": ["Cessation."], "author": "Hickory"}
{"word": ["halt"], "author": "mm324"}
{"word": ["Pause."], "author": "Narcia_"}
{"word": ["play"], "author": "mm324"}
{"word": ["date"], "author": "sanscript"}
{"word": ["Masamune"], "author": "ChesHatter"}
{"word": ["Time."], "author": "gixgox"}
{"word": ["Life."], "author": "codefenix"}
{"word": ["Circle."], "author": "Hickory"}
{"word": ["Compasses."], "author": "gixgox"}
{"word": ["Maps."], "author": "codefenix"}
{"word": ["land"], "author": "Accatone"}
{"word": ["sea"], "author": "mm324"}
{"word": ["Salt."], "author": "codefenix"}
{"word": ["pepper"], "author": "park_84"}
{"word": ["mint"], "author": "mm324"}
{"word": ["Condition."], "author": "codefenix"}
{"word": ["Zero"], "author": "mm324"}
{"word": ["gravity"], "author": "Accatone"}
{"word": ["space"], "author": "mm324"}
{"word": ["Frontier."], "author": "codefenix"}
{"word": ["untamed"], "author": "mm324"}
{"word": ["Felines"], "author": "doctorsinister"}
{"word": ["canines"], "author": "mm324"}
{"word": ["Dogs"], "author": "GandalftheCool"}
{"word": ["labrador"], "author": "mm324"}
{"word": ["Retriever"], "author": "GandalftheCool"}
{"word": ["Terrier."], "author": "Hickory"}
{"word": ["Rat"], "author": "GandalftheCool"}
{"word": ["trap"], "author": "le_chevalier"}
{"word": ["Ackbar"], "author": "GandalftheCool"}
{"word": ["admiral"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": ["Caterpillar"], "author": "PaterAlf"}
{"word": ["cocoon"], "author": "Dzsono"}
{"word": ["Chrysalis."], "author": "Hickory"}
{"word": ["Pupa."], "author": "gixgox"}
{"word": ["Larva."], "author": "REDVWIN"}
{"word": ["baby"], "author": "camplify"}
{"word": ["Puppy."], "author": "gixgox"}
{"word": ["pub"], "author": "Accatone"}
{"word": ["Beer"], "author": "Yezemin"}
{"word": ["Yellow"], "author": "risingcomet"}
{"word": ["Mellow"], "author": "mm324"}
{"word": ["Calm"], "author": "NinjaShadow24"}
{"word": ["serene"], "author": "mm324"}
{"word": ["Peaceful."], "author": "codefenix"}
{"word": ["quiet"], "author": "mm324"}
{"word": ["Introvert"], "author": "Zoltan999"}
{"word": ["shy"], "author": "mm324"}
{"word": ["Timid."], "author": "Narcia_"}
{"word": ["Mouse"], "author": "GandalftheCool"}
{"word": ["Trap"], "author": "TDP"}
{"word": ["Clap."], "author": "codefenix"}
{"word": ["applaud"], "author": "mm324"}
{"word": ["Audience."], "author": "Hickory"}
{"word": ["Stares"], "author": "doctorsinister"}
{"word": ["Steps"], "author": "GandalftheCool"}
{"word": ["Baby"], "author": "Yezemin"}
{"word": ["Toddler"], "author": "GandalftheCool"}
{"word": ["infant"], "author": "TARFU"}
{"word": ["spawn"], "author": "mm324"}
{"word": ["hatchling"], "author": "le_chevalier"}
{"word": ["dragon"], "author": "mm324"}
{"word": ["fly"], "author": "gixgox"}
{"word": ["Swatter"], "author": "GandalftheCool"}
{"word": [], "author": "flubbucket"}
{"word": ["zap"], "author": "Accatone"}
{"word": ["Shoot"], "author": "Zoltan999"}
{"word": ["Fire."], "author": "Hickory"}
{"word": ["Alarm."], "author": "codefenix"}
{"word": ["Dismay."], "author": "Hickory"}
{"word": ["Disappointment."], "author": "Narcia_"}
{"word": ["Bummer!"], "author": "gixgox"}
{"word": ["me"], "author": "flanner"}
{"word": ["you?"], "author": "park_84"}
{"word": ["Us."], "author": "codefenix"}
{"word": ["We"], "author": "mm324"}
{"word": ["They."], "author": "Hickory"}
{"word": ["Others"], "author": "Yezemin"}
{"word": ["Extra"], "author": "motorkar"}
{"word": ["More"], "author": "GandalftheCool"}
{"word": ["additional"], "author": "TARFU"}
{"word": ["supplementary"], "author": "le_chevalier"}
{"word": ["vitamins"], "author": "ashwald"}
{"word": ["healthy"], "author": "camplify"}
{"word": ["fertiliser"], "author": "Dzsono"}
{"word": ["manure"], "author": "le_chevalier"}
{"word": ["guano"], "author": "Exoanthrope"}
{"word": ["Amonia."], "author": "Hickory"}
{"word": ["Compost."], "author": "gixgox"}
{"word": ["nitrates"], "author": "Dzsono"}
{"word": ["food"], "author": "camplify"}
{"word": ["Tasty"], "author": "Yezemin"}
{"word": ["taste"], "author": "Accatone"}
{"word": ["Tongue."], "author": "viperfdl"}
{"word": ["Uvula."], "author": "gixgox"}
{"word": ["throat"], "author": "sluniq"}
{"word": ["Tonsils."], "author": "gixgox"}
{"word": ["Redundant."], "author": "Hickory"}
{"word": ["unnecessary"], "author": "ashwald"}
{"word": ["Precaution"], "author": "Zoltan999"}
{"word": ["careful."], "author": "Narcia_"}
{"word": ["Measured."], "author": "Hickory"}
{"word": ["slow"], "author": "flanner"}
{"word": ["thinking"], "author": "park_84"}
{"word": ["pondering"], "author": "mm324"}
{"word": ["Mindful."], "author": "Hickory"}
{"word": ["thoughtful"], "author": "mm324"}
{"word": ["Person."], "author": "chibi23"}
{"word": ["entity"], "author": "mm324"}
{"word": ["creature"], "author": "ashwald"}
{"word": ["animal"], "author": "TARFU"}
{"word": ["Centipede."], "author": "gixgox"}
{"word": ["legs"], "author": "Dzsono"}
{"word": ["feet"], "author": "le_chevalier"}
{"word": [" stank"], "author": "Magic_Of_Light"}
{"word": ["Reeked."], "author": "Hickory"}
{"word": ["weekend"], "author": "Accatone"}
{"word": ["Sunday"], "author": "Yezemin"}
{"word": ["soon"], "author": "ashwald"}
{"word": ["Soonday?"], "author": "gixgox"}
{"word": ["Pardon?"], "author": "Narcia_"}
{"word": ["Beg."], "author": "codefenix"}
{"word": ["Plead."], "author": "Hickory"}
{"word": ["please"], "author": "Accatone"}
{"word": ["thanks"], "author": "mm324"}
{"word": [" anytime :P"], "author": "ashwald"}
{"word": ["tomorrow"], "author": "gixgox"}
{"word": ["Enigma. [Tomorrow never comes.]"], "author": "Hickory"}
{"word": ["encrypt"], "author": "park_84"}
{"word": ["script"], "author": "Madshaker"}
{"word": ["font"], "author": "mm324"}
{"word": ["Gothic"], "author": "Zoltan999"}
{"word": ["Risen"], "author": "park_84"}
{"word": ["Fallen"], "author": "kmonster"}
{"word": ["Angel."], "author": "gixgox"}
{"word": ["guardian"], "author": "le_chevalier"}
{"word": ["newspaper"], "author": "sanscript"}
{"word": ["Editor."], "author": "Hickory"}
{"word": ["Censor."], "author": "gixgox"}
{"word": ["Truth"], "author": "TDP"}
{"word": ["honesty"], "author": "mm324"}
{"word": ["loyalty"], "author": "TARFU"}
{"word": ["allegiance"], "author": "mm324"}
{"word": ["fealty"], "author": "le_chevalier"}
{"word": ["devotion"], "author": "mm324"}
{"word": ["dedication"], "author": "le_chevalier"}
{"word": ["Fanboyism."], "author": "gixgox"}
{"word": ["infatuation"], "author": "Dzsono"}
{"word": ["Intimidation."], "author": "Narcia_"}
{"word": ["Coercion."], "author": "Hickory"}
{"word": ["force"], "author": "mm324"}
{"word": ["Jedi"], "author": "toxicTom"}
{"word": ["Numinous... :P"], "author": "GhostwriterDoF"}
{"word": ["numeral"], "author": "TARFU"}
{"word": ["math"], "author": "camplify"}
{"word": ["blaster"], "author": "squidbee"}
{"word": ["phaser"], "author": "Dzsono"}
{"word": ["taser"], "author": "le_chevalier"}
{"word": ["."], "author": "Hickory"}
{"word": [], "author": "park_84"}
{"word": ["red"], "author": "Accatone"}
{"word": [" "], "author": "gixgox"}
{"word": ["uncle"], "author": "ashwald"}
{"word": ["Fireman."], "author": "Narcia_"}
{"word": ["policeman"], "author": "mm324"}
{"word": ["Uniform."], "author": "Hickory"}
{"word": ["Costume"], "author": "TDP"}
{"word": ["Cosplay."], "author": "gixgox"}
{"word": ["Pretend."], "author": "Hickory"}
{"word": ["imagine"], "author": "mm324"}
{"word": ["Lennon"], "author": "park_84"}
{"word": ["John."], "author": "viperfdl"}
{"word": ["Snow"], "author": "GandalftheCool"}
{"word": ["Forecast."], "author": "Hickory"}
{"word": ["Phantasy."], "author": "gixgox"}
{"word": ["phantasm"], "author": "Dzsono"}
{"word": [], "author": "Zoltan999"}
{"word": ["shark"], "author": "TARFU"}
{"word": ["Tank"], "author": "GandalftheCool"}
{"word": ["Conflict."], "author": "REDVWIN"}
{"word": ["Resolution."], "author": "NowaAnglia"}
{"word": ["reconciliation"], "author": "le_chevalier"}
{"word": ["church"], "author": "camplify"}
{"word": ["Synagogue."], "author": "gixgox"}
{"word": ["Pray"], "author": "Yezemin"}
{"word": ["Prey."], "author": "viperfdl"}
{"word": ["Booty."], "author": "gixgox"}
{"word": ["boot"], "author": "Accatone"}
{"word": ["Cowboy"], "author": "Zoltan999"}
{"word": ["Bebop"], "author": "ashwald"}
{"word": ["Dancing."], "author": "Narcia_"}
{"word": ["drinking"], "author": "mm324"}
{"word": ["Rabble-rousing... ;)"], "author": "GhostwriterDoF"}
{"word": ["carousing"], "author": "mm324"}
{"word": ["Wassailing."], "author": "Hickory"}
{"word": ["Waffling."], "author": "codefenix"}
{"word": ["Babbling"], "author": "Yezemin"}
{"word": ["brook"], "author": "TARFU"}
{"word": ["Bridge"], "author": "tort1234"}
{"word": ["Across."], "author": "Hickory"}
{"word": ["Over"], "author": "Zoltan999"}
{"word": ["."], "author": "gixgox"}
{"word": ["done"], "author": "Dzsono"}
{"word": ["cooked"], "author": "le_chevalier"}
{"word": ["Boiled"], "author": "tort1234"}
{"word": ["spoiled"], "author": "Madshaker"}
{"word": ["ruined"], "author": "le_chevalier"}
{"word": ["Ruins"], "author": "Zoltan999"}
{"word": ["debris"], "author": "ashwald"}
{"word": ["Rubble."], "author": "Hickory"}
{"word": ["Bam-bam."], "author": "Narcia_"}
{"word": ["cartoon"], "author": "park_84"}
{"word": ["caricature"], "author": "mm324"}
{"word": ["Parody."], "author": "codefenix"}
{"word": ["spoof"], "author": "mm324"}
{"word": ["credible"], "author": "Ardal"}
{"word": ["believable"], "author": "mm324"}
{"word": ["Trustworthy."], "author": "viperfdl"}
{"word": ["Loyal."], "author": "codefenix"}
{"word": ["friend"], "author": "BlackDawn"}
{"word": ["ship"], "author": "flubbucket"}
{"word": ["Air- ", " ", " "], "author": "gixgox"}
{"word": ["atmosphere"], "author": "TARFU"}
{"word": ["pressure"], "author": "le_chevalier"}
{"word": ["barometer"], "author": "Dzsono"}
{"word": ["Thermometer"], "author": "Yezemin"}
{"word": ["Rectum."], "author": "viperfdl"}
{"word": ["Probe."], "author": "gixgox"}
{"word": ["robe"], "author": "Accatone"}
{"word": ["rob"], "author": "le_chevalier"}
{"word": ["Steal"], "author": "Zoltan999"}
{"word": ["Snip."], "author": "gixgox"}
{"word": ["Snap."], "author": "codefenix"}
{"word": ["Fingers"], "author": "cose_vecchie"}
{"word": ["Toes."], "author": "codefenix"}
{"word": ["Ballet."], "author": "Narcia_"}
{"word": ["shoes"], "author": "mm324"}
{"word": ["painful"], "author": "ashwald"}
{"word": ["hurtful"], "author": "mm324"}
{"word": ["Offensive."], "author": "codefenix"}
{"word": ["defensive"], "author": "mm324"}
{"word": ["attack"], "author": "park_84"}
{"word": ["gun"], "author": "camplify"}
{"word": ["Control"], "author": "GandalftheCool"}
{"word": ["Alt."], "author": "codefenix"}
{"word": ["Delete."], "author": "viperfdl"}
{"word": ["Erase"], "author": "Yezemin"}
{"word": ["mistake"], "author": "mm324"}
{"word": ["error"], "author": "TARFU"}
{"word": ["miscalculation"], "author": "mm324"}
{"word": ["Mistake"], "author": "GandalftheCool"}
{"word": ["Repeat ", " ", " ", " ", " ", " ", " "], "author": "Zoltan999"}
{"word": ["loop"], "author": "Dzsono"}
{"word": ["Time"], "author": "GandalftheCool"}
{"word": ["tempo"], "author": "le_chevalier"}
{"word": ["Speed."], "author": "gixgox"}
{"word": ["velocity"], "author": "le_chevalier"}
{"word": ["physics"], "author": "camplify"}
{"word": ["Sience. ", " ", " --- ", " ", " Sorry - a typo. ", " Adding a ", "."], "author": "gixgox"}
{"word": [" ", " ", " ", " ", " ", " ", " ", " FTFY"], "author": "Zoltan999"}
{"word": [" <thanks> "], "author": "gixgox"}
{"word": ["Mate."], "author": "codefenix"}
{"word": ["Buddy."], "author": "Narcia_"}
{"word": ["pal"], "author": "mm324"}
{"word": ["Friend"], "author": "TDP"}
{"word": ["Guy."], "author": "codefenix"}
{"word": ["Family"], "author": "doctorsinister"}
{"word": ["drama"], "author": "mm324"}
{"word": ["Queen."], "author": "viperfdl"}
{"word": ["King."], "author": "codefenix"}
{"word": ["Intangible."], "author": "GhostwriterDoF"}
{"word": ["ethereal"], "author": "mm324"}
{"word": ["ghostly"], "author": "TARFU"}
{"word": ["Ghastly"], "author": "GandalftheCool"}
{"word": ["home"], "author": "kmonster"}
{"word": ["Grown"], "author": "Zoltan999"}
{"word": ["up"], "author": "gixgox"}
{"word": ["north"], "author": "le_chevalier"}
{"word": ["Pole"], "author": "GandalftheCool"}
{"word": ["Polish"], "author": "Dzsono"}
{"word": ["nail"], "author": "le_chevalier"}
{"word": ["hammer"], "author": "camplify"}
{"word": ["Sink"], "author": "Yezemin"}
{"word": ["sin"], "author": "Accatone"}
{"word": ["sinister"], "author": "gixgox"}
{"word": ["sinestro"], "author": "ashwald"}
{"word": ["villain"], "author": "mm324"}
{"word": ["Hero."], "author": "Narcia_"}
{"word": ["Batman"], "author": "mm324"}
{"word": ["Robin."], "author": "codefenix"}
{"word": ["Christopher"], "author": "Yezemin"}
{"word": ["Nolan"], "author": "GandalftheCool"}
{"word": ["Ryan."], "author": "codefenix"}
{"word": ["Reynolds"], "author": "GandalftheCool"}
{"word": ["Deadpool"], "author": "TARFU"}
{"word": ["Marvel"], "author": "GandalftheCool"}
{"word": ["dc"], "author": "BlackDawn"}
{"word": ["Superman"], "author": "GandalftheCool"}
{"word": ["River"], "author": "doctorsinister"}
{"word": ["yellow"], "author": "park_84"}
{"word": ["Mellow."], "author": "gixgox"}
{"word": ["fellow"], "author": "le_chevalier"}
{"word": ["Buddy."], "author": "REDVWIN"}
{"word": ["Friend"], "author": "GandalftheCool"}
{"word": ["chum"], "author": "mm324"}
{"word": ["sharks"], "author": "JDelekto"}
{"word": ["Teeth."], "author": "gixgox"}
{"word": ["fairy"], "author": "park_84"}
{"word": ["Pixie."], "author": "gixgox"}
{"word": ["dust"], "author": "cose_vecchie"}
{"word": ["Broom."], "author": "gixgox"}
{"word": ["sweep"], "author": "ashwald"}
{"word": ["weep"], "author": "Accatone"}
{"word": ["Cry"], "author": "Zoltan999"}
{"word": [" -engine"], "author": "gixgox"}
{"word": ["Motor."], "author": "Narcia_"}
{"word": ["racer"], "author": "Accatone"}
{"word": ["racecourse"], "author": "mm324"}
{"word": ["horses"], "author": "TARFU"}
{"word": ["riders"], "author": "truhlik"}
{"word": ["Rohan"], "author": "GandalftheCool"}
{"word": ["Gohan"], "author": "park_84"}
{"word": ["Goku."], "author": "LoboBlanco"}
{"word": ["Legend."], "author": "REDVWIN"}
{"word": ["myth"], "author": "mm324"}
{"word": ["buster"], "author": "le_chevalier"}
{"word": [], "author": "gixgox"}
{"word": ["kitten"], "author": "le_chevalier"}
{"word": ["kit"], "author": "Accatone"}
{"word": ["kat"], "author": "ashwald"}
{"word": ["katal"], "author": "Ardal"}
{"word": ["Catalyst"], "author": "Zoltan999"}
{"word": ["Caterpillar."], "author": "gixgox"}
{"word": ["butterfly"], "author": "mm324"}
{"word": ["Effect"], "author": "Yezemin"}
{"word": ["Affect."], "author": "codefenix"}
{"word": ["Accent."], "author": "NowaAnglia"}
{"word": ["Inflection."], "author": "GhostwriterDoF"}
{"word": ["lisp"], "author": "park_84"}
{"word": ["speech"], "author": "TARFU"}
{"word": ["delivery"], "author": "le_chevalier"}
{"word": ["DiGiorno"], "author": "DaCostaBR"}
{"word": ["Oven"], "author": "TDP"}
{"word": ["Coven"], "author": "Dzsono"}
{"word": ["Forum."], "author": "REDVWIN"}
{"word": ["post"], "author": "camplify"}
{"word": ["Apocalyptic"], "author": "GandalftheCool"}
{"word": ["catastrophic"], "author": "le_chevalier"}
{"word": ["Dire."], "author": "Hickory"}
{"word": ["need"], "author": "Ardal"}
{"word": ["speed"], "author": "Accatone"}
{"word": ["Velocity"], "author": "Yezemin"}
{"word": ["Terminal."], "author": "codefenix"}
{"word": ["Airport"], "author": "skimmie"}
{"word": ["Runway"], "author": "Zoltan999"}
{"word": ["runaway"], "author": "Dzsono"}
{"word": ["fugitive"], "author": "mm324"}
{"word": ["The."], "author": "Narcia_"}
{"word": ["That."], "author": "gixgox"}
{"word": ["This."], "author": "codefenix"}
{"word": ["Simplistic..."], "author": "GhostwriterDoF"}
{"word": ["...complexity"], "author": "park_84"}
{"word": ["Complicatedness."], "author": "codefenix"}
{"word": ["*Sigh!*"], "author": "Hickory"}
{"word": ["*Groan*"], "author": "codefenix"}
{"word": ["*cough*"], "author": "GandalftheCool"}
{"word": ["Syrup"], "author": "Yezemin"}
{"word": ["Maple."], "author": "codefenix"}
{"word": ["."], "author": "Hickory"}
{"word": ["Smoked."], "author": "RyeFlavoredToast"}
{"word": ["roast"], "author": "Ardal"}
{"word": ["beef"], "author": "TARFU"}
{"word": ["yummy"], "author": "ashwald"}
{"word": ["Burrito."], "author": "RyeFlavoredToast"}
{"word": ["tortilla"], "author": "le_chevalier"}
{"word": ["chip"], "author": "mm324"}
{"word": ["corn"], "author": "Dzsono"}
{"word": ["Pop ", " "], "author": "mm324"}
{"word": ["Weasel."], "author": "Hickory"}
{"word": ["Wicked"], "author": "le_chevalier"}
{"word": ["performance"], "author": "nicohvc"}
{"word": ["play"], "author": "park_84"}
{"word": ["Lists."], "author": "gixgox"}
{"word": [], "author": "le_chevalier"}
{"word": ["Done!"], "author": "Zoltan999"}
{"word": ["Deal."], "author": "HypersomniacLive"}
{"word": ["Real."], "author": "codefenix"}
{"word": ["True."], "author": "Narcia_"}
{"word": ["Madrid."], "author": "gixgox"}
{"word": ["Spain"], "author": "mm324"}
{"word": ["pain"], "author": "Accatone"}
{"word": ["Inarticulate."], "author": "GhostwriterDoF"}
{"word": ["Unintelligible."], "author": "codefenix"}
{"word": ["smeared"], "author": "Ardal"}
{"word": ["Smile"], "author": "tort1234"}
{"word": ["print"], "author": "ashwald"}
{"word": ["paper"], "author": "toxicTom"}
{"word": ["Cut"], "author": "TDP"}
{"word": ["Stitch."], "author": "HypersomniacLive"}
{"word": ["Snitch."], "author": "codefenix"}
{"word": ["Rat"], "author": "Zoltan999"}
{"word": ["Mole."], "author": "HypersomniacLive"}
{"word": ["Hole."], "author": "Hickory"}
{"word": ["man"], "author": "XYCat"}
{"word": ["super"], "author": "park_84"}
{"word": ["Hero"], "author": "GabesterOne"}
{"word": ["Heroine."], "author": "gixgox"}
{"word": ["Paragon."], "author": "Hickory"}
{"word": ["Apex"], "author": "tort1234"}
{"word": ["heart"], "author": "nicohvc"}
{"word": ["muscle"], "author": "TARFU"}
{"word": ["bulk"], "author": "Dzsono"}
{"word": ["Purchase."], "author": "Hickory"}
{"word": ["acquisition"], "author": "le_chevalier"}
{"word": ["Ownership."], "author": "REDVWIN"}
{"word": ["Battleship."], "author": "gixgox"}
{"word": ["One-upmanship."], "author": "Hickory"}
{"word": ["struggle"], "author": "Ardal"}
{"word": ["strive"], "author": "Accatone"}
{"word": ["string"], "author": "mariabarring"}
{"word": ["succeed"], "author": "mm324"}
{"word": ["Fail"], "author": "GandalftheCool"}
{"word": ["Flail."], "author": "codefenix"}
{"word": ["flag"], "author": "mariabarring"}
{"word": ["Flake."], "author": "gixgox"}
{"word": ["Snow"], "author": "Yezemin"}
{"word": ["Globe"], "author": "GandalftheCool"}
{"word": ["Trotter."], "author": "codefenix"}
{"word": ["hoof"], "author": "Dzsono"}
{"word": ["shoe"], "author": "Madshaker"}
{"word": ["Horn."], "author": "codefenix"}
{"word": ["Trumpet."], "author": "Narcia_"}
{"word": ["Trombone... :)"], "author": "GhostwriterDoF"}
{"word": ["Cheekbone."], "author": "gixgox"}
{"word": ["Skull ", " ", " Edit: ", " Ninja'd"], "author": "viperfdl"}
{"word": ["Bones"], "author": "tort1234"}
{"word": ["Fracture."], "author": "toxicTom"}
{"word": ["venture"], "author": "apehater"}
{"word": ["Forth"], "author": "GandalftheCool"}
{"word": ["Fort."], "author": "gixgox"}
{"word": ["Castle"], "author": "TARFU"}
{"word": ["Vania"], "author": "GandalftheCool"}
{"word": ["vein"], "author": "Dzsono"}
{"word": ["Bloody"], "author": "Antimateria"}
{"word": ["Vagina."], "author": "Kleetus"}
{"word": [" Mary."], "author": "gixgox"}
{"word": ["Rose"], "author": "park_84"}
{"word": ["Thorns"], "author": "Yezemin"}
{"word": [], "author": "gixgox"}
{"word": ["Kings"], "author": "vidsgame"}
{"word": ["Emperor."], "author": "viperfdl"}
{"word": ["Ruler."], "author": "REDVWIN"}
{"word": ["inch"], "author": "Ardal"}
{"word": ["screen"], "author": "park_84"}
{"word": ["green"], "author": "xalegra"}
{"word": ["Red."], "author": "codefenix"}
{"word": ["Alert"], "author": "Zoltan999"}
{"word": ["Awake"], "author": "toxicTom"}
{"word": ["Asleep."], "author": "Narcia_"}
{"word": ["Moony."], "author": "gixgox"}
{"word": ["Sunny"], "author": "toxicTom"}
{"word": ["hot"], "author": "mm324"}
{"word": ["Chick"], "author": "GandalftheCool"}
{"word": ["Vagina."], "author": "Kleetus"}
{"word": [" Hen."], "author": "gixgox"}
{"word": ["Rooster"], "author": "GandalftheCool"}
{"word": [" Cock."], "author": "Kleetus"}
{"word": ["Cocky."], "author": "toxicTom"}
{"word": ["Noodles"], "author": "tort1234"}
{"word": ["Chinese"], "author": "Azrael360"}
{"word": ["Confucianism"], "author": "toxicTom"}
{"word": [], "author": "park_84"}
{"word": ["Mistaken"], "author": "GandalftheCool"}
{"word": ["wrong"], "author": "TARFU"}
{"word": ["Right"], "author": "GandalftheCool"}
{"word": ["upright"], "author": "le_chevalier"}
{"word": ["standing"], "author": "Ardal"}
{"word": ["Sitting"], "author": "GandalftheCool"}
{"word": ["squatting"], "author": "le_chevalier"}
{"word": ["Jogging."], "author": "REDVWIN"}
{"word": ["lunging"], "author": "Dzsono"}
{"word": ["pounce"], "author": "Ardal"}
{"word": ["Attack"], "author": "Zoltan999"}
{"word": [], "author": "gixgox"}
{"word": ["Toppled."], "author": "Narcia_"}
{"word": ["face"], "author": "park_84"}
{"word": ["Nose"], "author": "Yezemin"}
{"word": ["moustache"], "author": "mm324"}
{"word": ["Ride."], "author": "codefenix"}
{"word": ["rid"], "author": "Accatone"}
{"word": ["Riddle"], "author": "Licurg"}
{"word": ["Puzzling."], "author": "vidsgame"}
{"word": ["Baffling."], "author": "codefenix"}
{"word": [" Filter ", " ", " ", " ", " ", " ", " Hey bud, how you been? Have a nice holiday and great new year bruh!"], "author": "Zoltan999"}
{"word": ["censor"], "author": "le_chevalier"}
{"word": ["retraction"], "author": "Dzsono"}
{"word": ["edit"], "author": "TARFU"}
{"word": ["Circumcision."], "author": "Kleetus"}
{"word": ["ouch!"], "author": "Tauto"}
{"word": [" Revise."], "author": "gixgox"}
{"word": ["review"], "author": "le_chevalier"}
{"word": ["Criticism."], "author": "toxicTom"}
{"word": ["critic"], "author": "Accatone"}
{"word": ["Opinion"], "author": "Zoltan999"}
{"word": ["subjective"], "author": "ashwald"}
{"word": ["Objective"], "author": "PaterAlf"}
{"word": ["Perceptive."], "author": "Narcia_"}
{"word": ["Receptive."], "author": "toxicTom"}
{"word": ["receptor"], "author": "Ardal"}
{"word": ["Reciprocation."], "author": "gixgox"}
{"word": [" Organ."], "author": "Kleetus"}
{"word": [" Engine"], "author": "TARFU"}
{"word": ["Motor."], "author": "toxicTom"}
{"word": ["Oil."], "author": "Hickory"}
{"word": ["lamp"], "author": "ashwald"}
{"word": ["diesel ", " ", " - ", " ", " ninja'd... ", " ", " "], "author": "park_84"}
{"word": ["Lamp"], "author": "vidsgame"}
{"word": ["light"], "author": "mm324"}
{"word": [], "author": "gixgox"}
{"word": [" Pale."], "author": "Kleetus"}
{"word": [" Rhythms."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Beats."], "author": "gixgox"}
{"word": ["Rhythm."], "author": "vidsgame"}
{"word": ["tempo"], "author": "Dzsono"}
{"word": ["Sound."], "author": "REDVWIN"}
{"word": ["Noise"], "author": "GandalftheCool"}
{"word": ["Loud"], "author": "VampiroAlhazred"}
{"word": ["clear"], "author": "le_chevalier"}
{"word": ["Shiny."], "author": "gixgox"}
{"word": ["Shimmer."], "author": "toxicTom"}
{"word": ["Glimmer."], "author": "gixgox"}
{"word": ["Glint... :)"], "author": "GhostwriterDoF"}
{"word": ["Glow"], "author": "toxicTom"}
{"word": ["Warm"], "author": "L30R0D"}
{"word": ["Fallout"], "author": "Lin545"}
{"word": ["Drop-in."], "author": "gixgox"}
{"word": ["drop"], "author": "Accatone"}
{"word": ["Drip."], "author": "codefenix"}
{"word": ["Dry."], "author": "Narcia_"}
{"word": ["Desert"], "author": "Zoltan999"}
{"word": ["Sand"], "author": "PaterAlf"}
{"word": ["Box."], "author": "gixgox"}
{"word": ["cutter"], "author": "Ardal"}
{"word": ["Ring."], "author": "REDVWIN"}
{"word": ["call"], "author": "Namxas01"}
{"word": ["Duty... ", " ", " ", " (sorry...)"], "author": "toxicTom"}
{"word": ["Honor"], "author": "mm324"}
{"word": ["For"], "author": "GandalftheCool"}
{"word": ["Hickory."], "author": "Kleetus"}
{"word": [" against"], "author": "TARFU"}
{"word": [" Hickory."], "author": "Kleetus"}
{"word": ["Stick."], "author": "vidsgame"}
{"word": ["Figure."], "author": "gixgox"}
{"word": ["shape"], "author": "le_chevalier"}
{"word": ["mold"], "author": "mm324"}
{"word": ["spore"], "author": "Dzsono"}
{"word": ["spread"], "author": "le_chevalier"}
{"word": ["Wildfire."], "author": "vidsgame"}
{"word": [], "author": "gixgox"}
{"word": ["Flame"], "author": "nebulosas"}
{"word": ["On."], "author": "codefenix"}
{"word": ["off"], "author": "Accatone"}
{"word": ["Topic"], "author": "Zoltan999"}
{"word": ["Subject."], "author": "Narcia_"}
{"word": ["Course."], "author": "codefenix"}
{"word": ["obstacle"], "author": "park_84"}
{"word": ["Parkour."], "author": "toxicTom"}
{"word": ["Athletics"], "author": "GandalftheCool"}
{"word": ["sports"], "author": "mm324"}
{"word": ["stadium"], "author": "TARFU"}
{"word": [" Games."], "author": "Kleetus"}
{"word": ["GoG"], "author": "Tcharr"}
{"word": [" Arena."], "author": "gixgox"}
{"word": ["Sand."], "author": "LoboBlanco"}
{"word": ["Desert"], "author": "GandalftheCool"}
{"word": ["defect"], "author": "le_chevalier"}
{"word": ["abscond"], "author": "Dzsono"}
{"word": ["Leave"], "author": "Yezemin"}
{"word": ["Abandon."], "author": "toxicTom"}
{"word": ["band"], "author": "Accatone"}
{"word": ["Aid."], "author": "gixgox"}
{"word": ["Help"], "author": "Zoltan999"}
{"word": ["Mayday!"], "author": "gixgox"}
{"word": ["SOS!!"], "author": "REDVWIN"}
{"word": ["Morse."], "author": "codefenix"}
{"word": ["Code."], "author": "Narcia_"}
{"word": ["cracker"], "author": "Ardal"}
{"word": ["safe"], "author": "mm324"}
{"word": ["Haven."], "author": "codefenix"}
{"word": ["heaven"], "author": "park_84"}
{"word": ["hell"], "author": "mm324"}
{"word": ["Highway"], "author": "truhlik"}
{"word": ["Downtown."], "author": "gixgox"}
{"word": ["Traffic."], "author": "codefenix"}
{"word": ["Sign"], "author": "mm324"}
{"word": ["Language"], "author": "GandalftheCool"}
{"word": ["Arts"], "author": "mm324"}
{"word": ["Painting"], "author": "GandalftheCool"}
{"word": ["Sculpture."], "author": "gixgox"}
{"word": ["Statue"], "author": "GandalftheCool"}
{"word": ["liberty"], "author": "Ardal"}
{"word": ["Justice"], "author": "GandalftheCool"}
{"word": ["Poetic."], "author": "codefenix"}
{"word": ["Equality. ", " "], "author": "gixgox"}
{"word": [" Dramatic."], "author": "Kleetus"}
{"word": [" fraternity"], "author": "TARFU"}
{"word": [" Dramatic."], "author": "Kleetus"}
{"word": [], "author": "vidsgame"}
{"word": ["Euro"], "author": "Tcharr"}
{"word": ["Value"], "author": "skimmie"}
{"word": ["price"], "author": "le_chevalier"}
{"word": ["rice"], "author": "Accatone"}
{"word": ["Mice."], "author": "gixgox"}
{"word": ["."], "author": "codefenix"}
{"word": ["Vermin"], "author": "Zoltan999"}
{"word": ["rats"], "author": "mm324"}
{"word": ["rotends"], "author": "ashwald"}
{"word": ["rodents"], "author": "park_84"}
{"word": ["gerbil"], "author": "Ardal"}
{"word": ["Kangaroo-rat."], "author": "Narcia_"}
{"word": [], "author": "gixgox"}
{"word": ["gargoyle"], "author": "Dzsono"}
{"word": ["Gothic"], "author": "Azrael360"}
{"word": ["emo"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": ["Emulator."], "author": "VampiroAlhazred"}
{"word": ["Vibrator."], "author": "Kleetus"}
{"word": [" Emulsifier."], "author": "gixgox"}
{"word": ["emulgent"], "author": "le_chevalier"}
{"word": ["coagulant"], "author": "Dzsono"}
{"word": ["blood"], "author": "nicohvc"}
{"word": ["loot"], "author": "Accatone"}
{"word": ["Loom"], "author": "shadow1980jpv"}
{"word": ["weaver"], "author": "mm324"}
{"word": [], "author": "Zoltan999"}
{"word": [], "author": "codefenix"}
{"word": ["Stage."], "author": "gixgox"}
{"word": ["Prop."], "author": "Narcia_"}
{"word": ["Up."], "author": "codefenix"}
{"word": ["down"], "author": "park_84"}
{"word": [" ..."], "author": "gixgox"}
{"word": [" Below."], "author": "Kleetus"}
{"word": ["Under"], "author": "Zoltan999"}
{"word": ["over"], "author": "mm324"}
{"word": ["Across"], "author": "TARFU"}
{"word": ["Crossword."], "author": "gixgox"}
{"word": ["cryptic"], "author": "Dzsono"}
{"word": ["note"], "author": "ashwald"}
{"word": ["book"], "author": "gixgox"}
{"word": ["hook ", " ", " EDIT: Ninja'd"], "author": "Accatone"}
{"word": [" Pimp"], "author": "koima57"}
{"word": [" "], "author": "mm324"}
{"word": ["Award."], "author": "REDVWIN"}
{"word": ["Trophy"], "author": "skimmie"}
{"word": ["Wife"], "author": "Zoltan999"}
{"word": ["mate"], "author": "mm324"}
{"word": ["."], "author": "gixgox"}
{"word": ["Friend"], "author": "TDP"}
{"word": ["close"], "author": "Ardal"}
{"word": ["open"], "author": "Kaesemeister"}
{"word": ["Wide"], "author": "Cavenagh"}
{"word": ["Load."], "author": "codefenix"}
{"word": ["Front."], "author": "Narcia_"}
{"word": ["Back"], "author": "GandalftheCool"}
{"word": [" "], "author": "gixgox"}
{"word": ["Boys"], "author": "GandalftheCool"}
{"word": ["To"], "author": "codefenix"}
{"word": ["Too."], "author": "viperfdl"}
{"word": ["additional"], "author": "Ardal"}
{"word": ["Extra"], "author": "le_chevalier"}
{"word": ["Plus."], "author": "gixgox"}
{"word": [" More."], "author": "Kleetus"}
{"word": [" additional"], "author": "TARFU"}
{"word": ["Bonus."], "author": "gixgox"}
{"word": ["More."], "author": "Kleetus"}
{"word": [" Feature"], "author": "Yezemin"}
{"word": ["star"], "author": "Dzsono"}
{"word": ["pentagram"], "author": "le_chevalier"}
{"word": ["inverted ", " ", " "], "author": "park_84"}
{"word": ["mirrored"], "author": "Ardal"}
{"word": ["Reflective."], "author": "Narcia_"}
{"word": ["Surface"], "author": "Zoltan999"}
{"word": ["Microsoft"], "author": "Kaesemeister"}
{"word": ["Windows"], "author": "nebulosas"}
{"word": ["doors"], "author": "apehater"}
{"word": ["Locks."], "author": "gixgox"}
{"word": ["Keys"], "author": "Kaesemeister"}
{"word": ["Codes"], "author": "Azrael360"}
{"word": [], "author": "gixgox"}
{"word": [" Languages"], "author": "Kleetus"}
{"word": [" message"], "author": "TARFU"}
{"word": ["Sexting"], "author": "Kaesemeister"}
{"word": ["chat"], "author": "park_84"}
{"word": ["talk"], "author": "mm324"}
{"word": ["gossip"], "author": "rtcvb32"}
{"word": ["rumor"], "author": "mm324"}
{"word": ["Spread"], "author": "Kaesemeister"}
{"word": ["legs"], "author": "Kleetus"}
{"word": ["knee"], "author": "Kaesemeister"}
{"word": ["arrow"], "author": "le_chevalier"}
{"word": ["straight"], "author": "Dzsono"}
{"word": ["vertical"], "author": "Kaesemeister"}
{"word": ["line"], "author": "park_84"}
{"word": ["circle"], "author": "camplify"}
{"word": ["circuit"], "author": "le_chevalier"}
{"word": ["circa"], "author": "Accatone"}
{"word": ["circus"], "author": "park_84"}
{"word": ["clown"], "author": "Kaesemeister"}
{"word": ["Creepy."], "author": "gixgox"}
{"word": ["nightmarish"], "author": "Dzsono"}
{"word": ["spooky"], "author": "ashwald"}
{"word": [], "author": "park_84"}
{"word": ["Spork."], "author": "Narcia_"}
{"word": ["Spock."], "author": "gixgox"}
{"word": ["Logical"], "author": "Yezemin"}
{"word": ["Conclusion"], "author": "Zoltan999"}
{"word": ["Result."], "author": "viperfdl"}
{"word": ["Consequence"], "author": "nebulosas"}
{"word": ["unforeseen"], "author": "Ardal"}
{"word": ["unexpected"], "author": "TARFU"}
{"word": [" Sudden."], "author": "Kleetus"}
{"word": ["Strike"], "author": "Kaesemeister"}
{"word": ["Baseball"], "author": "mm324"}
{"word": ["Bat"], "author": "GandalftheCool"}
{"word": ["glove"], "author": "mm324"}
{"word": ["leather"], "author": "ashwald"}
{"word": ["underwear"], "author": "Kleetus"}
{"word": ["Edit: Lingerie."], "author": "viperfdl"}
{"word": ["seduction"], "author": "Dzsono"}
{"word": ["Incredible."], "author": "REDVWIN"}
{"word": ["Unbelievable"], "author": "Yezemin"}
{"word": ["Extraordinary."], "author": "gixgox"}
{"word": ["ordinary"], "author": "Accatone"}
{"word": ["Normal"], "author": "le_chevalier"}
{"word": ["average"], "author": "Ardal"}
{"word": ["Joe."], "author": "codefenix"}
{"word": ["Coffee!"], "author": "Zoltan999"}
{"word": ["Beans."], "author": "gixgox"}
{"word": ["Pork."], "author": "Narcia_"}
{"word": ["pig"], "author": "park_84"}
{"word": ["gammon"], "author": "Kaesemeister"}
{"word": ["bacon"], "author": "mm324"}
{"word": ["wine"], "author": "Kaesemeister"}
{"word": ["Grapes"], "author": "nebulosas"}
{"word": ["Seeds"], "author": "Kaesemeister"}
{"word": ["kernel"], "author": "Ardal"}
{"word": ["Linux"], "author": "Kaesemeister"}
{"word": ["Unix"], "author": "TARFU"}
{"word": [" Colonel"], "author": "Kleetus"}
{"word": [" kernel"], "author": "Dzsono"}
{"word": ["shell"], "author": "le_chevalier"}
{"word": ["Fish."], "author": "gixgox"}
{"word": [" Crustacean."], "author": "Kleetus"}
{"word": ["prawn"], "author": "Ardal"}
{"word": ["Pawn."], "author": "codefenix"}
{"word": ["Shop"], "author": "mm324"}
{"word": ["Store"], "author": "nebulosas"}
{"word": ["cache"], "author": "mm324"}
{"word": ["hidden"], "author": "Ardal"}
{"word": ["Disguised."], "author": "Narcia_"}
{"word": ["Camouflage"], "author": "toxicTom"}
{"word": ["Invisible."], "author": "viperfdl"}
{"word": ["Stealth."], "author": "gixgox"}
{"word": ["Cloak"], "author": "TDP"}
{"word": ["Dagger."], "author": "codefenix"}
{"word": ["Assassin"], "author": "Kaesemeister"}
{"word": ["sneaky"], "author": "ashwald"}
{"word": ["big"], "author": "kmonster"}
{"word": ["slimey"], "author": "Kleetus"}
{"word": [" large"], "author": "TARFU"}
{"word": ["Gigantic."], "author": "gixgox"}
{"word": [" large"], "author": "Kleetus"}
{"word": ["behemoth"], "author": "Dzsono"}
{"word": ["gargantuan"], "author": "le_chevalier"}
{"word": ["Megalithic."], "author": "Hickory"}
{"word": ["slab"], "author": "Dzsono"}
{"word": ["Stone"], "author": "Yezemin"}
{"word": [" -deaf"], "author": "gixgox"}
{"word": ["dead"], "author": "Cadaver747"}
{"word": ["Buried."], "author": "codefenix"}
{"word": ["Alive"], "author": "Zoltan999"}
{"word": ["living"], "author": "mm324"}
{"word": ["dead"], "author": "ashwald"}
{"word": ["graveyard"], "author": "Ardal"}
{"word": ["bones"], "author": "GandalftheCool"}
{"word": ["Doggy."], "author": "gixgox"}
{"word": ["Kitty"], "author": "GandalftheCool"}
{"word": ["tasty"], "author": "apehater"}
{"word": ["delicious"], "author": "park_84"}
{"word": ["Exquisite"], "author": "toxicTom"}
{"word": ["exceptional"], "author": "Dzsono"}
{"word": ["unique"], "author": "nicohvc"}
{"word": ["special"], "author": "le_chevalier"}
{"word": ["Rare"], "author": "shadow1980jpv"}
{"word": ["are"], "author": "Accatone"}
{"word": ["Unusual."], "author": "Hickory"}
{"word": [" Missed you Hicks, where have you been, boarding?"], "author": "Kleetus"}
{"word": ["Kleetus"], "author": "Cavenagh"}
{"word": [" Precious."], "author": "gixgox"}
{"word": ["Ring."], "author": "Hickory"}
{"word": ["Boxing"], "author": "cose_vecchie"}
{"word": ["Day"], "author": "Zoltan999"}
{"word": ["Break."], "author": "codefenix"}
{"word": ["Lunch"], "author": "mm324"}
{"word": ["Box."], "author": "Hickory"}
{"word": ["cardboard"], "author": "mm324"}
{"word": ["Cutout."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["Splinter."], "author": "codefenix"}
{"word": ["Cell"], "author": "GandalftheCool"}
{"word": [], "author": "park_84"}
{"word": ["evil"], "author": "TARFU"}
{"word": ["Despicable"], "author": "GandalftheCool"}
{"word": ["minions"], "author": "ashwald"}
{"word": ["hilarious"], "author": "mm324"}
{"word": ["laughter"], "author": "kmonster"}
{"word": ["fit"], "author": "gixgox"}
{"word": ["clothing"], "author": "cose_vecchie"}
{"word": ["Jacket"], "author": "PaterAlf"}
{"word": ["Overcoat"], "author": "TARFU"}
{"word": [" Attire."], "author": "Kleetus"}
{"word": [" Mackintosh."], "author": "gixgox"}
{"word": ["Attire."], "author": "Kleetus"}
{"word": [" Gumboots."], "author": "Hickory"}
{"word": ["Attire."], "author": "Kleetus"}
{"word": [" Galoshes."], "author": "gixgox"}
{"word": ["Attire."], "author": "Kleetus"}
{"word": [" Wellingtons. [\"Wellies\"]"], "author": "Hickory"}
{"word": [". ", " ", " "], "author": "gixgox"}
{"word": ["dish"], "author": "Ardal"}
{"word": ["Plate."], "author": "Gravest"}
{"word": ["Bowl."], "author": "gixgox"}
{"word": ["spoon"], "author": "mm324"}
{"word": ["Dinner"], "author": "Azrael360"}
{"word": ["Party"], "author": "mm324"}
{"word": ["Animal."], "author": "Hickory"}
{"word": ["Dog."], "author": "Kleetus"}
{"word": [" Plant."], "author": "gixgox"}
{"word": ["Dog."], "author": "Kleetus"}
{"word": ["tinywee."], "author": "Tauto"}
{"word": ["green"], "author": "BlackDawn"}
{"word": ["grass"], "author": "mm324"}
{"word": ["Lawn"], "author": "toxicTom"}
{"word": ["garden"], "author": "le_chevalier"}
{"word": ["Fence."], "author": "gixgox"}
{"word": [" Fence."], "author": "Kleetus"}
{"word": ["Defence"], "author": "toxicTom"}
{"word": ["Defenestration."], "author": "gixgox"}
{"word": [" Protection."], "author": "Kleetus"}
{"word": [" plummet"], "author": "Dzsono"}
{"word": ["Protection."], "author": "Kleetus"}
{"word": [" Hurtle."], "author": "Hickory"}
{"word": ["Fling."], "author": "toxicTom"}
{"word": ["around"], "author": "Ardal"}
{"word": ["round"], "author": "Accatone"}
{"word": ["Circle"], "author": "Yezemin"}
{"word": ["indistinguishable..."], "author": "GhostwriterDoF"}
{"word": ["Homogeneous."], "author": "Hickory"}
{"word": ["Boring"], "author": "Zoltan999"}
{"word": ["Intriguing."], "author": "Narcia_"}
{"word": ["yeeeeeeeeeeessssssssssssssssss"], "author": "ashwald"}
{"word": [" noooooooooooooooooo ;)"], "author": "Accatone"}
{"word": ["Eh???"], "author": "gixgox"}
{"word": ["What?"], "author": "codefenix"}
{"word": ["Where?"], "author": "mm324"}
{"word": ["When?"], "author": "Hickory"}
{"word": ["Now."], "author": "codefenix"}
{"word": ["Procrastinating."], "author": "gixgox"}
{"word": [" How."], "author": "Kleetus"}
{"word": ["Cow"], "author": "Pier045"}
{"word": [" Dilly-dally."], "author": "Hickory"}
{"word": ["Loiter"], "author": "toxicTom"}
{"word": ["wait"], "author": "TARFU"}
{"word": ["pause"], "author": "mm324"}
{"word": ["play"], "author": "park_84"}
{"word": ["rewind"], "author": "mm324"}
{"word": ["relive"], "author": "Dzsono"}
{"word": ["Reboot"], "author": "Madshaker"}
{"word": ["restart"], "author": "le_chevalier"}
{"word": ["reborn"], "author": "park_84"}
{"word": ["phoenix"], "author": "Accatone"}
{"word": ["Ashes"], "author": "Yezemin"}
{"word": ["death"], "author": "camplify"}
{"word": ["certainty"], "author": "le_chevalier"}
{"word": ["Absolute"], "author": "Zoltan999"}
{"word": [" God"], "author": "deathrabit"}
{"word": [" Which?"], "author": "gixgox"}
{"word": ["Choose."], "author": "Hickory"}
{"word": ["Cheese."], "author": "viperfdl"}
{"word": ["Cheddar"], "author": "Gravest"}
{"word": ["Toasted."], "author": "Hickory"}
{"word": ["Chestnut... :D"], "author": "GhostwriterDoF"}
{"word": ["Delicious!"], "author": "Hickory"}
{"word": ["liking"], "author": "Ardal"}
{"word": ["Licking."], "author": "Kleetus"}
{"word": ["Lacking"], "author": "jakeryan72"}
{"word": ["deficient"], "author": "mm324"}
{"word": ["substandard"], "author": "Dzsono"}
{"word": ["Content."], "author": "Narcia_"}
{"word": ["satisfaction"], "author": "le_chevalier"}
{"word": ["substance"], "author": "TARFU"}
{"word": ["Abuse."], "author": "gixgox"}
{"word": [" Enjoyment."], "author": "Kleetus"}
{"word": [" Persecute."], "author": "Hickory"}
{"word": ["Bother."], "author": "Casval_Deikun"}
{"word": ["Brother."], "author": "viperfdl"}
{"word": ["Big"], "author": "Zoltan999"}
{"word": ["Foot."], "author": "gixgox"}
{"word": ["Print."], "author": "Hickory"}
{"word": ["Type."], "author": "Narcia_"}
{"word": ["Writer."], "author": "Hickory"}
{"word": ["Ghost."], "author": "viperfdl"}
{"word": ["host"], "author": "Accatone"}
{"word": ["party"], "author": "mm324"}
{"word": ["Political."], "author": "Hickory"}
{"word": ["bureaucrat"], "author": "TARFU"}
{"word": [" Function."], "author": "Kleetus"}
{"word": [" Faceless."], "author": "Hickory"}
{"word": ["Function."], "author": "Kleetus"}
{"word": [" Faceless."], "author": "Hickory"}
{"word": ["blank"], "author": "Dzsono"}
{"word": ["slate"], "author": "ashwald"}
{"word": ["granite"], "author": "mm324"}
{"word": ["Slab"], "author": "Zoltan999"}
{"word": ["plank"], "author": "le_chevalier"}
{"word": ["Pole."], "author": "REDVWIN"}
{"word": ["North."], "author": "gixgox"}
{"word": ["south"], "author": "Accatone"}
{"word": ["West"], "author": "Yezemin"}
{"word": ["Sunset."], "author": "Hickory"}
{"word": ["Dusk"], "author": "Yezemin"}
{"word": ["dawn"], "author": "ashwald"}
{"word": [], "author": "Zoltan999"}
{"word": ["walking"], "author": "park_84"}
{"word": ["."], "author": "gixgox"}
{"word": ["notes"], "author": "Ardal"}
{"word": ["Melodious... :P"], "author": "GhostwriterDoF"}
{"word": ["lyrical"], "author": "mm324"}
{"word": ["."], "author": "Hickory"}
{"word": ["intensify"], "author": "mm324"}
{"word": ["Praising."], "author": "viperfdl"}
{"word": ["Compliment"], "author": "TARFU"}
{"word": ["flattery"], "author": "le_chevalier"}
{"word": ["Flirt"], "author": "PaterAlf"}
{"word": ["date"], "author": "Accatone"}
{"word": ["expiry"], "author": "cose_vecchie"}
{"word": ["Spoiled"], "author": "TDP"}
{"word": ["rotten"], "author": "ashwald"}
{"word": ["Putrid."], "author": "Hickory"}
{"word": ["Disgusting"], "author": "Zoltan999"}
{"word": ["horrid"], "author": "mm324"}
{"word": ["torrid"], "author": "park_84"}
{"word": ["Sun-baked."], "author": "gixgox"}
{"word": ["Dried."], "author": "Narcia_"}
{"word": ["Freeze."], "author": "codefenix"}
{"word": ["Solidify."], "author": "Hickory"}
{"word": ["harden"], "author": "mm324"}
{"word": ["tone"], "author": "kmonster"}
{"word": ["Tune"], "author": "Azrael360"}
{"word": ["Tuna."], "author": "gixgox"}
{"word": ["Fish"], "author": "GandalftheCool"}
{"word": ["angler"], "author": "Dzsono"}
{"word": ["lure"], "author": "le_chevalier"}
{"word": ["entice"], "author": "TARFU"}
{"word": ["Entire."], "author": "Casval_Deikun"}
{"word": ["entity"], "author": "Accatone"}
{"word": ["being"], "author": "mm324"}
{"word": ["[Ninja'd] ", " ", " Soul."], "author": "Hickory"}
{"word": ["transcendent"], "author": "Dzsono"}
{"word": ["Supramundane."], "author": "gixgox"}
{"word": ["generic"], "author": "GabesterOne"}
{"word": ["oops! misread it ", " congenital ", " ", " "], "author": "mm324"}
{"word": ["bland"], "author": "skimmie"}
{"word": ["Plain."], "author": "codefenix"}
{"word": ["plateau"], "author": "cose_vecchie"}
{"word": ["deep"], "author": "kmonster"}
{"word": ["."], "author": "gixgox"}
{"word": [], "author": "tinyE"}
{"word": ["ART"], "author": "Xaviercrow"}
{"word": ["Fart."], "author": "Kleetus"}
{"word": [" Late."], "author": "Hickory"}
{"word": [" Fart."], "author": "Kleetus"}
{"word": [" tardy"], "author": "Dzsono"}
{"word": ["Fart."], "author": "Kleetus"}
{"word": [" Belated."], "author": "gixgox"}
{"word": ["birthday"], "author": "TARFU"}
{"word": ["Candle."], "author": "gixgox"}
{"word": ["Light"], "author": "GandalftheCool"}
{"word": ["beer"], "author": "Tcharr"}
{"word": ["Alcohol."], "author": "Casval_Deikun"}
{"word": ["Proof."], "author": "Hickory"}
{"word": ["burden"], "author": "le_chevalier"}
{"word": ["heavy"], "author": "ashwald"}
{"word": ["overweight"], "author": "nebulosas"}
{"word": ["skinny"], "author": "Accatone"}
{"word": ["bones"], "author": "Ardal"}
{"word": ["Marrow"], "author": "Zoltan999"}
{"word": ["narrow"], "author": "park_84"}
{"word": ["Slender."], "author": "gixgox"}
{"word": ["slim"], "author": "mm324"}
{"word": ["Fast."], "author": "codefenix"}
{"word": [], "author": "gixgox"}
{"word": ["Siren?"], "author": "Narcia_"}
{"word": ["sea"], "author": "nebulosas"}
{"word": ["Burial"], "author": "TaoTekko"}
{"word": ["Inter."], "author": "Hickory"}
{"word": [" Entombment."], "author": "Kleetus"}
{"word": [" Inter."], "author": "Hickory"}
{"word": ["Entombment."], "author": "Kleetus"}
{"word": [" Grave"], "author": "koima57"}
{"word": ["death"], "author": "camplify"}
{"word": [" Inter."], "author": "Hickory"}
{"word": ["crypt"], "author": "TARFU"}
{"word": [" Expiry."], "author": "Kleetus"}
{"word": [" Decryption"], "author": "GandalftheCool"}
{"word": ["Expiry."], "author": "Kleetus"}
{"word": [" Code."], "author": "Hickory"}
{"word": ["Name"], "author": "GandalftheCool"}
{"word": [" Language."], "author": "Kleetus"}
{"word": [" Address."], "author": "gixgox"}
{"word": [" Entombment."], "author": "Kleetus"}
{"word": [" Postal"], "author": "GandalftheCool"}
{"word": [" Speech."], "author": "Kleetus"}
{"word": [" Code."], "author": "gixgox"}
{"word": ["Morse"], "author": "GandalftheCool"}
{"word": ["sea-lion"], "author": "le_chevalier"}
{"word": ["Chimera."], "author": "Hickory"}
{"word": ["Manticore"], "author": "nebulosas"}
{"word": [], "author": "Dzsono"}
{"word": ["scorpion"], "author": "Accatone"}
{"word": ["sting"], "author": "ashwald"}
{"word": ["Venom"], "author": "Zoltan999"}
{"word": ["toxin"], "author": "Ardal"}
{"word": ["Cure."], "author": "Narcia_"}
{"word": ["Remedy."], "author": "codefenix"}
{"word": ["antidote"], "author": "mm324"}
{"word": ["drug"], "author": "GabesterOne"}
{"word": ["Addiction"], "author": "GandalftheCool"}
{"word": [" Dose."], "author": "Kleetus"}
{"word": [" Habit."], "author": "gixgox"}
{"word": [" Medication."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Medication."], "author": "Kleetus"}
{"word": ["prescription"], "author": "JDelekto"}
{"word": [" Anchorite,"], "author": "gixgox"}
{"word": [" Directive."], "author": "Kleetus"}
{"word": ["Director"], "author": "tort1234"}
{"word": [" Hermit."], "author": "Hickory"}
{"word": [" Administrator."], "author": "Kleetus"}
{"word": [" Crab"], "author": "GandalftheCool"}
{"word": ["Horseshoe"], "author": "Tcharr"}
{"word": ["Horse"], "author": "TARFU"}
{"word": [" Plate."], "author": "Kleetus"}
{"word": ["Dish"], "author": "JDelekto"}
{"word": ["Bowl"], "author": "Madshaker"}
{"word": ["Bowler."], "author": "gixgox"}
{"word": [" Vessel."], "author": "Kleetus"}
{"word": [" hat"], "author": "Dzsono"}
{"word": ["."], "author": "Hickory"}
{"word": ["cap"], "author": "Gravest"}
{"word": ["Dishes."], "author": "Casval_Deikun"}
{"word": ["Washed"], "author": "Tcharr"}
{"word": ["Wiped"], "author": "le_chevalier"}
{"word": ["Clean"], "author": "Azrael360"}
{"word": ["clan"], "author": "park_84"}
{"word": ["lan"], "author": "Accatone"}
{"word": ["Party."], "author": "gixgox"}
{"word": ["doll"], "author": "le_chevalier"}
{"word": ["Puppet."], "author": "viperfdl"}
{"word": ["strings"], "author": "Ardal"}
{"word": ["woodwinds"], "author": "JDelekto"}
{"word": ["Oboe :o"], "author": "Tcharr"}
{"word": ["Clarinet"], "author": "Zoltan999"}
{"word": ["Claret."], "author": "Narcia_"}
{"word": ["Fine."], "author": "Hickory"}
{"word": ["Penalty."], "author": "gixgox"}
{"word": ["Consequences"], "author": "TDP"}
{"word": [" Rewards"], "author": "NinjaShadow24"}
{"word": ["prizes"], "author": "mm324"}
{"word": ["gifts"], "author": "TARFU"}
{"word": [" Booty."], "author": "Kleetus"}
{"word": [" Alms."], "author": "Hickory"}
{"word": [" Booty."], "author": "Kleetus"}
{"word": [" Alms."], "author": "Hickory"}
{"word": [" Gifts."], "author": "Kleetus"}
{"word": [" Alms."], "author": "Hickory"}
{"word": [" Prizes."], "author": "Kleetus"}
{"word": [" Gratification."], "author": "gixgox"}
{"word": [" Booty."], "author": "Kleetus"}
{"word": [" Indulgence."], "author": "Hickory"}
{"word": ["decadence"], "author": "le_chevalier"}
{"word": ["Gluttony"], "author": "Zoltan999"}
{"word": ["obesity"], "author": "mm324"}
{"word": ["Epidemic."], "author": "Narcia_"}
{"word": ["Widespread."], "author": "codefenix"}
{"word": ["Ubiquitous."], "author": "Hickory"}
{"word": [" Distributed."], "author": "Kleetus"}
{"word": [" Ubiquitous."], "author": "Hickory"}
{"word": [" Far-flung."], "author": "Kleetus"}
{"word": ["gone"], "author": "kmonster"}
{"word": ["lost"], "author": "Ardal"}
{"word": ["found"], "author": "Dzsono"}
{"word": ["discovered"], "author": "TARFU"}
{"word": ["spotted"], "author": "le_chevalier"}
{"word": ["Wally"], "author": "park_84"}
{"word": ["Woody."], "author": "viperfdl"}
{"word": ["Sheriff"], "author": "nebulosas"}
{"word": ["marshall"], "author": "nicohvc"}
{"word": ["plan"], "author": "le_chevalier"}
{"word": ["Master"], "author": "Zoltan999"}
{"word": [" "], "author": "mm324"}
{"word": ["Sound."], "author": "Hickory"}
{"word": ["safe"], "author": "le_chevalier"}
{"word": ["practice"], "author": "ashwald"}
{"word": ["Private."], "author": "codefenix"}
{"word": ["Personal."], "author": "gixgox"}
{"word": ["space"], "author": "Dzsono"}
{"word": ["void"], "author": "TARFU"}
{"word": ["Pinhole."], "author": "gixgox"}
{"word": ["Pigeon-hole."], "author": "Hickory"}
{"word": ["Confine."], "author": "Narcia_"}
{"word": ["limit"], "author": "le_chevalier"}
{"word": ["Break."], "author": "codefenix"}
{"word": [" ", " ", " ", " ~This looked like it had so much potential :-("], "author": "Zoltan999"}
{"word": ["chaos"], "author": "park_84"}
{"word": ["Confusion"], "author": "nebulosas"}
{"word": ["Bewilderment."], "author": "Hickory"}
{"word": ["confusedness"], "author": "mm324"}
{"word": ["bedlam"], "author": "Ardal"}
{"word": ["Pandemonium."], "author": "Hickory"}
{"word": [" Mayhem."], "author": "Kleetus"}
{"word": [" Havoc."], "author": "gixgox"}
{"word": ["chaos"], "author": "TARFU"}
{"word": ["Order"], "author": "GandalftheCool"}
{"word": [" Confusion."], "author": "Kleetus"}
{"word": [" Law."], "author": "gixgox"}
{"word": [" Leech."], "author": "Kleetus"}
{"word": [" Enforcer."], "author": "Hickory"}
{"word": [" Scab."], "author": "Kleetus"}
{"word": [" Executor."], "author": "gixgox"}
{"word": ["executioneer"], "author": "le_chevalier"}
{"word": ["Headsman"], "author": "GandalftheCool"}
{"word": ["Herdsman."], "author": "Hickory"}
{"word": [" Killer."], "author": "Kleetus"}
{"word": [" Ranger"], "author": "Dzsono"}
{"word": [" Killer."], "author": "Kleetus"}
{"word": [" Hunter."], "author": "gixgox"}
{"word": [" Mayhem."], "author": "Kleetus"}
{"word": [" Killer."], "author": "Hickory"}
{"word": [" Instinct."], "author": "gixgox"}
{"word": [" Primal."], "author": "Gravest"}
{"word": ["rage"], "author": "park_84"}
{"word": ["inner"], "author": "Ardal"}
{"word": ["Demons."], "author": "viperfdl"}
{"word": ["anxiety"], "author": "Accatone"}
{"word": ["Sweat."], "author": "Hickory"}
{"word": ["-pants"], "author": "Lifthrasil"}
{"word": ["Shoes."], "author": "codefenix"}
{"word": ["Cobbler."], "author": "Hickory"}
{"word": [], "author": "le_chevalier"}
{"word": ["Hatter"], "author": "Zoltan999"}
{"word": ["Milliner."], "author": "Hickory"}
{"word": ["Modiste."], "author": "gixgox"}
{"word": ["seamstress"], "author": "mm324"}
{"word": ["Clothes"], "author": "nebulosas"}
{"word": ["Apparel"], "author": "Azrael360"}
{"word": ["Attire."], "author": "Hickory"}
{"word": [" Fur."], "author": "Kleetus"}
{"word": [" Outfit."], "author": "gixgox"}
{"word": ["Provision."], "author": "Hickory"}
{"word": ["bunker"], "author": "park_84"}
{"word": ["Buster."], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["river"], "author": "TARFU"}
{"word": ["cry"], "author": "le_chevalier"}
{"word": ["tears"], "author": "Sage103082"}
{"word": ["Sadness"], "author": "GandalftheCool"}
{"word": [" sorrow"], "author": "Kleetus"}
{"word": [" Melancholy."], "author": "Hickory"}
{"word": ["rain"], "author": "park_84"}
{"word": ["Snow."], "author": "gixgox"}
{"word": ["falling"], "author": "Ardal"}
{"word": ["meltdown"], "author": "Accatone"}
{"word": ["Reactor"], "author": "Zoltan999"}
{"word": ["reagent"], "author": "le_chevalier"}
{"word": ["Catalyst."], "author": "codefenix"}
{"word": ["Accelerator."], "author": "Hickory"}
{"word": ["decelerator"], "author": "mm324"}
{"word": ["Inhibitor."], "author": "gixgox"}
{"word": ["frequency"], "author": "park_84"}
{"word": ["Prevalence"], "author": "nebulosas"}
{"word": ["Ubiquitous."], "author": "Hickory"}
{"word": ["encompassing"], "author": "TARFU"}
{"word": [" Number."], "author": "Kleetus"}
{"word": ["iam really a nice girl to talk to ", " ", " ", " just saying u guys act you scared to talk to me"], "author": "kaylayuhos26"}
{"word": [" I know how you feel, they won't talk to me either."], "author": "Kleetus"}
{"word": [" Enclosure."], "author": "Hickory"}
{"word": ["Framed"], "author": "Sage103082"}
{"word": ["Photo."], "author": "Narcia_"}
{"word": ["Pic"], "author": "GandalftheCool"}
{"word": ["mural"], "author": "Dzsono"}
{"word": ["mosaic"], "author": "le_chevalier"}
{"word": ["Tesserae."], "author": "gixgox"}
{"word": ["tesseract"], "author": "le_chevalier"}
{"word": ["Hypercube."], "author": "Hickory"}
{"word": ["Infinity."], "author": "VampiroAlhazred"}
{"word": ["engine"], "author": "ashwald"}
{"word": ["piston"], "author": "park_84"}
{"word": ["brake"], "author": "Ardal"}
{"word": ["Drum"], "author": "Zoltan999"}
{"word": ["Beat."], "author": "viperfdl"}
{"word": ["Plurality."], "author": "GhostwriterDoF"}
{"word": ["singular"], "author": "Accatone"}
{"word": ["individual"], "author": "mm324"}
{"word": ["Particulate."], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["Discontinued"], "author": "nebulosas"}
{"word": ["Ended"], "author": "Sage103082"}
{"word": ["Finito."], "author": "gixgox"}
{"word": ["done"], "author": "Sage103082"}
{"word": ["Finished."], "author": "viperfdl"}
{"word": ["completed"], "author": "TARFU"}
{"word": ["Concluded."], "author": "Hickory"}
{"word": ["Icebound."], "author": "gixgox"}
{"word": ["Frigid."], "author": "Hickory"}
{"word": ["Cold"], "author": "GandalftheCool"}
{"word": ["Butt-freezing."], "author": "gixgox"}
{"word": [], "author": "park_84"}
{"word": ["dead"], "author": "kmonster"}
{"word": ["comatose"], "author": "Sage103082"}
{"word": [" end"], "author": "mm324"}
{"word": ["retire"], "author": "Dzsono"}
{"word": ["retreat"], "author": "le_chevalier"}
{"word": ["Skedaddle."], "author": "Hickory"}
{"word": ["bullshit"], "author": "Sage103082"}
{"word": ["Fertilizer."], "author": "Narcia_"}
{"word": ["soil"], "author": "le_chevalier"}
{"word": ["Clod."], "author": "gixgox"}
{"word": ["Dolt."], "author": "Gravest"}
{"word": ["Trump"], "author": "richlind33"}
{"word": ["card"], "author": "le_chevalier"}
{"word": ["credit"], "author": "JDelekto"}
{"word": ["debt"], "author": "richlind33"}
{"word": ["forgiveness"], "author": "JDelekto"}
{"word": ["peace"], "author": "Accatone"}
{"word": ["incorporated"], "author": "ashwald"}
{"word": ["dispersed"], "author": "JDelekto"}
{"word": ["Diffused."], "author": "gixgox"}
{"word": ["blurred"], "author": "park_84"}
{"word": ["Vision."], "author": "codefenix"}
{"word": ["visionary"], "author": "Ardal"}
{"word": ["idealist"], "author": "mm324"}
{"word": ["Fantasist."], "author": "Hickory"}
{"word": [" Dreamer"], "author": "koima57"}
{"word": ["Oneiromancer."], "author": "Hickory"}
{"word": [" Sleeper."], "author": "Kleetus"}
{"word": [" Oneiromancer."], "author": "Hickory"}
{"word": ["headlock"], "author": "Sage103082"}
{"word": ["mercy"], "author": "chevkoch"}
{"word": ["forgive"], "author": "Sage103082"}
{"word": ["forget"], "author": "T.Hodd"}
{"word": ["Remember"], "author": "GandalftheCool"}
{"word": [" Neglect."], "author": "Kleetus"}
{"word": ["Flowers"], "author": "tort1234"}
{"word": ["Violets"], "author": "Sage103082"}
{"word": ["i am just trying to make Friends and i love to talk and text people and iam outgoing i dont care what age you are its how you act when you text me"], "author": "kaylayuhos26"}
{"word": [" roses"], "author": "TARFU"}
{"word": [" Purples."], "author": "Kleetus"}
{"word": ["Lilac."], "author": "gixgox"}
{"word": ["honest"], "author": "kaylayuhos26"}
{"word": [" Gooseberries."], "author": "Hickory"}
{"word": ["python"], "author": "JDelekto"}
{"word": ["programming"], "author": "Dzsono"}
{"word": ["language"], "author": "le_chevalier"}
{"word": ["Communication."], "author": "LoboBlanco"}
{"word": ["Signals."], "author": "Gravest"}
{"word": [], "author": "gixgox"}
{"word": ["Chimney."], "author": "Hickory"}
{"word": ["Sweep"], "author": "GandalftheCool"}
{"word": ["...stake."], "author": "gixgox"}
{"word": ["Tent."], "author": "Hickory"}
{"word": ["Pole"], "author": "GandalftheCool"}
{"word": ["dance"], "author": "le_chevalier"}
{"word": [" This is a sewious gaming forum, Kayla. Sewious, sewious, sewious. :p"], "author": "richlind33"}
{"word": ["Company."], "author": "gixgox"}
{"word": ["store"], "author": "richlind33"}
{"word": [" Company."], "author": "gixgox"}
{"word": [" oh"], "author": "kaylayuhos26"}
{"word": [" heroes"], "author": "le_chevalier"}
{"word": ["icons"], "author": "mm324"}
{"word": ["symbols"], "author": "Tcharr"}
{"word": ["Hieroglyphs."], "author": "Hickory"}
{"word": ["Egypt."], "author": "viperfdl"}
{"word": ["ancient"], "author": "Accatone"}
{"word": ["Ruin."], "author": "codefenix"}
{"word": ["discovery"], "author": "chevkoch"}
{"word": ["explore"], "author": "mm324"}
{"word": ["Expedition ", " ", " ", " edit: Ninja'd"], "author": "Zoltan999"}
{"word": ["Polar"], "author": "mm324"}
{"word": ["outpost"], "author": "chevkoch"}
{"word": ["Postbellum."], "author": "gixgox"}
{"word": ["Fallout."], "author": "Hickory"}
{"word": ["hazmat"], "author": "chevkoch"}
{"word": ["suit"], "author": "Ardal"}
{"word": ["tie"], "author": "GabesterOne"}
{"word": ["bowtie"], "author": "ashwald"}
{"word": ["Necktie."], "author": "codefenix"}
{"word": ["Necklace."], "author": "gixgox"}
{"word": ["Amulet."], "author": "Hickory"}
{"word": ["Talisman."], "author": "codefenix"}
{"word": ["luck"], "author": "BlackDawn"}
{"word": ["Fortune."], "author": "Hickory"}
{"word": ["Teller"], "author": "GandalftheCool"}
{"word": ["liar"], "author": "Tauto"}
{"word": [" magician"], "author": "TARFU"}
{"word": ["Wizard"], "author": "GandalftheCool"}
{"word": ["Sorcerer."], "author": "Hickory"}
{"word": ["Sorceress"], "author": "GandalftheCool"}
{"word": ["Witch"], "author": "Dzsono"}
{"word": ["Warlock"], "author": "GandalftheCool"}
{"word": ["Wand."], "author": "Narcia_"}
{"word": ["Magic"], "author": "GandalftheCool"}
{"word": ["Mushroom."], "author": "Hickory"}
{"word": ["Toadstool"], "author": "GandalftheCool"}
{"word": [" Rod."], "author": "Kleetus"}
{"word": [], "author": "Azrael360"}
{"word": ["Plunger."], "author": "gixgox"}
{"word": ["Plumbing"], "author": "tort1234"}
{"word": ["plunging"], "author": "le_chevalier"}
{"word": ["Dive"], "author": "toxicTom"}
{"word": ["Ocean"], "author": "Yezemin"}
{"word": ["depth"], "author": "chevkoch"}
{"word": ["shallow"], "author": "Accatone"}
{"word": ["Superficial."], "author": "viperfdl"}
{"word": ["chitchat"], "author": "chevkoch"}
{"word": ["Gossip"], "author": "Zoltan999"}
{"word": ["Chinwag."], "author": "Hickory"}
{"word": ["informer"], "author": "mm324"}
{"word": ["rat"], "author": "Gerin"}
{"word": ["fink"], "author": "mm324"}
{"word": ["betrayer"], "author": "Dzsono"}
{"word": ["grudge"], "author": "Ardal"}
{"word": ["[Ninja'd] ", " ", " Grievance."], "author": "Hickory"}
{"word": ["Complaint."], "author": "codefenix"}
{"word": ["patience"], "author": "chevkoch"}
{"word": ["Patient"], "author": "Yezemin"}
{"word": ["Doctor"], "author": "cose_vecchie"}
{"word": ["Strange"], "author": "GandalftheCool"}
{"word": [" Medico."], "author": "Kleetus"}
{"word": [" Life"], "author": "Dogmaus"}
{"word": ["Death"], "author": "GandalftheCool"}
{"word": [" Existence."], "author": "Kleetus"}
{"word": ["presence"], "author": "Sage103082"}
{"word": ["Gifts. ", " ", " ", " I want to rub my face in your hair."], "author": "Kleetus"}
{"word": ["creep"], "author": "Sage103082"}
{"word": ["stalker"], "author": "Ardal"}
{"word": ["sneaks"], "author": "nicohvc"}
{"word": ["bedwetter"], "author": "Sage103082"}
{"word": ["phase"], "author": "Dzsono"}
{"word": ["moon"], "author": "chevkoch"}
{"word": ["crater"], "author": "TARFU"}
{"word": ["lake"], "author": "le_chevalier"}
{"word": ["Fish."], "author": "Hickory"}
{"word": ["Meat"], "author": "tort1234"}
{"word": ["Mutton"], "author": "Tcharr"}
{"word": ["Chop."], "author": "gixgox"}
{"word": ["Lamb"], "author": "GandalftheCool"}
{"word": ["Silence"], "author": "le_chevalier"}
{"word": ["Sound"], "author": "PaterAlf"}
{"word": ["Music."], "author": "viperfdl"}
{"word": [], "author": "Zoltan999"}
{"word": ["shaft"], "author": "Gerin"}
{"word": [], "author": "viperfdl"}
{"word": ["Panther"], "author": "Lifthrasil"}
{"word": ["Puma."], "author": "codefenix"}
{"word": ["Sport."], "author": "Hickory"}
{"word": ["equipment"], "author": "mm324"}
{"word": ["gear"], "author": "le_chevalier"}
{"word": ["Servo."], "author": "gixgox"}
{"word": ["Motor."], "author": "Hickory"}
{"word": ["Oil."], "author": "Narcia_"}
{"word": ["Essential."], "author": "codefenix"}
{"word": ["Substantial."], "author": "gixgox"}
{"word": [], "author": "cose_vecchie"}
{"word": ["massive"], "author": "Ardal"}
{"word": [" Structure."], "author": "Hickory"}
{"word": [" Monumental."], "author": "Kleetus"}
{"word": [" architecture"], "author": "Dzsono"}
{"word": [" Design."], "author": "Gravest"}
{"word": ["blueprint"], "author": "le_chevalier"}
{"word": [" Make"], "author": "oldgameryeah"}
{"word": ["build"], "author": "TARFU"}
{"word": ["Construct"], "author": "Madshaker"}
{"word": ["Blast."], "author": "gixgox"}
{"word": ["Cap."], "author": "Hickory"}
{"word": ["Head"], "author": "cose_vecchie"}
{"word": ["Brain"], "author": "nebulosas"}
{"word": ["Stem"], "author": "Gerin"}
{"word": ["Cell"], "author": "tinyE"}
{"word": ["Phone."], "author": "viperfdl"}
{"word": ["Home"], "author": "Zoltan999"}
{"word": ["Base."], "author": "codefenix"}
{"word": ["Foundation."], "author": "Hickory"}
{"word": ["Charity"], "author": "le_chevalier"}
{"word": ["donation"], "author": "mm324"}
{"word": ["Generous."], "author": "codefenix"}
{"word": ["free"], "author": "GabesterOne"}
{"word": [], "author": "gixgox"}
{"word": ["Bath."], "author": "Narcia_"}
{"word": ["bubbles"], "author": "Sage103082"}
{"word": ["Frothy."], "author": "Hickory"}
{"word": ["mouth"], "author": "Ardal"}
{"word": ["teeth"], "author": "TARFU"}
{"word": ["jaws"], "author": "nicohvc"}
{"word": ["shark"], "author": "oldgameryeah"}
{"word": ["investor"], "author": "Dzsono"}
{"word": [" Cartilage."], "author": "Kleetus"}
{"word": [" Entrepreneur."], "author": "Hickory"}
{"word": ["Industrialist"], "author": "gixgox"}
{"word": ["apitalist"], "author": "le_chevalier"}
{"word": ["Exploiter."], "author": "gixgox"}
{"word": ["socialist"], "author": "richlind33"}
{"word": ["communist"], "author": "Accatone"}
{"word": ["Anarchist."], "author": "gixgox"}
{"word": ["Chaos"], "author": "Yezemin"}
{"word": ["Order"], "author": "nebulosas"}
{"word": ["Form."], "author": "codefenix"}
{"word": ["construct"], "author": "mm324"}
{"word": ["erect"], "author": "le_chevalier"}
{"word": ["upright"], "author": "mm324"}
{"word": ["tall"], "author": "Zoltan999"}
{"word": ["Stand."], "author": "Narcia_"}
{"word": ["Hold."], "author": "toxicTom"}
{"word": ["Strong"], "author": "mm324"}
{"word": ["Weak."], "author": "codefenix"}
{"word": ["Link."], "author": "Hickory"}
{"word": ["Web."], "author": "toxicTom"}
{"word": ["network"], "author": "Tcharr"}
{"word": ["Streetwork."], "author": "gixgox"}
{"word": ["roadwork"], "author": "Ardal"}
{"word": ["construction"], "author": "TARFU"}
{"word": ["Destruction."], "author": "viperfdl"}
{"word": ["Obstruction."], "author": "Hickory"}
{"word": ["barrier"], "author": "Dzsono"}
{"word": ["speedbump"], "author": "Tcharr"}
{"word": ["Speedforce"], "author": "tort1234"}
{"word": ["Speedtrap"], "author": "Madshaker"}
{"word": [], "author": "gixgox"}
{"word": ["hasty"], "author": "le_chevalier"}
{"word": ["fast"], "author": "oldgameryeah"}
{"word": ["car"], "author": "kaylayuhos19"}
{"word": ["vehicle"], "author": "Dzsono"}
{"word": ["transportation"], "author": "GabesterOne"}
{"word": [], "author": "viperfdl"}
{"word": ["Setting."], "author": "toxicTom"}
{"word": ["location"], "author": "ashwald"}
{"word": ["site"], "author": "Tcharr"}
{"word": ["Place"], "author": "nebulosas"}
{"word": ["seat"], "author": "Namxas01"}
{"word": ["Armchair."], "author": "toxicTom"}
{"word": ["stool"], "author": "park_84"}
{"word": ["Specimen"], "author": "Zoltan999"}
{"word": ["Sample."], "author": "Narcia_"}
{"word": ["Sound."], "author": "toxicTom"}
{"word": ["Logistical... ;)"], "author": "GhostwriterDoF"}
{"word": ["Elaborate."], "author": "codefenix"}
{"word": ["intricate"], "author": "mm324"}
{"word": ["Gordian."], "author": "gixgox"}
{"word": ["Knot"], "author": "mm324"}
{"word": ["."], "author": "Hickory"}
{"word": ["wade"], "author": "Accatone"}
{"word": ["water"], "author": "TARFU"}
{"word": [" Virginia."], "author": "Kleetus"}
{"word": [" Fluid."], "author": "toxicTom"}
{"word": ["Liquid."], "author": "gixgox"}
{"word": ["Crystals"], "author": "cose_vecchie"}
{"word": ["Quartz."], "author": "viperfdl"}
{"word": ["Clock"], "author": "cose_vecchie"}
{"word": ["Time"], "author": "Azrael360"}
{"word": ["Race"], "author": "Gravest"}
{"word": ["Marathon"], "author": "le_chevalier"}
{"word": [], "author": "gixgox"}
{"word": ["Cadence."], "author": "Hickory"}
{"word": ["flow"], "author": "Dzsono"}
{"word": ["Rivers"], "author": "tort1234"}
{"word": ["Nil."], "author": "viperfdl"}
{"word": ["zeroed"], "author": "le_chevalier"}
{"word": ["Erased."], "author": "toxicTom"}
{"word": ["Terminated."], "author": "viperfdl"}
{"word": ["Completed"], "author": "nebulosas"}
{"word": ["Task"], "author": "Zoltan999"}
{"word": ["Force."], "author": "gixgox"}
{"word": ["Pressure."], "author": "Hickory"}
{"word": ["applied"], "author": "Ardal"}
{"word": ["apple"], "author": "Accatone"}
{"word": ["Strudel."], "author": "Narcia_"}
{"word": ["beer"], "author": "Sage103082"}
{"word": ["Keg"], "author": "mm324"}
{"word": ["Powder."], "author": "viperfdl"}
{"word": ["Dust."], "author": "Hickory"}
{"word": ["Pan"], "author": "mm324"}
{"word": ["Peter"], "author": "Sage103082"}
{"word": ["Paul"], "author": "TARFU"}
{"word": [" Piper."], "author": "Kleetus"}
{"word": ["Newman"], "author": "park_84"}
{"word": [], "author": "gixgox"}
{"word": ["chameleon"], "author": "Dzsono"}
{"word": ["Change"], "author": "Gravest"}
{"word": ["challenge"], "author": "le_chevalier"}
{"word": ["Channels"], "author": "tort1234"}
{"word": ["Canals."], "author": "codefenix"}
{"word": ["Rivers"], "author": "muter"}
{"word": ["sea"], "author": "Accatone"}
{"word": ["Deep"], "author": "Zoltan999"}
{"word": ["Six."], "author": "codefenix"}
{"word": ["Fathom"], "author": "le_chevalier"}
{"word": ["Measure."], "author": "Hickory"}
{"word": [], "author": "viperfdl"}
{"word": ["radiation"], "author": "mm324"}
{"word": ["Half-Life."], "author": "Narcia_"}
{"word": [" Three."], "author": "gixgox"}
{"word": ["impossible"], "author": "Dzsono"}
{"word": ["improbable"], "author": "Tcharr"}
{"word": ["odds"], "author": "Ardal"}
{"word": ["Evens."], "author": "Hickory"}
{"word": ["numbers"], "author": "TARFU"}
{"word": ["Symbols."], "author": "Hickory"}
{"word": ["References."], "author": "REDVWIN"}
{"word": ["Citations"], "author": "Dzsono"}
{"word": ["Quotation."], "author": "gixgox"}
{"word": ["excerpt"], "author": "le_chevalier"}
{"word": ["Snippet."], "author": "Hickory"}
{"word": [" Extract."], "author": "Kleetus"}
{"word": [" Whippet"], "author": "Tcharr"}
{"word": [" Terrier."], "author": "Kleetus"}
{"word": [" Good ", " ", " (Lets see who gets that) :P"], "author": "tinyE"}
{"word": [" killer"], "author": "Tcharr"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["clich\u00e9"], "author": "Dzsono"}
{"word": ["stereotype"], "author": "Accatone"}
{"word": ["Ignorant"], "author": "Zoltan999"}
{"word": ["Arrogant."], "author": "codefenix"}
{"word": ["pompous"], "author": "mm324"}
{"word": ["Poppycock."], "author": "Narcia_"}
{"word": ["Slowpoke"], "author": "TaoTekko"}
{"word": ["Gobbledygook."], "author": "Hickory"}
{"word": ["gibberish"], "author": "Ardal"}
{"word": [], "author": "gixgox"}
{"word": [" Nonsense."], "author": "Kleetus"}
{"word": [" Language"], "author": "TARFU"}
{"word": ["Mando'a"], "author": "Tcharr"}
{"word": ["Esperanto."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": [" Mandalore."], "author": "Kleetus"}
{"word": [" College."], "author": "Hickory"}
{"word": ["School"], "author": "toxicTom"}
{"word": [" Mandalore."], "author": "Kleetus"}
{"word": [" Term."], "author": "Hickory"}
{"word": ["Assignments."], "author": "gixgox"}
{"word": ["projects"], "author": "le_chevalier"}
{"word": ["Red CD"], "author": "TaoTekko"}
{"word": [" Research."], "author": "Hickory"}
{"word": ["Development."], "author": "viperfdl"}
{"word": ["progress"], "author": "Accatone"}
{"word": ["Forward"], "author": "Zoltan999"}
{"word": ["base"], "author": "Ardal"}
{"word": ["advance ", " Edit: ninja'd ", " ", " acid"], "author": "mm324"}
{"word": ["Wash."], "author": "codefenix"}
{"word": ["basin"], "author": "oldgameryeah"}
{"word": [" ", " ", " In some games, extra limitations are added, for instance: The associations between words must be strictly obvious, rather than the usual \"first word that comes to mind\", which can often require explaining to see how it is connected with the previous word. Word Disassociation (sometimes called Dissociation) is sometimes played. In this game, the aim is to say a word that is as unrelated as possible to the previous one. In such games, however, it is often found that creativity is lowered and the words stray towards having obvious associations again. There is a song about Word Disassociation by Neil Cicierega (Lemon Demon) on his Damn Skippy album. This game is sometimes known as \"Word for Word\". ", " Sometimes, repeated words are forbidden or otherwise noted on a separate list for interest. ", " A variant with an arbitrary name (sometimes called Ultra Word Association) involves associating words in a grid, where the first word is placed in the top-left, and where each word must be placed adjacent to another one and must associate with all those words adjacent to it. A game based on the Word Association game which is sometimes popular for informal social gatherings is Bobsledding."], "author": "karlbjorkman"}
{"word": [" Receptacle."], "author": "Hickory"}
{"word": ["Cup."], "author": "Narcia_"}
{"word": ["coffee"], "author": "kmonster"}
{"word": ["Percolator."], "author": "Hickory"}
{"word": [" Beverage."], "author": "Kleetus"}
{"word": [" Open a new thread ", " ", " "], "author": "gixgox"}
{"word": [" Cappuccino"], "author": "TARFU"}
{"word": ["Beverage"], "author": "Azrael360"}
{"word": ["Juice."], "author": "Hickory"}
{"word": ["Juiced"], "author": "MaximeMartyr"}
{"word": ["squeezed"], "author": "Dzsono"}
{"word": ["Pressed."], "author": "Hickory"}
{"word": ["pushed"], "author": "le_chevalier"}
{"word": [" up"], "author": "gixgox"}
{"word": ["exercised"], "author": "le_chevalier"}
{"word": ["Exhausted"], "author": "Zoltan999"}
{"word": ["Depleted."], "author": "codefenix"}
{"word": ["Spent."], "author": "Hickory"}
{"word": ["Dissipated."], "author": "gixgox"}
{"word": ["degraded"], "author": "mm324"}
{"word": ["Biodegradable."], "author": "Narcia_"}
{"word": ["Organic."], "author": "toxicTom"}
{"word": ["eco-friendly ", " ", " Edit: ninja'd but it works :)"], "author": "mm324"}
{"word": ["nature"], "author": "Accatone"}
{"word": ["Inherent. :)"], "author": "GhostwriterDoF"}
{"word": ["Innate."], "author": "Hickory"}
{"word": [" Inbuilt."], "author": "Kleetus"}
{"word": [" Innate."], "author": "Hickory"}
{"word": [" Inbuilt."], "author": "Kleetus"}
{"word": [" Innate."], "author": "Hickory"}
{"word": ["hardwired"], "author": "Tcharr"}
{"word": ["Integral."], "author": "Hickory"}
{"word": ["Calculus"], "author": "cose_vecchie"}
{"word": ["cactus"], "author": "kmonster"}
{"word": ["spines"], "author": "TARFU"}
{"word": [" Succulent."], "author": "Kleetus"}
{"word": [" Backbone."], "author": "Hickory"}
{"word": ["Fur."], "author": "Kleetus"}
{"word": [" Pillar."], "author": "gixgox"}
{"word": ["column"], "author": "le_chevalier"}
{"word": ["pylon"], "author": "Dzsono"}
{"word": ["Electricity."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["manpower ", " ", " ", " *cough* NSFW *cough*"], "author": "le_chevalier"}
{"word": ["production"], "author": "Tcharr"}
{"word": ["Factory."], "author": "toxicTom"}
{"word": ["Craft."], "author": "gixgox"}
{"word": ["Star."], "author": "viperfdl"}
{"word": ["Planet."], "author": "Hickory"}
{"word": ["World"], "author": "flubbucket"}
{"word": ["Moon."], "author": "gixgox"}
{"word": ["Paper."], "author": "toxicTom"}
{"word": ["Tiger"], "author": "Tcharr"}
{"word": ["Stripe."], "author": "Hickory"}
{"word": ["Tape"], "author": "Zoltan999"}
{"word": ["adhesive"], "author": "Ardal"}
{"word": ["glue"], "author": "Accatone"}
{"word": ["Mucilage."], "author": "gixgox"}
{"word": ["sticky"], "author": "mm324"}
{"word": ["Gungy."], "author": "Hickory"}
{"word": ["filthy"], "author": "mm324"}
{"word": ["Tawdry."], "author": "codefenix"}
{"word": ["Tart."], "author": "Narcia_"}
{"word": ["Fart"], "author": "Licurg"}
{"word": ["Involuntary? :o"], "author": "GhostwriterDoF"}
{"word": ["uncontrollable"], "author": "le_chevalier"}
{"word": ["Trump."], "author": "Tauto"}
{"word": [" wild"], "author": "TARFU"}
{"word": [" President."], "author": "Kleetus"}
{"word": ["Civics. :P"], "author": "GhostwriterDoF"}
{"word": ["civility"], "author": "Dzsono"}
{"word": ["civilization"], "author": "le_chevalier"}
{"word": ["Civilian."], "author": "gixgox"}
{"word": ["Denizen."], "author": "Hickory"}
{"word": [" Culture."], "author": "Kleetus"}
{"word": ["bacteria"], "author": "Tcharr"}
{"word": [" Trump."], "author": "Tauto"}
{"word": [" Denizen."], "author": "Hickory"}
{"word": ["Regular."], "author": "gixgox"}
{"word": ["Frequent"], "author": "nebulosas"}
{"word": ["Often"], "author": "Gravest"}
{"word": ["Commonplace."], "author": "Hickory"}
{"word": ["Market."], "author": "MaximeMartyr"}
{"word": [], "author": "gixgox"}
{"word": ["Farsi"], "author": "toxicTom"}
{"word": ["poetry"], "author": "Accatone"}
{"word": ["rhyme"], "author": "oldgameryeah"}
{"word": ["Thyme."], "author": "Narcia_"}
{"word": ["Spice."], "author": "viperfdl"}
{"word": ["Melange."], "author": "gixgox"}
{"word": ["Assortment."], "author": "GhostwriterDoF"}
{"word": ["Big"], "author": "TaoTekko"}
{"word": ["Bang."], "author": "gixgox"}
{"word": ["small"], "author": "mm324"}
{"word": ["Little."], "author": "toxicTom"}
{"word": [" Tiny."], "author": "Kleetus"}
{"word": [" microscopic"], "author": "TARFU"}
{"word": [" Tiny."], "author": "Kleetus"}
{"word": ["newborn"], "author": "kaylayuhos19"}
{"word": [" Microbe."], "author": "gixgox"}
{"word": [" Baby."], "author": "Kleetus"}
{"word": ["pergent"], "author": "kaylayuhos19"}
{"word": ["placenta"], "author": "Emob78"}
{"word": ["Umbilical."], "author": "Gravest"}
{"word": ["Biblical."], "author": "Kleetus"}
{"word": [" Cable."], "author": "gixgox"}
{"word": ["hose"], "author": "le_chevalier"}
{"word": ["water"], "author": "Dzsono"}
{"word": ["Drinks"], "author": "muter"}
{"word": ["Merlot."], "author": "gixgox"}
{"word": [" satanic"], "author": "richlind33"}
{"word": [" Grape."], "author": "Hickory"}
{"word": [" "], "author": "gixgox"}
{"word": ["Vegetable"], "author": "TaoTekko"}
{"word": ["comatose"], "author": "thomq"}
{"word": [], "author": "toxicTom"}
{"word": ["Conscious."], "author": "Gravest"}
{"word": ["Unconscious"], "author": "T.Hodd"}
{"word": ["KO ", " ", " ", " ", " ", " ", " ", " ", " (... filler text for validation that doesn't let me post only two letters...)"], "author": "toxicTom"}
{"word": ["Okay."], "author": "viperfdl"}
{"word": ["Coke"], "author": "Tcharr"}
{"word": ["Cocaine"], "author": "toxicTom"}
{"word": ["Amphetamine."], "author": "viperfdl"}
{"word": ["Chemical."], "author": "Hickory"}
{"word": ["Natural"], "author": "nebulosas"}
{"word": ["nature"], "author": "Accatone"}
{"word": ["biogenic"], "author": "oldgameryeah"}
{"word": ["Protoplasm..."], "author": "GhostwriterDoF"}
{"word": ["Life."], "author": "Hickory"}
{"word": ["Time."], "author": "Narcia_"}
{"word": [], "author": "gixgox"}
{"word": ["Prolapse..."], "author": "plagren"}
{"word": ["Overlap."], "author": "toxicTom"}
{"word": ["Laparoscopy."], "author": "Hickory"}
{"word": ["Surgery."], "author": "viperfdl"}
{"word": ["Scalpel."], "author": "toxicTom"}
{"word": ["knife"], "author": "mm324"}
{"word": ["Cook"], "author": "Caesar."}
{"word": ["eat"], "author": "mm324"}
{"word": ["Food."], "author": "toxicTom"}
{"word": ["Sustenance."], "author": "Hickory"}
{"word": [" Consume."], "author": "Kleetus"}
{"word": [" Replenish."], "author": "toxicTom"}
{"word": [" Ingest."], "author": "Kleetus"}
{"word": ["digest"], "author": "Tcharr"}
{"word": ["stomach"], "author": "TARFU"}
{"word": [" Process."], "author": "Kleetus"}
{"word": [" Liver."], "author": "gixgox"}
{"word": [" Treat."], "author": "Kleetus"}
{"word": [" Onions."], "author": "Hickory"}
{"word": [" Kibble."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": [], "author": "Dzsono"}
{"word": ["Yummy"], "author": "Emob78"}
{"word": ["tasty"], "author": "le_chevalier"}
{"word": ["Delectable."], "author": "Gravest"}
{"word": ["tidbits"], "author": "Zoltan999"}
{"word": ["babies"], "author": "kaylayuhos19"}
{"word": [" Sliders."], "author": "gixgox"}
{"word": ["Slideshow"], "author": "toxicTom"}
{"word": ["Sideshow"], "author": "Yezemin"}
{"word": ["show"], "author": "Accatone"}
{"word": ["."], "author": "gixgox"}
{"word": ["Clam."], "author": "codefenix"}
{"word": ["oyster"], "author": "mm324"}
{"word": ["Pearl"], "author": "Zoltan999"}
{"word": ["black"], "author": "Ardal"}
{"word": ["dahlia"], "author": "skimmie"}
{"word": ["Chrysanthemum."], "author": "Hickory"}
{"word": ["Daisy."], "author": "toxicTom"}
{"word": ["Duck."], "author": "gixgox"}
{"word": ["Pond."], "author": "Narcia_"}
{"word": ["Deep."], "author": "TaoTekko"}
{"word": ["Throat."], "author": "viperfdl"}
{"word": ["cut"], "author": "kmonster"}
{"word": ["Circumcise."], "author": "Kleetus"}
{"word": ["circumscribe"], "author": "Tcharr"}
{"word": ["enclose"], "author": "oldgameryeah"}
{"word": ["encompass"], "author": "TARFU"}
{"word": ["envelope"], "author": "Dzsono"}
{"word": ["Confine."], "author": "Hickory"}
{"word": ["intern"], "author": "le_chevalier"}
{"word": ["Trainee."], "author": "gixgox"}
{"word": ["apprentice"], "author": "Tcharr"}
{"word": ["Master."], "author": "Hickory"}
{"word": [], "author": "skimmie"}
{"word": ["medicine"], "author": "Ardal"}
{"word": ["Potion."], "author": "gixgox"}
{"word": ["Mixture"], "author": "nebulosas"}
{"word": ["Concoction."], "author": "Hickory"}
{"word": ["Preparation."], "author": "gixgox"}
{"word": ["Anticipation"], "author": "Yezemin"}
{"word": ["Eagerness."], "author": "codefenix"}
{"word": ["Apprentice"], "author": "Zoltan999"}
{"word": ["assistant"], "author": "mm324"}
{"word": ["Acolyte."], "author": "Hickory"}
{"word": ["disciple"], "author": "mm324"}
{"word": ["Follower"], "author": "toxicTom"}
{"word": ["leader"], "author": "mm324"}
{"word": ["Pathfinder."], "author": "gixgox"}
{"word": ["pioneer"], "author": "le_chevalier"}
{"word": ["Scout."], "author": "toxicTom"}
{"word": ["Reconnoitre."], "author": "Hickory"}
{"word": ["spy"], "author": "BlackDawn"}
{"word": ["bond"], "author": "Accatone"}
{"word": ["Zero"], "author": "TaoTekko"}
{"word": ["Nil."], "author": "toxicTom"}
{"word": ["Zilch."], "author": "Hickory"}
{"word": ["Void."], "author": "toxicTom"}
{"word": ["Vacuum."], "author": "Gravest"}
{"word": ["Cleaner"], "author": "nebulosas"}
{"word": ["heavy"], "author": "ashwald"}
{"word": ["cumbersome"], "author": "Dzsono"}
{"word": ["tortoise"], "author": "risingcomet"}
{"word": ["turtle"], "author": "Accatone"}
{"word": [], "author": "Zoltan999"}
{"word": ["Wane."], "author": "toxicTom"}
{"word": ["atrophied"], "author": "Ardal"}
{"word": ["deteriorate"], "author": "mm324"}
{"word": ["Crumble."], "author": "Narcia_"}
{"word": ["Apple"], "author": "mm324"}
{"word": ["Custard."], "author": "Hickory"}
{"word": ["Pie"], "author": "cose_vecchie"}
{"word": ["cake"], "author": "TARFU"}
{"word": [" Pastry."], "author": "Kleetus"}
{"word": ["bakery"], "author": "Dzsono"}
{"word": ["Confectioner."], "author": "gixgox"}
{"word": ["Sweets."], "author": "Hickory"}
{"word": ["candy"], "author": "Accatone"}
{"word": ["sugar"], "author": "le_chevalier"}
{"word": ["Shock."], "author": "viperfdl"}
{"word": ["Trauma."], "author": "gixgox"}
{"word": ["Center"], "author": "Zoltan999"}
{"word": ["Middle."], "author": "codefenix"}
{"word": [" ", " ", " ", " ", " ", " "], "author": "gixgox"}
{"word": ["Elsewhere."], "author": "Hickory"}
{"word": ["Science."], "author": "TaoTekko"}
{"word": ["Fiction."], "author": "viperfdl"}
{"word": ["Literature"], "author": "TARFU"}
{"word": [" Fable."], "author": "Kleetus"}
{"word": [" Library."], "author": "Hickory"}
{"word": ["Archive."], "author": "Gravest"}
{"word": ["Winrar"], "author": "muter"}
{"word": ["trial"], "author": "Dzsono"}
{"word": ["judgement"], "author": "le_chevalier"}
{"word": ["verdict"], "author": "mm324"}
{"word": ["Umpirage."], "author": "gixgox"}
{"word": ["baseball"], "author": "skimmie"}
{"word": ["Cricket."], "author": "Hickory"}
{"word": ["Croquet."], "author": "gixgox"}
{"word": ["Sport"], "author": "nebulosas"}
{"word": ["Bar."], "author": "codefenix"}
{"word": ["beer"], "author": "le_chevalier"}
{"word": ["Mug"], "author": "mm324"}
{"word": ["pot"], "author": "Ardal"}
{"word": ["Kettle."], "author": "Hickory"}
{"word": ["Cauldron"], "author": "Zoltan999"}
{"word": ["kettle"], "author": "Accatone"}
{"word": ["Alice"], "author": "TaoTekko"}
{"word": ["Wonderland"], "author": "TARFU"}
{"word": ["Cheshire."], "author": "viperfdl"}
{"word": ["Cat!"], "author": "Narcia_"}
{"word": ["cradle"], "author": "kmonster"}
{"word": ["bed"], "author": "oldgameryeah"}
{"word": ["Teddy."], "author": "gixgox"}
{"word": ["Bear"], "author": "Antimateria"}
{"word": ["bare"], "author": "Dzsono"}
{"word": ["Bald."], "author": "gixgox"}
{"word": ["Bold."], "author": "viperfdl"}
{"word": ["Bowled."], "author": "Hickory"}
{"word": ["bowl"], "author": "Accatone"}
{"word": ["bowel"], "author": "le_chevalier"}
{"word": ["Bowler."], "author": "gixgox"}
{"word": ["Intestine ", " ", " ", " edit: Ninja'd by the Gix ", " ", " Sportsman"], "author": "Zoltan999"}
{"word": ["Competitor."], "author": "Hickory"}
{"word": ["Rival"], "author": "nebulosas"}
{"word": ["Antagonist."], "author": "gixgox"}
{"word": ["evil"], "author": "Ardal"}
{"word": ["monster"], "author": "le_chevalier"}
{"word": ["bed"], "author": "skimmie"}
{"word": ["time"], "author": "tinyE"}
{"word": ["Travel."], "author": "Narcia_"}
{"word": ["Brochure."], "author": "Hickory"}
{"word": [" Furniture."], "author": "Kleetus"}
{"word": [" Brochure."], "author": "Hickory"}
{"word": ["pamphlet"], "author": "mm324"}
{"word": ["newspaper"], "author": "TARFU"}
{"word": [" Leaflet."], "author": "Kleetus"}
{"word": ["propaganda"], "author": "Fran67"}
{"word": ["Magazine."], "author": "gixgox"}
{"word": ["MAD"], "author": "Fran67"}
{"word": ["Humor."], "author": "Gravest"}
{"word": ["chuckle"], "author": "Dzsono"}
{"word": ["nice"], "author": "kaylayuhos19"}
{"word": ["Twice."], "author": "viperfdl"}
{"word": ["dice"], "author": "Accatone"}
{"word": ["Roleplay."], "author": "Casval_Deikun"}
{"word": ["Cosplay"], "author": "Zoltan999"}
{"word": ["costume"], "author": "mm324"}
{"word": ["Batsuit."], "author": "viperfdl"}
{"word": ["Belt."], "author": "Narcia_"}
{"word": ["rank"], "author": "le_chevalier"}
{"word": ["Ripe."], "author": "codefenix"}
{"word": ["River"], "author": "TaoTekko"}
{"word": ["water"], "author": "TARFU"}
{"word": ["flow"], "author": "skimmie"}
{"word": ["current"], "author": "Titanium"}
{"word": ["Sultana."], "author": "Kleetus"}
{"word": [" Present."], "author": "gixgox"}
{"word": [" Sultana."], "author": "Kleetus"}
{"word": [" Birthday."], "author": "Hickory"}
{"word": ["anniversary"], "author": "le_chevalier"}
{"word": ["Commemoration."], "author": "Hickory"}
{"word": [" Remembrance."], "author": "Kleetus"}
{"word": ["Remember"], "author": "tort1234"}
{"word": ["November"], "author": "Tcharr"}
{"word": ["December."], "author": "viperfdl"}
{"word": ["winter"], "author": "Accatone"}
{"word": [" "], "author": "gixgox"}
{"word": ["Jazz."], "author": "codefenix"}
{"word": ["Reggae."], "author": "Hickory"}
{"word": ["Jamaica"], "author": "mm324"}
{"word": ["Weed."], "author": "viperfdl"}
{"word": ["Perennial."], "author": "Hickory"}
{"word": ["perpetual"], "author": "Ardal"}
{"word": ["motion"], "author": "skimmie"}
{"word": ["sickness"], "author": "cose_vecchie"}
{"word": ["Perishing."], "author": "gixgox"}
{"word": ["Thought"], "author": "Tcharr"}
{"word": ["Imagine."], "author": "Hickory"}
{"word": ["Dragons."], "author": "semigroups"}
{"word": ["Dungeons."], "author": "codefenix"}
{"word": ["damsels"], "author": "le_chevalier"}
{"word": ["Distress."], "author": "gixgox"}
{"word": [" Maids."], "author": "Kleetus"}
{"word": ["Chess"], "author": "TaoTekko"}
{"word": [" Anxiety."], "author": "Hickory"}
{"word": [" emotion"], "author": "TARFU"}
{"word": ["Passion."], "author": "Gravest"}
{"word": ["Fruit."], "author": "Hickory"}
{"word": ["Basket."], "author": "Narcia_"}
{"word": ["Casket."], "author": "gixgox"}
{"word": [" Hoop."], "author": "Kleetus"}
{"word": ["Basket"], "author": "SamMagel"}
{"word": [" Coffin."], "author": "Hickory"}
{"word": ["corpse"], "author": "mm324"}
{"word": ["Carcass"], "author": "Zoltan999"}
{"word": ["compost"], "author": "le_chevalier"}
{"word": ["Heap."], "author": "Hickory"}
{"word": [" ", " :P"], "author": "GhostwriterDoF"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Penny."], "author": "Narcia_"}
{"word": ["Dollar"], "author": "muter"}
{"word": [], "author": "cose_vecchie"}
{"word": ["gift"], "author": "sluniq"}
{"word": [], "author": "gixgox"}
{"word": ["Corruption."], "author": "toxicTom"}
{"word": ["corrupt"], "author": "Accatone"}
{"word": ["Government"], "author": "TaoTekko"}
{"word": ["Executive"], "author": "toxicTom"}
{"word": ["order"], "author": "VeganDogMeat"}
{"word": ["Mandate."], "author": "Hickory"}
{"word": ["claims"], "author": "nicohvc"}
{"word": ["possession"], "author": "VeganDogMeat"}
{"word": ["belonging"], "author": "le_chevalier"}
{"word": ["Occupy"], "author": "oldgameryeah"}
{"word": ["Military"], "author": "VeganDogMeat"}
{"word": ["Army"], "author": "TARFU"}
{"word": [" Army."], "author": "Kleetus"}
{"word": [" Surplus."], "author": "Hickory"}
{"word": [" Army."], "author": "Kleetus"}
{"word": [" Surplus."], "author": "Hickory"}
{"word": [" Dickory"], "author": "Kleetus"}
{"word": [" Surplus."], "author": "Hickory"}
{"word": ["inventory"], "author": "Tcharr"}
{"word": ["RPG"], "author": "viperfdl"}
{"word": ["Role"], "author": "nebulosas"}
{"word": ["Sandwich."], "author": "Kleetus"}
{"word": ["Subway"], "author": "GOG_ML012"}
{"word": ["Paedophile."], "author": "Kleetus"}
{"word": [" Tube."], "author": "gixgox"}
{"word": ["3..............."], "author": "Kleetus"}
{"word": [" Metro."], "author": "gixgox"}
{"word": [" Paedophile."], "author": "Kleetus"}
{"word": [" Underground."], "author": "gixgox"}
{"word": ["food"], "author": "kaylayuhos19"}
{"word": [" Paedophile."], "author": "Kleetus"}
{"word": ["avocado"], "author": "Tcharr"}
{"word": [" Cavern."], "author": "Hickory"}
{"word": ["Den."], "author": "gixgox"}
{"word": ["Lair"], "author": "flubbucket"}
{"word": [], "author": "Tcharr"}
{"word": ["Beware."], "author": "Hickory"}
{"word": ["Swear."], "author": "gixgox"}
{"word": ["wear"], "author": "Accatone"}
{"word": ["Oath ", " ", " edit: Ninja'd ", " ", " Evening"], "author": "Zoltan999"}
{"word": ["Post."], "author": "codefenix"}
{"word": ["Ante"], "author": "Cavenagh"}
{"word": ["poker"], "author": "cose_vecchie"}
{"word": ["Fireplace."], "author": "toxicTom"}
{"word": ["Gown."], "author": "Hickory"}
{"word": [" Cards."], "author": "Kleetus"}
{"word": [" ", "."], "author": "gixgox"}
{"word": ["weave"], "author": "ashwald"}
{"word": ["Lace."], "author": "Hickory"}
{"word": [" Pattern."], "author": "Kleetus"}
{"word": ["Shape."], "author": "viperfdl"}
{"word": ["Form."], "author": "toxicTom"}
{"word": ["Transformer"], "author": "TaoTekko"}
{"word": ["."], "author": "gixgox"}
{"word": ["Shape-shifter"], "author": "TARFU"}
{"word": [" Chameleon."], "author": "Kleetus"}
{"word": ["invisible"], "author": "kmonster"}
{"word": ["eat"], "author": "kaylayuhos19"}
{"word": ["sexy"], "author": "SEXYKAYLA"}
{"word": [" Hidden."], "author": "gixgox"}
{"word": [" Treasure"], "author": "Shroy"}
{"word": ["bounty"], "author": "Dzsono"}
{"word": ["Ship."], "author": "toxicTom"}
{"word": ["cruiser"], "author": "le_chevalier"}
{"word": ["Hovercraft"], "author": "tort1234"}
{"word": ["Cushion."], "author": "Gravest"}
{"word": ["Pillow"], "author": "Yezemin"}
{"word": ["Feather"], "author": "motorkar"}
{"word": ["Tar."], "author": "toxicTom"}
{"word": ["Cigarette"], "author": "Tcharr"}
{"word": ["smoke"], "author": "skimmie"}
{"word": [], "author": "gixgox"}
{"word": ["Ice."], "author": "viperfdl"}
{"word": [], "author": "gixgox"}
{"word": ["milk"], "author": "Accatone"}
{"word": ["Cow"], "author": "nebulosas"}
{"word": ["Steak."], "author": "gixgox"}
{"word": ["Asparagus..."], "author": "GhostwriterDoF"}
{"word": ["Aspidistra."], "author": "Hickory"}
{"word": ["Asia"], "author": "mm324"}
{"word": ["Continent."], "author": "Narcia_"}
{"word": ["landmass"], "author": "le_chevalier"}
{"word": ["island"], "author": "mm324"}
{"word": ["Iceland."], "author": "toxicTom"}
{"word": ["Tundra."], "author": "Hickory"}
{"word": ["Taiga."], "author": "gixgox"}
{"word": ["Tiger."], "author": "codefenix"}
{"word": [], "author": "ashwald"}
{"word": [], "author": "toxicTom"}
{"word": [], "author": "gixgox"}
{"word": ["Insect"], "author": "TaoTekko"}
{"word": ["pest"], "author": "mm324"}
{"word": ["Cholera."], "author": "viperfdl"}
{"word": ["Epidemic."], "author": "Hickory"}
{"word": [" Disease."], "author": "Kleetus"}
{"word": [" Contagion."], "author": "gixgox"}
{"word": ["Blight."], "author": "Gravest"}
{"word": ["real"], "author": "SEXYKAYLA"}
{"word": [" plague"], "author": "TARFU"}
{"word": ["pestilence"], "author": "Dzsono"}
{"word": ["Stench."], "author": "toxicTom"}
{"word": ["Smell."], "author": "viperfdl"}
{"word": ["stink"], "author": "le_chevalier"}
{"word": ["Wash."], "author": "toxicTom"}
{"word": ["cloth"], "author": "skimmie"}
{"word": ["Fabric."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["Ragtag."], "author": "toxicTom"}
{"word": ["."], "author": "Hickory"}
{"word": ["bobcat"], "author": "Accatone"}
{"word": [], "author": "toxicTom"}
{"word": ["Sleigh."], "author": "gixgox"}
{"word": ["bells"], "author": "mm324"}
{"word": ["Whistles."], "author": "codefenix"}
{"word": ["Locomotive"], "author": "Zoltan999"}
{"word": ["."], "author": "gixgox"}
{"word": ["Somnambulism... :D"], "author": "GhostwriterDoF"}
{"word": ["noctambulism :P"], "author": "ashwald"}
{"word": ["Nightmare"], "author": "TaoTekko"}
{"word": ["Nineteeneightyfour."], "author": "toxicTom"}
{"word": ["Novel"], "author": "TARFU"}
{"word": ["original"], "author": "Dzsono"}
{"word": ["Unique."], "author": "Hickory"}
{"word": ["Special."], "author": "viperfdl"}
{"word": ["one"], "author": "Accatone"}
{"word": ["single"], "author": "le_chevalier"}
{"word": ["Loner."], "author": "gixgox"}
{"word": ["lonesome"], "author": "Ardal"}
{"word": [], "author": "Zoltan999"}
{"word": ["Paleface"], "author": "toxicTom"}
{"word": ["Ghost."], "author": "Narcia_"}
{"word": [], "author": "mm324"}
{"word": ["Void"], "author": "TaoTekko"}
{"word": ["deserted"], "author": "mm324"}
{"word": ["Abandoned."], "author": "Hickory"}
{"word": ["forgotten"], "author": "mm324"}
{"word": [], "author": "nebulosas"}
{"word": ["Kingdoms"], "author": "TARFU"}
{"word": ["Commonwealth."], "author": "gixgox"}
{"word": [" Realms."], "author": "Kleetus"}
{"word": [" Alliance."], "author": "Hickory"}
{"word": [" Pack."], "author": "Kleetus"}
{"word": [" Confederation."], "author": "gixgox"}
{"word": ["slaughter"], "author": "kmonster"}
{"word": ["house"], "author": "Ardal"}
{"word": ["dwelling"], "author": "Dzsono"}
{"word": ["lurking"], "author": "Tcharr"}
{"word": ["Creeping."], "author": "codefenix"}
{"word": ["sneaking"], "author": "oldgameryeah"}
{"word": ["Stealth."], "author": "Hickory"}
{"word": ["infiltration"], "author": "le_chevalier"}
{"word": ["Subversion."], "author": "toxicTom"}
{"word": ["Revolution"], "author": "Caesar."}
{"word": ["change"], "author": "Accatone"}
{"word": ["Shift."], "author": "gixgox"}
{"word": ["Reform."], "author": "Gravest"}
{"word": ["Bullshit."], "author": "viperfdl"}
{"word": ["dung"], "author": "Ardal"}
{"word": ["Manure."], "author": "toxicTom"}
{"word": ["Fertilizer"], "author": "Zoltan999"}
{"word": ["Humus."], "author": "Hickory"}
{"word": ["Hummus."], "author": "gixgox"}
{"word": ["Tahini."], "author": "Hickory"}
{"word": ["Sesame."], "author": "Narcia_"}
{"word": ["Seed"], "author": "mm324"}
{"word": ["Germinate."], "author": "Hickory"}
{"word": ["Sprout."], "author": "gixgox"}
{"word": ["Bean"], "author": "TaoTekko"}
{"word": ["Stalk."], "author": "gixgox"}
{"word": [" Bag."], "author": "Kleetus"}
{"word": [" Branch."], "author": "Hickory"}
{"word": [" Tail."], "author": "Kleetus"}
{"word": [" Twig."], "author": "gixgox"}
{"word": [" Paw."], "author": "Kleetus"}
{"word": [" Leaf."], "author": "Hickory"}
{"word": ["green"], "author": "TARFU"}
{"word": ["go"], "author": "kmonster"}
{"word": ["Chess"], "author": "Tcharr"}
{"word": ["Queen."], "author": "Gravest"}
{"word": ["pawn"], "author": "Dzsono"}
{"word": ["Pawnbroker."], "author": "toxicTom"}
{"word": ["Market"], "author": "Tcharr"}
{"word": ["Stall."], "author": "Hickory"}
{"word": ["stand"], "author": "le_chevalier"}
{"word": ["standoff"], "author": "skimmie"}
{"word": ["Mexican"], "author": "Treadstone1-5"}
{"word": [], "author": "gixgox"}
{"word": ["Banjo"], "author": "nebulosas"}
{"word": ["instrument"], "author": "Accatone"}
{"word": ["trumpet"], "author": "Lifthrasil"}
{"word": ["Trump"], "author": "almabrds"}
{"word": ["Override"], "author": "Tcharr"}
{"word": ["overhaul"], "author": "thomq"}
{"word": ["rebuild"], "author": "mm324"}
{"word": ["Demolish."], "author": "codefenix"}
{"word": ["conquer"], "author": "thomq"}
{"word": ["Vanquish."], "author": "Hickory"}
{"word": ["Erase"], "author": "Yezemin"}
{"word": ["Blank."], "author": "Narcia_"}
{"word": ["Punch."], "author": "gixgox"}
{"word": ["Face ", " ", " EDIT: ninja'd"], "author": "cose_vecchie"}
{"word": ["Facet."], "author": "GhostwriterDoF"}
{"word": ["Aspect."], "author": "Hickory"}
{"word": ["ratio"], "author": "cose_vecchie"}
{"word": ["Rational."], "author": "toxicTom"}
{"word": ["number"], "author": "le_chevalier"}
{"word": ["Maths"], "author": "TaoTekko"}
{"word": ["Numbers"], "author": "tort1234"}
{"word": ["seven"], "author": "kmonster"}
{"word": ["even"], "author": "Dzsono"}
{"word": ["level"], "author": "TARFU"}
{"word": ["garden"], "author": "Tcharr"}
{"word": ["Eden."], "author": "REDVWIN"}
{"word": ["Barbara"], "author": "Tcharr"}
{"word": ["Barbarossa"], "author": "viperfdl"}
{"word": ["Beard."], "author": "Gravest"}
{"word": ["bard"], "author": "Accatone"}
{"word": ["Troubadour."], "author": "viperfdl"}
{"word": ["Minstrel."], "author": "Hickory"}
{"word": ["traveling"], "author": "Habanerose"}
{"word": ["Tourist."], "author": "gixgox"}
{"word": ["Backpack."], "author": "toxicTom"}
{"word": ["Totebag."], "author": "codefenix"}
{"word": ["Briefcase"], "author": "Zoltan999"}
{"word": ["businessman"], "author": "mm324"}
{"word": ["entrepreneur"], "author": "Ardal"}
{"word": ["risk-taker"], "author": "mm324"}
{"word": ["Daredevil."], "author": "codefenix"}
{"word": ["Fool."], "author": "Hickory"}
{"word": ["errand"], "author": "cose_vecchie"}
{"word": ["Boy."], "author": "viperfdl"}
{"word": ["Childish... :)"], "author": "GhostwriterDoF"}
{"word": ["immature"], "author": "le_chevalier"}
{"word": ["Infantile."], "author": "codefenix"}
{"word": ["Infantry."], "author": "gixgox"}
{"word": [" Young."], "author": "Kleetus"}
{"word": [" chaaaaaaaaaaarge!"], "author": "ashwald"}
{"word": ["Rush"], "author": "TaoTekko"}
{"word": ["."], "author": "Hickory"}
{"word": [" Hurry."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" Hurry."], "author": "Kleetus"}
{"word": ["impetuous..."], "author": "GhostwriterDoF"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" Impulsive."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Palatable..? :D"], "author": "GhostwriterDoF"}
{"word": [" grass"], "author": "TARFU"}
{"word": [" Edible."], "author": "Kleetus"}
{"word": [" ", "."], "author": "gixgox"}
{"word": ["Emerald."], "author": "Hickory"}
{"word": ["City"], "author": "Treadstone1-5"}
{"word": ["township"], "author": "Dzsono"}
{"word": ["Mayor"], "author": "toxicTom"}
{"word": ["major"], "author": "Accatone"}
{"word": ["Minor"], "author": "nebulosas"}
{"word": ["."], "author": "gixgox"}
{"word": ["digger"], "author": "skimmie"}
{"word": ["shovel"], "author": "mm324"}
{"word": ["Knight"], "author": "Zoltan999"}
{"word": ["Forever"], "author": "Tcharr"}
{"word": ["young"], "author": "skimmie"}
{"word": ["adult"], "author": "Ardal"}
{"word": ["Responsible."], "author": "Narcia_"}
{"word": ["Accountable."], "author": "codefenix"}
{"word": ["Dependable."], "author": "t850terminator"}
{"word": ["Steadfast."], "author": "Hickory"}
{"word": ["spontaneous"], "author": "camplify"}
{"word": ["."], "author": "gixgox"}
{"word": ["Irascible"], "author": "toxicTom"}
{"word": [" Instantaneous."], "author": "Kleetus"}
{"word": ["Flash"], "author": "TaoTekko"}
{"word": ["Back."], "author": "viperfdl"}
{"word": ["to the future"], "author": "VeganDogMeat"}
{"word": [" Forth."], "author": "gixgox"}
{"word": ["forward"], "author": "TARFU"}
{"word": [" Upcoming."], "author": "Kleetus"}
{"word": [" Advance."], "author": "Hickory"}
{"word": [" Upcoming."], "author": "Kleetus"}
{"word": [" Advance."], "author": "Hickory"}
{"word": ["Progression."], "author": "gixgox"}
{"word": [" recession"], "author": "VeganDogMeat"}
{"word": ["Depression."], "author": "Hickory"}
{"word": ["Impression."], "author": "toxicTom"}
{"word": ["indentation"], "author": "Dzsono"}
{"word": ["Prestidigitation. :P"], "author": "GhostwriterDoF"}
{"word": ["Pickpocket"], "author": "Tcharr"}
{"word": ["Finger"], "author": "TaoTekko"}
{"word": ["hand"], "author": "Smogg"}
{"word": ["glove"], "author": "skimmie"}
{"word": ["Gauntlet."], "author": "viperfdl"}
{"word": ["challenge"], "author": "le_chevalier"}
{"word": ["obstacle"], "author": "Accatone"}
{"word": ["Barrier"], "author": "nebulosas"}
{"word": [" ", "."], "author": "gixgox"}
{"word": ["Climactic."], "author": "Hickory"}
{"word": ["apical"], "author": "mm324"}
{"word": ["consonant"], "author": "cose_vecchie"}
{"word": ["Vowel."], "author": "codefenix"}
{"word": ["Sequoia."], "author": "Hickory"}
{"word": ["huge"], "author": "mm324"}
{"word": ["Enormous."], "author": "REDVWIN"}
{"word": ["massive"], "author": "mm324"}
{"word": [], "author": "Zoltan999"}
{"word": ["ironclad"], "author": "Ardal"}
{"word": ["Inflexible."], "author": "Hickory"}
{"word": ["Rigid."], "author": "Narcia_"}
{"word": ["Stiffy."], "author": "eksasol"}
{"word": ["Wood."], "author": "toxicTom"}
{"word": ["Saw"], "author": "RagnarokDay"}
{"word": ["lumber"], "author": "TARFU"}
{"word": [" Tool."], "author": "Kleetus"}
{"word": [" "], "author": "gixgox"}
{"word": ["Plank."], "author": "Hickory"}
{"word": ["rigid"], "author": "Dzsono"}
{"word": ["Immutable."], "author": "Gravest"}
{"word": ["unchangeable"], "author": "GabesterOne"}
{"word": ["Static."], "author": "toxicTom"}
{"word": ["spark"], "author": "Tcharr"}
{"word": ["."], "author": "viperfdl"}
{"word": ["book"], "author": "Smogg"}
{"word": ["Worm"], "author": "Zoltan999"}
{"word": ["."], "author": "Hickory"}
{"word": ["caste"], "author": "Accatone"}
{"word": [" Dark"], "author": "koima57"}
{"word": ["evil"], "author": "le_chevalier"}
{"word": ["Ominous."], "author": "Hickory"}
{"word": ["Suspicious."], "author": "viperfdl"}
{"word": ["Dodgy"], "author": "Tcharr"}
{"word": ["sketchy"], "author": "mm324"}
{"word": ["Artsy."], "author": "codefenix"}
{"word": ["Pretentious."], "author": "Hickory"}
{"word": ["superficial"], "author": "Ardal"}
{"word": ["shallow"], "author": "ashwald"}
{"word": ["Puddle."], "author": "codefenix"}
{"word": ["Paddle."], "author": "gixgox"}
{"word": ["peddle"], "author": "le_chevalier"}
{"word": ["Haggle"], "author": "toxicTom"}
{"word": ["dicker"], "author": "mm324"}
{"word": ["Bicker."], "author": "Hickory"}
{"word": ["argue"], "author": "mm324"}
{"word": ["Fight."], "author": "toxicTom"}
{"word": ["Versus"], "author": "TaoTekko"}
{"word": ["Against."], "author": "toxicTom"}
{"word": ["*bump*"], "author": "toxicTom"}
{"word": ["opposing"], "author": "TARFU"}
{"word": ["force"], "author": "nicohvc"}
{"word": ["Vigour."], "author": "gixgox"}
{"word": ["vim"], "author": "Dzsono"}
{"word": ["vitality"], "author": "Tcharr"}
{"word": ["Hitpoints."], "author": "toxicTom"}
{"word": ["Mana."], "author": "viperfdl"}
{"word": ["manacle"], "author": "thomq"}
{"word": ["Trammel."], "author": "toxicTom"}
{"word": ["Bondage."], "author": "viperfdl"}
{"word": ["sadomasochism"], "author": "cose_vecchie"}
{"word": ["kinky"], "author": "Ardal"}
{"word": [], "author": "gixgox"}
{"word": ["Surreal."], "author": "Hickory"}
{"word": ["Dream"], "author": "Zoltan999"}
{"word": ["Lennox"], "author": "Tcharr"}
{"word": ["Diva"], "author": "toxicTom"}
{"word": ["Valkyrie"], "author": "TaoTekko"}
{"word": ["Profile"], "author": "ashwald"}
{"word": ["account"], "author": "le_chevalier"}
{"word": ["bank"], "author": "Tcharr"}
{"word": ["cash"], "author": "TARFU"}
{"word": ["Change."], "author": "toxicTom"}
{"word": ["coin"], "author": "oldgameryeah"}
{"word": ["Steal"], "author": "coryrj1995"}
{"word": ["Pickpocketing."], "author": "gixgox"}
{"word": ["deception"], "author": "Dzsono"}
{"word": [" Pilfer."], "author": "Kleetus"}
{"word": ["Illusion"], "author": "Tcharr"}
{"word": ["Dream"], "author": "toxicTom"}
{"word": ["Nightmare"], "author": "nebulosas"}
{"word": ["living"], "author": "Ardal"}
{"word": ["breathing"], "author": "nicohvc"}
{"word": ["diffusion"], "author": "thomq"}
{"word": ["Osmosis."], "author": "gixgox"}
{"word": [], "author": "mm324"}
{"word": ["Bones."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["Styx"], "author": "toxicTom"}
{"word": ["River."], "author": "Hickory"}
{"word": ["Flood."], "author": "codefenix"}
{"word": ["deluge"], "author": "Ardal"}
{"word": ["Pair"], "author": "TaoTekko"}
{"word": [" Torrent."], "author": "Hickory"}
{"word": [" Couple."], "author": "Kleetus"}
{"word": [" Torrent."], "author": "Hickory"}
{"word": ["........"], "author": "Kleetus"}
{"word": [" Current."], "author": "toxicTom"}
{"word": ["Flow."], "author": "Hickory"}
{"word": [" Couple."], "author": "Kleetus"}
{"word": [" Flow."], "author": "Hickory"}
{"word": [" Couple."], "author": "Kleetus"}
{"word": [" Flow."], "author": "Hickory"}
{"word": [" Couple."], "author": "Kleetus"}
{"word": [" pipe"], "author": "TARFU"}
{"word": [" Flow."], "author": "Kleetus"}
{"word": ["smoke"], "author": "Madshaker"}
{"word": [" ", " Vapour."], "author": "Hickory"}
{"word": [" Fume."], "author": "Kleetus"}
{"word": [" Exhalation."], "author": "gixgox"}
{"word": ["expulsion"], "author": "Dzsono"}
{"word": ["Play word association games when you are out and about with your child. You can let your child pick the first word, for example \u201ccat\u201d. You then think of a word off the top of your head that is connected like \u201cdog\u201d \u2013 it\u2019s an animal. Your child then chooses the next word that they associate with \u2018dog\u2019 - for example, \u2018bone\u2019. You keep going until you get stuck. Ask your child why they linked one word to the last if you don\u2019t understand. ", " ", " This is a game that gets your child thinking, making links (which is good for memory), and gives them an experience of having fun with words."], "author": "karlbjorkman"}
{"word": [" Exile."], "author": "toxicTom"}
{"word": ["game"], "author": "Tcharr"}
{"word": ["Recreation."], "author": "Hickory"}
{"word": ["Sleep."], "author": "viperfdl"}
{"word": ["dream"], "author": "Smogg"}
{"word": ["Subconscious"], "author": "Yezemin"}
{"word": ["mind"], "author": "le_chevalier"}
{"word": [], "author": "gixgox"}
{"word": ["body"], "author": "le_chevalier"}
{"word": ["heart"], "author": "Accatone"}
{"word": ["heartburn"], "author": "thomq"}
{"word": ["Reflux."], "author": "Hickory"}
{"word": ["Reflex."], "author": "codefenix"}
{"word": ["Speed."], "author": "toxicTom"}
{"word": ["Need"], "author": "Zoltan999"}
{"word": ["want"], "author": "mm324"}
{"word": [], "author": "gixgox"}
{"word": ["Died"], "author": "Tcharr"}
{"word": ["Cell"], "author": "TaoTekko"}
{"word": ["phone"], "author": "oldgameryeah"}
{"word": ["Modem."], "author": "toxicTom"}
{"word": ["demodulator"], "author": "Dzsono"}
{"word": ["Carrier."], "author": "Hickory"}
{"word": ["Flattop."], "author": "gixgox"}
{"word": ["Haircut"], "author": "TARFU"}
{"word": ["Barber."], "author": "toxicTom"}
{"word": ["Shaver."], "author": "REDVWIN"}
{"word": ["Tad"], "author": "Tcharr"}
{"word": [" ...pole"], "author": "gixgox"}
{"word": ["Polish"], "author": "le_chevalier"}
{"word": ["poland"], "author": "Accatone"}
{"word": ["Polska"], "author": "nebulosas"}
{"word": ["."], "author": "gixgox"}
{"word": ["river"], "author": "Smogg"}
{"word": ["stream"], "author": "mm324"}
{"word": ["Flow."], "author": "toxicTom"}
{"word": ["Floe."], "author": "Hickory"}
{"word": ["Ice"], "author": "mm324"}
{"word": ["Slush."], "author": "gixgox"}
{"word": ["Sludge."], "author": "toxicTom"}
{"word": ["Sewage."], "author": "Gravest"}
{"word": ["Raw"], "author": "Zoltan999"}
{"word": ["Meat."], "author": "codefenix"}
{"word": ["Muscle."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["Lard."], "author": "toxicTom"}
{"word": [], "author": "ashwald"}
{"word": ["Rock."], "author": "Narcia_"}
{"word": ["Sedimentary."], "author": "Hickory"}
{"word": ["Silt"], "author": "TaoTekko"}
{"word": ["river"], "author": "TARFU"}
{"word": [" Mud."], "author": "Kleetus"}
{"word": [" Tributary."], "author": "Hickory"}
{"word": ["Delta."], "author": "gixgox"}
{"word": ["Omega"], "author": "TARFU"}
{"word": ["greek"], "author": "Dzsono"}
{"word": ["Olympus."], "author": "toxicTom"}
{"word": [], "author": "viperfdl"}
{"word": ["Mars."], "author": "Gravest"}
{"word": ["Veneris"], "author": "toxicTom"}
{"word": ["Venus"], "author": "le_chevalier"}
{"word": ["Goddess."], "author": "viperfdl"}
{"word": ["Flytrap."], "author": "gixgox"}
{"word": ["Limerick"], "author": "Tcharr"}
{"word": ["lime"], "author": "Accatone"}
{"word": ["Green."], "author": "toxicTom"}
{"word": ["Tea"], "author": "mm324"}
{"word": ["Party"], "author": "Zoltan999"}
{"word": ["On."], "author": "codefenix"}
{"word": ["... line"], "author": "gixgox"}
{"word": ["Status."], "author": "REDVWIN"}
{"word": ["Social."], "author": "toxicTom"}
{"word": ["[Ninja'd] ", " ", ". ", " ", " ", " Media."], "author": "Hickory"}
{"word": ["mass"], "author": "Ardal"}
{"word": ["Size."], "author": "Narcia_"}
{"word": ["Matters."], "author": "gixgox"}
{"word": ["Matter."], "author": "toxicTom"}
{"word": ["mind"], "author": "Smogg"}
{"word": ["brain"], "author": "ashwald"}
{"word": [], "author": "toxicTom"}
{"word": ["Zombie."], "author": "Hickory"}
{"word": ["Television"], "author": "TaoTekko"}
{"word": ["screen"], "author": "Smogg"}
{"word": ["capture"], "author": "cose_vecchie"}
{"word": ["arrest"], "author": "Tcharr"}
{"word": ["jail"], "author": "TARFU"}
{"word": [" ... ", " ", " ", " "], "author": "gixgox"}
{"word": ["rock"], "author": "Dzsono"}
{"word": ["Blues."], "author": "codefenix"}
{"word": ["Won"], "author": "tinyE"}
{"word": [" Music."], "author": "Kleetus"}
{"word": [" Blind"], "author": "VeganDogMeat"}
{"word": [" "], "author": "gixgox"}
{"word": ["Wonderful"], "author": "nebulosas"}
{"word": ["beautiful"], "author": "Accatone"}
{"word": ["Gorgeous."], "author": "Gravest"}
{"word": ["maiden"], "author": "Ardal"}
{"word": ["Iron ", " ", " (I mean, come on, could I really associate any other word with Maiden, being an old metal head?)"], "author": "Zoltan999"}
{"word": ["Fist"], "author": "cose_vecchie"}
{"word": ["Punch."], "author": "codefenix"}
{"word": [" Northstar"], "author": "koima57"}
{"word": [" Drink"], "author": "cose_vecchie"}
{"word": ["Fluid."], "author": "toxicTom"}
{"word": ["flowing"], "author": "mm324"}
{"word": ["Nostril..."], "author": "GhostwriterDoF"}
{"word": ["...hair."], "author": "toxicTom"}
{"word": ["... dresser"], "author": "gixgox"}
{"word": ["Sideboard."], "author": "Hickory"}
{"word": ["elegant"], "author": "Ardal"}
{"word": ["fancy"], "author": "mm324"}
{"word": ["Posh."], "author": "toxicTom"}
{"word": ["Spice..."], "author": "codefenix"}
{"word": ["Space"], "author": "TaoTekko"}
{"word": ["travel"], "author": "Smogg"}
{"word": ["journal"], "author": "cose_vecchie"}
{"word": ["Diary."], "author": "Hickory"}
{"word": ["notebook"], "author": "TARFU"}
{"word": ["Laptop."], "author": "viperfdl"}
{"word": ["Computer"], "author": "oldgameryeah"}
{"word": ["Machine."], "author": "Gravest"}
{"word": [], "author": "gixgox"}
{"word": ["cyborg"], "author": "Dzsono"}
{"word": ["Synthetic."], "author": "Hickory"}
{"word": ["artificial"], "author": "le_chevalier"}
{"word": [" ", " ", " ", " ", " ", " "], "author": "gixgox"}
{"word": ["Counterfeit"], "author": "toxicTom"}
{"word": ["copy"], "author": "le_chevalier"}
{"word": ["... cat"], "author": "gixgox"}
{"word": ["cater"], "author": "Accatone"}
{"word": ["Caterpie"], "author": "nebulosas"}
{"word": ["caterpillar"], "author": "le_chevalier"}
{"word": ["Butterfly."], "author": "codefenix"}
{"word": [], "author": "Zoltan999"}
{"word": ["Fence."], "author": "Hickory"}
{"word": ["Post."], "author": "Narcia_"}
{"word": ["Office."], "author": "mm324"}
{"word": ["lady"], "author": "Ardal"}
{"word": ["Tramp."], "author": "codefenix"}
{"word": ["Stamp."], "author": "mm324"}
{"word": ["Mail."], "author": "toxicTom"}
{"word": ["Delivery."], "author": "Hickory"}
{"word": ["Pizza."], "author": "codefenix"}
{"word": ["crust."], "author": "mm324"}
{"word": ["Crunchy."], "author": "toxicTom"}
{"word": ["Bone"], "author": "TaoTekko"}
{"word": ["rib"], "author": "TARFU"}
{"word": ["Barbecue!!! ", " ", " ", " *yearning for spring*"], "author": "toxicTom"}
{"word": ["Cremation."], "author": "gixgox"}
{"word": ["dead"], "author": "kmonster"}
{"word": ["deceased"], "author": "Dzsono"}
{"word": [" ", " ", " ", " "], "author": "gixgox"}
{"word": [" Buried."], "author": "toxicTom"}
{"word": ["Interred."], "author": "Hickory"}
{"word": ["Entombed."], "author": "Gravest"}
{"word": ["Entomorph"], "author": "truhlik"}
{"word": ["Thunderscape."], "author": "toxicTom"}
{"word": ["landscape"], "author": "Accatone"}
{"word": ["Scapegoat."], "author": "gixgox"}
{"word": ["Goat"], "author": "nebulosas"}
{"word": ["Horns"], "author": "toxicTom"}
{"word": ["Brass"], "author": "cose_vecchie"}
{"word": ["Knuckles."], "author": "viperfdl"}
{"word": ["Joints."], "author": "Hickory"}
{"word": ["Gout"], "author": "toxicTom"}
{"word": ["Pain"], "author": "Zoltan999"}
{"word": ["painless"], "author": "thomq"}
{"word": ["Treatment."], "author": "Narcia_"}
{"word": ["Remedy."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["Satyr"], "author": "toxicTom"}
{"word": ["Dionysus"], "author": "Caesar."}
{"word": ["Dinosaurs."], "author": "codefenix"}
{"word": ["Sauropode."], "author": "gixgox"}
{"word": ["Lizard"], "author": "TaoTekko"}
{"word": ["Scale."], "author": "Hickory"}
{"word": ["weight"], "author": "cose_vecchie"}
{"word": ["class"], "author": "le_chevalier"}
{"word": ["teacher"], "author": "cose_vecchie"}
{"word": ["Mentor."], "author": "toxicTom"}
{"word": ["tutor"], "author": "le_chevalier"}
{"word": ["Guru."], "author": "Hickory"}
{"word": [" Trainer."], "author": "Kleetus"}
{"word": [" Guru."], "author": "Hickory"}
{"word": [" Dickory."], "author": "Kleetus"}
{"word": [" Guru."], "author": "Hickory"}
{"word": ["lama"], "author": "Dzsono"}
{"word": ["Camel."], "author": "Gravest"}
{"word": ["Desert."], "author": "Hickory"}
{"word": [" Kibble."], "author": "Kleetus"}
{"word": [" Dessert."], "author": "gixgox"}
{"word": [" Bones."], "author": "Kleetus"}
{"word": ["built"], "author": "kmonster"}
{"word": ["temple"], "author": "southern"}
{"word": ["Ruins"], "author": "Madshaker"}
{"word": ["ancient"], "author": "TARFU"}
{"word": ["antediluvian"], "author": "Ardal"}
{"word": ["Old."], "author": "toxicTom"}
{"word": ["mould ", " ", " Edit: can't spell :/"], "author": "Dzsono"}
{"word": ["mud"], "author": "Accatone"}
{"word": ["grass"], "author": "nicohvc"}
{"word": ["Lawnmower"], "author": "Caesar."}
{"word": ["reaper"], "author": "le_chevalier"}
{"word": ["Soul"], "author": "nebulosas"}
{"word": ["Spirit."], "author": "codefenix"}
{"word": ["ghost"], "author": "mm324"}
{"word": ["sheet"], "author": "ashwald"}
{"word": ["Bed"], "author": "mm324"}
{"word": ["Comfort."], "author": "Hickory"}
{"word": [" Mattress."], "author": "Kleetus"}
{"word": [" Zone."], "author": "gixgox"}
{"word": ["Category."], "author": "Narcia_"}
{"word": ["Paragraph"], "author": "TaoTekko"}
{"word": ["sentence"], "author": "oldgameryeah"}
{"word": ["Trial."], "author": "toxicTom"}
{"word": ["size."], "author": "mm324"}
{"word": ["Dimention."], "author": "Hickory"}
{"word": [" Dimension."], "author": "Kleetus"}
{"word": [" Dimension ", " ", " ", " ", " ", " ", " ", " :-P"], "author": "toxicTom"}
{"word": [" Brain-fart. (\uff61\uff65_\uff65\uff61)"], "author": "Hickory"}
{"word": [" Dimention."], "author": "Kleetus"}
{"word": ["dementia"], "author": "kmonster"}
{"word": ["Disease"], "author": "TARFU"}
{"word": ["scourge"], "author": "Dzsono"}
{"word": ["Infestation."], "author": "gixgox"}
{"word": ["Plague."], "author": "Hickory"}
{"word": [" Insanity."], "author": "Kleetus"}
{"word": [" Plague."], "author": "Hickory"}
{"word": ["Epidemic."], "author": "toxicTom"}
{"word": [" Insanity."], "author": "Kleetus"}
{"word": [" Pestilence."], "author": "Hickory"}
{"word": ["Infection."], "author": "toxicTom"}
{"word": ["Disease"], "author": "nebulosas"}
{"word": ["ease"], "author": "Accatone"}
{"word": ["Easy"], "author": "Zoltan999"}
{"word": ["Rider."], "author": "codefenix"}
{"word": [" Easy Rider - ome of my fav flicks.... ", " ", " ", " "], "author": "Zoltan999"}
{"word": ["... "], "author": "gixgox"}
{"word": ["viper"], "author": "mm324"}
{"word": ["cobra"], "author": "le_chevalier"}
{"word": [], "author": "cose_vecchie"}
{"word": ["general"], "author": "nicohvc"}
{"word": ["purpose"], "author": "cose_vecchie"}
{"word": ["Reason."], "author": "Hickory"}
{"word": [" Intent."], "author": "Kleetus"}
{"word": ["Crime"], "author": "TaoTekko"}
{"word": ["Thriller."], "author": "gixgox"}
{"word": ["Comedy."], "author": "Narcia_"}
{"word": ["Central."], "author": "codefenix"}
{"word": ["Station."], "author": "gixgox"}
{"word": ["Establishment."], "author": "Gravest"}
{"word": ["premises"], "author": "Dzsono"}
{"word": ["conclusion"], "author": "le_chevalier"}
{"word": ["ending"], "author": "TARFU"}
{"word": ["Finish."], "author": "toxicTom"}
{"word": ["complete"], "author": "le_chevalier"}
{"word": ["Edition"], "author": "Zoltan999"}
{"word": ["Addition."], "author": "codefenix"}
{"word": ["Audition."], "author": "Hickory"}
{"word": ["tryout"], "author": "mm324"}
{"word": ["Test"], "author": "nebulosas"}
{"word": ["reaction"], "author": "dbzane"}
{"word": ["Chemical."], "author": "codefenix"}
{"word": ["Biological."], "author": "Hickory"}
{"word": ["Alchemical"], "author": "nicohvc"}
{"word": ["potion"], "author": "BlackDawn"}
{"word": ["Elixer."], "author": "codefenix"}
{"word": ["Philtre."], "author": "gixgox"}
{"word": ["Mental"], "author": "TaoTekko"}
{"word": [" Cupid."], "author": "Hickory"}
{"word": [" Crazy."], "author": "Kleetus"}
{"word": [" Eros."], "author": "gixgox"}
{"word": ["Myth."], "author": "Hickory"}
{"word": [" Drink."], "author": "Kleetus"}
{"word": [" legend"], "author": "Dzsono"}
{"word": [" Fables"], "author": "TARFU"}
{"word": ["Morals."], "author": "Hickory"}
{"word": [" Crazy."], "author": "Kleetus"}
{"word": ["Decency. ", " "], "author": "gixgox"}
{"word": ["Extinct"], "author": "flubbucket"}
{"word": ["Gone"], "author": "Yezemin"}
{"word": ["Dodo."], "author": "gixgox"}
{"word": ["ode"], "author": "Accatone"}
{"word": ["Poem"], "author": "nebulosas"}
{"word": ["Composition"], "author": "Zoltan999"}
{"word": ["Makeup."], "author": "codefenix"}
{"word": ["Fiction."], "author": "gixgox"}
{"word": ["Tale"], "author": "koima57"}
{"word": ["fairy"], "author": "le_chevalier"}
{"word": ["dust"], "author": "ashwald"}
{"word": ["Bin."], "author": "gixgox"}
{"word": ["box"], "author": "mm324"}
{"word": ["Crate."], "author": "toxicTom"}
{"word": ["Loot"], "author": "mm324"}
{"word": ["Prize."], "author": "Narcia_"}
{"word": ["fight."], "author": "mm324"}
{"word": ["Conflict."], "author": "Hickory"}
{"word": ["escalation"], "author": "le_chevalier"}
{"word": ["Escalator"], "author": "toxicTom"}
{"word": [], "author": "gixgox"}
{"word": [" Increase."], "author": "Kleetus"}
{"word": ["Point"], "author": "TaoTekko"}
{"word": [" Squad."], "author": "Hickory"}
{"word": [" Finger."], "author": "Kleetus"}
{"word": [" platoon"], "author": "Dzsono"}
{"word": [" Location."], "author": "Kleetus"}
{"word": [" Infantry."], "author": "Hickory"}
{"word": [" Finger."], "author": "Kleetus"}
{"word": ["nail"], "author": "nicohvc"}
{"word": ["Hammer"], "author": "TARFU"}
{"word": [" Infantry."], "author": "Hickory"}
{"word": [" Time."], "author": "Kleetus"}
{"word": [" Infantry."], "author": "Hickory"}
{"word": [" Time."], "author": "Kleetus"}
{"word": [" Cavalry. ", " "], "author": "gixgox"}
{"word": ["Charge."], "author": "Hickory"}
{"word": ["Attack."], "author": "viperfdl"}
{"word": ["offense"], "author": "le_chevalier"}
{"word": ["defense"], "author": "Accatone"}
{"word": ["Attorney"], "author": "Zoltan999"}
{"word": [], "author": "nicohvc"}
{"word": ["."], "author": "gixgox"}
{"word": ["Dust."], "author": "codefenix"}
{"word": ["wind"], "author": "le_chevalier"}
{"word": ["Tunnel."], "author": "Hickory"}
{"word": ["vision"], "author": "ashwald"}
{"word": ["Sight."], "author": "Narcia_"}
{"word": ["Eye"], "author": "mm324"}
{"word": ["."], "author": "Hickory"}
{"word": ["Classic"], "author": "mm324"}
{"word": ["Antiquity"], "author": "TaoTekko"}
{"word": ["Ancient."], "author": "Gravest"}
{"word": ["ancestor"], "author": "le_chevalier"}
{"word": ["Forefathers/-mothers."], "author": "gixgox"}
{"word": [" Relative."], "author": "Kleetus"}
{"word": [" Progenitor."], "author": "Hickory"}
{"word": [" Relative."], "author": "Kleetus"}
{"word": [" Progenitor."], "author": "Hickory"}
{"word": [" Relative."], "author": "Kleetus"}
{"word": [" Forebearer."], "author": "gixgox"}
{"word": [" Pallbearer"], "author": "JohnnyDangerDCD"}
{"word": ["Undertaker."], "author": "Hickory"}
{"word": [" Mourner."], "author": "Kleetus"}
{"word": [" Undertaker."], "author": "Hickory"}
{"word": [" Mourner."], "author": "Kleetus"}
{"word": ["speeder"], "author": "kmonster"}
{"word": ["Racer"], "author": "TARFU"}
{"word": ["Automobile."], "author": "Gravest"}
{"word": ["transportation"], "author": "Dzsono"}
{"word": ["means"], "author": "le_chevalier"}
{"word": ["easier"], "author": "tort1234"}
{"word": ["difficult"], "author": "Accatone"}
{"word": ["Hard"], "author": "Yezemin"}
{"word": [" ...ship."], "author": "gixgox"}
{"word": ["Vessel."], "author": "Hickory"}
{"word": ["blood"], "author": "cose_vecchie"}
{"word": ["Rain"], "author": "TaoTekko"}
{"word": ["."], "author": "gixgox"}
{"word": ["Cumulonimbus"], "author": "nebulosas"}
{"word": ["Meteorology"], "author": "Zoltan999"}
{"word": ["Meteor."], "author": "toxicTom"}
{"word": ["Shower."], "author": "codefenix"}
{"word": ["Cap."], "author": "gixgox"}
{"word": ["Baseball"], "author": "mm324"}
{"word": ["Umpire..."], "author": "GhostwriterDoF"}
{"word": ["mask"], "author": "mm324"}
{"word": [" ", " "], "author": "gixgox"}
{"word": ["Fairy."], "author": "Narcia_"}
{"word": ["dust."], "author": "mm324"}
{"word": ["Dirt."], "author": "codefenix"}
{"word": ["soil"], "author": "mm324"}
{"word": [], "author": "gixgox"}
{"word": [" Stain."], "author": "Kleetus"}
{"word": [" Laundry."], "author": "Hickory"}
{"word": [" Stain."], "author": "Kleetus"}
{"word": [" Laundry."], "author": "Hickory"}
{"word": [" Stain."], "author": "Kleetus"}
{"word": [" Laundry."], "author": "Hickory"}
{"word": [" Rack."], "author": "gixgox"}
{"word": [" shelf"], "author": "TARFU"}
{"word": [" Stain."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["Drift."], "author": "gixgox"}
{"word": [" Stain."], "author": "Kleetus"}
{"word": [" Meander."], "author": "Hickory"}
{"word": [" Stain."], "author": "Kleetus"}
{"word": [" Meander."], "author": "Hickory"}
{"word": ["wander"], "author": "mm324"}
{"word": ["Drift."], "author": "toxicTom"}
{"word": [" ", " Rebound. ;-p"], "author": "Hickory"}
{"word": [], "author": "viperfdl"}
{"word": ["Substance."], "author": "toxicTom"}
{"word": ["matter"], "author": "Dzsono"}
{"word": ["atom"], "author": "Accatone"}
{"word": ["Nucleus"], "author": "nebulosas"}
{"word": ["core"], "author": "Ardal"}
{"word": ["Reactor"], "author": "Zoltan999"}
{"word": ["Generator."], "author": "codefenix"}
{"word": ["Transformer."], "author": "gixgox"}
{"word": ["Robot"], "author": "GammaEmerald"}
{"word": ["Android."], "author": "Gravest"}
{"word": ["Cyborg."], "author": "Hickory"}
{"word": ["Borg."], "author": "gixgox"}
{"word": [" Humanoid."], "author": "Kleetus"}
{"word": [" Adaptability."], "author": "Hickory"}
{"word": ["Submission."], "author": "gixgox"}
{"word": ["ASSIMILATION"], "author": "GammaEmerald"}
{"word": ["incorporation"], "author": "mm324"}
{"word": ["Stealth"], "author": "TaoTekko"}
{"word": ["sneak"], "author": "mm324"}
{"word": ["Yes-person."], "author": "gixgox"}
{"word": [" Crawl."], "author": "Kleetus"}
{"word": [" Sycophant."], "author": "Hickory"}
{"word": [" Crawl."], "author": "Kleetus"}
{"word": [" Sycophant."], "author": "Hickory"}
{"word": [" Crawl."], "author": "Kleetus"}
{"word": [" Sycophant."], "author": "Hickory"}
{"word": [" Crawl."], "author": "Kleetus"}
{"word": [" Sycophant."], "author": "Hickory"}
{"word": ["elephant"], "author": "thomq"}
{"word": ["Tusk."], "author": "toxicTom"}
{"word": ["Ivory."], "author": "Hickory"}
{"word": ["Tower"], "author": "cose_vecchie"}
{"word": ["House"], "author": "GammaEmerald"}
{"word": ["mouse"], "author": "thomq"}
{"word": ["Terrier."], "author": "Kleetus"}
{"word": [" Hamster."], "author": "gixgox"}
{"word": [" Terrier."], "author": "Kleetus"}
{"word": ["Wheel"], "author": "kmonster"}
{"word": ["Cart"], "author": "GammaEmerald"}
{"word": ["Oxen."], "author": "Hickory"}
{"word": [" beast"], "author": "TARFU"}
{"word": ["burden"], "author": "Dzsono"}
{"word": ["Tribulation."], "author": "Hickory"}
{"word": ["Trial"], "author": "GammaEmerald"}
{"word": ["judge"], "author": "le_chevalier"}
{"word": ["Attorney"], "author": "toxicTom"}
{"word": ["district"], "author": "Accatone"}
{"word": ["Region."], "author": "Hickory"}
{"word": ["Manager"], "author": "Zoltan999"}
{"word": ["president"], "author": "thomq"}
{"word": ["CEO."], "author": "viperfdl"}
{"word": ["Neo"], "author": "thomq"}
{"word": ["New."], "author": "codefenix"}
{"word": ["Fake."], "author": "gixgox"}
{"word": ["fa\u00e7ade"], "author": "thomq"}
{"word": ["masquerade"], "author": "mm324"}
{"word": ["Carnival."], "author": "gixgox"}
{"word": ["party"], "author": "mm324"}
{"word": ["Game"], "author": "GammaEmerald"}
{"word": ["play."], "author": "mm324"}
{"word": ["Entertainment"], "author": "nebulosas"}
{"word": ["entertainer"], "author": "Ardal"}
{"word": ["."], "author": "gixgox"}
{"word": ["Syncopation."], "author": "Hickory"}
{"word": ["Sycophant"], "author": "GammaEmerald"}
{"word": ["Vair"], "author": "TaoTekko"}
{"word": [" Crawler."], "author": "Hickory"}
{"word": [" Fur."], "author": "Kleetus"}
{"word": [" Crawler."], "author": "Hickory"}
{"word": [" Fur."], "author": "Kleetus"}
{"word": ["Cat"], "author": "GammaEmerald"}
{"word": [" :)"], "author": "GhostwriterDoF"}
{"word": [" Crawler."], "author": "Hickory"}
{"word": [" prowler"], "author": "TARFU"}
{"word": ["Stalker."], "author": "Hickory"}
{"word": [" Pram."], "author": "Kleetus"}
{"word": [" Creep."], "author": "gixgox"}
{"word": ["stalk"], "author": "Dzsono"}
{"word": [" Pram."], "author": "Kleetus"}
{"word": ["Dam"], "author": "SamMagel"}
{"word": [" Stem."], "author": "Hickory"}
{"word": [" Log."], "author": "gixgox"}
{"word": ["Book."], "author": "Hickory"}
{"word": ["Library ", " (Also Hickory you're rather selfish)"], "author": "GammaEmerald"}
{"word": ["Sockpuppet."], "author": "Hickory"}
{"word": ["Marionette."], "author": "gixgox"}
{"word": [" Repository."], "author": "Kleetus"}
{"word": [" String."], "author": "Hickory"}
{"word": [" ", "."], "author": "gixgox"}
{"word": ["Mime."], "author": "Hickory"}
{"word": [], "author": "toxicTom"}
{"word": ["Silent."], "author": "codefenix"}
{"word": ["Passive."], "author": "Hickory"}
{"word": ["Active"], "author": "nebulosas"}
{"word": ["Engaged."], "author": "toxicTom"}
{"word": ["committed"], "author": "mm324"}
{"word": ["Married"], "author": "GammaEmerald"}
{"word": ["Comet."], "author": "Narcia_"}
{"word": [" Confused. :/"], "author": "Hickory"}
{"word": ["Puzzled. ", " ", " (I believe \"Comet\" was in response to \"committed\", but was ninja'd)"], "author": "codefenix"}
{"word": ["Eureka!"], "author": "Hickory"}
{"word": ["Breakthrough."], "author": "LoboBlanco"}
{"word": ["Epiphany."], "author": "Gravest"}
{"word": ["Revelation."], "author": "codefenix"}
{"word": ["."], "author": "gixgox"}
{"word": ["Beholder"], "author": "TaoTekko"}
{"word": ["vision"], "author": "bhrigu"}
{"word": ["Avenger"], "author": "JohnnyDangerDCD"}
{"word": ["revenge"], "author": "kmonster"}
{"word": ["Malice."], "author": "Hickory"}
{"word": [" Retaliate."], "author": "Kleetus"}
{"word": [" Malice."], "author": "Hickory"}
{"word": [" animosity"], "author": "TARFU"}
{"word": ["Rancour."], "author": "Hickory"}
{"word": [" Retaliate."], "author": "Kleetus"}
{"word": [" Odium."], "author": "gixgox"}
{"word": ["Disgust."], "author": "Hickory"}
{"word": ["repulsion"], "author": "Dzsono"}
{"word": ["Magnetics ", " (Kleetus and Hickory, chill)"], "author": "GammaEmerald"}
{"word": ["compass"], "author": "le_chevalier"}
{"word": ["maps"], "author": "golfmade"}
{"word": ["drawn"], "author": "Ardal"}
{"word": ["Art."], "author": "viperfdl"}
{"word": ["Expression."], "author": "Hickory"}
{"word": ["press"], "author": "Accatone"}
{"word": ["Expressionism."], "author": "gixgox"}
{"word": ["Impressionism"], "author": "nebulosas"}
{"word": ["Impersonation."], "author": "codefenix"}
{"word": ["Mimicry."], "author": "Hickory"}
{"word": ["mimeography"], "author": "thomq"}
{"word": ["copies"], "author": "mm324"}
{"word": ["Facsimile."], "author": "Hickory"}
{"word": ["simile"], "author": "thomq"}
{"word": ["Simulacrum"], "author": "toxicTom"}
{"word": [" Simulation"], "author": "bhrigu"}
{"word": ["Emulation."], "author": "codefenix"}
{"word": [" Imitation"], "author": "bhrigu"}
{"word": ["Metamorphosis"], "author": "TaoTekko"}
{"word": ["transformation"], "author": "mm324"}
{"word": ["Mutation."], "author": "toxicTom"}
{"word": [" Alteration."], "author": "Kleetus"}
{"word": [" Beast. ", " ", " (Altered Beast. lol)"], "author": "JohnnyDangerDCD"}
{"word": ["Cancerous"], "author": "sanscript"}
{"word": [" Evolution."], "author": "Hickory"}
{"word": [" Progression"], "author": "TARFU"}
{"word": [" Malignant."], "author": "Kleetus"}
{"word": [" Accretion."], "author": "gixgox"}
{"word": [" Malignant."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" Badge."], "author": "gixgox"}
{"word": ["Medal."], "author": "toxicTom"}
{"word": ["Gold"], "author": "golfmade"}
{"word": ["metal"], "author": "le_chevalier"}
{"word": ["alloy"], "author": "thomq"}
{"word": ["smelting"], "author": "Ardal"}
{"word": ["Are we ignoring words that we don't like now? O_o ", " ", " If so, do tell me..."], "author": "sanscript"}
{"word": ["Blacksmith"], "author": "Zoltan999"}
{"word": [" [Just ignoring the resident troll (Kleetus) and its sockpuppets]. ", " ", " Farrier."], "author": "Hickory"}
{"word": ["Hephaestus."], "author": "gixgox"}
{"word": ["Vulcan."], "author": "Hickory"}
{"word": ["Volcano"], "author": "nebulosas"}
{"word": ["magma"], "author": "Accatone"}
{"word": [" Earth"], "author": "bhrigu"}
{"word": ["Venus."], "author": "codefenix"}
{"word": [" Planet"], "author": "bhrigu"}
{"word": ["world"], "author": "mm324"}
{"word": [" "], "author": "gixgox"}
{"word": ["Abound."], "author": "codefenix"}
{"word": ["Astound."], "author": "Hickory"}
{"word": ["confound"], "author": "thomq"}
{"word": ["confuse"], "author": "mm324"}
{"word": ["Puzzle"], "author": "bhrigu"}
{"word": ["Jigsaw."], "author": "gixgox"}
{"word": ["Fretsaw."], "author": "Hickory"}
{"word": ["woodworker"], "author": "thomq"}
{"word": ["Shaving"], "author": "TaoTekko"}
{"word": ["Clipping."], "author": "Hickory"}
{"word": ["Cuting"], "author": "oldgameryeah"}
{"word": ["Cute."], "author": "GammaEmerald"}
{"word": ["small"], "author": "TARFU"}
{"word": [" Precious."], "author": "Kleetus"}
{"word": ["me"], "author": "Tauto"}
{"word": [" insignificant"], "author": "Dzsono"}
{"word": [" Insignificant."], "author": "Kleetus"}
{"word": [" Trivial."], "author": "Hickory"}
{"word": [" Bathetic."], "author": "gixgox"}
{"word": [" Insignificant."], "author": "Kleetus"}
{"word": [" Let-down."], "author": "Hickory"}
{"word": [" Insignificant."], "author": "Kleetus"}
{"word": [" Let-down."], "author": "Hickory"}
{"word": [" Potty."], "author": "gixgox"}
{"word": ["Crazy."], "author": "toxicTom"}
{"word": [" rugrat."], "author": "Tauto"}
{"word": [" Insane."], "author": "Hickory"}
{"word": ["Lunatic."], "author": "viperfdl"}
{"word": ["Lunar."], "author": "codefenix"}
{"word": ["mission"], "author": "Namxas01"}
{"word": ["complete."], "author": "mm324"}
{"word": ["Game"], "author": "GammaEmerald"}
{"word": ["Done."], "author": "toxicTom"}
{"word": [" Over"], "author": "JohnnyDangerDCD"}
{"word": [" ... "], "author": "gixgox"}
{"word": ["Mercy."], "author": "codefenix"}
{"word": ["Spare"], "author": "GammaEmerald"}
{"word": [" Tire"], "author": "JohnnyDangerDCD"}
{"word": ["tired...zzzzzzzzzzzzzzzzzzzzzz"], "author": "gixgox"}
{"word": ["Sleepy."], "author": "codefenix"}
{"word": ["."], "author": "Hickory"}
{"word": ["Out."], "author": "Narcia_"}
{"word": [], "author": "mm324"}
{"word": ["Mad"], "author": "Azrael360"}
{"word": ["Max."], "author": "mm324"}
{"word": ["Min."], "author": "toxicTom"}
{"word": ["least"], "author": "mm324"}
{"word": ["Yeast."], "author": "Hickory"}
{"word": ["bread"], "author": "mm324"}
{"word": ["\u0421orn"], "author": "TaoTekko"}
{"word": ["kernel."], "author": "mm324"}
{"word": ["Core."], "author": "Hickory"}
{"word": ["center"], "author": "Ardal"}
{"word": ["middle"], "author": "le_chevalier"}
{"word": ["finger"], "author": "Accatone"}
{"word": ["nail"], "author": "JohnnyDangerDCD"}
{"word": ["road"], "author": "Ardal"}
{"word": [" highway"], "author": "TARFU"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" ", "."], "author": "gixgox"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" ..."], "author": "gixgox"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" Breeder."], "author": "Hickory"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" Breeder."], "author": "Hickory"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" Breeder."], "author": "Hickory"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" Grower."], "author": "gixgox"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" Farmer."], "author": "Hickory"}
{"word": [" Cultivator."], "author": "gixgox"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" Harvester."], "author": "Hickory"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" Harvester."], "author": "Hickory"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" Harvester."], "author": "Hickory"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" Harvester."], "author": "Hickory"}
{"word": [" "], "author": "gixgox"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" Redacted."], "author": "Hickory"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" Redacted."], "author": "Hickory"}
{"word": [" Street."], "author": "Kleetus"}
{"word": [" Sesame ", " (someone stop these two clowns!)"], "author": "GammaEmerald"}
{"word": [" Obscured."], "author": "gixgox"}
{"word": [" Seeds."], "author": "Kleetus"}
{"word": [" Covered."], "author": "Hickory"}
{"word": [" Seeds."], "author": "Kleetus"}
{"word": [" "], "author": "flubbucket"}
{"word": ["Bun ", " (meant as a reply to seeds and covered)"], "author": "GammaEmerald"}
{"word": [" Covered."], "author": "Hickory"}
{"word": ["Naked."], "author": "gixgox"}
{"word": [" Enough. ", " As in, enough is enough, you're being a baby now, I created a decent reconciliation and you dismissed it. ", " ", " Knock"], "author": "GammaEmerald"}
{"word": [" Fight."], "author": "Kleetus"}
{"word": ["What"], "author": "GammaEmerald"}
{"word": [" Bare."], "author": "toxicTom"}
{"word": ["essence"], "author": "thomq"}
{"word": ["time"], "author": "Ardal"}
{"word": ["Capsule."], "author": "Hickory"}
{"word": [" peace."], "author": "Tauto"}
{"word": [" Capsule."], "author": "Hickory"}
{"word": [" Detonator."], "author": "gixgox"}
{"word": ["Propellant."], "author": "Hickory"}
{"word": ["Aerosol."], "author": "gixgox"}
{"word": ["Pollution."], "author": "Hickory"}
{"word": ["Business."], "author": "viperfdl"}
{"word": ["pleasure"], "author": "Accatone"}
{"word": ["Happiness"], "author": "nebulosas"}
{"word": ["Smile"], "author": "oldgameryeah"}
{"word": ["cheese"], "author": "le_chevalier"}
{"word": ["."], "author": "gixgox"}
{"word": ["."], "author": "Hickory"}
{"word": ["Ninja'd ", " ", " Mystery"], "author": "Zoltan999"}
{"word": [], "author": "gixgox"}
{"word": ["Story."], "author": "Hickory"}
{"word": ["Time."], "author": "codefenix"}
{"word": ["zone."], "author": "mm324"}
{"word": ["Prison"], "author": "TaoTekko"}
{"word": ["riot"], "author": "GammaEmerald"}
{"word": ["Rebellion."], "author": "viperfdl"}
{"word": ["Outbreak."], "author": "gixgox"}
{"word": [" Uprising."], "author": "Kleetus"}
{"word": [" Downfall"], "author": "JohnnyDangerDCD"}
{"word": [" "], "author": "GhostwriterDoF"}
{"word": [" Eruption."], "author": "Hickory"}
{"word": [" Californiation."], "author": "Kleetus"}
{"word": [" Eruption."], "author": "Hickory"}
{"word": [" Capitalism."], "author": "Kleetus"}
{"word": [" Eruption."], "author": "Hickory"}
{"word": [" Capitalism."], "author": "Kleetus"}
{"word": [" Eruption."], "author": "Hickory"}
{"word": [" Capitalism."], "author": "Kleetus"}
{"word": ["cap"], "author": "kmonster"}
{"word": [" Steve"], "author": "JohnnyDangerDCD"}
{"word": ["Stave."], "author": "Narcia_"}
{"word": [" barrel"], "author": "TARFU"}
{"word": [" Volcano"], "author": "toxicTom"}
{"word": ["fertility"], "author": "le_chevalier"}
{"word": ["vigour"], "author": "Dzsono"}
{"word": ["Fitness."], "author": "Hickory"}
{"word": ["Planet"], "author": "GammaEmerald"}
{"word": ["World"], "author": "Azrael360"}
{"word": ["Moon"], "author": "risingcomet"}
{"word": ["Luna"], "author": "toxicTom"}
{"word": ["Goddess."], "author": "Hickory"}
{"word": ["Demoness."], "author": "viperfdl"}
{"word": [" Devil"], "author": "deathrabit"}
{"word": ["Fiend."], "author": "Hickory"}
{"word": [" ", " ", " "], "author": "toxicTom"}
{"word": ["doom"], "author": "Accatone"}
{"word": ["acceptance"], "author": "thomq"}
{"word": ["Denial."], "author": "toxicTom"}
{"word": ["Egypt"], "author": "thomq"}
{"word": ["Pun."], "author": "Hickory"}
{"word": ["."], "author": "gixgox"}
{"word": ["jog"], "author": "mm324"}
{"word": ["Run"], "author": "nebulosas"}
{"word": ["Clueless."], "author": "GammaEmerald"}
{"word": ["Doll"], "author": "TaoTekko"}
{"word": ["Shoes."], "author": "Narcia_"}
{"word": [" Trot."], "author": "Hickory"}
{"word": ["horse"], "author": "mm324"}
{"word": ["Stable."], "author": "Hickory"}
{"word": ["barn"], "author": "mm324"}
{"word": ["Hay."], "author": "Hickory"}
{"word": ["stack."], "author": "mm324"}
{"word": ["Pile."], "author": "Hickory"}
{"word": ["heap"], "author": "mm324"}
{"word": ["Mound."], "author": "Hickory"}
{"word": ["Burial"], "author": "mm324"}
{"word": ["Mourning"], "author": "toxicTom"}
{"word": ["sorrow"], "author": "mm324"}
{"word": ["Misery."], "author": "Gravest"}
{"word": ["Grief."], "author": "gixgox"}
{"word": ["Angst."], "author": "Hickory"}
{"word": ["Teenage"], "author": "mm324"}
{"word": [" school"], "author": "TARFU"}
{"word": ["teacher."], "author": "mm324"}
{"word": ["Sage"], "author": "Dzsono"}
{"word": ["brush"], "author": "TheSun"}
{"word": ["comb"], "author": "mm324"}
{"word": ["scissors"], "author": "nicohvc"}
{"word": ["Paper."], "author": "gixgox"}
{"word": [" Rock."], "author": "Kleetus"}
{"word": [" Sheet."], "author": "toxicTom"}
{"word": ["Pentagram"], "author": "nebulosas"}
{"word": ["pen"], "author": "Accatone"}
{"word": [], "author": "gixgox"}
{"word": ["Heptatonic"], "author": "toxicTom"}
{"word": ["Scale."], "author": "Hickory"}
{"word": ["Measure."], "author": "viperfdl"}
{"word": ["Ruler"], "author": "Allinstein"}
{"word": ["Chronometer..."], "author": "GhostwriterDoF"}
{"word": ["."], "author": "gixgox"}
{"word": ["Watches."], "author": "Hickory"}
{"word": ["clockwork"], "author": "Ardal"}
{"word": [], "author": "nicohvc"}
{"word": ["Juice"], "author": "Caesar."}
{"word": ["box."], "author": "mm324"}
{"word": ["Crate."], "author": "codefenix"}
{"word": ["trunk"], "author": "mm324"}
{"word": ["Road."], "author": "Hickory"}
{"word": ["Asphalt"], "author": "TaoTekko"}
{"word": ["Tar."], "author": "toxicTom"}
{"word": [" Paving."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" Paving."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["trades"], "author": "Ardal"}
{"word": [" automobile"], "author": "TARFU"}
{"word": [" Swaps."], "author": "Kleetus"}
{"word": ["Autobus."], "author": "gixgox"}
{"word": [" Swaps."], "author": "Kleetus"}
{"word": [" automate"], "author": "Dzsono"}
{"word": ["Dehumanize."], "author": "Gravest"}
{"word": ["Alienation."], "author": "viperfdl"}
{"word": ["Alien"], "author": "nebulosas"}
{"word": ["ancestor"], "author": "thomq"}
{"word": ["old"], "author": "Ardal"}
{"word": ["new"], "author": "Accatone"}
{"word": ["unverified"], "author": "thomq"}
{"word": ["Certified."], "author": "viperfdl"}
{"word": ["Imitated."], "author": "gixgox"}
{"word": ["Aped."], "author": "Hickory"}
{"word": ["Pooched."], "author": "codefenix"}
{"word": [" Dog. :)"], "author": "Kleetus"}
{"word": ["Snoop"], "author": "TaoTekko"}
{"word": ["Sneak"], "author": "JohnnyDangerDCD"}
{"word": ["Hide."], "author": "Narcia_"}
{"word": ["Skin."], "author": "codefenix"}
{"word": ["Bone."], "author": "toxicTom"}
{"word": ["ivory"], "author": "mm324"}
{"word": ["ebony"], "author": "le_chevalier"}
{"word": ["Raven."], "author": "Gravest"}
{"word": ["crow"], "author": "TARFU"}
{"word": [" Crow."], "author": "Kleetus"}
{"word": ["Toucan"], "author": "nicohvc"}
{"word": ["tropical"], "author": "Dzsono"}
{"word": [" Bird."], "author": "Kleetus"}
{"word": [" Island"], "author": "toxicTom"}
{"word": [" Bird."], "author": "Kleetus"}
{"word": [" Island."], "author": "toxicTom"}
{"word": [" Bird."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": ["."], "author": "viperfdl"}
{"word": ["\u200eSkyscraper"], "author": "nebulosas"}
{"word": ["london"], "author": "Ardal"}
{"word": ["."], "author": "gixgox"}
{"word": ["rich"], "author": "Accatone"}
{"word": ["Poor"], "author": "JohnnyDangerDCD"}
{"word": [" Sub-par"], "author": "jimmerdip"}
{"word": ["Shoddy."], "author": "codefenix"}
{"word": ["Sloppy."], "author": "Hickory"}
{"word": ["Mess"], "author": "Zoltan999"}
{"word": ["Hall."], "author": "mm324"}
{"word": ["Corridor."], "author": "Hickory"}
{"word": ["passageway"], "author": "mm324"}
{"word": ["Arterial... :)"], "author": "GhostwriterDoF"}
{"word": ["Blood"], "author": "rouge1701"}
{"word": ["Vessel."], "author": "gixgox"}
{"word": ["Ship."], "author": "codefenix"}
{"word": ["Aft..."], "author": "GhostwriterDoF"}
{"word": ["Stern."], "author": "toxicTom"}
{"word": ["Strict."], "author": "Hickory"}
{"word": ["discipline"], "author": "mm324"}
{"word": ["strength"], "author": "kmonster"}
{"word": ["Attribute"], "author": "TaoTekko"}
{"word": ["Property."], "author": "codefenix"}
{"word": ["properly"], "author": "thomq"}
{"word": ["Propensity."], "author": "gixgox"}
{"word": ["antipensive"], "author": "thomq"}
{"word": ["tendency"], "author": "TARFU"}
{"word": [" Oppose."], "author": "Kleetus"}
{"word": [" Unintended."], "author": "gixgox"}
{"word": ["motivation"], "author": "thomq"}
{"word": ["impetus"], "author": "Dzsono"}
{"word": ["Momentum."], "author": "toxicTom"}
{"word": ["velocity"], "author": "thomq"}
{"word": ["Speed."], "author": "Hickory"}
{"word": ["cop"], "author": "Ardal"}
{"word": ["attitude"], "author": "thomq"}
{"word": ["Contempt."], "author": "Hickory"}
{"word": ["court"], "author": "le_chevalier"}
{"word": ["Scornfulness. ", " ", " ", " ", " ", " <ninja'd>"], "author": "gixgox"}
{"word": ["gesture"], "author": "thomq"}
{"word": ["Sign"], "author": "Yezemin"}
{"word": ["Symbol"], "author": "nebulosas"}
{"word": ["Ideogram."], "author": "Hickory"}
{"word": ["gram"], "author": "Accatone"}
{"word": ["Grammar."], "author": "gixgox"}
{"word": ["Grandma."], "author": "Hickory"}
{"word": ["Gramps."], "author": "gixgox"}
{"word": ["Grumpy."], "author": "Hickory"}
{"word": ["Grouchy."], "author": "codefenix"}
{"word": ["Grinch"], "author": "Zoltan999"}
{"word": ["killjoy"], "author": "mm324"}
{"word": ["Griefer."], "author": "toxicTom"}
{"word": [" Spoilsport."], "author": "Kleetus"}
{"word": ["Sports car"], "author": "TaoTekko"}
{"word": [" Troll."], "author": "Hickory"}
{"word": [" Automobile."], "author": "Kleetus"}
{"word": [" Troll."], "author": "Hickory"}
{"word": ["Bridge."], "author": "viperfdl"}
{"word": ["Kennel."], "author": "Kleetus"}
{"word": ["Dog"], "author": "rouge1701"}
{"word": ["Terrier."], "author": "Kleetus"}
{"word": [" Canasta."], "author": "gixgox"}
{"word": ["Blackjack."], "author": "Hickory"}
{"word": [" Terrier. :)"], "author": "Kleetus"}
{"word": [" Rummy."], "author": "gixgox"}
{"word": [" Terrier. :)"], "author": "Kleetus"}
{"word": ["Moo !"], "author": "kmonster"}
{"word": [" Cards"], "author": "TARFU"}
{"word": ["Deck."], "author": "Hickory"}
{"word": ["Ace"], "author": "oldgameryeah"}
{"word": ["spadille"], "author": "le_chevalier"}
{"word": ["trump"], "author": "Dzsono"}
{"word": ["dump"], "author": "TheSun"}
{"word": ["Waste."], "author": "toxicTom"}
{"word": [" Defecate."], "author": "Kleetus"}
{"word": [" Squander."], "author": "Hickory"}
{"word": ["Misuse."], "author": "Gravest"}
{"word": ["Abuse."], "author": "viperfdl"}
{"word": ["Eurythmics"], "author": "thomq"}
{"word": ["rhythm"], "author": "Accatone"}
{"word": ["moves"], "author": "Ardal"}
{"word": ["moonwalk"], "author": "thomq"}
{"word": ["Moon"], "author": "nebulosas"}
{"word": ["Satellite."], "author": "gixgox"}
{"word": ["dish."], "author": "mm324"}
{"word": ["Plate"], "author": "Zoltan999"}
{"word": ["Fork."], "author": "viperfdl"}
{"word": ["Pitch."], "author": "codefenix"}
{"word": ["catch"], "author": "mm324"}
{"word": ["Fish"], "author": "JohnnyDangerDCD"}
{"word": ["Fillet."], "author": "gixgox"}
{"word": [" Pisces."], "author": "Kleetus"}
{"word": [" Steak."], "author": "gixgox"}
{"word": ["Cow"], "author": "TaoTekko"}
{"word": ["Milka"], "author": "Gog8"}
{"word": ["Pint."], "author": "Hickory"}
{"word": ["Beer"], "author": "JohnnyDangerDCD"}
{"word": ["Root."], "author": "LoboBlanco"}
{"word": ["Rotten."], "author": "gixgox"}
{"word": [" Branch."], "author": "Kleetus"}
{"word": [" Tomato."], "author": "gixgox"}
{"word": [" Branch."], "author": "Kleetus"}
{"word": [" Ketchup."], "author": "Hickory"}
{"word": ["Jam"], "author": "tort1234"}
{"word": ["Sandwich."], "author": "Hickory"}
{"word": [" Preserve."], "author": "Kleetus"}
{"word": [" bread ", " ", " bread"], "author": "TARFU"}
{"word": ["Butter."], "author": "gixgox"}
{"word": ["churn."], "author": "mm324"}
{"word": ["Whisk."], "author": "Hickory"}
{"word": ["detergent"], "author": "thomq"}
{"word": [" Stir. ", " ", " Soap."], "author": "Kleetus"}
{"word": [" Deterrent."], "author": "gixgox"}
{"word": [" Soap."], "author": "Kleetus"}
{"word": [" disincentive"], "author": "Dzsono"}
{"word": [" Soap."], "author": "Kleetus"}
{"word": [" Discouragement."], "author": "gixgox"}
{"word": ["prevention"], "author": "le_chevalier"}
{"word": ["Barrier."], "author": "Hickory"}
{"word": ["language"], "author": "Ardal"}
{"word": ["Country"], "author": "nebulosas"}
{"word": [" ...side."], "author": "gixgox"}
{"word": ["site"], "author": "Accatone"}
{"word": ["location"], "author": "rouge1701"}
{"word": ["position"], "author": "mm324"}
{"word": ["Whereabouts."], "author": "Hickory"}
{"word": ["Thereabout."], "author": "gixgox"}
{"word": ["Roundabout."], "author": "codefenix"}
{"word": ["merry\u2013go\u2013round"], "author": "mm324"}
{"word": ["Carousel."], "author": "toxicTom"}
{"word": ["horses."], "author": "mm324"}
{"word": ["."], "author": "Hickory"}
{"word": ["Steep."], "author": "codefenix"}
{"word": ["steeple"], "author": "thomq"}
{"word": [" People"], "author": "JohnnyDangerDCD"}
{"word": ["Crowd."], "author": "toxicTom"}
{"word": [" Citizens."], "author": "Kleetus"}
{"word": [" Congruence..."], "author": "GhostwriterDoF"}
{"word": ["Coherence"], "author": "TaoTekko"}
{"word": ["Cohesive."], "author": "codefenix"}
{"word": ["Glue"], "author": "rouge1701"}
{"word": ["Super"], "author": "mm324"}
{"word": ["Hyper."], "author": "toxicTom"}
{"word": ["scooter"], "author": "XYCat"}
{"word": ["drive. ", " ninja'd ", " ", " Motor"], "author": "mm324"}
{"word": ["Engine."], "author": "Hickory"}
{"word": ["Steam"], "author": "mm324"}
{"word": ["Vapour."], "author": "toxicTom"}
{"word": ["cloud"], "author": "mm324"}
{"word": ["Cumulus."], "author": "toxicTom"}
{"word": ["Nimbus."], "author": "Gravest"}
{"word": ["Halo."], "author": "toxicTom"}
{"word": ["Rainbow."], "author": "Narcia_"}
{"word": ["Trout."], "author": "Hickory"}
{"word": ["Char(r)."], "author": "gixgox"}
{"word": ["scorch"], "author": "TARFU"}
{"word": ["Torch"], "author": "le_chevalier"}
{"word": ["Battery."], "author": "Hickory"}
{"word": [" Burn."], "author": "Kleetus"}
{"word": [" Incinerate"], "author": "NinjaShadow24"}
{"word": [" Charger."], "author": "gixgox"}
{"word": ["Destrier."], "author": "Hickory"}
{"word": ["Horse"], "author": "nebulosas"}
{"word": ["Wrangler."], "author": "viperfdl"}
{"word": ["jeans"], "author": "BlackDawn"}
{"word": ["western"], "author": "Accatone"}
{"word": [], "author": "Zoltan999"}
{"word": ["Ravioli"], "author": "toxicTom"}
{"word": ["penne"], "author": "mm324"}
{"word": ["sauce"], "author": "Ardal"}
{"word": ["Coulis."], "author": "Hickory"}
{"word": ["Dressing."], "author": "REDVWIN"}
{"word": ["Swimmingly... :D"], "author": "GhostwriterDoF"}
{"word": ["bandage"], "author": "thomq"}
{"word": ["Gown. ", " <ninja'd> ", " ", " Tape."], "author": "gixgox"}
{"word": ["Duct."], "author": "toxicTom"}
{"word": ["Tube."], "author": "Hickory"}
{"word": ["Underground."], "author": "gixgox"}
{"word": ["Metro."], "author": "toxicTom"}
{"word": ["Year"], "author": "TaoTekko"}
{"word": ["Date"], "author": "nebulosas"}
{"word": ["Dinner"], "author": "mm324"}
{"word": ["late"], "author": "ashwald"}
{"word": ["Night."], "author": "toxicTom"}
{"word": ["... mare."], "author": "gixgox"}
{"word": ["Foal."], "author": "Hickory"}
{"word": ["cub"], "author": "TARFU"}
{"word": ["Offspring."], "author": "Gravest"}
{"word": ["Bedspring."], "author": "gixgox"}
{"word": ["bouncing"], "author": "Dzsono"}
{"word": ["balls"], "author": "kmonster"}
{"word": ["."], "author": "gixgox"}
{"word": [" Testicles."], "author": "Kleetus"}
{"word": [" Rage."], "author": "gixgox"}
{"word": [" Testicles."], "author": "Kleetus"}
{"word": [" Tantrum."], "author": "Hickory"}
{"word": [" lonesome."], "author": "Tauto"}
{"word": [" Temper."], "author": "gixgox"}
{"word": ["Steel"], "author": "Yezemin"}
{"word": ["cold"], "author": "le_chevalier"}
{"word": ["Flu."], "author": "gixgox"}
{"word": ["Sickness."], "author": "viperfdl"}
{"word": ["Infirmity."], "author": "gixgox"}
{"word": ["Infirmary."], "author": "toxicTom"}
{"word": ["Sanitarium."], "author": "Hickory"}
{"word": ["hospital"], "author": "Ardal"}
{"word": ["Theme"], "author": "nebulosas"}
{"word": ["park"], "author": "Accatone"}
{"word": ["wildlife"], "author": "Zoltan999"}
{"word": ["Indigenous."], "author": "Hickory"}
{"word": ["Native."], "author": "Narcia_"}
{"word": ["Aborigine."], "author": "gixgox"}
{"word": ["indigenous"], "author": "mm324"}
{"word": ["Repetition."], "author": "Hickory"}
{"word": ["Copycat."], "author": "gixgox"}
{"word": ["Coincidental..? :P"], "author": "GhostwriterDoF"}
{"word": ["fated"], "author": "Ardal"}
{"word": ["Ordained."], "author": "Hickory"}
{"word": ["Forced."], "author": "gixgox"}
{"word": [" Doomed."], "author": "Kleetus"}
{"word": ["Cancer"], "author": "TaoTekko"}
{"word": ["Survivor"], "author": "tinyE"}
{"word": [" Testicular."], "author": "Kleetus"}
{"word": [" Alive."], "author": "toxicTom"}
{"word": [" living"], "author": "TARFU"}
{"word": ["dead"], "author": "kmonster"}
{"word": ["corpse"], "author": "Dzsono"}
{"word": ["flesh"], "author": "nicohvc"}
{"word": ["fletch"], "author": "morrowslant"}
{"word": ["Flash"], "author": "tort1234"}
{"word": ["Flare."], "author": "Gravest"}
{"word": ["Solar."], "author": "toxicTom"}
{"word": ["polar"], "author": "thomq"}
{"word": ["Ice."], "author": "Hickory"}
{"word": ["Cream"], "author": "Yezemin"}
{"word": ["Cone."], "author": "gixgox"}
{"word": ["Conical."], "author": "Hickory"}
{"word": ["Comical."], "author": "toxicTom"}
{"word": ["Comic-Con."], "author": "gixgox"}
{"word": ["Convention."], "author": "Hickory"}
{"word": ["custom"], "author": "Accatone"}
{"word": ["Hall. ", " ninja'd ", " ", " habit"], "author": "mm324"}
{"word": ["Habitat."], "author": "gixgox"}
{"word": ["Home"], "author": "nebulosas"}
{"word": ["Sweet."], "author": "gixgox"}
{"word": ["Merciful."], "author": "codefenix"}
{"word": ["Compassionate."], "author": "Hickory"}
{"word": ["Empathy"], "author": "Zoltan999"}
{"word": ["salesman"], "author": "thomq"}
{"word": ["Traveling."], "author": "codefenix"}
{"word": ["Wanderer."], "author": "Narcia_"}
{"word": [" Roamer"], "author": "JohnnyDangerDCD"}
{"word": ["Rogue"], "author": "TaoTekko"}
{"word": ["."], "author": "gixgox"}
{"word": ["red"], "author": "kmonster"}
{"word": ["Herring,"], "author": "gixgox"}
{"word": [" sardines"], "author": "TARFU"}
{"word": ["canned"], "author": "le_chevalier"}
{"word": ["canceled"], "author": "Dzsono"}
{"word": ["Abandoned."], "author": "Gravest"}
{"word": ["deserted"], "author": "le_chevalier"}
{"word": ["Alone."], "author": "viperfdl"}
{"word": ["Solitary."], "author": "Hickory"}
{"word": ["Confinement."], "author": "toxicTom"}
{"word": ["Containment."], "author": "codefenix"}
{"word": ["container"], "author": "Accatone"}
{"word": ["Flask"], "author": "Zoltan999"}
{"word": ["."], "author": "gixgox"}
{"word": ["Neck."], "author": "Hickory"}
{"word": ["tie."], "author": "mm324"}
{"word": ["draw"], "author": "le_chevalier"}
{"word": ["String."], "author": "codefenix"}
{"word": ["Noose."], "author": "gixgox"}
{"word": ["Loose."], "author": "Hickory"}
{"word": ["Goose."], "author": "codefenix"}
{"word": ["Bump."], "author": "toxicTom"}
{"word": ["Up..."], "author": "TaoTekko"}
{"word": ["Mesosphere... :)"], "author": "GhostwriterDoF"}
{"word": ["Ionsphere"], "author": "Madshaker"}
{"word": ["Stratosphere."], "author": "Hickory"}
{"word": ["Troposphere."], "author": "Gravest"}
{"word": ["sky"], "author": "Dzsono"}
{"word": ["stars"], "author": "TARFU"}
{"word": ["Planetoids."], "author": "gixgox"}
{"word": ["asteroid"], "author": "le_chevalier"}
{"word": ["Steroids."], "author": "gixgox"}
{"word": ["Hormones."], "author": "toxicTom"}
{"word": ["Teenagers."], "author": "viperfdl"}
{"word": ["edgy"], "author": "Ardal"}
{"word": ["Angst."], "author": "Hickory"}
{"word": ["Torment"], "author": "nebulosas"}
{"word": ["Abuse"], "author": "Zoltan999"}
{"word": ["Torture"], "author": "Yezemin"}
{"word": ["Ordeal."], "author": "Hickory"}
{"word": ["order"], "author": "Accatone"}
{"word": ["disruption"], "author": "mm324"}
{"word": ["Eruption."], "author": "viperfdl"}
{"word": ["."], "author": "codefenix"}
{"word": [" Emission."], "author": "Hickory"}
{"word": ["Omission..."], "author": "GhostwriterDoF"}
{"word": ["Emission."], "author": "codefenix"}
{"word": ["Radiation."], "author": "toxicTom"}
{"word": ["Solar"], "author": "TaoTekko"}
{"word": ["Flare."], "author": "LoboBlanco"}
{"word": ["Signal."], "author": "Hickory"}
{"word": ["Gesticulate."], "author": "Gravest"}
{"word": ["Countenance."], "author": "viperfdl"}
{"word": ["lose"], "author": "Ardal"}
{"word": ["Misplace"], "author": "Zoltan999"}
{"word": ["Forgetful"], "author": "jamyskis"}
{"word": ["Where?"], "author": "gixgox"}
{"word": ["disremember"], "author": "Accatone"}
{"word": ["omit"], "author": "mm324"}
{"word": ["Disappear."], "author": "REDVWIN"}
{"word": ["Dimaterialise."], "author": "gixgox"}
{"word": ["vaporize"], "author": "mm324"}
{"word": ["Obliterate"], "author": "TARFU"}
{"word": ["eradicate"], "author": "mm324"}
{"word": ["Exterminate."], "author": "Hickory"}
{"word": ["Incinerate."], "author": "gixgox"}
{"word": ["Disintegrate"], "author": "Yezemin"}
{"word": ["Vaporize."], "author": "Narcia_"}
{"word": ["sublime"], "author": "thomq"}
{"word": [" Atomise."], "author": "Hickory"}
{"word": ["Corpuscle"], "author": "TaoTekko"}
{"word": ["artery"], "author": "TARFU"}
{"word": ["blood"], "author": "kmonster"}
{"word": ["Vessel."], "author": "Gravest"}
{"word": ["Ship."], "author": "codefenix"}
{"word": ["Captain"], "author": "TheBible"}
{"word": ["Paragon"], "author": "Dzsono"}
{"word": ["Gong"], "author": "nebulosas"}
{"word": [" Commander."], "author": "Hickory"}
{"word": ["."], "author": "codefenix"}
{"word": ["Eager"], "author": "Yezemin"}
{"word": ["enthused"], "author": "mm324"}
{"word": ["Passionate."], "author": "Hickory"}
{"word": ["ardent"], "author": "mm324"}
{"word": ["love ", " ", " Edit: Ninja'd!"], "author": "Accatone"}
{"word": ["Peace"], "author": "Zoltan999"}
{"word": ["Piece."], "author": "codefenix"}
{"word": ["gun"], "author": "thomq"}
{"word": ["Powder."], "author": "viperfdl"}
{"word": ["keg"], "author": "Ardal"}
{"word": ["Barrel."], "author": "xieliming"}
{"word": ["Cask."], "author": "REDVWIN"}
{"word": ["Flagon."], "author": "Narcia_"}
{"word": ["Growler."], "author": "codefenix"}
{"word": ["Refill."], "author": "Hickory"}
{"word": ["fuel"], "author": "TARFU"}
{"word": ["refuel"], "author": "le_chevalier"}
{"word": ["Energy"], "author": "TaoTekko"}
{"word": ["Charge."], "author": "toxicTom"}
{"word": ["Cavalry"], "author": "mm324"}
{"word": ["Stable."], "author": "LoboBlanco"}
{"word": ["Volatile."], "author": "jamyskis"}
{"word": [], "author": "toxicTom"}
{"word": ["mirror"], "author": "kmonster"}
{"word": ["image"], "author": "TARFU"}
{"word": ["Impression."], "author": "Gravest"}
{"word": ["cast"], "author": "Dzsono"}
{"word": ["Iron"], "author": "TheBible"}
{"word": ["food"], "author": "le_chevalier"}
{"word": ["flood"], "author": "Accatone"}
{"word": ["email"], "author": "Ardal"}
{"word": ["Spam."], "author": "viperfdl"}
{"word": ["eggs"], "author": "thomq"}
{"word": ["Animals"], "author": "nebulosas"}
{"word": ["beasts"], "author": "mm324"}
{"word": ["Monsters."], "author": "codefenix"}
{"word": ["Dungeons."], "author": "Hickory"}
{"word": ["Keeper"], "author": "Zoltan999"}
{"word": ["dragons"], "author": "mm324"}
{"word": ["."], "author": "gixgox"}
{"word": ["Horse"], "author": "TaoTekko"}
{"word": ["Shoe."], "author": "Narcia_"}
{"word": ["laces"], "author": "TARFU"}
{"word": ["Ribbon."], "author": "Hickory"}
{"word": [" Footwear."], "author": "Kleetus"}
{"word": [" Ribbon."], "author": "Hickory"}
{"word": ["Bow."], "author": "gixgox"}
{"word": [" Laces."], "author": "Kleetus"}
{"word": [" Tie."], "author": "gixgox"}
{"word": [" Knot."], "author": "Hickory"}
{"word": ["Vertex."], "author": "gixgox"}
{"word": ["joining"], "author": "Dzsono"}
{"word": [" ", " ", " RIP Chuck Berry"], "author": "gixgox"}
{"word": [" WHAO shit! ", " We need a thread. ", " ", " and a month of mourning. ", " ", " Sorry about the thread intrusion there, it just kind of shocked me."], "author": "tinyE"}
{"word": [" sadness"], "author": "mm324"}
{"word": ["Memories...."], "author": "gixgox"}
{"word": [" Feeling."], "author": "Kleetus"}
{"word": ["Memoirs"], "author": "SamMagel"}
{"word": [" Nostalgia."], "author": "Hickory"}
{"word": ["Feeling."], "author": "REDVWIN"}
{"word": ["Perception"], "author": "TaoTekko"}
{"word": ["Impression"], "author": "nebulosas"}
{"word": ["impressive"], "author": "Accatone"}
{"word": ["deeds"], "author": "Ardal"}
{"word": ["Actions."], "author": "toxicTom"}
{"word": ["Consequences."], "author": "Hickory"}
{"word": ["ramifications"], "author": "mm324"}
{"word": ["Effects."], "author": "codefenix"}
{"word": ["Side"], "author": "le_chevalier"}
{"word": ["facet"], "author": "TARFU"}
{"word": ["pool"], "author": "kmonster"}
{"word": ["Billiards."], "author": "Gravest"}
{"word": ["felt"], "author": "Dzsono"}
{"word": ["Carambole."], "author": "REDVWIN"}
{"word": ["Snooker."], "author": "codefenix"}
{"word": ["Billiards"], "author": "nebulosas"}
{"word": ["Balls."], "author": "viperfdl"}
{"word": ["orbs"], "author": "mm324"}
{"word": [], "author": "codefenix"}
{"word": ["minerals"], "author": "mm324"}
{"word": ["vegetable"], "author": "thomq"}
{"word": ["Tablecloth."], "author": "gixgox"}
{"word": ["Cutlery."], "author": "Hickory"}
{"word": ["Silver"], "author": "Yezemin"}
{"word": ["longjohns"], "author": "thomq"}
{"word": ["longing"], "author": "Accatone"}
{"word": ["Yearning."], "author": "Narcia_"}
{"word": ["Pining."], "author": "codefenix"}
{"word": ["Craving."], "author": "Hickory"}
{"word": ["Lust."], "author": "gixgox"}
{"word": ["desire"], "author": "Ardal"}
{"word": ["Despair"], "author": "PaterAlf"}
{"word": ["Hope"], "author": "TaoTekko"}
{"word": ["Glimmer."], "author": "Hickory"}
{"word": [" Despair."], "author": "Kleetus"}
{"word": [" Glimmer."], "author": "Hickory"}
{"word": [" Despair."], "author": "Kleetus"}
{"word": [" Glimmer."], "author": "Hickory"}
{"word": [" Despair."], "author": "Kleetus"}
{"word": [" Glimmer."], "author": "Hickory"}
{"word": [" Despair."], "author": "Kleetus"}
{"word": [" Glimmer."], "author": "Hickory"}
{"word": [" Despair."], "author": "Kleetus"}
{"word": ["Hope."], "author": "T.Hodd"}
{"word": [" Glimmer."], "author": "Hickory"}
{"word": ["sparkle"], "author": "mm324"}
{"word": ["Shine"], "author": "TARFU"}
{"word": ["Twinkle."], "author": "Gravest"}
{"word": ["."], "author": "Hickory"}
{"word": [" Star."], "author": "Kleetus"}
{"word": [" ", "."], "author": "Hickory"}
{"word": [" Clavus."], "author": "gixgox"}
{"word": ["callus"], "author": "le_chevalier"}
{"word": ["Corn"], "author": "Zoltan999"}
{"word": ["tortilla"], "author": "thomq"}
{"word": ["Wrap."], "author": "gixgox"}
{"word": ["Taco"], "author": "nebulosas"}
{"word": ["burrito"], "author": "mm324"}
{"word": ["burr"], "author": "Accatone"}
{"word": ["Barb."], "author": "codefenix"}
{"word": ["Thorn."], "author": "Hickory"}
{"word": ["Sting."], "author": "toxicTom"}
{"word": ["Clown"], "author": "TaoTekko"}
{"word": ["jester"], "author": "TARFU"}
{"word": ["Court."], "author": "Narcia_"}
{"word": ["ball"], "author": "gagaga"}
{"word": [], "author": "gixgox"}
{"word": ["programming"], "author": "Dzsono"}
{"word": ["Job."], "author": "toxicTom"}
{"word": ["Labor."], "author": "REDVWIN"}
{"word": ["hard"], "author": "le_chevalier"}
{"word": ["Difficult"], "author": "Zoltan999"}
{"word": ["easy"], "author": "Accatone"}
{"word": ["Simple."], "author": "codefenix"}
{"word": ["Complicated"], "author": "nebulosas"}
{"word": [], "author": "gixgox"}
{"word": ["Entwined"], "author": "oldgameryeah"}
{"word": ["Ensnared."], "author": "codefenix"}
{"word": ["netted"], "author": "mm324"}
{"word": ["Grossed."], "author": "codefenix"}
{"word": ["income."], "author": "mm324"}
{"word": ["Expenditure."], "author": "Hickory"}
{"word": ["Acquisition."], "author": "toxicTom"}
{"word": ["takeover"], "author": "mm324"}
{"word": ["occupy"], "author": "dbzane"}
{"word": ["House"], "author": "oldgameryeah"}
{"word": ["Fortress"], "author": "TaoTekko"}
{"word": ["Bastion."], "author": "Hickory"}
{"word": [" Defence."], "author": "Kleetus"}
{"word": [" Bastion."], "author": "Hickory"}
{"word": ["Cannons."], "author": "viperfdl"}
{"word": ["Balls."], "author": "toxicTom"}
{"word": ["space"], "author": "Smogg"}
{"word": ["Pirate."], "author": "Hickory"}
{"word": ["ship"], "author": "TARFU"}
{"word": ["Water"], "author": "PaterAlf"}
{"word": [" Craft."], "author": "Kleetus"}
{"word": ["hot"], "author": "kmonster"}
{"word": [" ", " Chocolate."], "author": "Hickory"}
{"word": ["Dark."], "author": "Gravest"}
{"word": ["pitch"], "author": "Dzsono"}
{"word": ["Elevator."], "author": "REDVWIN"}
{"word": ["lift"], "author": "le_chevalier"}
{"word": ["Raise"], "author": "TARFU"}
{"word": ["Promotion"], "author": "Zoltan999"}
{"word": ["Sale."], "author": "codefenix"}
{"word": ["clearance"], "author": "Ardal"}
{"word": ["."], "author": "gixgox"}
{"word": ["Music."], "author": "viperfdl"}
{"word": ["spring"], "author": "Accatone"}
{"word": ["Season."], "author": "REDVWIN"}
{"word": ["episode"], "author": "dbzane"}
{"word": ["Cliffhanger."], "author": "gixgox"}
{"word": ["suspenseful"], "author": "mm324"}
{"word": ["Suspension."], "author": "codefenix"}
{"word": ["lowrider"], "author": "thomq"}
{"word": ["Vehicle"], "author": "nebulosas"}
{"word": ["Wheels."], "author": "toxicTom"}
{"word": ["Tires."], "author": "gixgox"}
{"word": ["Bicycle"], "author": "TaoTekko"}
{"word": ["Cyclopaedia."], "author": "gixgox"}
{"word": [" Trike."], "author": "Kleetus"}
{"word": [" dictionary"], "author": "TARFU"}
{"word": [" Trike."], "author": "Kleetus"}
{"word": [" Book."], "author": "toxicTom"}
{"word": [" Trike."], "author": "Kleetus"}
{"word": ["page"], "author": "kmonster"}
{"word": ["Folio."], "author": "gixgox"}
{"word": [" Paper."], "author": "Kleetus"}
{"word": [], "author": "s_a"}
{"word": [" Leaf."], "author": "Hickory"}
{"word": ["Greenery."], "author": "gixgox"}
{"word": ["Asparagus"], "author": "Gorilla123"}
{"word": ["vegetable"], "author": "Dzsono"}
{"word": ["cabbage"], "author": "TARFU"}
{"word": ["rage"], "author": "Accatone"}
{"word": ["Fury."], "author": "toxicTom"}
{"word": [], "author": "viperfdl"}
{"word": ["chicken"], "author": "le_chevalier"}
{"word": ["Bird"], "author": "nebulosas"}
{"word": ["Feathers."], "author": "toxicTom"}
{"word": ["Pillow."], "author": "gixgox"}
{"word": ["Fight."], "author": "codefenix"}
{"word": ["flight"], "author": "Ardal"}
{"word": ["NVM Ninja'd"], "author": "Zoltan999"}
{"word": [" ", " ", " "], "author": "gixgox"}
{"word": ["Light"], "author": "Zoltan999"}
{"word": ["Tight."], "author": "viperfdl"}
{"word": ["Rope"], "author": "Gorilla123"}
{"word": ["Dope."], "author": "gixgox"}
{"word": ["idiot"], "author": "mm324"}
{"word": ["Imbecile"], "author": "Gorilla123"}
{"word": ["dullard"], "author": "mm324"}
{"word": ["."], "author": "Hickory"}
{"word": ["Threat"], "author": "TaoTekko"}
{"word": ["Scared"], "author": "Gorilla123"}
{"word": ["Trembling."], "author": "gixgox"}
{"word": ["leaf"], "author": "Gorilla123"}
{"word": ["branch"], "author": "TARFU"}
{"word": ["Twig."], "author": "toxicTom"}
{"word": ["dogs"], "author": "Gorilla123"}
{"word": ["bark"], "author": "Dzsono"}
{"word": [], "author": "gixgox"}
{"word": ["spicy"], "author": "le_chevalier"}
{"word": ["curry"], "author": "ashwald"}
{"word": ["india"], "author": "Smogg"}
{"word": ["tea"], "author": "Ardal"}
{"word": ["eat"], "author": "Accatone"}
{"word": ["ate"], "author": "thomq"}
{"word": ["Devour."], "author": "Gravest"}
{"word": ["Starving."], "author": "viperfdl"}
{"word": ["craving"], "author": "le_chevalier"}
{"word": ["Chocolate"], "author": "Gorilla123"}
{"word": ["Temptation."], "author": "REDVWIN"}
{"word": ["Enticing"], "author": "Zoltan999"}
{"word": ["alluring"], "author": "mm324"}
{"word": ["bait"], "author": "Ardal"}
{"word": ["Switch."], "author": "gixgox"}
{"word": ["Lever."], "author": "Hickory"}
{"word": ["Trap."], "author": "viperfdl"}
{"word": ["Greek"], "author": "TaoTekko"}
{"word": [], "author": "s_a"}
{"word": ["."], "author": "gixgox"}
{"word": [" Heracles."], "author": "Kleetus"}
{"word": [" glasses"], "author": "Gorilla123"}
{"word": ["Spectacle."], "author": "Hickory"}
{"word": ["party"], "author": "kmonster"}
{"word": ["Balloons"], "author": "Gorilla123"}
{"word": ["dirigible"], "author": "le_chevalier"}
{"word": ["Blimp."], "author": "Gravest"}
{"word": ["Zeppelin."], "author": "viperfdl"}
{"word": ["pelerine"], "author": "Accatone"}
{"word": ["cape"], "author": "BlackDawn"}
{"word": ["fear"], "author": "Tauto"}
{"word": ["desire"], "author": "thomq"}
{"word": ["Stalk"], "author": "Zoltan999"}
{"word": ["hunt"], "author": "mm324"}
{"word": ["Chase"], "author": "nebulosas"}
{"word": ["stalk"], "author": "Dzsono"}
{"word": ["celery"], "author": "thomq"}
{"word": ["Peanut-butter"], "author": "Gorilla123"}
{"word": ["Vegemite."], "author": "gixgox"}
{"word": ["australian"], "author": "Ardal"}
{"word": ["southern"], "author": "thomq"}
{"word": ["Texas"], "author": "Gorilla123"}
{"word": ["State."], "author": "Hickory"}
{"word": ["country"], "author": "Gorilla123"}
{"word": ["Hill"], "author": "TaoTekko"}
{"word": [" -", "."], "author": "gixgox"}
{"word": ["Implacable..."], "author": "GhostwriterDoF"}
{"word": ["inflexible"], "author": "TARFU"}
{"word": ["Brittle"], "author": "Gorilla123"}
{"word": ["peanut"], "author": "thomq"}
{"word": ["Chestnut."], "author": "gixgox"}
{"word": ["Walnut."], "author": "Gravest"}
{"word": ["almond"], "author": "TARFU"}
{"word": [" Cashew."], "author": "Kleetus"}
{"word": ["eyes"], "author": "Dzsono"}
{"word": ["Glasses."], "author": "gixgox"}
{"word": ["Superman"], "author": "VampiroAlhazred"}
{"word": ["alien"], "author": "le_chevalier"}
{"word": ["E.T."], "author": "viperfdl"}
{"word": ["movie"], "author": "Ardal"}
{"word": ["theater."], "author": "mm324"}
{"word": ["Stage."], "author": "toxicTom"}
{"word": ["Play"], "author": "Gorilla123"}
{"word": ["book"], "author": "Accatone"}
{"word": ["Library"], "author": "nebulosas"}
{"word": ["api"], "author": "nicohvc"}
{"word": ["Apiary."], "author": "Narcia_"}
{"word": ["Swarm"], "author": "TaoTekko"}
{"word": ["Zerg."], "author": "viperfdl"}
{"word": ["Arthropod."], "author": "Hickory"}
{"word": ["invertebrate"], "author": "TARFU"}
{"word": ["vertebrae"], "author": "Gorilla123"}
{"word": ["spined"], "author": "Dzsono"}
{"word": ["Spineless."], "author": "GhostwriterDoF"}
{"word": ["Spiney."], "author": "Kleetus"}
{"word": [" Dastard."], "author": "gixgox"}
{"word": ["Conniving"], "author": "flubbucket"}
{"word": ["conspire"], "author": "Accatone"}
{"word": ["treason"], "author": "Ardal"}
{"word": ["Betrayal."], "author": "Gravest"}
{"word": ["coward"], "author": "thomq"}
{"word": ["craven"], "author": "mm324"}
{"word": ["Timorous."], "author": "Hickory"}
{"word": ["Oriental"], "author": "TaoTekko"}
{"word": ["Trading"], "author": "Gorilla123"}
{"word": ["bartering"], "author": "TARFU"}
{"word": [" Swapping."], "author": "Kleetus"}
{"word": ["commerce"], "author": "Dzsono"}
{"word": ["Market"], "author": "le_chevalier"}
{"word": ["Trade"], "author": "nebulosas"}
{"word": ["Fair."], "author": "gixgox"}
{"word": ["sportsmanship"], "author": "Ardal"}
{"word": ["Chivalry."], "author": "viperfdl"}
{"word": ["Knight"], "author": "Zoltan999"}
{"word": ["Crusader."], "author": "Gravest"}
{"word": ["zealot"], "author": "mm324"}
{"word": ["Fanboy."], "author": "viperfdl"}
{"word": ["fanzine"], "author": "Accatone"}
{"word": ["Doujin."], "author": "toxicTom"}
{"word": ["Shogun"], "author": "TaoTekko"}
{"word": ["Lord"], "author": "Azrael360"}
{"word": ["master"], "author": "mm324"}
{"word": ["Apprentice."], "author": "Hickory"}
{"word": ["Padawan."], "author": "gixgox"}
{"word": ["Jedi"], "author": "TARFU"}
{"word": ["knight"], "author": "kmonster"}
{"word": ["Rook"], "author": "oldgameryeah"}
{"word": ["equine"], "author": "Dzsono"}
{"word": ["Bovine."], "author": "Kleetus"}
{"word": ["manure"], "author": "thomq"}
{"word": ["stink"], "author": "gixgox"}
{"word": ["Stench."], "author": "viperfdl"}
{"word": ["smell"], "author": "Accatone"}
{"word": ["Proboscis"], "author": "Zoltan999"}
{"word": ["latin"], "author": "Ardal"}
{"word": ["Language"], "author": "nebulosas"}
{"word": ["communication"], "author": "mm324"}
{"word": ["Chat."], "author": "gixgox"}
{"word": ["gab"], "author": "mm324"}
{"word": ["blabber"], "author": "Dzsono"}
{"word": ["babble"], "author": "le_chevalier"}
{"word": ["Babylon."], "author": "Narcia_"}
{"word": ["Language"], "author": "TaoTekko"}
{"word": ["trade"], "author": "le_chevalier"}
{"word": ["Barter."], "author": "viperfdl"}
{"word": ["Fallout."], "author": "Carradice"}
{"word": ["radiation"], "author": "TARFU"}
{"word": [], "author": "gixgox"}
{"word": ["Sobriquet."], "author": "Hickory"}
{"word": [" Tactics."], "author": "Kleetus"}
{"word": ["Strategy."], "author": "viperfdl"}
{"word": ["plan"], "author": "Ardal"}
{"word": ["Emergency"], "author": "Zoltan999"}
{"word": ["Exit."], "author": "gixgox"}
{"word": ["existence"], "author": "Accatone"}
{"word": ["living"], "author": "Agrilla"}
{"word": [], "author": "gixgox"}
{"word": ["ninja'd ", " ", " human"], "author": "viperfdl"}
{"word": ["mortal"], "author": "mm324"}
{"word": ["Vulnerable"], "author": "oldgameryeah"}
{"word": ["Hole"], "author": "TaoTekko"}
{"word": ["leak"], "author": "le_chevalier"}
{"word": ["dripping"], "author": "TARFU"}
{"word": ["Drop."], "author": "Casval_Deikun"}
{"word": ["Splash"], "author": "oldgameryeah"}
{"word": ["waves"], "author": "Dzsono"}
{"word": ["Gesticulate."], "author": "Gravest"}
{"word": ["signal"], "author": "le_chevalier"}
{"word": ["Batman"], "author": "thomq"}
{"word": ["Issues"], "author": "datennuke"}
{"word": ["Edition."], "author": "gixgox"}
{"word": ["Collection"], "author": "nebulosas"}
{"word": ["Stamps."], "author": "viperfdl"}
{"word": ["Seal."], "author": "gixgox"}
{"word": ["Walrus"], "author": "Zoltan999"}
{"word": ["manatee"], "author": "Ardal"}
{"word": ["cow"], "author": "Accatone"}
{"word": ["People"], "author": "Gorilla123"}
{"word": ["Mover."], "author": "Narcia_"}
{"word": ["Earth"], "author": "mm324"}
{"word": ["Wind."], "author": "REDVWIN"}
{"word": ["Hurricane"], "author": "Caesar."}
{"word": [" "], "author": "gixgox"}
{"word": ["Strike."], "author": "Hickory"}
{"word": ["Bowling"], "author": "TaoTekko"}
{"word": ["Columbine."], "author": "Kleetus"}
{"word": ["Sadness."], "author": "toxicTom"}
{"word": ["Madness"], "author": "Detlik"}
{"word": ["insanity"], "author": "TARFU"}
{"word": ["journalism"], "author": "thomq"}
{"word": ["unverified"], "author": "Dzsono"}
{"word": ["Unproven."], "author": "Gravest"}
{"word": ["untested"], "author": "le_chevalier"}
{"word": ["Laboratory."], "author": "viperfdl"}
{"word": ["Experiment."], "author": "Hickory"}
{"word": ["monster"], "author": "Accatone"}
{"word": ["movie"], "author": "Silverhawk170485"}
{"word": ["theatrical"], "author": "Ardal"}
{"word": ["Acting."], "author": "toxicTom"}
{"word": ["Captain."], "author": "Narcia_"}
{"word": [], "author": "Zoltan999"}
{"word": ["lingerie"], "author": "mm324"}
{"word": ["Erotic."], "author": "toxicTom"}
{"word": ["Exotic."], "author": "codefenix"}
{"word": ["quixotic"], "author": "thomq"}
{"word": ["Chaotic."], "author": "Hickory"}
{"word": ["Confused"], "author": "nebulosas"}
{"word": ["Concussed."], "author": "gixgox"}
{"word": ["Essence"], "author": "TaoTekko"}
{"word": ["Character."], "author": "toxicTom"}
{"word": ["strong"], "author": "Charon121"}
{"word": ["Testosterone."], "author": "LoboBlanco"}
{"word": ["Testicle."], "author": "Kleetus"}
{"word": ["Vulgarity."], "author": "Casval_Deikun"}
{"word": ["obscenity"], "author": "TARFU"}
{"word": ["taboo"], "author": "Dzsono"}
{"word": ["Forbidden."], "author": "toxicTom"}
{"word": ["Inadequate."], "author": "REDVWIN"}
{"word": ["insufficient"], "author": "le_chevalier"}
{"word": ["Lack"], "author": "TaoTekko"}
{"word": ["Dearth."], "author": "Hickory"}
{"word": ["death"], "author": "Accatone"}
{"word": ["Skull"], "author": "nebulosas"}
{"word": [], "author": "Zoltan999"}
{"word": ["Sauron."], "author": "viperfdl"}
{"word": ["Eye."], "author": "Narcia_"}
{"word": ["Beholder."], "author": "codefenix"}
{"word": ["Spectator."], "author": "Hickory"}
{"word": ["bystander"], "author": "mm324"}
{"word": ["Innocent."], "author": "codefenix"}
{"word": ["Alibi."], "author": "viperfdl"}
{"word": ["Excuse."], "author": "Hickory"}
{"word": ["Exonerate."], "author": "GhostwriterDoF"}
{"word": ["Release"], "author": "oldgameryeah"}
{"word": ["unleash"], "author": "TARFU"}
{"word": ["Liberate."], "author": "Hickory"}
{"word": [], "author": "gixgox"}
{"word": ["Independent."], "author": "Gravest"}
{"word": ["solo"], "author": "Dzsono"}
{"word": ["Chewbacca."], "author": "viperfdl"}
{"word": ["comrade"], "author": "Ardal"}
{"word": ["Colleague."], "author": "Hickory"}
{"word": ["Peer."], "author": "gixgox"}
{"word": ["Pier."], "author": "codefenix"}
{"word": ["Dock"], "author": "Zoltan999"}
{"word": ["Ships."], "author": "viperfdl"}
{"word": ["."], "author": "gixgox"}
{"word": ["Pot"], "author": "le_chevalier"}
{"word": ["boat"], "author": "Accatone"}
{"word": ["float"], "author": "mm324"}
{"word": ["Fishing."], "author": "Hickory"}
{"word": ["Lure."], "author": "Narcia_"}
{"word": ["Tempt..."], "author": "GhostwriterDoF"}
{"word": ["Fate."], "author": "codefenix"}
{"word": ["Destiny"], "author": "toxicTom"}
{"word": [], "author": "gixgox"}
{"word": ["Karma"], "author": "oldgameryeah"}
{"word": ["Chameleon."], "author": "Hickory"}
{"word": ["Invisibility"], "author": "TaoTekko"}
{"word": ["Cloaking."], "author": "viperfdl"}
{"word": ["Stealth."], "author": "Hickory"}
{"word": ["Thief."], "author": "VampiroAlhazred"}
{"word": ["Bandit."], "author": "Gravest"}
{"word": ["."], "author": "gixgox"}
{"word": ["Fugitive"], "author": "le_chevalier"}
{"word": ["Escapee"], "author": "TARFU"}
{"word": ["Refugee."], "author": "Hickory"}
{"word": ["War."], "author": "viperfdl"}
{"word": ["Peace"], "author": "nebulosas"}
{"word": ["Truce"], "author": "Zoltan999"}
{"word": ["armistice"], "author": "mm324"}
{"word": ["negotiations."], "author": "Narcia_"}
{"word": ["broken"], "author": "Ardal"}
{"word": ["."], "author": "gixgox"}
{"word": ["A\u0336r\u0336r\u0336o\u0336w\u0336. ", " [Ninja'd] ", " ", " Bow."], "author": "Hickory"}
{"word": ["String"], "author": "le_chevalier"}
{"word": ["ring"], "author": "Accatone"}
{"word": ["."], "author": "gixgox"}
{"word": ["Engine."], "author": "codefenix"}
{"word": ["Motor"], "author": "oldgameryeah"}
{"word": ["Machine."], "author": "toxicTom"}
{"word": ["Inventor"], "author": "TaoTekko"}
{"word": ["Creative."], "author": "toxicTom"}
{"word": ["artistic"], "author": "TARFU"}
{"word": ["drop"], "author": "kmonster"}
{"word": ["head"], "author": "gixgox"}
{"word": ["skull"], "author": "Sage103082"}
{"word": ["Bonce."], "author": "gixgox"}
{"word": ["Noodle."], "author": "Gravest"}
{"word": ["Poodle."], "author": "Kleetus"}
{"word": ["Puddle."], "author": "Tauto"}
{"word": [" pot"], "author": "Dzsono"}
{"word": ["Clay."], "author": "Hickory"}
{"word": ["Earth"], "author": "le_chevalier"}
{"word": ["Solsystem"], "author": "viperfdl"}
{"word": ["Orbit"], "author": "Zoltan999"}
{"word": ["lower"], "author": "Ardal"}
{"word": ["Power"], "author": "nebulosas"}
{"word": ["Control."], "author": "codefenix"}
{"word": ["Supervision"], "author": "le_chevalier"}
{"word": ["television"], "author": "Accatone"}
{"word": ["program."], "author": "mm324"}
{"word": ["Movie"], "author": "oldgameryeah"}
{"word": ["screen."], "author": "mm324"}
{"word": ["Capture."], "author": "Hickory"}
{"word": ["prisoner"], "author": "mm324"}
{"word": ["Star"], "author": "TaoTekko"}
{"word": ["Movie."], "author": "codefenix"}
{"word": ["Cinema"], "author": "toxicTom"}
{"word": [" Panama"], "author": "oldgamebuff42"}
{"word": ["canal"], "author": "Dzsono"}
{"word": ["river"], "author": "TARFU"}
{"word": ["plate"], "author": "REDVWIN"}
{"word": ["Land."], "author": "Casval_Deikun"}
{"word": ["Terran."], "author": "Gravest"}
{"word": ["Earthling."], "author": "Hickory"}
{"word": ["Zergling"], "author": "nebulosas"}
{"word": ["alien"], "author": "mm324"}
{"word": ["unknown"], "author": "Ardal"}
{"word": ["Void"], "author": "Zoltan999"}
{"word": ["Null."], "author": "codefenix"}
{"word": ["Invalid."], "author": "REDVWIN"}
{"word": ["Fake"], "author": "oldgameryeah"}
{"word": ["Food."], "author": "Narcia_"}
{"word": ["wood"], "author": "Accatone"}
{"word": ["Log."], "author": "codefenix"}
{"word": ["Captain"], "author": "le_chevalier"}
{"word": ["Ship"], "author": "Gorilla123"}
{"word": [" Veruna"], "author": "oldgamebuff42"}
{"word": ["Veneer"], "author": "TaoTekko"}
{"word": ["Thin"], "author": "Zoltan999"}
{"word": ["Patience"], "author": "le_chevalier"}
{"word": ["Virtue."], "author": "LoboBlanco"}
{"word": ["Positiveness."], "author": "REDVWIN"}
{"word": ["Optimism."], "author": "Gravest"}
{"word": ["outlook"], "author": "Dzsono"}
{"word": ["Express."], "author": "Hickory"}
{"word": ["train"], "author": "TARFU"}
{"word": ["Wreck."], "author": "viperfdl"}
{"word": ["Salvage."], "author": "Hickory"}
{"word": ["salve"], "author": "thomq"}
{"word": ["ointment"], "author": "ashwald"}
{"word": ["wound"], "author": "Ardal"}
{"word": ["injury"], "author": "mm324"}
{"word": ["scar"], "author": "Accatone"}
{"word": ["Face ", " ", " edit: Ninja'd"], "author": "Zoltan999"}
{"word": ["emotion"], "author": "le_chevalier"}
{"word": ["Gesticulation."], "author": "REDVWIN"}
{"word": ["Hands."], "author": "viperfdl"}
{"word": ["Deft... :)"], "author": "GhostwriterDoF"}
{"word": ["Agility"], "author": "TaoTekko"}
{"word": ["S.P.E.C.I.A.L."], "author": "viperfdl"}
{"word": ["S.P.O.T.S."], "author": "tinyE"}
{"word": ["Holstein"], "author": "TARFU"}
{"word": ["baltic"], "author": "Dzsono"}
{"word": ["Hansa"], "author": "le_chevalier"}
{"word": [], "author": "viperfdl"}
{"word": ["."], "author": "Hickory"}
{"word": [], "author": "toxicTom"}
{"word": ["frontier"], "author": "Ardal"}
{"word": ["Final"], "author": "le_chevalier"}
{"word": ["Last."], "author": "toxicTom"}
{"word": ["Chance"], "author": "Zoltan999"}
{"word": ["luck"], "author": "Smogg"}
{"word": ["Fortune."], "author": "toxicTom"}
{"word": ["Fame"], "author": "oldgameryeah"}
{"word": ["renown"], "author": "mm324"}
{"word": ["Notoriety."], "author": "codefenix"}
{"word": ["Infamy."], "author": "toxicTom"}
{"word": ["Evil"], "author": "nebulosas"}
{"word": ["Chaotic"], "author": "mm324"}
{"word": ["Good."], "author": "viperfdl"}
{"word": ["Uplifting."], "author": "gixgox"}
{"word": ["Positive."], "author": "toxicTom"}
{"word": ["Optimistic."], "author": "Hickory"}
{"word": ["Smile"], "author": "TaoTekko"}
{"word": ["Warm."], "author": "toxicTom"}
{"word": ["hot"], "author": "TARFU"}
{"word": ["Popular."], "author": "REDVWIN"}
{"word": ["Sought-after."], "author": "Hickory"}
{"word": ["desired"], "author": "Dzsono"}
{"word": ["conclusion"], "author": "Ardal"}
{"word": ["goal"], "author": "thomq"}
{"word": ["Post"], "author": "Zoltan999"}
{"word": ["Office."], "author": "viperfdl"}
{"word": ["Title"], "author": "le_chevalier"}
{"word": ["Headline."], "author": "gixgox"}
{"word": ["News."], "author": "codefenix"}
{"word": ["gossip"], "author": "thomq"}
{"word": ["Rumor"], "author": "le_chevalier"}
{"word": ["scuttlebutt"], "author": "mm324"}
{"word": ["Skinny."], "author": "Hickory"}
{"word": ["Thin"], "author": "nebulosas"}
{"word": ["Transparent."], "author": "gixgox"}
{"word": [" Slim."], "author": "Kleetus"}
{"word": [" Clear."], "author": "Hickory"}
{"word": ["Purify"], "author": "TaoTekko"}
{"word": ["Cleanse."], "author": "toxicTom"}
{"word": ["Sanitize"], "author": "oldgameryeah"}
{"word": ["Sanitarium"], "author": "VampiroAlhazred"}
{"word": ["bedlam"], "author": "Dzsono"}
{"word": ["Turmoil."], "author": "Gravest"}
{"word": ["Conflict."], "author": "Hickory"}
{"word": ["battle"], "author": "TARFU"}
{"word": ["Struggle."], "author": "REDVWIN"}
{"word": ["Resistance"], "author": "le_chevalier"}
{"word": ["Futile."], "author": "viperfdl"}
{"word": ["Pointless."], "author": "toxicTom"}
{"word": ["Useless"], "author": "nebulosas"}
{"word": ["Defunct."], "author": "Hickory"}
{"word": ["erroneous"], "author": "Dzsono"}
{"word": ["Invalid"], "author": "Zoltan999"}
{"word": ["valid"], "author": "Accatone"}
{"word": ["Vapid."], "author": "Hickory"}
{"word": ["shallow"], "author": "Ardal"}
{"word": ["superficial"], "author": "mm324"}
{"word": ["Surface."], "author": "codefenix"}
{"word": ["veneer"], "author": "mm324"}
{"word": ["Covering."], "author": "Hickory"}
{"word": ["Ground."], "author": "Exoanthrope"}
{"word": ["Floor."], "author": "toxicTom"}
{"word": ["Function"], "author": "Gorilla123"}
{"word": ["Pavement."], "author": "gixgox"}
{"word": ["Sidewalk."], "author": "Hickory"}
{"word": ["Street."], "author": "codefenix"}
{"word": ["."], "author": "gixgox"}
{"word": ["road"], "author": "ashwald"}
{"word": ["Sign"], "author": "TaoTekko"}
{"word": ["in"], "author": "kmonster"}
{"word": ["Enclosed."], "author": "Hickory"}
{"word": ["covered"], "author": "TARFU"}
{"word": ["Hide."], "author": "Gravest"}
{"word": ["Seek."], "author": "gixgox"}
{"word": ["Help."], "author": "Exoanthrope"}
{"word": ["Harm"], "author": "Blastoise00"}
{"word": ["Infliction."], "author": "toxicTom"}
{"word": ["pain"], "author": "le_chevalier"}
{"word": ["agony"], "author": "Dzsono"}
{"word": ["Game."], "author": "viperfdl"}
{"word": ["Venison."], "author": "gixgox"}
{"word": ["fawn"], "author": "thomq"}
{"word": ["Doe."], "author": "Hickory"}
{"word": ["John."], "author": "toxicTom"}
{"word": ["Unknown"], "author": "nebulosas"}
{"word": ["mystery"], "author": "skimmie"}
{"word": ["Secret"], "author": "toxicTom"}
{"word": ["."], "author": "gixgox"}
{"word": ["Loathe."], "author": "codefenix"}
{"word": ["despise"], "author": "mm324"}
{"word": ["Hatred."], "author": "REDVWIN"}
{"word": ["Extreme"], "author": "Zoltan999"}
{"word": ["Very."], "author": "toxicTom"}
{"word": ["so"], "author": "le_chevalier"}
{"word": ["Therefore."], "author": "Hickory"}
{"word": ["furthermore"], "author": "Accatone"}
{"word": ["Moreover."], "author": "codefenix"}
{"word": ["Hence."], "author": "REDVWIN"}
{"word": ["Because."], "author": "toxicTom"}
{"word": ["Why."], "author": "codefenix"}
{"word": ["Not"], "author": "le_chevalier"}
{"word": ["Note."], "author": "viperfdl"}
{"word": [], "author": "Zoltan999"}
{"word": ["Passing."], "author": "toxicTom"}
{"word": ["Transitory."], "author": "Hickory"}
{"word": ["Traffic"], "author": "TaoTekko"}
{"word": ["Travel."], "author": "codefenix"}
{"word": ["Globe"], "author": "Gorilla123"}
{"word": ["Sphere."], "author": "toxicTom"}
{"word": ["circle"], "author": "TARFU"}
{"word": ["round"], "author": "Dzsono"}
{"word": ["melons"], "author": "thomq"}
{"word": ["Fruit."], "author": "Gravest"}
{"word": ["Drosophila."], "author": "gixgox"}
{"word": ["hemophilia"], "author": "thomq"}
{"word": ["Hemophobia."], "author": "Exoanthrope"}
{"word": ["faint"], "author": "Dzsono"}
{"word": ["feint"], "author": "le_chevalier"}
{"word": ["Fence."], "author": "toxicTom"}
{"word": ["sell"], "author": "thomq"}
{"word": ["Procure."], "author": "Hickory"}
{"word": ["Obtain"], "author": "nebulosas"}
{"word": ["Steal"], "author": "Zoltan999"}
{"word": ["Pilfer."], "author": "Hickory"}
{"word": ["purloin"], "author": "mm324"}
{"word": ["loin"], "author": "Accatone"}
{"word": ["Tender."], "author": "codefenix"}
{"word": ["elvis"], "author": "Ardal"}
{"word": ["Elvish"], "author": "le_chevalier"}
{"word": ["Tree-hugger"], "author": "Gorilla123"}
{"word": ["Druid."], "author": "Hickory"}
{"word": ["Shannara"], "author": "oldgamebuff42"}
{"word": ["Sword."], "author": "Hickory"}
{"word": ["Excalibur."], "author": "viperfdl"}
{"word": ["Lake"], "author": "TaoTekko"}
{"word": ["Fishing."], "author": "Hickory"}
{"word": [" Swiss|Catholic cocksucker."], "author": "d3v14n7"}
{"word": [" Fishing."], "author": "Hickory"}
{"word": ["lure"], "author": "TARFU"}
{"word": ["Trap."], "author": "toxicTom"}
{"word": ["Door."], "author": "Hickory"}
{"word": ["Passage."], "author": "toxicTom"}
{"word": ["*bump*"], "author": "toxicTom"}
{"word": ["Post"], "author": "VampiroAlhazred"}
{"word": ["Thread."], "author": "Gravest"}
{"word": ["Needle."], "author": "Narcia_"}
{"word": ["."], "author": "gixgox"}
{"word": ["fasteners"], "author": "le_chevalier"}
{"word": ["Clips."], "author": "Hickory"}
{"word": ["Ammo."], "author": "viperfdl"}
{"word": ["Rifle"], "author": "nebulosas"}
{"word": ["Bore"], "author": "le_chevalier"}
{"word": ["Tusk"], "author": "Dessimu"}
{"word": ["Warthog"], "author": "Zoltan999"}
{"word": ["Tough."], "author": "Hickory"}
{"word": ["Difficult."], "author": "codefenix"}
{"word": ["terrain"], "author": "Ardal"}
{"word": ["Steep."], "author": "REDVWIN"}
{"word": ["Slope"], "author": "toxicTom"}
{"word": ["Incline."], "author": "Hickory"}
{"word": ["Decline"], "author": "oldgameryeah"}
{"word": ["Deny."], "author": "toxicTom"}
{"word": ["reject"], "author": "mm324"}
{"word": ["[Ninja'd] ", " I\u0336n\u0336t\u0336e\u0336r\u0336d\u0336i\u0336c\u0336t\u0336. ", " ", " Rebuff."], "author": "Hickory"}
{"word": ["snub"], "author": "mm324"}
{"word": ["Ban"], "author": "TaoTekko"}
{"word": ["hammer."], "author": "mm324"}
{"word": ["Nail."], "author": "codefenix"}
{"word": ["lumber"], "author": "TARFU"}
{"word": ["Forest."], "author": "Hickory"}
{"word": ["ecosystem"], "author": "thomq"}
{"word": ["Environment."], "author": "Hickory"}
{"word": ["biome"], "author": "Dzsono"}
{"word": ["Forest."], "author": "Gravest"}
{"word": ["Gump."], "author": "REDVWIN"}
{"word": ["Chump."], "author": "Hickory"}
{"word": ["Chimp."], "author": "toxicTom"}
{"word": ["troglodyte"], "author": "le_chevalier"}
{"word": ["cave"], "author": "Ardal"}
{"word": ["Spelunk."], "author": "Hickory"}
{"word": [], "author": "toxicTom"}
{"word": ["night"], "author": "Accatone"}
{"word": ["Darkness."], "author": "REDVWIN"}
{"word": ["evening"], "author": "Dzsono"}
{"word": ["Dusk."], "author": "toxicTom"}
{"word": ["Twilight."], "author": "Hickory"}
{"word": ["Zone."], "author": "mm324"}
{"word": ["one"], "author": "Accatone"}
{"word": ["Uno."], "author": "viperfdl"}
{"word": ["Moment"], "author": "TaoTekko"}
{"word": ["Now."], "author": "toxicTom"}
{"word": ["Present"], "author": "Azrael360"}
{"word": ["Gift"], "author": "thanhtotti"}
{"word": ["Bequeath"], "author": "Dzsono"}
{"word": ["will"], "author": "thomq"}
{"word": ["Power"], "author": "le_chevalier"}
{"word": ["electricity"], "author": "TARFU"}
{"word": ["Cable."], "author": "Gravest"}
{"word": ["television"], "author": "le_chevalier"}
{"word": ["Box."], "author": "REDVWIN"}
{"word": ["Crate."], "author": "toxicTom"}
{"word": ["Container"], "author": "nebulosas"}
{"word": ["Ninja'd. ", " ", " Ship."], "author": "viperfdl"}
{"word": ["Sail."], "author": "Hickory"}
{"word": ["Glide."], "author": "toxicTom"}
{"word": ["wings"], "author": "Ardal"}
{"word": ["Flap."], "author": "codefenix"}
{"word": ["flare"], "author": "Accatone"}
{"word": ["Flair."], "author": "Hickory"}
{"word": ["Stylishness..."], "author": "GhostwriterDoF"}
{"word": ["Elegance."], "author": "Hickory"}
{"word": ["Grace."], "author": "Narcia_"}
{"word": ["Fall."], "author": "viperfdl"}
{"word": ["Bomb."], "author": "almabrds"}
{"word": ["Atom"], "author": "mm324"}
{"word": ["Lego"], "author": "thomq"}
{"word": ["Constructor"], "author": "TaoTekko"}
{"word": ["construction"], "author": "TARFU"}
{"word": ["contractor"], "author": "le_chevalier"}
{"word": ["Outsource."], "author": "Hickory"}
{"word": ["sour"], "author": "Accatone"}
{"word": ["apple"], "author": "BlackDawn"}
{"word": ["Cider."], "author": "gixgox"}
{"word": ["Fog"], "author": "almabrds"}
{"word": ["War."], "author": "viperfdl"}
{"word": [], "author": "mm324"}
{"word": ["."], "author": "Hickory"}
{"word": ["Popping."], "author": "codefenix"}
{"word": ["popcorn"], "author": "Dzsono"}
{"word": [], "author": "gixgox"}
{"word": ["addictive"], "author": "mm324"}
{"word": ["Additive."], "author": "codefenix"}
{"word": ["adduction"], "author": "thomq"}
{"word": ["Abduction"], "author": "nebulosas"}
{"word": ["Rapture."], "author": "REDVWIN"}
{"word": ["Underwater"], "author": "TaoTekko"}
{"word": ["diving"], "author": "TARFU"}
{"word": ["Sky."], "author": "viperfdl"}
{"word": ["Stars."], "author": "Gravest"}
{"word": ["Moon."], "author": "Narcia_"}
{"word": ["moonlighting"], "author": "thomq"}
{"word": ["overwork"], "author": "Ardal"}
{"word": ["shift"], "author": "Dzsono"}
{"word": ["Ctrl"], "author": "nebulosas"}
{"word": ["Alt."], "author": "viperfdl"}
{"word": ["alternative"], "author": "Accatone"}
{"word": ["Surrogate."], "author": "Hickory"}
{"word": ["Substitute."], "author": "viperfdl"}
{"word": ["Teacher"], "author": "Zoltan999"}
{"word": ["Pupil."], "author": "codefenix"}
{"word": ["Eyeball."], "author": "Hickory"}
{"word": ["stare"], "author": "le_chevalier"}
{"word": ["boobs"], "author": "cose_vecchie"}
{"word": ["[Edit: previous reply could have been misconstrued, so herewith an explanation:] ", " ", " [to Stare >> at Boobs >> is...] ", " ", " Juvenile."], "author": "Hickory"}
{"word": ["Delinquent."], "author": "codefenix"}
{"word": ["Heretic."], "author": "oldgamebuff42"}
{"word": ["renegade"], "author": "mm324"}
{"word": ["guerrilla"], "author": "Dzsono"}
{"word": ["Tactics"], "author": "VampiroAlhazred"}
{"word": ["Tictac."], "author": "gixgox"}
{"word": ["Toe."], "author": "Gravest"}
{"word": ["tip"], "author": "le_chevalier"}
{"word": ["Apex"], "author": "TARFU"}
{"word": ["ape"], "author": "Accatone"}
{"word": ["Jungle"], "author": "Zoltan999"}
{"word": ["Wild"], "author": "nebulosas"}
{"word": ["Side."], "author": "codefenix"}
{"word": ["choose"], "author": "Ardal"}
{"word": ["decide"], "author": "T.Hodd"}
{"word": ["Commit."], "author": "Hickory"}
{"word": ["Entertain."], "author": "Narcia_"}
{"word": ["Amuse."], "author": "toxicTom"}
{"word": ["Amaze."], "author": "codefenix"}
{"word": ["Awake."], "author": "REDVWIN"}
{"word": ["dreaming"], "author": "kmonster"}
{"word": ["hallucinating"], "author": "mm324"}
{"word": ["Matrix"], "author": "TaoTekko"}
{"word": ["Morpheus"], "author": "TARFU"}
{"word": ["Accoutrement."], "author": "GhostwriterDoF"}
{"word": ["Accessory."], "author": "Hickory"}
{"word": ["accomplice"], "author": "Dzsono"}
{"word": ["Crimes?"], "author": "Exoanthrope"}
{"word": ["Justice."], "author": "Gravest"}
{"word": ["scale"], "author": "le_chevalier"}
{"word": ["Balance."], "author": "viperfdl"}
{"word": ["account"], "author": "Ardal"}
{"word": ["Customer"], "author": "Zoltan999"}
{"word": ["Care"], "author": "cose_vecchie"}
{"word": ["Bear."], "author": "codefenix"}
{"word": ["beast"], "author": "dbzane"}
{"word": ["Beauty."], "author": "Hickory"}
{"word": ["art"], "author": "Accatone"}
{"word": ["Artwork"], "author": "nebulosas"}
{"word": ["Work."], "author": "toxicTom"}
{"word": ["Labor."], "author": "REDVWIN"}
{"word": ["job"], "author": "mm324"}
{"word": ["Mission."], "author": "toxicTom"}
{"word": ["Complete."], "author": "Narcia_"}
{"word": ["Accomplished."], "author": "viperfdl"}
{"word": ["Satisfied."], "author": "codefenix"}
{"word": ["Conceptual..."], "author": "GhostwriterDoF"}
{"word": ["Unreal."], "author": "toxicTom"}
{"word": ["Tournament"], "author": "TaoTekko"}
{"word": ["Competition."], "author": "codefenix"}
{"word": ["Ideology."], "author": "viperfdl"}
{"word": ["theory"], "author": "TARFU"}
{"word": ["Practice."], "author": "Hickory"}
{"word": ["hypothetically"], "author": "Dzsono"}
{"word": ["Theoretically."], "author": "Gravest"}
{"word": ["appliable"], "author": "Ardal"}
{"word": ["cable"], "author": "le_chevalier"}
{"word": ["Wire"], "author": "nebulosas"}
{"word": ["Switch"], "author": "Zoltan999"}
{"word": ["change"], "author": "dbzane"}
{"word": ["Spare."], "author": "codefenix"}
{"word": ["Superfluous."], "author": "Hickory"}
{"word": ["extra"], "author": "mm324"}
{"word": ["Life"], "author": "TwisterBE"}
{"word": ["Death"], "author": "Cavenagh"}
{"word": ["Work."], "author": "oldgamebuff42"}
{"word": ["Load."], "author": "codefenix"}
{"word": ["Burden."], "author": "Hickory"}
{"word": ["Heavy."], "author": "Narcia_"}
{"word": ["Lead."], "author": "toxicTom"}
{"word": ["metal"], "author": "TARFU"}
{"word": ["Steel"], "author": "PaterAlf"}
{"word": ["Slug."], "author": "REDVWIN"}
{"word": ["Shell."], "author": "viperfdl"}
{"word": ["Turtle."], "author": "Hickory"}
{"word": ["defend"], "author": "Dzsono"}
{"word": ["Shield"], "author": "VampiroAlhazred"}
{"word": ["Guard"], "author": "oldgameryeah"}
{"word": ["Protect."], "author": "Gravest"}
{"word": ["serve"], "author": "le_chevalier"}
{"word": ["Waiter."], "author": "toxicTom"}
{"word": ["Butler."], "author": "viperfdl"}
{"word": ["butter"], "author": "Accatone"}
{"word": ["Toast"], "author": "Zoltan999"}
{"word": ["cup"], "author": "Ardal"}
{"word": ["Tea."], "author": "toxicTom"}
{"word": [], "author": "cose_vecchie"}
{"word": ["Dual."], "author": "Hickory"}
{"word": ["Duel."], "author": "codefenix"}
{"word": ["Joust."], "author": "REDVWIN"}
{"word": ["Tourney."], "author": "Hickory"}
{"word": ["Lance."], "author": "Narcia_"}
{"word": ["Formation"], "author": "TaoTekko"}
{"word": ["."], "author": "viperfdl"}
{"word": ["Carbon."], "author": "Hickory"}
{"word": ["Coal."], "author": "toxicTom"}
{"word": ["Mine."], "author": "REDVWIN"}
{"word": ["Yours."], "author": "Hickory"}
{"word": ["family"], "author": "le_chevalier"}
{"word": ["Blood."], "author": "Gravest"}
{"word": ["Cell"], "author": "TARFU"}
{"word": ["insurgent"], "author": "Dzsono"}
{"word": ["Rebel."], "author": "toxicTom"}
{"word": ["alliance"], "author": "Ardal"}
{"word": ["Cooperation."], "author": "viperfdl"}
{"word": ["Teamwork."], "author": "toxicTom"}
{"word": ["Rapport."], "author": "Hickory"}
{"word": ["port"], "author": "Accatone"}
{"word": ["."], "author": "viperfdl"}
{"word": ["Shout."], "author": "Narcia_"}
{"word": ["Cry."], "author": "REDVWIN"}
{"word": ["Tears"], "author": "PaterAlf"}
{"word": ["weep"], "author": "mm324"}
{"word": ["Sea"], "author": "TaoTekko"}
{"word": [" Wail."], "author": "Hickory"}
{"word": ["scream"], "author": "TARFU"}
{"word": ["Disquiet... :P"], "author": "GhostwriterDoF"}
{"word": ["disconcert"], "author": "le_chevalier"}
{"word": ["apprehension"], "author": "Dzsono"}
{"word": ["Dread."], "author": "Gravest"}
{"word": ["Fear"], "author": "Zoltan999"}
{"word": ["Shaking."], "author": "REDVWIN"}
{"word": ["cocktail"], "author": "dbzane"}
{"word": ["Aperitif."], "author": "Hickory"}
{"word": ["digestif"], "author": "le_chevalier"}
{"word": ["metropolitan"], "author": "mm324"}
{"word": ["Municipal."], "author": "Hickory"}
{"word": ["."], "author": "codefenix"}
{"word": ["."], "author": "GhostwriterDoF"}
{"word": ["."], "author": "Hickory"}
{"word": ["Patch."], "author": "gixgox"}
{"word": ["cloth"], "author": "TARFU"}
{"word": ["loin"], "author": "le_chevalier"}
{"word": ["coin"], "author": "kmonster"}
{"word": ["Purse."], "author": "Narcia_"}
{"word": ["Pouch."], "author": "Gravest"}
{"word": ["marsupial"], "author": "Dzsono"}
{"word": ["Kangaroos"], "author": "tort1234"}
{"word": ["Australia."], "author": "REDVWIN"}
{"word": ["southern"], "author": "le_chevalier"}
{"word": ["Hemisphere."], "author": "Hickory"}
{"word": ["Latitude. :)"], "author": "GhostwriterDoF"}
{"word": ["degree"], "author": "Ardal"}
{"word": ["Celsius."], "author": "viperfdl"}
{"word": ["Thermometer"], "author": "Zoltan999"}
{"word": ["Fahrenheit"], "author": "nebulosas"}
{"word": ["indigo"], "author": "TwisterBE"}
{"word": ["Child."], "author": "REDVWIN"}
{"word": ["inner"], "author": "Accatone"}
{"word": ["Outer."], "author": "Narcia_"}
{"word": ["Space."], "author": "codefenix"}
{"word": ["Odyssey."], "author": "Hickory"}
{"word": ["Adventure"], "author": "Chad28_69"}
{"word": ["MUD"], "author": "thomq"}
{"word": ["quagmire"], "author": "cose_vecchie"}
{"word": ["entanglement"], "author": "mm324"}
{"word": ["Snarl."], "author": "gixgox"}
{"word": ["Growl."], "author": "Hickory"}
{"word": ["Yelp!"], "author": "GhostwriterDoF"}
{"word": ["Restaurant"], "author": "TaoTekko"}
{"word": [" Whimper."], "author": "Hickory"}
{"word": ["puppy"], "author": "TARFU"}
{"word": ["Bark."], "author": "Ikarugamesh"}
{"word": ["Tree."], "author": "Gravest"}
{"word": [" ... "], "author": "gixgox"}
{"word": ["trog"], "author": "le_chevalier"}
{"word": ["hermit"], "author": "Dzsono"}
{"word": ["deranged"], "author": "Ardal"}
{"word": ["Politicians."], "author": "viperfdl"}
{"word": ["Corruption"], "author": "nebulosas"}
{"word": ["File"], "author": "Zoltan999"}
{"word": ["Folder."], "author": "toxicTom"}
{"word": ["Binder."], "author": "codefenix"}
{"word": ["chest"], "author": "thomq"}
{"word": ["Thorax."], "author": "gixgox"}
{"word": ["Abdomen."], "author": "codefenix"}
{"word": ["stomach"], "author": "mm324"}
{"word": ["Acid."], "author": "Hickory"}
{"word": ["Poison."], "author": "viperfdl"}
{"word": ["snake"], "author": "ashwald"}
{"word": ["trouser"], "author": "le_chevalier"}
{"word": ["Shorts"], "author": "almabrds"}
{"word": ["Panties."], "author": "gixgox"}
{"word": ["Briefs."], "author": "Narcia_"}
{"word": ["Letter"], "author": "TaoTekko"}
{"word": ["Love"], "author": "almabrds"}
{"word": ["glove"], "author": "thomq"}
{"word": ["Shove."], "author": "Hickory"}
{"word": ["shovel"], "author": "TARFU"}
{"word": ["Knight"], "author": "almabrds"}
{"word": ["down"], "author": "kmonster"}
{"word": ["Fall."], "author": "viperfdl"}
{"word": ["Fallout"], "author": "VampiroAlhazred"}
{"word": ["nuclear"], "author": "le_chevalier"}
{"word": ["Atomic."], "author": "Hickory"}
{"word": ["quark"], "author": "Dzsono"}
{"word": ["Muon"], "author": "Zoltan999"}
{"word": ["Particle."], "author": "viperfdl"}
{"word": ["Crumb."], "author": "toxicTom"}
{"word": ["Bread"], "author": "Play4Ever"}
{"word": ["Food."], "author": "REDVWIN"}
{"word": ["lifeform"], "author": "thomq"}
{"word": ["organism"], "author": "mm324"}
{"word": ["Alien."], "author": "viperfdl"}
{"word": ["Invasion."], "author": "Hickory"}
{"word": ["infestation"], "author": "le_chevalier"}
{"word": ["bedbugs!"], "author": "Fran67"}
{"word": ["Parasite"], "author": "nebulosas"}
{"word": ["Organism"], "author": "oldgamebuff42"}
{"word": ["Repetition."], "author": "viperfdl"}
{"word": ["Iteration."], "author": "Hickory"}
{"word": ["Flotation"], "author": "SamMagel"}
{"word": ["Drifting."], "author": "toxicTom"}
{"word": ["Racing"], "author": "Zoltan999"}
{"word": ["automobile"], "author": "TARFU"}
{"word": ["automotive"], "author": "le_chevalier"}
{"word": ["superlative"], "author": "kmonster"}
{"word": ["super-duper"], "author": "thomq"}
{"word": ["good"], "author": "Dzsono"}
{"word": ["Better."], "author": "Gravest"}
{"word": ["Butter."], "author": "REDVWIN"}
{"word": ["bitter"], "author": "le_chevalier"}
{"word": ["Pill."], "author": "gixgox"}
{"word": ["pillars"], "author": "thomq"}
{"word": ["eternity"], "author": "BlackDawn"}
{"word": ["."], "author": "Hickory"}
{"word": ["vampire"], "author": "Ardal"}
{"word": ["Bloodlines."], "author": "VampiroAlhazred"}
{"word": ["Heritage."], "author": "viperfdl"}
{"word": ["hermitage"], "author": "thomq"}
{"word": ["Lonely"], "author": "Yezemin"}
{"word": ["Secluded"], "author": "Zoltan999"}
{"word": ["solitude"], "author": "Accatone"}
{"word": ["Isolation"], "author": "nebulosas"}
{"word": ["Cold."], "author": "viperfdl"}
{"word": ["Flu."], "author": "codefenix"}
{"word": ["Flux."], "author": "toxicTom"}
{"word": ["change"], "author": "mm324"}
{"word": ["Transformation."], "author": "gixgox"}
{"word": ["Polymorph."], "author": "Hickory"}
{"word": ["Wave"], "author": "TaoTekko"}
{"word": ["Sine"], "author": "oldgamebuff42"}
{"word": ["cosine"], "author": "TARFU"}
{"word": ["Hypotenuse."], "author": "toxicTom"}
{"word": ["Pythagoras."], "author": "VampiroAlhazred"}
{"word": ["Euclid"], "author": "Dzsono"}
{"word": ["Galileo"], "author": "nicohvc"}
{"word": ["Copernicus"], "author": "le_chevalier"}
{"word": ["Kepler."], "author": "Gravest"}
{"word": ["Telescope."], "author": "codefenix"}
{"word": ["telegraph"], "author": "thomq"}
{"word": ["Morse Code"], "author": "Fran67"}
{"word": [], "author": "viperfdl"}
{"word": ["politics"], "author": "Ardal"}
{"word": ["Decisions"], "author": "nebulosas"}
{"word": ["Choices."], "author": "viperfdl"}
{"word": ["default"], "author": "thomq"}
{"word": ["failure"], "author": "cose_vecchie"}
{"word": ["."], "author": "gixgox"}
{"word": ["Flip"], "author": "mm324"}
{"word": ["Flippant."], "author": "codefenix"}
{"word": ["Facetious."], "author": "Hickory"}
{"word": ["Lopsided"], "author": "TaoTekko"}
{"word": ["off-center"], "author": "TARFU"}
{"word": ["Skewed"], "author": "toxicTom"}
{"word": ["screwed"], "author": "kmonster"}
{"word": ["tatooed"], "author": "JDelekto"}
{"word": ["branded"], "author": "le_chevalier"}
{"word": ["Criminal."], "author": "Narcia_"}
{"word": ["Conduct."], "author": "gixgox"}
{"word": ["procedure"], "author": "Dzsono"}
{"word": ["function"], "author": "le_chevalier"}
{"word": [], "author": "gixgox"}
{"word": ["Shape."], "author": "viperfdl"}
{"word": ["shifter"], "author": "Ardal"}
{"word": ["capitalize"], "author": "thomq"}
{"word": ["Uppercase"], "author": "nebulosas"}
{"word": ["briefcase"], "author": "thomq"}
{"word": ["document"], "author": "Accatone"}
{"word": ["Report."], "author": "codefenix"}
{"word": ["consequence"], "author": "chevkoch"}
{"word": ["Responsibility."], "author": "viperfdl"}
{"word": ["Spiderman."], "author": "Ikarugamesh"}
{"word": ["Batman"], "author": "mm324"}
{"word": ["Workman."], "author": "gixgox"}
{"word": ["Laborious..."], "author": "GhostwriterDoF"}
{"word": ["scrivener"], "author": "chevkoch"}
{"word": ["writer"], "author": "TARFU"}
{"word": ["Storyteller."], "author": "Narcia_"}
{"word": ["."], "author": "gixgox"}
{"word": ["blue"], "author": "kmonster"}
{"word": ["Rainbow."], "author": "Gravest"}
{"word": ["Sad"], "author": "Zoltan999"}
{"word": ["."], "author": "gixgox"}
{"word": ["ballad"], "author": "le_chevalier"}
{"word": ["Trance"], "author": "SamMagel"}
{"word": ["house"], "author": "Dzsono"}
{"word": ["Courtesy."], "author": "REDVWIN"}
{"word": ["Polite."], "author": "toxicTom"}
{"word": ["Gesture"], "author": "Zoltan999"}
{"word": ["Sign"], "author": "nebulosas"}
{"word": ["symbol"], "author": "Accatone"}
{"word": ["emblem"], "author": "mm324"}
{"word": ["fire"], "author": "Smogg"}
{"word": ["Fighter."], "author": "viperfdl"}
{"word": ["Remnant."], "author": "GhostwriterDoF"}
{"word": ["group"], "author": "Ardal"}
{"word": ["Assembly"], "author": "oldgameryeah"}
{"word": ["code"], "author": "cose_vecchie"}
{"word": ["Turing"], "author": "chevkoch"}
{"word": ["Test."], "author": "viperfdl"}
{"word": ["Tube."], "author": "gixgox"}
{"word": ["Vacuum."], "author": "codefenix"}
{"word": ["Polarization"], "author": "TaoTekko"}
{"word": ["Ray-Ban"], "author": "chevkoch"}
{"word": ["glare"], "author": "Dzsono"}
{"word": ["Shade."], "author": "Gravest"}
{"word": ["blind"], "author": "le_chevalier"}
{"word": ["sightless"], "author": "TARFU"}
{"word": ["Obscured."], "author": "REDVWIN"}
{"word": [], "author": "gixgox"}
{"word": ["Sniper."], "author": "almabrds"}
{"word": ["Rifle."], "author": "viperfdl"}
{"word": ["barrel"], "author": "Ardal"}
{"word": ["Wine"], "author": "Zoltan999"}
{"word": ["Bouquet."], "author": "viperfdl"}
{"word": ["aroma"], "author": "mm324"}
{"word": ["Essence."], "author": "gixgox"}
{"word": ["Road"], "author": "almabrds"}
{"word": ["Path"], "author": "TaoTekko"}
{"word": ["Exile"], "author": "TwisterBE"}
{"word": ["Banishment."], "author": "codefenix"}
{"word": ["Leaving."], "author": "toxicTom"}
{"word": [], "author": "gixgox"}
{"word": ["Nevada"], "author": "TARFU"}
{"word": ["envy"], "author": "le_chevalier"}
{"word": ["covet"], "author": "Dzsono"}
{"word": ["pleonexia"], "author": "Ardal"}
{"word": ["Hedgefonds."], "author": "viperfdl"}
{"word": ["Hedgehog"], "author": "nebulosas"}
{"word": ["Hedgehogs. ", " ", " ", " ninjas."], "author": "gixgox"}
{"word": ["Jump"], "author": "Zoltan999"}
{"word": ["Height."], "author": "REDVWIN"}
{"word": ["length"], "author": "mm324"}
{"word": ["long"], "author": "Accatone"}
{"word": ["."], "author": "viperfdl"}
{"word": ["Racket."], "author": "codefenix"}
{"word": ["Rickets."], "author": "gixgox"}
{"word": ["Skittles."], "author": "Narcia_"}
{"word": ["Nine."], "author": "toxicTom"}
{"word": ["No..."], "author": "TaoTekko"}
{"word": ["Batsu"], "author": "almabrds"}
{"word": ["Gun."], "author": "toxicTom"}
{"word": ["arms"], "author": "Dzsono"}
{"word": [], "author": "nicohvc"}
{"word": ["router"], "author": "TARFU"}
