{"word": ["I have to admit I wasn't expecting this game to last so long :D ", " Thanks everyone for keeping it going. ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " I post Dark ", " Next person posts Light ", " Next person Posts Sun ", " ", " ", " ", " ", " ", " Castle"], "author": "Arianus.836"}
{"word": ["Moat"], "author": "JMich"}
{"word": ["Bridge ", " ", " /edit: got ninja'd"], "author": "Adzeth"}
{"word": [" Troll"], "author": "Arianus.836"}
{"word": [" Thud"], "author": "granny"}
{"word": ["Pain"], "author": "Leroux"}
{"word": ["Weapon"], "author": "swizzle66"}
{"word": ["shield"], "author": "Gerin"}
{"word": ["Knight"], "author": "Arianus.836"}
{"word": ["Princess"], "author": "A_Future_Pilot"}
{"word": ["Prince"], "author": "aymerict"}
{"word": ["Cream"], "author": "Karlallen"}
{"word": ["Tea"], "author": "Rodzaju"}
{"word": ["Lemon."], "author": "tarangwydion"}
{"word": ["Zest"], "author": "GameRager"}
{"word": ["cake"], "author": "xa_chan"}
{"word": ["LIE"], "author": "GameRager"}
{"word": [" consequences"], "author": "n99127"}
{"word": ["effects"], "author": "GameRager"}
{"word": ["special"], "author": "n99127"}
{"word": ["kids"], "author": "GameRager"}
{"word": ["Trix"], "author": "swizzle66"}
{"word": ["Asian"], "author": "GameRager"}
{"word": ["Japan"], "author": "WaithPDX"}
{"word": ["Radiation"], "author": "GameRager"}
{"word": ["Fallout."], "author": "tarangwydion"}
{"word": ["Vegas"], "author": "GameRager"}
{"word": ["strip"], "author": "xa_chan"}
{"word": ["comic"], "author": "Typhoon45"}
{"word": [" book"], "author": "n99127"}
{"word": ["Binding"], "author": "GameRager"}
{"word": ["glue"], "author": "n99127"}
{"word": ["Horses"], "author": "swizzle66"}
{"word": ["derby"], "author": "Lou"}
{"word": [" Shoes ", " ", " EDIT: Ninja'd! ", " ", " Derby-> ", " Hat"], "author": "Matchstickman"}
{"word": ["Trick"], "author": "GoJays2025"}
{"word": ["Tips."], "author": "tarangwydion"}
{"word": ["hints"], "author": "xa_chan"}
{"word": [" Cheater!"], "author": "Arianus.836"}
{"word": ["Liar!"], "author": "Leroux"}
{"word": ["thief!"], "author": "GameRager"}
{"word": [" Sneaky"], "author": "JMich"}
{"word": ["Bugger"], "author": "GameRager"}
{"word": [" Off"], "author": "Matchstickman"}
{"word": ["Set"], "author": "GameRager"}
{"word": ["Point"], "author": "n99127"}
{"word": ["Taken"], "author": "Leroux"}
{"word": ["Surprise"], "author": "Adzeth"}
{"word": [" Birthday!"], "author": "Arianus.836"}
{"word": ["Sex"], "author": "reaver894"}
{"word": ["Baby"], "author": "Tulivu"}
{"word": [" Ooops"], "author": "Arianus.836"}
{"word": [" run?"], "author": "reaver894"}
{"word": ["Forest"], "author": "Leroux"}
{"word": [" Burn"], "author": "Tulivu"}
{"word": [" Die!"], "author": "agogfan"}
{"word": ["Gambling."], "author": "Adzeth"}
{"word": ["Den"], "author": "Matchstickman"}
{"word": ["drugs"], "author": "reaver894"}
{"word": ["addiction"], "author": "aymerict"}
{"word": [" GoG"], "author": "Arianus.836"}
{"word": [" support"], "author": "reaver894"}
{"word": [" angry"], "author": "Detlik"}
{"word": ["Birds"], "author": "n99127"}
{"word": [" Eggs"], "author": "Detlik"}
{"word": [" basket"], "author": "serpantino"}
{"word": [" Ralph (", ")"], "author": "Detlik"}
{"word": [" Politics"], "author": "Arianus.836"}
{"word": [" Non-intelligent."], "author": "Detlik"}
{"word": [" aristocratic"], "author": "reaver894"}
{"word": [" Wealthy"], "author": "Detlik"}
{"word": [" snobs"], "author": "reaver894"}
{"word": [" Revolution"], "author": "Detlik"}
{"word": [" War"], "author": "Arianus.836"}
{"word": [" decimation"], "author": "reaver894"}
{"word": [" Death"], "author": "Detlik"}
{"word": [" Reaper"], "author": "Arianus.836"}
{"word": ["underworld"], "author": "serpantino"}
{"word": [" Scythe"], "author": "Detlik"}
{"word": ["Underworld-> Vampires"], "author": "Matchstickman"}
{"word": [" Sparkly?"], "author": "Detlik"}
{"word": [" Where?"], "author": "reaver894"}
{"word": [" Twilight :("], "author": "Detlik"}
{"word": [" Shit..."], "author": "reaver894"}
{"word": [" Indeed..."], "author": "Detlik"}
{"word": ["Quite"], "author": "Hesusio"}
{"word": ["Banana"], "author": "Detlik"}
{"word": ["Split"], "author": "Lou"}
{"word": ["Daikiri?"], "author": "Detlik"}
{"word": [" Spelling?"], "author": "Matchstickman"}
{"word": [" Tired :("], "author": "Detlik"}
{"word": [" maybe..."], "author": "Arianus.836"}
{"word": [" Coffee"], "author": "Detlik"}
{"word": [" Beans"], "author": "JMich"}
{"word": [" Stink"], "author": "Detlik"}
{"word": [" CREAMER! :D"], "author": "Arianus.836"}
{"word": [" Random :)"], "author": "Detlik"}
{"word": [" no"], "author": "Arianus.836"}
{"word": [" Maybe?"], "author": "Detlik"}
{"word": [" sure :D"], "author": "Arianus.836"}
{"word": [" Spy!!!"], "author": "Detlik"}
{"word": [" 007"], "author": "Arianus.836"}
{"word": [" TF2!"], "author": "Detlik"}
{"word": [" ", " ", " Game"], "author": "Arianus.836"}
{"word": [" Play"], "author": "JMich"}
{"word": [" Fun"], "author": "Detlik"}
{"word": ["Bamboo Boogie-Boots"], "author": "Matchstickman"}
{"word": [" KittenTorture."], "author": "wpegg"}
{"word": [" "], "author": "Arianus.836"}
{"word": [" Unspontaneous ;) ", " ", " ", " So the current word is still fun?"], "author": "Matchstickman"}
{"word": ["Splenda"], "author": "Tulivu"}
{"word": [" sweet"], "author": "reaver894"}
{"word": [" Rad"], "author": "Tulivu"}
{"word": [" "], "author": "reaver894"}
{"word": [" Master."], "author": "Thiev"}
{"word": [" bator :-D"], "author": "reaver894"}
{"word": ["Hitman"], "author": "Matchstickman"}
{"word": [" President"], "author": "Arianus.836"}
{"word": [" (NSFW)"], "author": "Leroux"}
{"word": [" quack!"], "author": "Arianus.836"}
{"word": [" doctor"], "author": "reaver894"}
{"word": ["Doom."], "author": "tarangwydion"}
{"word": [" Sleep"], "author": "reaver894"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Metallica"], "author": "Lou"}
{"word": ["Metal"], "author": "n99127"}
{"word": ["Paramagnetism"], "author": "Hesusio"}
{"word": ["external"], "author": "n99127"}
{"word": ["hard drive"], "author": "Cadenza"}
{"word": ["gigabyte"], "author": "Ubivis"}
{"word": ["billion"], "author": "n99127"}
{"word": ["rich"], "author": "Detlik"}
{"word": ["stinking"], "author": "Leroux"}
{"word": ["shower"], "author": "Ubivis"}
{"word": ["golden"], "author": "n99127"}
{"word": [" Axe"], "author": "Thiev"}
{"word": ["headless"], "author": "reaver894"}
{"word": ["Crazy"], "author": "n99127"}
{"word": ["zombie"], "author": "reaver894"}
{"word": ["Pox"], "author": "Leroux"}
{"word": ["goblin"], "author": "reaver894"}
{"word": ["green"], "author": "Ubivis"}
{"word": [" jolly"], "author": "Tulivu"}
{"word": ["giant"], "author": "n99127"}
{"word": [" Kabuto"], "author": "Detlik"}
{"word": ["rated"], "author": "Tulivu"}
{"word": ["arrrr! ", " ", " Ok, that' not really a word, so let's continue with: ", " ", " Pirates"], "author": "Leroux"}
{"word": ["scum"], "author": "reaver894"}
{"word": ["bar"], "author": "n99127"}
{"word": ["gin"], "author": "GoJays2025"}
{"word": ["[oops, ninja'd ... \"gin\" it is then]"], "author": "Leroux"}
{"word": [" Spirit."], "author": "tarangwydion"}
{"word": ["Soul"], "author": "reaver894"}
{"word": ["Stolen"], "author": "n99127"}
{"word": ["Moments"], "author": "Stuff"}
{"word": ["Precious."], "author": "tarangwydion"}
{"word": ["Ring"], "author": "reaver894"}
{"word": ["World"], "author": "Stuff"}
{"word": ["Rule"], "author": "n99127"}
{"word": ["Authority"], "author": "Lou"}
{"word": ["Lawful."], "author": "tarangwydion"}
{"word": ["Good"], "author": "n99127"}
{"word": ["Night"], "author": "Lou"}
{"word": ["Astronomy"], "author": "Geraldine"}
{"word": ["Astrology."], "author": "Nel-A"}
{"word": ["Black hole"], "author": "reaver894"}
{"word": [" Two"], "author": "agogfan"}
{"word": ["Poo"], "author": "GoJays2025"}
{"word": [], "author": "Stuff"}
{"word": ["misfit"], "author": "Lou"}
{"word": ["Outcast"], "author": "Maighstir"}
{"word": [" Jedi"], "author": "agogfan"}
{"word": ["Knight"], "author": "GoJays2025"}
{"word": ["Sword"], "author": "Stuff"}
{"word": ["Discord."], "author": "ahabschmidt"}
{"word": ["Zither"], "author": "Thiev"}
{"word": ["Exotic"], "author": "Stuff"}
{"word": [" Fish"], "author": "Lou"}
{"word": ["Tuna"], "author": "GoJays2025"}
{"word": ["sandwich"], "author": "oasis789"}
{"word": ["chew"], "author": "Leroux"}
{"word": ["Gum"], "author": "Lou"}
{"word": ["Ball"], "author": "reaver894"}
{"word": ["Sack"], "author": "Prydeless"}
{"word": ["Ball"], "author": "reaver894"}
{"word": ["Soccer."], "author": "tarangwydion"}
{"word": ["Dramatics"], "author": "reaver894"}
{"word": [" ", "."], "author": "tarangwydion"}
{"word": ["War"], "author": "swizzle66"}
{"word": ["Peace"], "author": "Arianus.836"}
{"word": [" Lie."], "author": "Thiev"}
{"word": [" deplomancy :D"], "author": "Arianus.836"}
{"word": [" Futile"], "author": "Nel-A"}
{"word": ["Resistance"], "author": "reaver894"}
{"word": ["Shooter"], "author": "swizzle66"}
{"word": ["Sniper."], "author": "tarangwydion"}
{"word": ["Zaitsev"], "author": "Lou"}
{"word": [" Propaganda"], "author": "serpantino"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Useless"], "author": "Arianus.836"}
{"word": [" Luigi"], "author": "Nel-A"}
{"word": ["Twin"], "author": "Stuff"}
{"word": [" Siamese"], "author": "Arianus.836"}
{"word": ["Connection"], "author": "GoJays2025"}
{"word": ["French"], "author": "agogfan"}
{"word": ["Levi-Civita - Sorry ninja'd ", " ", " Vanilla"], "author": "Lou"}
{"word": ["Baby"], "author": "Leroux"}
{"word": ["Diapers"], "author": "GoJays2025"}
{"word": ["Excrement."], "author": "swizzle66"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Win"], "author": "Arianus.836"}
{"word": ["Achieve"], "author": "Stuff"}
{"word": ["accolade"], "author": "Tulivu"}
{"word": ["deadlock"], "author": "BarryMC"}
{"word": ["stalemate"], "author": "Nel-A"}
{"word": ["tie"], "author": "swizzle66"}
{"word": ["suit"], "author": "Nel-A"}
{"word": ["Stylish."], "author": "tarangwydion"}
{"word": ["art"], "author": "swizzle66"}
{"word": ["Vandelay"], "author": "Hesusio"}
{"word": [], "author": "Lou"}
{"word": ["Sitcom."], "author": "tarangwydion"}
{"word": ["Jokes"], "author": "swizzle66"}
{"word": ["Chandler"], "author": "ExecB5"}
{"word": ["Bing"], "author": "GoJays2025"}
{"word": ["Search"], "author": "Maighstir"}
{"word": ["Engine"], "author": "Stuff"}
{"word": ["Steam"], "author": "GoJays2025"}
{"word": ["DRM"], "author": "Elenarie"}
{"word": ["rape"], "author": "Tulivu"}
{"word": ["barf"], "author": "Maighstir"}
{"word": ["mouth"], "author": "ExecB5"}
{"word": ["breath"], "author": "KneeTheCap"}
{"word": ["Air."], "author": "tarangwydion"}
{"word": ["Bender"], "author": "Lou"}
{"word": ["Robot"], "author": "GoJays2025"}
{"word": ["Terminator."], "author": "tarangwydion"}
{"word": ["California"], "author": "icepowdah"}
{"word": ["."], "author": "bsu"}
{"word": ["Machine"], "author": "n99127"}
{"word": ["Steampunk"], "author": "Stuff"}
{"word": ["Arcanum"], "author": "Lou"}
{"word": ["Wizard"], "author": "icepowdah"}
{"word": ["racist"], "author": "Tulivu"}
{"word": ["color"], "author": "ExecB5"}
{"word": [" Rainbow"], "author": "Arianus.836"}
{"word": ["Connection."], "author": "tarangwydion"}
{"word": ["Wire"], "author": "swizzle66"}
{"word": ["Baltimore"], "author": "GoJays2025"}
{"word": [" Applecore"], "author": "GameRager"}
{"word": [" room-service"], "author": "icepowdah"}
{"word": ["Maid"], "author": "GameRager"}
{"word": ["costume"], "author": "ExecB5"}
{"word": ["jewelry"], "author": "Lou"}
{"word": ["grill"], "author": "Tulivu"}
{"word": ["Barbecue"], "author": "swizzle66"}
{"word": ["Longpig"], "author": "GameRager"}
{"word": ["fork"], "author": "icepowdah"}
{"word": ["Spoon"], "author": "GoJays2025"}
{"word": [], "author": "ilves"}
{"word": ["Tale. ", " ", " * see my current avatar :-D"], "author": "tarangwydion"}
{"word": ["."], "author": "bsu"}
{"word": ["Bait."], "author": "tarangwydion"}
{"word": ["Master"], "author": "swizzle66"}
{"word": ["Degree"], "author": "GoJays2025"}
{"word": ["Temperature."], "author": "tarangwydion"}
{"word": ["Flu"], "author": "icepowdah"}
{"word": ["Shot"], "author": "Stuff"}
{"word": [" Bird"], "author": "n99127"}
{"word": [], "author": "icepowdah"}
{"word": ["Ford"], "author": "Tulivu"}
{"word": ["truck"], "author": "GoJays2025"}
{"word": ["Monster"], "author": "Nel-A"}
{"word": ["Them."], "author": "bladeofBG"}
{"word": ["Ants"], "author": "GoJays2025"}
{"word": ["Picnic"], "author": "Stuff"}
{"word": ["Grass"], "author": "icepowdah"}
{"word": ["Hippies"], "author": "Hesusio"}
{"word": ["Extermination"], "author": "Tulivu"}
{"word": ["quiet"], "author": "icepowdah"}
{"word": ["Night"], "author": "Skystrider"}
{"word": ["Stars"], "author": "GoJays2025"}
{"word": [], "author": "Lou"}
{"word": ["Foreman."], "author": "tarangwydion"}
{"word": ["George"], "author": "GoJays2025"}
{"word": ["Jungle"], "author": "icepowdah"}
{"word": ["Urban."], "author": "Tulivu"}
{"word": ["Keith"], "author": "Lou"}
{"word": ["Alexander"], "author": "GoJays2025"}
{"word": ["Great."], "author": "tarangwydion"}
{"word": ["Scott!"], "author": "GameRager"}
{"word": ["Scotch"], "author": "Tulivu"}
{"word": ["Ice cube"], "author": "icepowdah"}
{"word": [" Bad acting"], "author": "Xaromir"}
{"word": ["Laugh"], "author": "Tulivu"}
{"word": [" cry"], "author": "Arianus.836"}
{"word": ["Aerosmith"], "author": "icepowdah"}
{"word": ["Steven"], "author": "ExecB5"}
{"word": ["even"], "author": "GoJays2025"}
{"word": ["steven"], "author": "Lou"}
{"word": ["Crown"], "author": "Stuff"}
{"word": ["scepter"], "author": "icepowdah"}
{"word": ["Sovereign"], "author": "Nel-A"}
{"word": ["Lord"], "author": "Arianus.836"}
{"word": ["British"], "author": "KneeTheCap"}
{"word": ["Bulldog"], "author": "wolfsnake"}
{"word": ["Breed."], "author": "tarangwydion"}
{"word": ["Pigs"], "author": "bladeofBG"}
{"word": ["Bacon"], "author": "swizzle66"}
{"word": ["Eggs"], "author": "wolfsnake"}
{"word": ["Chicken."], "author": "tarangwydion"}
{"word": ["Cow"], "author": "GoJays2025"}
{"word": ["pasture"], "author": "icepowdah"}
{"word": ["greener"], "author": "n99127"}
{"word": ["Environmental"], "author": "Lou"}
{"word": ["hazard"], "author": "bladeofBG"}
{"word": ["dukes"], "author": "icepowdah"}
{"word": ["Fist"], "author": "Tulivu"}
{"word": ["Punch"], "author": "GoJays2025"}
{"word": ["Dragon"], "author": "n99127"}
{"word": ["Hoard"], "author": "Rohan15"}
{"word": ["Mongolians"], "author": "icepowdah"}
{"word": ["Khan"], "author": "KneeTheCap"}
{"word": ["Genghis"], "author": "Stuff"}
{"word": ["Food"], "author": "Maighstir"}
{"word": ["Tums"], "author": "Tulivu"}
{"word": ["Heartburn."], "author": "Nel-A"}
{"word": ["Indigestion"], "author": "GoJays2025"}
{"word": ["Upset"], "author": "Tulivu"}
{"word": ["Angry"], "author": "swizzle66"}
{"word": ["Birds."], "author": "tarangwydion"}
{"word": ["Ripoff."], "author": "Rohan15"}
{"word": ["DRM"], "author": "Tulivu"}
{"word": ["Steam."], "author": "tarangwydion"}
{"word": ["Valve"], "author": "GoJays2025"}
{"word": ["Portal"], "author": "Lou"}
{"word": ["Stargate."], "author": "tarangwydion"}
{"word": ["Egypt"], "author": "Tulivu"}
{"word": ["Anubis"], "author": "Lou"}
{"word": ["Jackal"], "author": "GoJays2025"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Goodnight. [/signout]"], "author": "Tulivu"}
{"word": ["."], "author": "tarangwydion"}
{"word": [], "author": "Lou"}
{"word": ["Starbuck"], "author": "Arianus.836"}
{"word": ["Coffee"], "author": "Rohan15"}
{"word": ["Tea"], "author": "Lexor"}
{"word": ["Leaves"], "author": "swizzle66"}
{"word": ["Tree."], "author": "Nel-A"}
{"word": ["forest"], "author": "GoJays2025"}
{"word": ["gump"], "author": "wolfsnake"}
{"word": ["quiet"], "author": "Arianus.836"}
{"word": [], "author": "Stuff"}
{"word": ["Bjork"], "author": "Nel-A"}
{"word": ["Icelandic"], "author": "tarangwydion"}
{"word": ["Volcanic"], "author": "Tulivu"}
{"word": ["Tectonic."], "author": "bsu"}
{"word": [], "author": "Lou"}
{"word": ["Minecraft. ", " ", " * What's tectonicus? Obviously I am not a Minecraft gamer."], "author": "tarangwydion"}
{"word": ["Inconsequential."], "author": "bladeofBG"}
{"word": [" * See Link"], "author": "Lou"}
{"word": ["...consequence?"], "author": "Rohan15"}
{"word": [], "author": "tarangwydion"}
{"word": ["Lie"], "author": "icepowdah"}
{"word": ["Politics"], "author": "Ubivis"}
{"word": ["Pointless."], "author": "Nel-A"}
{"word": ["sweets"], "author": "KneeTheCap"}
{"word": [], "author": "icepowdah"}
{"word": ["Sigmund Freud"], "author": "LulzKiller"}
{"word": [" Sex"], "author": "Cryxo"}
{"word": ["Masturbation"], "author": "LulzKiller"}
{"word": ["porn"], "author": "GoJays2025"}
{"word": ["WOMEN!"], "author": "Arianus.836"}
{"word": ["difficult"], "author": "KneeTheCap"}
{"word": ["Level."], "author": "tarangwydion"}
{"word": ["Experience"], "author": "Lou"}
{"word": ["S.P.E.C.I.A.L"], "author": "icepowdah"}
{"word": [". ", " ", " * That game is using ", " system."], "author": "tarangwydion"}
{"word": ["Squall"], "author": "ExecB5"}
{"word": [" Wind"], "author": "LulzKiller"}
{"word": ["Wing"], "author": "Tulivu"}
{"word": [" Commander"], "author": "Arianus.836"}
{"word": ["Keen"], "author": "Lou"}
{"word": ["Eager."], "author": "tarangwydion"}
{"word": ["Wait."], "author": "swizzle66"}
{"word": ["Pause"], "author": "Stuff"}
{"word": ["Break"], "author": "KneeTheCap"}
{"word": ["Tie"], "author": "icepowdah"}
{"word": ["Fighter."], "author": "Nel-A"}
{"word": ["Tekken"], "author": "KneeTheCap"}
{"word": ["Japan"], "author": "ExecB5"}
{"word": ["sushi"], "author": "GoJays2025"}
{"word": [" Jaws"], "author": "cosminm"}
{"word": ["^ Oblivion"], "author": "Thiev"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Soccer."], "author": "bsu"}
{"word": ["Goal!"], "author": "AeonofOblivion"}
{"word": ["Bucket list"], "author": "icepowdah"}
{"word": [" That's two words! ", " ", " but anyways... ", " ", " Hat"], "author": "n99127"}
{"word": ["."], "author": "tarangwydion"}
{"word": [" Periods."], "author": "LulzKiller"}
{"word": [" Gross."], "author": "AeonofOblivion"}
{"word": ["Net."], "author": "Nel-A"}
{"word": ["Tennis"], "author": "GoJays2025"}
{"word": ["sport"], "author": "ExecB5"}
{"word": [" Handegg A.K.A American Football."], "author": "LulzKiller"}
{"word": ["joke"], "author": "KneeTheCap"}
{"word": ["comedian"], "author": "GoJays2025"}
{"word": ["Lewis"], "author": "Lou"}
{"word": ["Formula 1"], "author": "icepowdah"}
{"word": ["Class"], "author": "Stuff"}
{"word": ["Rank"], "author": "AeonofOblivion"}
{"word": ["Page"], "author": "icepowdah"}
{"word": ["Ellen"], "author": "GoJays2025"}
{"word": ["Light"], "author": "Stuff"}
{"word": ["Star"], "author": "park_84"}
{"word": ["Porn"], "author": "wolfsnake"}
{"word": ["Internet"], "author": "icepowdah"}
{"word": ["Meme."], "author": "tarangwydion"}
{"word": ["Nyan!"], "author": "AeonofOblivion"}
{"word": ["Cat"], "author": "Nel-A"}
{"word": ["Felix"], "author": "KneeTheCap"}
{"word": ["Cat"], "author": "Arianus.836"}
{"word": ["Woman."], "author": "tarangwydion"}
{"word": ["Breasts"], "author": "GoJays2025"}
{"word": ["Chicken"], "author": "Lou"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Commander"], "author": "swizzle66"}
{"word": ["Military"], "author": "Nel-A"}
{"word": ["Discipline"], "author": "KneeTheCap"}
{"word": ["Chaos"], "author": "icepowdah"}
{"word": ["Theory"], "author": "GoJays2025"}
{"word": ["Einstein"], "author": "KneeTheCap"}
{"word": ["Mass"], "author": "SaraB123"}
{"word": ["Destruction."], "author": "AeonofOblivion"}
{"word": ["Totoanihilation"], "author": "Arianus.836"}
{"word": ["Emptiness"], "author": "icepowdah"}
{"word": ["Void"], "author": "KneeTheCap"}
{"word": ["Null"], "author": "SaraB123"}
{"word": ["Nonexistent"], "author": "AeonofOblivion"}
{"word": ["Demons"], "author": "GameRager"}
{"word": ["Fallen"], "author": "Nel-A"}
{"word": ["Hair"], "author": "icepowdah"}
{"word": ["Removal."], "author": "tarangwydion"}
{"word": ["Surgery"], "author": "KneeTheCap"}
{"word": ["Brain"], "author": "AeonofOblivion"}
{"word": ["Pinky"], "author": "icepowdah"}
{"word": ["Brain"], "author": "Stuff"}
{"word": ["."], "author": "tarangwydion"}
{"word": [" Superman"], "author": "Arianus.836"}
{"word": ["Lasers"], "author": "AeonofOblivion"}
{"word": ["Lasik"], "author": "Lou"}
{"word": ["Eyes"], "author": "Nel-A"}
{"word": ["Glasses!"], "author": "AeonofOblivion"}
{"word": ["Goggles"], "author": "GoJays2025"}
{"word": ["Biggles"], "author": "wolfsnake"}
{"word": ["Pilot."], "author": "Nel-A"}
{"word": ["Actor"], "author": "icepowdah"}
{"word": ["Fake"], "author": "KneeTheCap"}
{"word": ["Plastic"], "author": "Arianus.836"}
{"word": ["Trees"], "author": "GoJays2025"}
{"word": ["Ents"], "author": "AeonofOblivion"}
{"word": ["Giant"], "author": "Arianus.836"}
{"word": ["Cyclops"], "author": "KneeTheCap"}
{"word": [" Eye"], "author": "Arianus.836"}
{"word": ["Sauron"], "author": "Stuff"}
{"word": ["Ring."], "author": "tarangwydion"}
{"word": ["Boxing"], "author": "TrollumThinks"}
{"word": ["Gloves"], "author": "wolfsnake"}
{"word": ["Mittens"], "author": "AeonofOblivion"}
{"word": [" Kittens"], "author": "icepowdah"}
{"word": [" Furry"], "author": "ShogunDarius"}
{"word": ["Werewolf"], "author": "KOCollins"}
{"word": ["vampire ", " ", " (if someone says \"Twilight\" I'm gonna strangle him/her...)"], "author": "KneeTheCap"}
{"word": ["Fangs"], "author": "Stuff"}
{"word": ["Teeth"], "author": "swizzle66"}
{"word": ["Braces!"], "author": "AeonofOblivion"}
{"word": ["Jaws ", " (James Bond)"], "author": "KOCollins"}
{"word": [], "author": "icepowdah"}
{"word": ["Disco"], "author": "dmetras"}
{"word": ["Ball"], "author": "swizzle66"}
{"word": ["Beach"], "author": "Lou"}
{"word": ["Bikini"], "author": "AeonofOblivion"}
{"word": ["Bottom"], "author": "GoJays2025"}
{"word": ["Barrel."], "author": "tarangwydion"}
{"word": ["Roll"], "author": "KneeTheCap"}
{"word": ["Bread"], "author": "wolfsnake"}
{"word": [" Ham"], "author": "WrathOfTheAngels"}
{"word": ["-string"], "author": "TrollumThinks"}
{"word": ["Theory"], "author": "GoJays2025"}
{"word": [" Bazinga"], "author": "icepowdah"}
{"word": ["Eureka!"], "author": "AeonofOblivion"}
{"word": ["SyFy"], "author": "Lou"}
{"word": ["Dune"], "author": "KOCollins"}
{"word": ["Worms"], "author": "wolfsnake"}
{"word": ["Armageddon"], "author": "Nel-A"}
{"word": ["movie"], "author": "KneeTheCap"}
{"word": ["Popcorn"], "author": "AeonofOblivion"}
{"word": [], "author": "KOCollins"}
{"word": ["Goodman"], "author": "Lou"}
{"word": ["'Nam"], "author": "swizzle66"}
{"word": ["nihilists"], "author": "GoJays2025"}
{"word": ["Ontology"], "author": "AeonofOblivion"}
{"word": ["argument"], "author": "MasterFoobar"}
{"word": ["moot"], "author": "TrollumThinks"}
{"word": [], "author": "KOCollins"}
{"word": ["Hell."], "author": "Rohan15"}
{"word": ["planet ", " ", " (", ")"], "author": "KneeTheCap"}
{"word": ["Jupiter"], "author": "icepowdah"}
{"word": ["Uranus"], "author": "TrollumThinks"}
{"word": ["Smell-O-scope"], "author": "MasterFoobar"}
{"word": ["Farnsworth"], "author": "GoJays2025"}
{"word": ["Professor"], "author": "AeonofOblivion"}
{"word": ["instructor"], "author": "Arianus.836"}
{"word": ["Driving."], "author": "Nel-A"}
{"word": ["road"], "author": "dmetras"}
{"word": ["rage"], "author": "spindown"}
{"word": ["Fury"], "author": "AeonofOblivion"}
{"word": ["Furry"], "author": "GoJays2025"}
{"word": ["Pussy"], "author": "wolfsnake"}
{"word": ["Cat"], "author": "KneeTheCap"}
{"word": ["Fleas"], "author": "wolfsnake"}
{"word": ["dogs"], "author": "Arianus.836"}
{"word": ["Rabies."], "author": "tarangwydion"}
{"word": ["Vaccine"], "author": "AeonofOblivion"}
{"word": ["immunity"], "author": "TrollumThinks"}
{"word": ["Diplomatic."], "author": "tarangwydion"}
{"word": ["Attache'"], "author": "Lou"}
{"word": ["briefcase"], "author": "KOCollins"}
{"word": ["leather"], "author": "icepowdah"}
{"word": ["Jacket"], "author": "Stuff"}
{"word": ["Potato."], "author": "Nel-A"}
{"word": [" Gun"], "author": "Arianus.836"}
{"word": ["robber"], "author": "KneeTheCap"}
{"word": ["prison"], "author": "wolfsnake"}
{"word": ["Cell"], "author": "AeonofOblivion"}
{"word": ["Mitosis"], "author": "GoJays2025"}
{"word": ["Biology"], "author": "Arianus.836"}
{"word": ["Astrology"], "author": "cosminm"}
{"word": ["Sociology"], "author": "Arianus.836"}
{"word": ["Marx"], "author": "KneeTheCap"}
{"word": ["Richard."], "author": "tarangwydion"}
{"word": ["Nixon."], "author": "dmetras"}
{"word": ["Crook."], "author": "tarangwydion"}
{"word": ["Thief"], "author": "Stuff"}
{"word": ["Generous"], "author": "KneeTheCap"}
{"word": ["Generation"], "author": "cosminm"}
{"word": ["Love"], "author": "icepowdah"}
{"word": ["Sex"], "author": "ExecB5"}
{"word": ["number ", " ", " (it's swedish)"], "author": "KneeTheCap"}
{"word": ["Two"], "author": "wolfsnake"}
{"word": ["Three"], "author": "Arianus.836"}
{"word": ["Musketeers"], "author": "KneeTheCap"}
{"word": ["French"], "author": "GoJays2025"}
{"word": ["Dip"], "author": "Ballistic_Peanut"}
{"word": ["Dab"], "author": "wolfsnake"}
{"word": ["Dub"], "author": "KneeTheCap"}
{"word": ["Step"], "author": "AeonofOblivion"}
{"word": ["Right"], "author": "icepowdah"}
{"word": ["exactly"], "author": "CyPhErIoN"}
{"word": ["point"], "author": "KneeTheCap"}
{"word": ["blank"], "author": "icepowdah"}
{"word": ["range"], "author": "Arianus.836"}
{"word": ["Chicken"], "author": "Ballistic_Peanut"}
{"word": ["street"], "author": "spindown"}
{"word": ["Nuggets!!"], "author": "AeonofOblivion"}
{"word": ["golden"], "author": "wolfsnake"}
{"word": [" "], "author": "Arianus.836"}
{"word": ["flies"], "author": "Maighstir"}
{"word": ["Boar"], "author": "Nel-A"}
{"word": ["Pig"], "author": "swizzle66"}
{"word": ["COP"], "author": "cosminm"}
{"word": ["Octobrain :)"], "author": "SpiderFighter"}
{"word": ["OctoMom"], "author": "Lou"}
{"word": ["stupid"], "author": "KneeTheCap"}
{"word": ["Religion"], "author": "AeonofOblivion"}
{"word": ["Spaghetti"], "author": "GoJays2025"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["selling"], "author": "CyPhErIoN"}
{"word": ["Seducing"], "author": "KOCollins"}
{"word": ["Romance"], "author": "AeonofOblivion"}
{"word": ["bromance"], "author": "bevinator"}
{"word": ["LOOK!"], "author": "Arianus.836"}
{"word": ["Loom"], "author": "ExecB5"}
{"word": ["Shroom"], "author": "icepowdah"}
{"word": ["Psychedelic"], "author": "Nel-A"}
{"word": ["Seventies"], "author": "wolfsnake"}
{"word": ["show"], "author": "KneeTheCap"}
{"word": ["Entertainment"], "author": "Nel-A"}
{"word": ["Rare"], "author": "Stuff"}
{"word": ["pokemon"], "author": "Ballistic_Peanut"}
{"word": ["collector"], "author": "icepowdah"}
{"word": ["compulsive"], "author": "SpiderFighter"}
{"word": ["Gamer"], "author": "Lou"}
{"word": ["Controller"], "author": "AeonofOblivion"}
{"word": [], "author": "KOCollins"}
{"word": ["Blue"], "author": "ExecB5"}
{"word": ["coins"], "author": "KneeTheCap"}
{"word": ["fountain"], "author": "SpiderFighter"}
{"word": ["youth"], "author": "MasterFoobar"}
{"word": ["Alien"], "author": "Lou"}
{"word": ["Technology"], "author": "AeonofOblivion"}
{"word": [], "author": "KOCollins"}
{"word": ["Zeppelin"], "author": "Lou"}
{"word": ["Balloon"], "author": "wolfsnake"}
{"word": ["party"], "author": "KneeTheCap"}
{"word": ["Animal"], "author": "Stuff"}
{"word": ["Cracker"], "author": "Ballistic_Peanut"}
{"word": ["cookie"], "author": "Maighstir"}
{"word": ["Peanut Butter"], "author": "Lou"}
{"word": ["Jelly"], "author": "Ballistic_Peanut"}
{"word": ["Time"], "author": "AeonofOblivion"}
{"word": ["Commando ", " ", " "], "author": "ExecB5"}
{"word": ["Going. ", " ", " ", " ", " :-D"], "author": "tarangwydion"}
{"word": ["Rogue"], "author": "Lou"}
{"word": ["Spear ", " ", " ", " ", " ", " :P"], "author": "AeonofOblivion"}
{"word": [" ", " ;pp"], "author": "KOCollins"}
{"word": ["Incarnation."], "author": "Trevorish"}
{"word": ["Religion"], "author": "ExecB5"}
{"word": ["Belief."], "author": "tarangwydion"}
{"word": ["Idea"], "author": "swizzle66"}
{"word": ["Tabula Rasa"], "author": "Lou"}
{"word": ["British"], "author": "Trevorish"}
{"word": ["Football"], "author": "icepowdah"}
{"word": ["American"], "author": "wolfsnake"}
{"word": ["eagle"], "author": "Trevorish"}
{"word": ["Desert"], "author": "ExecB5"}
{"word": ["vast"], "author": "KneeTheCap"}
{"word": ["space"], "author": "wolfsnake"}
{"word": ["Galaxy"], "author": "AeonofOblivion"}
{"word": ["Quest"], "author": "KneeTheCap"}
{"word": ["Hero"], "author": "Trevorish"}
{"word": ["Villain"], "author": "ChaunceyK"}
{"word": ["Cruella"], "author": "Trevorish"}
{"word": ["dalmations"], "author": "SpiderFighter"}
{"word": ["spots"], "author": "ChaunceyK"}
{"word": ["leprosy"], "author": "Trevorish"}
{"word": ["Thomas Covenant"], "author": "Lou"}
{"word": [" (you do know this is a one-word game, not two, right?) ", " ", " ", " Pact"], "author": "AeonofOblivion"}
{"word": ["Warsaw."], "author": "tarangwydion"}
{"word": ["Polish"], "author": "swizzle66"}
{"word": ["Shoes."], "author": "tarangwydion"}
{"word": ["Bundy"], "author": "icepowdah"}
{"word": ["Ted"], "author": "wolfsnake"}
{"word": ["Chopped! ", " ", " (note: this is reference to Ted Allen's show on Food Network, not Ted Bundy \"chopping\" people. :)"], "author": "SpiderFighter"}
{"word": ["Knife!"], "author": "AeonofOblivion"}
{"word": ["humiliation"], "author": "CyPhErIoN"}
{"word": ["Painful"], "author": "Rohan15"}
{"word": ["Sting"], "author": "Nel-A"}
{"word": ["Police"], "author": "SpiderFighter"}
{"word": ["Bandit"], "author": "ExecB5"}
{"word": ["Steal"], "author": "swizzle66"}
{"word": ["loss"], "author": "Maighstir"}
{"word": ["Gain"], "author": "AeonofOblivion"}
{"word": ["weight"], "author": "EvilDoc"}
{"word": ["Heavy."], "author": "tarangwydion"}
{"word": ["Rain"], "author": "KneeTheCap"}
{"word": ["Canada"], "author": "Trevorish"}
{"word": ["Leaf"], "author": "AeonofOblivion"}
{"word": ["Ryan"], "author": "GoJays2025"}
{"word": ["Gosling."], "author": "tarangwydion"}
{"word": ["Goose"], "author": "AeonofOblivion"}
{"word": ["stuffed"], "author": "SpiderFighter"}
{"word": ["bear"], "author": "Trevorish"}
{"word": ["Polar"], "author": "Nel-A"}
{"word": ["Opposite"], "author": "Arianus.836"}
{"word": ["Attraction"], "author": "AeonofOblivion"}
{"word": ["Fatal."], "author": "tarangwydion"}
{"word": ["Injury."], "author": "Noah120"}
{"word": ["death"], "author": "Trevorish"}
{"word": ["wish"], "author": "liberatorx1"}
{"word": ["Genie"], "author": "AeonofOblivion"}
{"word": ["Bottle."], "author": "tarangwydion"}
{"word": ["Caps"], "author": "Lou"}
{"word": ["hats"], "author": "TrollumThinks"}
{"word": ["Valve"], "author": "swizzle66"}
{"word": [], "author": "KOCollins"}
{"word": ["Regulate"], "author": "Stuff"}
{"word": ["censor"], "author": "SpiderFighter"}
{"word": ["Government"], "author": "wolfsnake"}
{"word": ["Rebellion"], "author": "AeonofOblivion"}
{"word": ["Scum"], "author": "Trevorish"}
{"word": ["Bar ", " ", " "], "author": "ExecB5"}
{"word": ["Soap"], "author": "Trevorish"}
{"word": ["Uh-Oh"], "author": "Arianus.836"}
{"word": ["Bummer."], "author": "tarangwydion"}
{"word": ["Bugger"], "author": "AeonofOblivion"}
{"word": ["Ender"], "author": "Trevorish"}
{"word": [], "author": "Stuff"}
{"word": ["Lost"], "author": "KneeTheCap"}
{"word": ["Confused"], "author": "Nel-A"}
{"word": ["Dazed"], "author": "SpiderFighter"}
{"word": ["Concussion"], "author": "wolfsnake"}
{"word": ["Grenade"], "author": "Nel-A"}
{"word": ["Plasma"], "author": "Trevorish"}
{"word": ["Centrifuge"], "author": "4gamin"}
{"word": ["Axis"], "author": "AeonofOblivion"}
{"word": ["gyroscope"], "author": "Maighstir"}
{"word": ["alien ", " ", " ", "/"], "author": "Trevorish"}
{"word": ["Dell"], "author": "ExecB5"}
{"word": ["lapTOP"], "author": "Arianus.836"}
{"word": ["Overheat"], "author": "wolfsnake"}
{"word": ["Broken"], "author": "Arianus.836"}
{"word": ["kneecap"], "author": "KneeTheCap"}
{"word": ["Bones"], "author": "Detlik"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Backpack"], "author": "Detlik"}
{"word": ["Backpacking"], "author": "swizzle66"}
{"word": ["Vacation"], "author": "Detlik"}
{"word": ["Permanent"], "author": "EvilDoc"}
{"word": ["Resident."], "author": "tarangwydion"}
{"word": ["Evil"], "author": "swizzle66"}
{"word": ["Microsoft. ", " ", " :-P"], "author": "tarangwydion"}
{"word": ["Software"], "author": "bsu"}
{"word": ["Design."], "author": "tarangwydion"}
{"word": ["aesthetic"], "author": "Lou"}
{"word": ["liposuction"], "author": "icepowdah"}
{"word": ["fat"], "author": "wolfsnake"}
{"word": ["american"], "author": "Detlik"}
{"word": ["dream"], "author": "KneeTheCap"}
{"word": ["nightmare"], "author": "TrollumThinks"}
{"word": ["creature"], "author": "icepowdah"}
{"word": ["gremlin"], "author": "wolfsnake"}
{"word": ["Goblin"], "author": "AeonofOblivion"}
{"word": ["Sappers"], "author": "Sparkbomber"}
{"word": ["Spy"], "author": "swizzle66"}
{"word": ["KGB"], "author": "spindown"}
{"word": ["007"], "author": "ExecB5"}
{"word": ["suave"], "author": "KneeTheCap"}
{"word": ["prell"], "author": "4gamin"}
{"word": [], "author": "KOCollins"}
{"word": ["Focus"], "author": "Stuff"}
{"word": ["camera"], "author": "wolfsnake"}
{"word": ["picture"], "author": "ExecB5"}
{"word": ["birthday"], "author": "WrathOfTheAngels"}
{"word": ["cake"], "author": "KneeTheCap"}
{"word": ["Icing"], "author": "Nel-A"}
{"word": ["Hockey."], "author": "tarangwydion"}
{"word": ["Sticks"], "author": "Ballistic_Peanut"}
{"word": ["stones"], "author": "KneeTheCap"}
{"word": ["Throwing."], "author": "tarangwydion"}
{"word": ["Up! ", " ", " (edit: It wouldn't let me post just 'Up' - I guess there's a minimum character limit of '3' which didn't take this game into account lol )"], "author": "TrollumThinks"}
{"word": ["Starlight"], "author": "KOCollins"}
{"word": ["romance"], "author": "icepowdah"}
{"word": ["Paris"], "author": "Nel-A"}
{"word": ["Tower"], "author": "wolfsnake"}
{"word": ["castle"], "author": "KneeTheCap"}
{"word": ["Rook"], "author": "Arianus.836"}
{"word": ["Chess."], "author": "nmillar"}
{"word": ["Knight"], "author": "Arianus.836"}
{"word": ["Armor"], "author": "icepowdah"}
{"word": ["Leather."], "author": "tarangwydion"}
{"word": ["Pleather"], "author": "Tulivu"}
{"word": ["Shmeather"], "author": "Ballistic_Peanut"}
{"word": ["Heather"], "author": "icepowdah"}
{"word": ["Grass"], "author": "wolfsnake"}
{"word": ["Plant"], "author": "ExecB5"}
{"word": ["Bomb"], "author": "icepowdah"}
{"word": ["Nuclear"], "author": "Nel-A"}
{"word": ["science"], "author": "Thiev"}
{"word": ["Biology"], "author": "Nel-A"}
{"word": ["Physics"], "author": "ExecB5"}
{"word": ["Cannons"], "author": "Ballistic_Peanut"}
{"word": ["Boom"], "author": "Arianus.836"}
{"word": ["stick"], "author": "KneeTheCap"}
{"word": ["Carrot"], "author": "agogfan"}
{"word": ["Wabbit"], "author": "Arianus.836"}
{"word": ["Replica. ", " ", " * never heard or knew about Wabbit until today, and just read the short entry on Wikipedia."], "author": "tarangwydion"}
{"word": ["Fake"], "author": "Lou"}
{"word": ["Water. ", " ", " * do not google for it. It is just a childhood joke between me and my brother that whenever we drank Sprite we always called it as \"fake water\""], "author": "tarangwydion"}
{"word": ["Costner"], "author": "Tulivu"}
{"word": [], "author": "KOCollins"}
{"word": ["dated"], "author": "TrollumThinks"}
{"word": ["Old"], "author": "Stuff"}
{"word": ["Cheese"], "author": "icepowdah"}
{"word": ["Puffs"], "author": "Lou"}
{"word": ["Sugar"], "author": "wolfsnake"}
{"word": ["splenda"], "author": "Arianus.836"}
{"word": ["atrocity"], "author": "Ballistic_Peanut"}
{"word": ["Metal ", " ", " "], "author": "Nel-A"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["cuffs"], "author": "TrollumThinks"}
{"word": ["Cufflinks"], "author": "swizzle66"}
{"word": [" Chains."], "author": "sloganvirst"}
{"word": ["Pinhead"], "author": "KneeTheCap"}
{"word": ["Small"], "author": "ExecB5"}
{"word": ["Ha!"], "author": "Arianus.836"}
{"word": ["joke"], "author": "4gamin"}
{"word": ["Funny"], "author": "Nel-A"}
{"word": [" Haha? :)"], "author": "Arianus.836"}
{"word": ["Nelson"], "author": "swizzle66"}
{"word": ["Half"], "author": "wolfsnake"}
{"word": ["Life"], "author": "Nel-A"}
{"word": ["Love."], "author": "tarangwydion"}
{"word": ["hate"], "author": "ExecB5"}
{"word": ["Bad"], "author": "swizzle66"}
{"word": ["taste"], "author": "KneeTheCap"}
{"word": ["Acquired."], "author": "Tulivu"}
{"word": [" Found."], "author": "sloganvirst"}
{"word": ["Discovery."], "author": "tarangwydion"}
{"word": ["Voyage"], "author": "KOCollins"}
{"word": ["Sinbad"], "author": "Lou"}
{"word": ["Sea"], "author": "ExecB5"}
{"word": ["."], "author": "tarangwydion"}
{"word": [], "author": "TrollumThinks"}
{"word": ["Stick."], "author": "Tulivu"}
{"word": [" Wood."], "author": "sloganvirst"}
{"word": ["Elves."], "author": "tarangwydion"}
{"word": ["Myth"], "author": "wolfsnake"}
{"word": ["Thor"], "author": "KOCollins"}
{"word": ["Thursday"], "author": "Nel-A"}
{"word": ["Bulldozer ", " ", " (HHGTTG reference) ", " ", " (Edit: Ninja'd - was Hammer)"], "author": "TrollumThinks"}
{"word": [], "author": "Stuff"}
{"word": [" Butterfly"], "author": "Arianus.836"}
{"word": ["Moth"], "author": "Nel-A"}
{"word": [" flame"], "author": "Arianus.836"}
{"word": ["Charmander"], "author": "Nel-A"}
{"word": [" Commander."], "author": "sloganvirst"}
{"word": [" Riker"], "author": "Arianus.836"}
{"word": ["William."], "author": "tarangwydion"}
{"word": ["Wallace"], "author": "KOCollins"}
{"word": ["Gromit"], "author": "Ballistic_Peanut"}
{"word": ["Sidekick"], "author": "TrollumThinks"}
{"word": [" Muttly."], "author": "sloganvirst"}
{"word": ["Sassafrassarassum"], "author": "Lou"}
{"word": ["Nonsense"], "author": "swizzle66"}
{"word": ["Babbling"], "author": "Sparkbomber"}
{"word": ["Brook"], "author": "Nel-A"}
{"word": [], "author": "Stuff"}
{"word": ["Cripple"], "author": "Lou"}
{"word": ["Crutch"], "author": "Sparkbomber"}
{"word": ["Aid"], "author": "TrollumThinks"}
{"word": ["First"], "author": "icepowdah"}
{"word": ["Second"], "author": "Nel-A"}
{"word": ["Minute"], "author": "Cassidy"}
{"word": ["Hour."], "author": "tarangwydion"}
{"word": [" Year"], "author": "sloganvirst"}
{"word": ["Yearling"], "author": "TrollumThinks"}
{"word": ["Youngling"], "author": "Trevorish"}
{"word": ["Jedi"], "author": "Lou"}
{"word": ["Knight"], "author": "Stuff"}
{"word": ["Forever."], "author": "tarangwydion"}
{"word": [" Neverending."], "author": "sloganvirst"}
{"word": ["Story"], "author": "Nel-A"}
{"word": ["Bedtime"], "author": "Lou"}
{"word": ["Pijamas"], "author": "icepowdah"}
{"word": ["Bananas"], "author": "Trevorish"}
{"word": ["Gorilla"], "author": "Arianus.836"}
{"word": [" Chimp."], "author": "sloganvirst"}
{"word": ["Caesar"], "author": "Trevorish"}
{"word": [" Rome"], "author": "Arianus.836"}
{"word": ["Coliseum"], "author": "KOCollins"}
{"word": ["Stadium"], "author": "Trevorish"}
{"word": ["."], "author": "tarangwydion"}
{"word": [], "author": "Ballistic_Peanut"}
{"word": ["Aregorn ", " ", " *edit too slow! :P"], "author": "Nel-A"}
{"word": ["Tolkien"], "author": "KOCollins"}
{"word": [], "author": "Stuff"}
{"word": ["Gondor"], "author": "Nel-A"}
{"word": ["Aragorn"], "author": "Lou"}
{"word": [" repeat?"], "author": "Arianus.836"}
{"word": ["Echo"], "author": "Nel-A"}
{"word": [" Spelling"], "author": "Lou"}
{"word": [" word :)"], "author": "Arianus.836"}
{"word": ["logos"], "author": "Trevorish"}
{"word": ["Legos"], "author": "spindown"}
{"word": ["Eggos"], "author": "Ballistic_Peanut"}
{"word": ["Waffles"], "author": "Lou"}
{"word": [" Cream"], "author": "sloganvirst"}
{"word": ["Clapton"], "author": "Stuff"}
{"word": ["Music"], "author": "Arianus.836"}
{"word": ["Sound"], "author": "Nel-A"}
{"word": ["Silence! ;)"], "author": "KOCollins"}
{"word": ["sexy"], "author": "Zhirek"}
{"word": ["Hips ;)"], "author": "Arianus.836"}
{"word": [], "author": "Stuff"}
{"word": ["DRM! :P"], "author": "Trevorish"}
{"word": ["Steam. ", " ", " * No matter how they try to deny it."], "author": "tarangwydion"}
{"word": ["Valve"], "author": "Zenphic"}
{"word": ["Pipe"], "author": "Maighstir"}
{"word": ["Peace"], "author": "KOCollins"}
{"word": [], "author": "Stuff"}
{"word": ["Signature"], "author": "Nel-A"}
{"word": ["Doctor"], "author": "Lou"}
{"word": ["Falsify"], "author": "Nel-A"}
{"word": ["Evidence"], "author": "Deadman619"}
{"word": ["Detective"], "author": "Nel-A"}
{"word": ["Gloves"], "author": "4gamin"}
{"word": ["Classic Game Characters"], "author": "DebugMode"}
{"word": ["*BZZZZZZZT*"], "author": "4gamin"}
{"word": ["electricity"], "author": "KneeTheCap"}
{"word": ["Rock."], "author": "Deadman619"}
{"word": ["Fossil"], "author": "4gamin"}
{"word": ["Fuel."], "author": "tarangwydion"}
{"word": [], "author": "VetMichael"}
{"word": [], "author": "Stuff"}
{"word": ["Cartman"], "author": "Nel-A"}
{"word": ["Pickaxe"], "author": "LordAvatar"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["rape"], "author": "Kynes"}
{"word": ["Prison"], "author": "KOCollins"}
{"word": ["Lockup"], "author": "Lou"}
{"word": ["Cell"], "author": "Stuff"}
{"word": ["nucleus"], "author": "VetMichael"}
{"word": ["Core"], "author": "Nel-A"}
{"word": ["Hyperspace"], "author": "InkPanther"}
{"word": ["Warp"], "author": "Arianus.836"}
{"word": ["Kirk"], "author": "Lou"}
{"word": ["Trekkies"], "author": "LordAvatar"}
{"word": ["Intelligence ;-P"], "author": "KOCollins"}
{"word": ["Attribute"], "author": "TrollumThinks"}
{"word": ["Character"], "author": "Stuff"}
{"word": ["RPG"], "author": "LordAvatar"}
{"word": ["Weapon ", " ", " (", ")"], "author": "Nel-A"}
{"word": [], "author": "VetMichael"}
{"word": ["Denied"], "author": "Arianus.836"}
{"word": ["Allowed"], "author": "swizzle66"}
{"word": ["Permission."], "author": "tarangwydion"}
{"word": ["Denied"], "author": "Lou"}
{"word": ["Access"], "author": "KOCollins"}
{"word": [". ", " ", " * Thank you Access Software for Crime Wave (1990)."], "author": "tarangwydion"}
{"word": ["Bits"], "author": "TrollumThinks"}
{"word": ["Fragments"], "author": "Nel-A"}
{"word": ["Shards"], "author": "4gamin"}
{"word": ["Crystals"], "author": "Lou"}
{"word": ["Energy"], "author": "ExecB5"}
{"word": ["E=MC2"], "author": "VetMichael"}
{"word": ["Theory"], "author": "Nel-A"}
{"word": ["Chaos"], "author": "Deadman619"}
{"word": ["splinter"], "author": "Arianus.836"}
{"word": ["Cell."], "author": "tarangwydion"}
{"word": ["Battery"], "author": "KOCollins"}
{"word": ["Assault"], "author": "TrollumThinks"}
{"word": ["Rifle"], "author": "Stuff"}
{"word": ["Trifle"], "author": "Nel-A"}
{"word": ["Trivial"], "author": "TrollumThinks"}
{"word": ["Pursuit"], "author": "Lou"}
{"word": ["crash"], "author": "Arianus.836"}
{"word": ["Shattered"], "author": "4gamin"}
{"word": ["Smashed"], "author": "Nel-A"}
{"word": ["Pissed"], "author": "VetMichael"}
{"word": ["^Leaky :)"], "author": "Arianus.836"}
{"word": ["Plumber."], "author": "tarangwydion"}
{"word": ["Mario"], "author": "Lou"}
{"word": ["Bowser"], "author": "KOCollins"}
{"word": ["Peach"], "author": "TrollumThinks"}
{"word": ["Princess"], "author": "Ezakael"}
{"word": ["Dragons"], "author": "LordAvatar"}
{"word": ["rpg"], "author": "ExecB5"}
{"word": ["Witcher"], "author": "Lenriak"}
{"word": [], "author": "KOCollins"}
{"word": [], "author": "Ballistic_Peanut"}
{"word": ["Invalid"], "author": "Nel-A"}
{"word": ["Expired"], "author": "Stuff"}
{"word": [" Trial"], "author": "sloganvirst"}
{"word": ["Law"], "author": "Lenriak"}
{"word": ["Society"], "author": "Nel-A"}
{"word": ["People"], "author": "ExecB5"}
{"word": ["crowd"], "author": "Niggles"}
{"word": [" Heads."], "author": "sloganvirst"}
{"word": ["Guillotine"], "author": "KOCollins"}
{"word": ["Robespierre"], "author": "Aidinthel"}
{"word": ["Lawyer"], "author": "Stuff"}
{"word": ["Expensive"], "author": "Niggles"}
{"word": ["Cost"], "author": "TrollumThinks"}
{"word": ["Price"], "author": "Lenriak"}
{"word": [" Cut"], "author": "Arianus.836"}
{"word": ["Swords"], "author": "Lenriak"}
{"word": ["Thundercats"], "author": "VetMichael"}
{"word": ["Snyarf!"], "author": "Nel-A"}
{"word": [" Blarge!"], "author": "sloganvirst"}
{"word": [" onomatopoeia"], "author": "VetMichael"}
{"word": ["sounds"], "author": "TrollumThinks"}
{"word": [" Speaker."], "author": "sloganvirst"}
{"word": ["microphone"], "author": "Lenriak"}
{"word": ["Voice"], "author": "ExecB5"}
{"word": ["Song"], "author": "Nel-A"}
{"word": ["Dance"], "author": "spindown"}
{"word": [" Disco"], "author": "Lou"}
{"word": ["I'm a bad dancer.. But I danced enough. They don't get it. If I moonwalk, they hasto see something.. I died but it was worth it."], "author": "Antimateria"}
{"word": ["^ Liquored up"], "author": "VetMichael"}
{"word": ["Inebriated"], "author": "Niggles"}
{"word": ["Hammered"], "author": "4gamin"}
{"word": ["Smashed"], "author": "KOCollins"}
{"word": ["Pumpkin"], "author": "Lou"}
{"word": [" Orange."], "author": "sloganvirst"}
{"word": ["Unrhymable"], "author": "TrollumThinks"}
{"word": ["Purple"], "author": "Stuff"}
{"word": ["dinosaur"], "author": "icepowdah"}
{"word": ["buick"], "author": "Lenriak"}
{"word": ["Barney"], "author": "Nel-A"}
{"word": [], "author": "VetMichael"}
{"word": ["One"], "author": "Arianus.836"}
{"word": ["Lonely"], "author": "Lou"}
{"word": ["Hearts"], "author": "Trevorish"}
{"word": ["Club"], "author": "KOCollins"}
{"word": ["Caveman"], "author": "Deadman619"}
{"word": ["Captain"], "author": "Nel-A"}
{"word": [" Picard"], "author": "Arianus.836"}
{"word": ["Maneuver"], "author": "spindown"}
{"word": ["Dogfight"], "author": "4gamin"}
{"word": ["Michael Vick"], "author": "Parvateshwar"}
{"word": ["Eagles"], "author": "GoJays2025"}
{"word": ["terrible"], "author": "Niggles"}
{"word": [" Tradgedy."], "author": "sloganvirst"}
{"word": ["Awful"], "author": "Nel-A"}
{"word": ["Awesome"], "author": "TrollumThinks"}
{"word": ["fantastic"], "author": "Niggles"}
{"word": ["Amazing"], "author": "crdy123"}
{"word": [" Spider-Man"], "author": "Trevorish"}
{"word": [" Web"], "author": "sloganvirst"}
{"word": ["Tangled"], "author": "crdy123"}
{"word": ["Rapunzel"], "author": "Lou"}
{"word": ["Haircut."], "author": "Parvateshwar"}
{"word": ["Scalp"], "author": "Nel-A"}
{"word": ["Follicle"], "author": "4gamin"}
{"word": [" Shackles."], "author": "sloganvirst"}
{"word": ["ignorance"], "author": "VetMichael"}
{"word": ["Bliss"], "author": "Lou"}
{"word": ["Muse"], "author": "Nel-A"}
{"word": ["lost"], "author": "TrollumThinks"}
{"word": ["Forgotten"], "author": "4gamin"}
{"word": [" Remember."], "author": "sloganvirst"}
{"word": ["anniversary"], "author": "Niggles"}
{"word": [" HALO"], "author": "Arianus.836"}
{"word": [" Reach."], "author": "sloganvirst"}
{"word": ["remote ", " ", " (cause I always have to reach for the remote)"], "author": "ExecB5"}
{"word": ["Pluto"], "author": "VetMichael"}
{"word": ["Mickey"], "author": "Lou"}
{"word": ["Donald."], "author": "tarangwydion"}
{"word": [" trump"], "author": "Arianus.836"}
{"word": [" Trumpet"], "author": "sloganvirst"}
{"word": ["Bugel"], "author": "Niggles"}
{"word": ["call ", " ", " edit - ninja'd twice - that'll teach me to leave the window open too long"], "author": "TrollumThinks"}
{"word": ["Duty"], "author": "Nel-A"}
{"word": ["Obligation"], "author": "Stuff"}
{"word": ["bills"], "author": "KneeTheCap"}
{"word": ["Mail"], "author": "4gamin"}
{"word": ["Chain"], "author": "Nel-A"}
{"word": ["Ball"], "author": "Parvateshwar"}
{"word": ["Quidditch"], "author": "Lou"}
{"word": ["Cup"], "author": "KOCollins"}
{"word": ["Goblet"], "author": "TrollumThinks"}
{"word": [" Cup"], "author": "sloganvirst"}
{"word": ["Chalice"], "author": "Stuff"}
{"word": ["grail"], "author": "Niggles"}
{"word": ["holy"], "author": "ExecB5"}
{"word": ["Robin"], "author": "Lou"}
{"word": ["Wonder"], "author": "Nel-A"}
{"word": [" Pyramid"], "author": "sloganvirst"}
{"word": ["mystery"], "author": "Niggles"}
{"word": ["Murder."], "author": "tarangwydion"}
{"word": [" Myself."], "author": "sloganvirst"}
{"word": ["yourself"], "author": "ExecB5"}
{"word": ["selfish"], "author": "TrollumThinks"}
{"word": ["Egotistical."], "author": "tarangwydion"}
{"word": [" Ego. :D"], "author": "sloganvirst"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Animation"], "author": "Nel-A"}
{"word": ["Cartoon"], "author": "Stuff"}
{"word": ["Disney"], "author": "pezhead53"}
{"word": ["Fantasia"], "author": "Ballistic_Peanut"}
{"word": [], "author": "KOCollins"}
{"word": ["Tinkerbell"], "author": "Lou"}
{"word": [" Fake!"], "author": "sloganvirst"}
{"word": [" Neverland!"], "author": "Arianus.836"}
{"word": ["Ranch"], "author": "KOCollins"}
{"word": ["Dressing"], "author": "Fever_Discordia"}
{"word": ["Crouton"], "author": "4gamin"}
{"word": [" Kryten."], "author": "sloganvirst"}
{"word": ["Dwarf"], "author": "Lou"}
{"word": ["Gimli."], "author": "tarangwydion"}
{"word": ["Moria"], "author": "spindown"}
{"word": ["Mithril"], "author": "KOCollins"}
{"word": ["armour"], "author": "TrollumThinks"}
{"word": ["."], "author": "Rohan15"}
{"word": ["miniclip ", " ", " EDIT: "], "author": "ExecB5"}
{"word": [" Minigun. ;-)"], "author": "sloganvirst"}
{"word": [], "author": "Stuff"}
{"word": ["Gunship"], "author": "Nel-A"}
{"word": ["Helicopter"], "author": "Fever_Discordia"}
{"word": ["rescue"], "author": "CyPhErIoN"}
{"word": ["Rangers"], "author": "Fever_Discordia"}
{"word": ["Bears"], "author": "4gamin"}
{"word": ["Yogi"], "author": "Lou"}
{"word": ["Guru"], "author": "Fever_Discordia"}
{"word": ["India"], "author": "Nel-A"}
{"word": ["Asia"], "author": "lightnica"}
{"word": [" Teriyaki"], "author": "Arianus.836"}
{"word": ["Chicken"], "author": "spindown"}
{"word": ["legs"], "author": "lightnica"}
{"word": [" Quad"], "author": "sloganvirst"}
{"word": ["Core"], "author": "Lou"}
{"word": ["Eidos."], "author": "tarangwydion"}
{"word": ["Interactive"], "author": "TrollumThinks"}
{"word": [" Game."], "author": "sloganvirst"}
{"word": ["drm"], "author": "CyPhErIoN"}
{"word": ["restrictive"], "author": "TrollumThinks"}
{"word": ["Manacles"], "author": "KOCollins"}
{"word": ["Rack"], "author": "Fever_Discordia"}
{"word": ["mammaries :P"], "author": "Niggles"}
{"word": ["platypus"], "author": "VetMichael"}
{"word": ["Ornithorhynchidae"], "author": "lightnica"}
{"word": ["orthodontist"], "author": "pezhead53"}
{"word": ["Tooth"], "author": "Daedalus1138"}
{"word": [" White."], "author": "sloganvirst"}
{"word": ["Shark"], "author": "Nel-A"}
{"word": ["Fin"], "author": "TrollumThinks"}
{"word": ["Diving"], "author": "Daedalus1138"}
{"word": [" Vrrrooomm!"], "author": "sloganvirst"}
{"word": ["dragrace"], "author": "Niggles"}
{"word": ["Deathrace"], "author": "Lou"}
{"word": ["Movie"], "author": "Stuff"}
{"word": ["Dr.Strangelove"], "author": "FAUXmadison"}
{"word": [" Dr. Suess (or however you spell that)"], "author": "sloganvirst"}
{"word": [" Ham"], "author": "Daedalus1138"}
{"word": ["Birmingham"], "author": "Nel-A"}
{"word": ["Brummie"], "author": "TrollumThinks"}
{"word": ["Yampy"], "author": "Lou"}
{"word": [" Yankee."], "author": "sloganvirst"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Curse"], "author": "KOCollins"}
{"word": ["Bless"], "author": "TrollumThinks"}
{"word": ["Protect"], "author": "Stuff"}
{"word": ["Fireball"], "author": "4gamin"}
{"word": ["Inferno"], "author": "Lou"}
{"word": [" Eeofol"], "author": "Arianus.836"}
{"word": [" Paris"], "author": "sloganvirst"}
{"word": [" What?"], "author": "Arianus.836"}
{"word": [" Why?"], "author": "sloganvirst"}
{"word": [" When?"], "author": "Daedalus1138"}
{"word": [" Where?"], "author": "lightnica"}
{"word": [" How?"], "author": "saldite"}
{"word": [" Who?"], "author": "Daedalus1138"}
{"word": [" Dr?"], "author": "lightnica"}
{"word": ["Nurse?"], "author": "Niggles"}
{"word": ["Hospital"], "author": "ExecB5"}
{"word": ["Theme. ", " ", " * I really have no choice, it was the first word that came to mind, even though I have never played the game nor do I know anything whatsoever about it."], "author": "tarangwydion"}
{"word": ["Monoword."], "author": "lightnica"}
{"word": ["monotone"], "author": "TrollumThinks"}
{"word": ["Monorail"], "author": "4gamin"}
{"word": ["Mononucleosis"], "author": "Lou"}
{"word": ["Monocular"], "author": "4gamin"}
{"word": [" Binoculars."], "author": "sloganvirst"}
{"word": ["Monocular"], "author": "lightnica"}
{"word": ["Again? ", " ", " :-D"], "author": "tarangwydion"}
{"word": ["Again."], "author": "lightnica"}
{"word": ["repeat"], "author": "TrollumThinks"}
{"word": ["Again."], "author": "lightnica"}
{"word": ["Rinse"], "author": "Stuff"}
{"word": ["Combo"], "author": "Fever_Discordia"}
{"word": ["Meal."], "author": "tarangwydion"}
{"word": [" TODO"], "author": "lightnica"}
{"word": [], "author": "lightnica"}
{"word": ["Complete"], "author": "Lou"}
{"word": ["level"], "author": "TrollumThinks"}
{"word": ["Flat"], "author": "Nel-A"}
{"word": ["Mountainous"], "author": "muttly13"}
{"word": ["Rockys"], "author": "Arianus.836"}
{"word": [" Sharp"], "author": "jefequeso"}
{"word": [" Sharpies"], "author": "lightnica"}
{"word": [" Chalkboard (not right, I know, but it's what first came to mind :P)"], "author": "jefequeso"}
{"word": [" Permanent"], "author": "lightnica"}
{"word": [" marker"], "author": "jefequeso"}
{"word": ["Signal"], "author": "Nel-A"}
{"word": ["Sigil"], "author": "lightnica"}
{"word": ["code"], "author": "akwater"}
{"word": ["Red."], "author": "tarangwydion"}
{"word": ["Blue"], "author": "lightnica"}
{"word": [" ray"], "author": "jefequeso"}
{"word": [" Dead."], "author": "lightnica"}
{"word": [" ALARM ALARM INSERTING EDITORIALS INTO THE GAME >_< ", " ", " ", " OT: Island"], "author": "jefequeso"}
{"word": [" So?"], "author": "lightnica"}
{"word": ["Confused. ", " ", " * confused on whether to reply for 'Island' or for 'So?' :-D"], "author": "tarangwydion"}
{"word": [" :3"], "author": "jefequeso"}
{"word": ["Emoticon"], "author": "ExecB5"}
{"word": ["Smiley"], "author": "Daedalus1138"}
{"word": [" Suffering"], "author": "Arianus.836"}
{"word": ["succotash"], "author": "Fever_Discordia"}
{"word": [" daffy"], "author": "jefequeso"}
{"word": ["Duck ", " ", " * well, what else other than duck?"], "author": "tarangwydion"}
{"word": ["Howard"], "author": "Lou"}
{"word": ["Rajesh"], "author": "spindown"}
{"word": [" Radish."], "author": "sloganvirst"}
{"word": [" bitter"], "author": "jefequeso"}
{"word": ["Grok"], "author": "jdyer1012"}
{"word": ["Ork"], "author": "Daedalus1138"}
{"word": ["Fork"], "author": "lightnica"}
{"word": ["Pitch."], "author": "tarangwydion"}
{"word": ["black"], "author": "TrollumThinks"}
{"word": ["Orpheus"], "author": "Lou"}
{"word": [" Helius."], "author": "sloganvirst"}
{"word": ["Sol"], "author": "Fever_Discordia"}
{"word": ["Beer"], "author": "Nel-A"}
{"word": ["Beard."], "author": "lightnica"}
{"word": [], "author": "Stuff"}
{"word": ["Black"], "author": "Fever_Discordia"}
{"word": ["Cat"], "author": "KOCollins"}
{"word": ["scan"], "author": "Fever_Discordia"}
{"word": ["Disk."], "author": "tarangwydion"}
{"word": [" DOS"], "author": "sloganvirst"}
{"word": ["TOS"], "author": "TrollumThinks"}
{"word": [" Tosser."], "author": "sloganvirst"}
{"word": ["Caber"], "author": "Fever_Discordia"}
{"word": ["Kilt"], "author": "Nel-A"}
{"word": ["Hasselhoff"], "author": "Lou"}
{"word": ["Knight"], "author": "Daedalus1138"}
{"word": ["Arthur"], "author": "Nel-A"}
{"word": ["Dent"], "author": "Fever_Discordia"}
{"word": [" Car."], "author": "sloganvirst"}
{"word": ["Enzo"], "author": "Nel-A"}
{"word": ["Ferrari"], "author": "Lou"}
{"word": [" Engine."], "author": "sloganvirst"}
{"word": ["Chaos"], "author": "Fever_Discordia"}
{"word": ["Emerald"], "author": "Nel-A"}
{"word": ["City"], "author": "Lou"}
{"word": [" Towers."], "author": "sloganvirst"}
{"word": ["Twin"], "author": "Fever_Discordia"}
{"word": ["Identical."], "author": "tarangwydion"}
{"word": [" samey"], "author": "jefequeso"}
{"word": [" Salmon."], "author": "sloganvirst"}
{"word": ["fish"], "author": "jefequeso"}
{"word": ["Chips."], "author": "tarangwydion"}
{"word": ["Estrada"], "author": "Lou"}
{"word": [" Stratos."], "author": "sloganvirst"}
{"word": ["Stratosphere"], "author": "TrollumThinks"}
{"word": ["Atmosphere"], "author": "KOCollins"}
{"word": ["Atmosfear!"], "author": "Fever_Discordia"}
{"word": ["fiddle sticks"], "author": "Kaliosmasteris"}
{"word": ["Violin"], "author": "Nel-A"}
{"word": [" "], "author": "lightnica"}
{"word": [" Free."], "author": "sloganvirst"}
{"word": [" Idealism"], "author": "ShmenonPie"}
{"word": ["Idea"], "author": "ExecB5"}
{"word": [" Lightbulb."], "author": "sloganvirst"}
{"word": ["."], "author": "tarangwydion"}
{"word": [" One."], "author": "lightnica"}
{"word": ["Uno"], "author": "TrollumThinks"}
{"word": ["Uru"], "author": "Stuff"}
{"word": ["Myst"], "author": "Lou"}
{"word": ["Real ", " "], "author": "lightnica"}
{"word": ["Madrid"], "author": "Nel-A"}
{"word": ["Spain"], "author": "ExecB5"}
{"word": [" Spanish."], "author": "sloganvirst"}
{"word": ["Inquisition"], "author": "Nel-A"}
{"word": ["History"], "author": "ExecB5"}
{"word": [" Tome."], "author": "sloganvirst"}
{"word": [" "], "author": "lightnica"}
{"word": ["on!"], "author": "TrollumThinks"}
{"word": [" Oni"], "author": "sloganvirst"}
{"word": ["onimusha"], "author": "Kaliosmasteris"}
{"word": ["Capcom"], "author": "KOCollins"}
{"word": [" MegamanX"], "author": "sloganvirst"}
{"word": ["X-men"], "author": "lightnica"}
{"word": ["X-Factor."], "author": "tarangwydion"}
{"word": [" Simon and Garfunkel (spelling?)"], "author": "jefequeso"}
{"word": [" Rules"], "author": "lightnica"}
{"word": ["Formula"], "author": "Nel-A"}
{"word": ["Alchemy"], "author": "KOCollins"}
{"word": [" oops. My bad."], "author": "jefequeso"}
{"word": [" Again!"], "author": "sloganvirst"}
{"word": [" Alchemy"], "author": "KOCollins"}
{"word": [], "author": "Stuff"}
{"word": [" PvZ."], "author": "sloganvirst"}
{"word": ["Apocalypse"], "author": "Fever_Discordia"}
{"word": ["Horsemen"], "author": "Niggles"}
{"word": ["Abandonia. ", " ", " * because there is an admin named The Fifth Horseman there."], "author": "tarangwydion"}
{"word": ["Reloaded"], "author": "Nel-A"}
{"word": ["Metalica"], "author": "Lou"}
{"word": [" Rammstein."], "author": "sloganvirst"}
{"word": ["Television"], "author": "Fever_Discordia"}
{"word": ["Radio"], "author": "Nel-A"}
{"word": ["Active"], "author": "Fever_Discordia"}
{"word": ["Passive."], "author": "tarangwydion"}
{"word": ["Grammar"], "author": "ExecB5"}
{"word": [" English."], "author": "sloganvirst"}
{"word": ["Johnny"], "author": "TrollumThinks"}
{"word": ["prophylactic"], "author": "Fever_Discordia"}
{"word": ["Vaccination"], "author": "Zenphic"}
{"word": ["Disease"], "author": "Nel-A"}
{"word": ["Death"], "author": "Stuff"}
{"word": ["Adder"], "author": "Fever_Discordia"}
{"word": [" Black ", " ", " (from Black Adder)"], "author": "sloganvirst"}
{"word": ["Books"], "author": "Fever_Discordia"}
{"word": ["Writing."], "author": "ExecB5"}
{"word": ["Sacred"], "author": "Lou"}
{"word": ["Texts"], "author": "KOCollins"}
{"word": ["Messaging"], "author": "Zenphic"}
{"word": ["massaging ", " ", " (as my students would pronounce it)"], "author": "TrollumThinks"}
{"word": [" Bench."], "author": "sloganvirst"}
{"word": ["Park"], "author": "Nel-A"}
{"word": ["Central"], "author": "ExecB5"}
{"word": ["Grand"], "author": "Fever_Discordia"}
{"word": ["Theft"], "author": "Juggernaught222"}
{"word": [" Police."], "author": "sloganvirst"}
{"word": ["Siren"], "author": "Juggernaught222"}
{"word": ["Ambulance"], "author": "ExecB5"}
{"word": ["Emergency"], "author": "Juggernaught222"}
{"word": ["Hospital"], "author": "Zenphic"}
{"word": ["Patient ", " ", " (This'll probably be my last one for a while lol.)"], "author": "Juggernaught222"}
{"word": ["Virtue."], "author": "tarangwydion"}
{"word": ["vice"], "author": "TrollumThinks"}
{"word": ["City"], "author": "ExecB5"}
{"word": ["."], "author": "Rohan15"}
{"word": ["Pack. ", " ", " (curses, couldn't resist...)"], "author": "Juggernaught222"}
{"word": ["rations"], "author": "Niggles"}
{"word": [" Chips."], "author": "sloganvirst"}
{"word": ["Fish"], "author": "Zenphic"}
{"word": ["Surrealism"], "author": "Fever_Discordia"}
{"word": [" Imagination."], "author": "sloganvirst"}
{"word": ["Land. ", " ", " (South Park!)"], "author": "Nel-A"}
{"word": ["Earth ", " ", " (lol @ Imagination Land. That episode was absolutely insane!)"], "author": "Zenphic"}
{"word": ["Space."], "author": "Deadman619"}
{"word": ["Pirates"], "author": "ExecB5"}
{"word": ["Boats"], "author": "Juggernaught222"}
{"word": ["cruise"], "author": "Niggles"}
{"word": [" Tom."], "author": "sloganvirst"}
{"word": ["Sawyer."], "author": "tarangwydion"}
{"word": ["Manipulative."], "author": "Juggernaught222"}
{"word": ["Children ;-)"], "author": "Lou"}
{"word": ["Offspring"], "author": "TrollumThinks"}
{"word": [" Band"], "author": "sloganvirst"}
{"word": ["Rubber."], "author": "tarangwydion"}
{"word": ["Tire."], "author": "drevo2"}
{"word": ["Slow"], "author": "Nel-A"}
{"word": ["Motion"], "author": "ExecB5"}
{"word": ["Sickness"], "author": "Lou"}
{"word": [" Ailment."], "author": "sloganvirst"}
{"word": ["Syndrome."], "author": "tarangwydion"}
{"word": ["Symptoms"], "author": "almabrds"}
{"word": ["Disease."], "author": "ExecB5"}
{"word": ["outbreak"], "author": "TrollumThinks"}
{"word": [". ", " ", " * Although technically the virus is not Ebola, just similar to it."], "author": "tarangwydion"}
{"word": ["Incubation"], "author": "Stuff"}
{"word": [" Incubator."], "author": "sloganvirst"}
{"word": ["Incubus"], "author": "Nel-A"}
{"word": ["Lilith."], "author": "tarangwydion"}
{"word": ["wut"], "author": "jefequeso"}
{"word": [" What?"], "author": "sloganvirst"}
{"word": [" Now?"], "author": "jefequeso"}
{"word": [" Now!"], "author": "lightnica"}
{"word": [" Never!"], "author": "jefequeso"}
{"word": [" Why....???"], "author": "tarangwydion"}
{"word": ["...there?"], "author": "ExecB5"}
{"word": ["their?"], "author": "TrollumThinks"}
{"word": ["!!!"], "author": "Rohan15"}
{"word": [" Thor?"], "author": "sloganvirst"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Mythology"], "author": "Niggles"}
{"word": ["Greek"], "author": "Nel-A"}
{"word": ["titanquest"], "author": "CyPhErIoN"}
{"word": ["Clash"], "author": "drevo2"}
{"word": ["Kasbah ", " ", " (as in Rock The...)"], "author": "Fever_Discordia"}
{"word": [" ", "?"], "author": "Rohan15"}
{"word": ["Batman"], "author": "almabrds"}
{"word": ["Joker."], "author": "tarangwydion"}
{"word": [" Jester."], "author": "sloganvirst"}
{"word": ["FOOL"], "author": "TrollumThinks"}
{"word": ["Gold."], "author": "tarangwydion"}
{"word": ["Rush"], "author": "KOCollins"}
{"word": [], "author": "Stuff"}
{"word": ["Waist"], "author": "TrollumThinks"}
{"word": [" Belt."], "author": "sloganvirst"}
{"word": ["Leather"], "author": "ExecB5"}
{"word": ["Tanning"], "author": "drevo2"}
{"word": ["Tanner."], "author": "tarangwydion"}
{"word": ["Tummy"], "author": "ExecB5"}
{"word": ["Tuck"], "author": "Lou"}
{"word": [" Tucker"], "author": "sloganvirst"}
{"word": ["Guitar"], "author": "almabrds"}
{"word": ["."], "author": "tarangwydion"}
{"word": [" Red. ", " (Red vs Blue)"], "author": "sloganvirst"}
{"word": ["Ribbon ", " ", " "], "author": "ExecB5"}
{"word": ["Yellow"], "author": "muttly13"}
{"word": ["Orange"], "author": "almabrds"}
{"word": ["assailant"], "author": "drevo2"}
{"word": ["unsub"], "author": "Lou"}
{"word": [" Suburb"], "author": "sloganvirst"}
{"word": ["City"], "author": "Nel-A"}
{"word": ["Cesspit... :-p"], "author": "KOCollins"}
{"word": ["Wallow"], "author": "Niggles"}
{"word": [" Willow."], "author": "sloganvirst"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Bread ", " ", " *cause good grandmas make good bread"], "author": "ExecB5"}
{"word": [". ", " ", " * was one of my favorite childhood songs from Bread."], "author": "tarangwydion"}
{"word": ["asterisks"], "author": "lightnica"}
{"word": [" Obelisk."], "author": "sloganvirst"}
{"word": ["2001"], "author": "Lou"}
{"word": ["Odyssey."], "author": "Pangaea666"}
{"word": ["Homer"], "author": "liberatorx1"}
{"word": ["Simpson"], "author": "ExecB5"}
{"word": ["Futurama"], "author": "almabrds"}
{"word": ["tomorrow"], "author": "reaver894"}
{"word": ["dentist"], "author": "drevo2"}
{"word": ["ouchie"], "author": "reaver894"}
{"word": ["Lobotomy :P"], "author": "KOCollins"}
{"word": ["Dodge"], "author": "Lou"}
{"word": ["Charger ", " ", " "], "author": "Nel-A"}
{"word": ["Solar"], "author": "Stuff"}
{"word": [" Power."], "author": "sloganvirst"}
{"word": ["Fuel"], "author": "ExecB5"}
{"word": [], "author": "KOCollins"}
{"word": ["Rubbish"], "author": "michaelleung"}
{"word": ["Compactor."], "author": "tarangwydion"}
{"word": [" Cube."], "author": "sloganvirst"}
{"word": ["Borg"], "author": "Lou"}
{"word": ["Cyborg"], "author": "ExecB5"}
{"word": ["Robo Cop"], "author": "nineinchnails90"}
{"word": ["Memories"], "author": "Nel-A"}
{"word": ["Supressed"], "author": "nineinchnails90"}
{"word": ["Annihilate"], "author": "Stuff"}
{"word": ["Totally"], "author": "drevo2"}
{"word": ["Cool."], "author": "tarangwydion"}
{"word": [" Awsome."], "author": "sloganvirst"}
{"word": ["Fantastic"], "author": "Niggles"}
{"word": ["Four"], "author": "ExecB5"}
{"word": ["Five"], "author": "lightnica"}
{"word": ["Fingers"], "author": "BlazeKING"}
{"word": ["Butts"], "author": "michaelleung"}
{"word": ["Bum"], "author": "nineinchnails90"}
{"word": [" Slums."], "author": "sloganvirst"}
{"word": ["Shanty."], "author": "tarangwydion"}
{"word": ["town"], "author": "Niggles"}
{"word": ["State"], "author": "almabrds"}
{"word": ["Province."], "author": "tarangwydion"}
{"word": ["Dynasty"], "author": "nineinchnails90"}
{"word": ["China"], "author": "Juggernaught222"}
{"word": [" ChingChangChong."], "author": "sloganvirst"}
{"word": [" lol ", " ", " chinese"], "author": "ExecB5"}
{"word": [" Industrial. ", " (How'd you guess?)"], "author": "sloganvirst"}
{"word": ["Waste"], "author": "Lou"}
{"word": ["Nuclear"], "author": "Juggernaught222"}
{"word": ["Fallout"], "author": "nineinchnails90"}
{"word": ["Wasteland"], "author": "michaelleung"}
{"word": ["Hell"], "author": "nineinchnails90"}
{"word": ["Boss."], "author": "tarangwydion"}
{"word": ["horrible"], "author": "Niggles"}
{"word": ["Onions"], "author": "nineinchnails90"}
{"word": ["Rings"], "author": "ExecB5"}
{"word": ["Diamond."], "author": "tarangwydion"}
{"word": ["Topaz"], "author": "almabrds"}
{"word": [" Gem."], "author": "sloganvirst"}
{"word": ["(are) forever"], "author": "nineinchnails90"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Thyme"], "author": "nineinchnails90"}
{"word": ["herb"], "author": "Niggles"}
{"word": ["Plants."], "author": "ExecB5"}
{"word": ["Mint"], "author": "Juggernaught222"}
{"word": ["Pepper"], "author": "Lou"}
{"word": ["Sergeant"], "author": "Nel-A"}
{"word": ["British"], "author": "drevo2"}
{"word": ["Lord"], "author": "agogfan"}
{"word": ["Religion"], "author": "michaelleung"}
{"word": ["Bad"], "author": "Lou"}
{"word": ["Attitude"], "author": "agogfan"}
{"word": ["Longitude"], "author": "drevo2"}
{"word": ["Sextant."], "author": "tarangwydion"}
{"word": ["Sex"], "author": "ExecB5"}
{"word": ["Pistols"], "author": "Lou"}
{"word": ["Vicious"], "author": "Daedalus1138"}
{"word": [" Monster. ", " ", " ", " I am at a loss trying to understand how sex relates to sextant :-)"], "author": "tarangwydion"}
{"word": [" Cookie."], "author": "sloganvirst"}
{"word": ["Monster"], "author": "Lou"}
{"word": [], "author": "Stuff"}
{"word": ["Johnny ", " ", " ", "/ ", " ", " ", " ", " ", " SEXtant =P"], "author": "ExecB5"}
{"word": ["Bravo"], "author": "GoJays2025"}
{"word": [" Applaud."], "author": "sloganvirst"}
{"word": ["Appreciation"], "author": "Nel-A"}
{"word": ["Dinner"], "author": "Daedalus1138"}
{"word": [" Pudding."], "author": "sloganvirst"}
{"word": ["Christmas"], "author": "drevo2"}
{"word": ["Elf"], "author": "Daedalus1138"}
{"word": ["Dwarf"], "author": "almabrds"}
{"word": ["Fortress"], "author": "KOCollins"}
{"word": ["Archer"], "author": "icepowdah"}
{"word": ["Arrow"], "author": "almabrds"}
{"word": [" Spear."], "author": "sloganvirst"}
{"word": ["Pointy"], "author": "Juggernaught222"}
{"word": ["Ears"], "author": "Nel-A"}
{"word": [" Legolas."], "author": "sloganvirst"}
{"word": ["Arod"], "author": "Lou"}
{"word": ["(a) rod"], "author": "nineinchnails90"}
{"word": ["cone"], "author": "jefequeso"}
{"word": ["Ice cream"], "author": "almabrds"}
{"word": ["sandwich"], "author": "mitac"}
{"word": ["Ham."], "author": "tarangwydion"}
{"word": ["Blood"], "author": "almabrds"}
{"word": ["Period"], "author": "nineinchnails90"}
{"word": ["Tampons"], "author": "ExecB5"}
{"word": ["Menstrual"], "author": "nineinchnails90"}
{"word": ["Cycle."], "author": "tarangwydion"}
{"word": ["Bicycle"], "author": "almabrds"}
{"word": ["Tricycle"], "author": "nineinchnails90"}
{"word": ["Monocycle"], "author": "almabrds"}
{"word": ["Cyclist"], "author": "nineinchnails90"}
{"word": [" 10pts"], "author": "sloganvirst"}
{"word": [" (for) Griffondor"], "author": "nineinchnails90"}
{"word": ["vague"], "author": "Niggles"}
{"word": ["politicians"], "author": "Dzsono"}
{"word": ["Honesty"], "author": "spindown"}
{"word": ["Oxymoron"], "author": "KOCollins"}
{"word": ["Bitter-Sweet"], "author": "Stuff"}
{"word": [], "author": "TrollumThinks"}
{"word": ["Twisted-Metal"], "author": "nineinchnails90"}
{"word": ["Sister"], "author": "Lou"}
{"word": ["Brother"], "author": "Nel-A"}
{"word": ["Mario (Bros.)"], "author": "almabrds"}
{"word": ["Shrooms."], "author": "Runehamster"}
{"word": ["Poisonous"], "author": "almabrds"}
{"word": ["Snake"], "author": "spindown"}
{"word": ["gear"], "author": "Region"}
{"word": ["shift"], "author": "TrollumThinks"}
{"word": ["Tectonic"], "author": "Lou"}
{"word": ["Plate"], "author": "mitac"}
{"word": ["Food"], "author": "Daedalus1138"}
{"word": ["Pizza"], "author": "ExecB5"}
{"word": [" Takeaway."], "author": "sloganvirst"}
{"word": ["Indian"], "author": "michaelleung"}
{"word": ["yuck"], "author": "Niggles"}
{"word": [" Gross."], "author": "sloganvirst"}
{"word": ["Fascinating."], "author": "SELF"}
{"word": [" Interesting. ", " ", " /How does that relate to gross?/"], "author": "sloganvirst"}
{"word": ["Curious"], "author": "ExecB5"}
{"word": [" snooping"], "author": "Arianus.836"}
{"word": ["Detective"], "author": "mitac"}
{"word": [], "author": "Stuff"}
{"word": ["Grace"], "author": "Lou"}
{"word": ["Fall ", " ", " ", " Just me being weird, like how I think things with exoskeletons make far better pets than mammals."], "author": "SELF"}
{"word": [], "author": "almabrds"}
{"word": [" Amazing. ", " ", " (From Amazing Grace)"], "author": "sloganvirst"}
{"word": ["maze"], "author": "TrollumThinks"}
{"word": ["shrubbery"], "author": "Dzsono"}
{"word": ["knights"], "author": "Detlik"}
{"word": [], "author": "Stuff"}
{"word": ["(Holy) Grail"], "author": "almabrds"}
{"word": [], "author": "Arianus.836"}
{"word": ["Black"], "author": "almabrds"}
{"word": ["Dark"], "author": "Nel-A"}
{"word": [" Evil (Me)"], "author": "sloganvirst"}
{"word": ["Devil"], "author": "ExecB5"}
{"word": ["Angel"], "author": "almabrds"}
{"word": ["spiritual"], "author": "mitac"}
{"word": [" Virtual."], "author": "sloganvirst"}
{"word": ["Reality"], "author": "Daedalus1138"}
{"word": ["Realty"], "author": "TrollumThinks"}
{"word": ["mortgage"], "author": "Dzsono"}
{"word": ["House"], "author": "Zenphic"}
{"word": ["Madness ", " ", " (", ")"], "author": "Nel-A"}
{"word": ["Method"], "author": "4gamin"}
{"word": ["Science"], "author": "Daedalus1138"}
{"word": ["Technology"], "author": "ExecB5"}
{"word": [" Computers"], "author": "sloganvirst"}
{"word": ["Tablet"], "author": "almabrds"}
{"word": ["Hammurabi"], "author": "Lou"}
{"word": ["Ashurbanipal"], "author": "Daedalus1138"}
{"word": [" Japanese."], "author": "sloganvirst"}
{"word": ["Samurai"], "author": "TrollumThinks"}
{"word": ["Katana"], "author": "Stuff"}
{"word": ["Kunai"], "author": "almabrds"}
{"word": [" Moauri."], "author": "sloganvirst"}
{"word": ["Culture"], "author": "ExecB5"}
{"word": ["Warrior"], "author": "Lou"}
{"word": [" Armor."], "author": "sloganvirst"}
{"word": ["Protection"], "author": "almabrds"}
{"word": ["Codpiece"], "author": "KOCollins"}
{"word": [" Codfish."], "author": "sloganvirst"}
{"word": ["Captain"], "author": "Crono908"}
{"word": [" Hook. ", " ", " I take it you have seen that as well?"], "author": "sloganvirst"}
{"word": ["Line"], "author": "TrollumThinks"}
{"word": ["Sinker"], "author": "Lou"}
{"word": [" Book"], "author": "sloganvirst"}
{"word": ["Library"], "author": "Nel-A"}
{"word": ["Worm"], "author": "icepowdah"}
{"word": [" "], "author": "almabrds"}
{"word": ["Cow ", " ", " ", "/"], "author": "ExecB5"}
{"word": ["Bull"], "author": "TrollumThinks"}
{"word": [" "], "author": "almabrds"}
{"word": ["Molyneux"], "author": "Daedalus1138"}
{"word": ["Peter"], "author": "Lou"}
{"word": ["James"], "author": "Daedalus1138"}
{"word": ["King"], "author": "Lou"}
{"word": [" Arthur"], "author": "almabrds"}
{"word": ["Legend"], "author": "Nel-A"}
{"word": ["Camelot"], "author": "Stuff"}
{"word": ["Spamalot"], "author": "TrollumThinks"}
{"word": [" Spambot"], "author": "almabrds"}
{"word": ["Robot"], "author": "ExecB5"}
{"word": [" Johnny 5"], "author": "jefequeso"}
{"word": [" ..."], "author": "almabrds"}
{"word": ["Rocket"], "author": "ExecB5"}
{"word": [" Man"], "author": "Arianus.836"}
{"word": ["Mortal"], "author": "Nel-A"}
{"word": [" Immortal"], "author": "Arianus.836"}
{"word": [" Hogan"], "author": "Nel-A"}
{"word": [" Man-Ape"], "author": "Arianus.836"}
{"word": [" Avengers"], "author": "Nel-A"}
{"word": ["Captain"], "author": "Juggernaught222"}
{"word": ["America"], "author": "Zenphic"}
{"word": [], "author": "Lou"}
{"word": ["Ace"], "author": "icepowdah"}
{"word": ["Hardware"], "author": "Stuff"}
{"word": ["Software"], "author": "Nel-A"}
{"word": ["Abandonware"], "author": "ExecB5"}
{"word": ["Malware"], "author": "Juggernaught222"}
{"word": ["Spyware"], "author": "Zenphic"}
{"word": ["Windows. ", " ", " OT: aahhh... it's good to be back after being absent from GOG forum for about 10 days..."], "author": "tarangwydion"}
{"word": ["LInux. ", " ", " And I totally agree =D"], "author": "Juggernaught222"}
{"word": ["cli"], "author": "Anoniempje"}
{"word": ["Cheat ", " ", " * as in CLI Cheat Sheet."], "author": "tarangwydion"}
{"word": ["DR.Hax (sorry.)"], "author": "l0rdtr3k"}
{"word": ["Who"], "author": "Niggles"}
{"word": ["Doctor (who)"], "author": "almabrds"}
{"word": ["Doom."], "author": "tarangwydion"}
{"word": ["Imp"], "author": "Ivory&Gold"}
{"word": ["Castlevania"], "author": "ExecB5"}
{"word": [" "], "author": "almabrds"}
{"word": ["Harryhausen"], "author": "Lou"}
{"word": ["producer"], "author": "mitac"}
{"word": ["produce"], "author": "TrollumThinks"}
{"word": ["Output."], "author": "tarangwydion"}
{"word": ["Input"], "author": "ExecB5"}
{"word": ["Data"], "author": "Stuff"}
{"word": ["Lore"], "author": "Arianus.836"}
{"word": ["Lands."], "author": "tarangwydion"}
{"word": ["Kingdoms"], "author": "darknath"}
{"word": ["Castle"], "author": "almabrds"}
{"word": ["Hamlet"], "author": "Lou"}
{"word": ["Macbeth"], "author": "KOCollins"}
{"word": ["Scottish"], "author": "TrollumThinks"}
{"word": ["Kilt"], "author": "ExecB5"}
{"word": ["Man"], "author": "Juggernaught222"}
{"word": ["Penis."], "author": "Anoniempje"}
{"word": ["Dick (insult)"], "author": "almabrds"}
{"word": ["Steele"], "author": "Verwandlung"}
{"word": ["Steal"], "author": "Nel-A"}
{"word": ["Thief: The Dark Project"], "author": "Bardehvalen"}
{"word": ["Game"], "author": "ExecB5"}
{"word": ["addicted"], "author": "CyPhErIoN"}
{"word": ["smoke"], "author": "mitac"}
{"word": ["Mortal (Kombat)"], "author": "ExecB5"}
{"word": ["Fatality"], "author": "almabrds"}
{"word": ["gory"], "author": "TrollumThinks"}
{"word": ["bloodshed"], "author": "Lou"}
{"word": ["period"], "author": "Anoniempje"}
{"word": ["time"], "author": "TrollumThinks"}
{"word": ["Machine."], "author": "tarangwydion"}
{"word": [" Vehicle"], "author": "sloganvirst"}
{"word": ["Helicopter"], "author": "Nel-A"}
{"word": ["Fan"], "author": "ExecB5"}
{"word": ["Fanboy"], "author": "almabrds"}
{"word": ["Apple? ", " ", " :-D"], "author": "tarangwydion"}
{"word": ["Orange."], "author": "bsu"}
{"word": ["colour"], "author": "TrollumThinks"}
{"word": ["Green"], "author": "ExecB5"}
{"word": ["Yellow"], "author": "almabrds"}
{"word": ["Coldplay"], "author": "Ivory&Gold"}
{"word": ["Dull"], "author": "Nel-A"}
{"word": ["Shiny"], "author": "Stuff"}
{"word": [" Steel."], "author": "sloganvirst"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Touch"], "author": "Lou"}
{"word": ["Down"], "author": "ExecB5"}
{"word": [], "author": "Lou"}
{"word": ["Music"], "author": "almabrds"}
{"word": ["Noise"], "author": "Psyringe"}
{"word": ["Jackhammer"], "author": "spindown"}
{"word": [" Sledgehammer"], "author": "sloganvirst"}
{"word": ["Hammer"], "author": "ExecB5"}
{"word": ["Forge"], "author": "Stuff"}
{"word": [" Smith"], "author": "Arianus.836"}
{"word": ["James. ", " ", " * as in \"James St. John Smith\" (pronounced \"sin-jin-smythe\"), the alias used by James Bond in that A View To A Kill movie."], "author": "tarangwydion"}
{"word": ["Town ", " (as in Jamestown the game)"], "author": "Niggles"}
{"word": ["Square"], "author": "Lou"}
{"word": ["Circle"], "author": "Stuff"}
{"word": ["ring"], "author": "TrollumThinks"}
{"word": ["horror"], "author": "moomphas"}
{"word": [" Spooky"], "author": "Arianus.836"}
{"word": ["fear"], "author": "ExecB5"}
{"word": [" F3AR"], "author": "Arianus.836"}
{"word": ["FPS."], "author": "tarangwydion"}
{"word": ["Shoot"], "author": "Juggernaught222"}
{"word": [" BANG!!!"], "author": "almabrds"}
{"word": ["loud"], "author": "TrollumThinks"}
{"word": [" Noise."], "author": "sloganvirst"}
{"word": ["party"], "author": "moomphas"}
{"word": ["house"], "author": "CyPhErIoN"}
{"word": ["Laurie"], "author": "Lou"}
{"word": ["Actor"], "author": "ExecB5"}
{"word": [" Unreal (As in, Actor in UnrealEd modding)"], "author": "sloganvirst"}
{"word": [], "author": "almabrds"}
{"word": ["Epic ", " ", " ", "/"], "author": "ExecB5"}
{"word": ["Poem."], "author": "sauvignon1"}
{"word": ["shakespeare"], "author": "CyPhErIoN"}
{"word": ["Play"], "author": "Stuff"}
{"word": ["theatre"], "author": "moomphas"}
{"word": ["Thespian"], "author": "Nel-A"}
{"word": ["tragedy."], "author": "sauvignon1"}
{"word": ["Greece"], "author": "ExecB5"}
{"word": ["bankrupt?"], "author": "reaver894"}
{"word": ["homeless"], "author": "SebasM"}
{"word": ["vulnerable"], "author": "SlappyBag"}
{"word": ["cute."], "author": "sauvignon1"}
{"word": ["kitty"], "author": "Lou"}
{"word": ["dog"], "author": "Zenphic"}
{"word": ["bone"], "author": "TrollumThinks"}
{"word": ["her ;)"], "author": "Niggles"}
{"word": ["coffeetable."], "author": "Antimateria"}
{"word": ["Coffee"], "author": "Stuff"}
{"word": ["beans"], "author": "moomphas"}
{"word": [" Peas"], "author": "Arianus.836"}
{"word": [], "author": "almabrds"}
{"word": [" Biscuits (Diet Biscuits for the Cat)"], "author": "sloganvirst"}
{"word": ["waffle"], "author": "SlappyBag"}
{"word": ["speech"], "author": "TrollumThinks"}
{"word": ["impediment"], "author": "Lou"}
{"word": [" Forceful."], "author": "sloganvirst"}
{"word": ["Aggressive"], "author": "Stuff"}
{"word": ["Passive"], "author": "Ivory&Gold"}
{"word": ["Thoughtful"], "author": "Nel-A"}
{"word": [" arrogant"], "author": "Arianus.836"}
{"word": ["lout"], "author": "moomphas"}
{"word": ["format c:"], "author": "mrmarioanonym"}
{"word": [" Lynette ", " ", " Edit: Ninja'd?"], "author": "almabrds"}
{"word": [], "author": "Stuff"}
{"word": ["clean"], "author": "Ivory&Gold"}
{"word": [" Obsessive"], "author": "Arianus.836"}
{"word": ["voyeur :D"], "author": "moomphas"}
{"word": ["French"], "author": "ExecB5"}
{"word": ["toast"], "author": "jefequeso"}
{"word": [" Toaster"], "author": "almabrds"}
{"word": ["Brave"], "author": "Lou"}
{"word": ["Chicken"], "author": "TrollumThinks"}
{"word": ["Egg"], "author": "almabrds"}
{"word": ["sperm"], "author": "Niggles"}
{"word": ["Whale"], "author": "Stuff"}
{"word": ["Ocean"], "author": "almabrds"}
{"word": ["Atlantic"], "author": "Lou"}
{"word": ["treasure"], "author": "moomphas"}
{"word": ["trove"], "author": "TrollumThinks"}
{"word": ["Trophy."], "author": "tarangwydion"}
{"word": ["Achievement"], "author": "ExecB5"}
{"word": ["satisfaction"], "author": "moomphas"}
{"word": ["Happy"], "author": "Stuff"}
{"word": ["Drugs"], "author": "Detlik"}
{"word": ["Heroin"], "author": "almabrds"}
{"word": ["wonder woman"], "author": "l0rdtr3k"}
{"word": [" Seven. ", " ", " * It's a one-word game, so I ignore \"woman\" and concentrate on your first word \"wonder\"."], "author": "tarangwydion"}
{"word": ["Dwarves"], "author": "Lou"}
{"word": ["axe"], "author": "TrollumThinks"}
{"word": ["Gold"], "author": "icepowdah"}
{"word": ["Mine"], "author": "Stuff"}
{"word": ["Canary"], "author": "4gamin"}
{"word": ["Bird"], "author": "jefequeso"}
{"word": ["falcon"], "author": "l0rdtr3k"}
{"word": ["Atlanta"], "author": "Lou"}
{"word": ["Atlantis"], "author": "Detlik"}
{"word": ["mysterious"], "author": "SlappyBag"}
{"word": ["Myst"], "author": "moomphas"}
{"word": ["Cyst"], "author": "Nel-A"}
{"word": ["brain"], "author": "Niggles"}
{"word": ["Mind"], "author": "Zenphic"}
{"word": ["Freak"], "author": "Lou"}
{"word": ["Out"], "author": "TrollumThinks"}
{"word": ["Doors"], "author": "BlackenedZoid"}
{"word": ["Barmitzvah."], "author": "sauvignon1"}
{"word": ["Ritual"], "author": "Stuff"}
{"word": ["Religion"], "author": "ExecB5"}
{"word": ["Spirituality"], "author": "Zenphic"}
{"word": ["Superstition"], "author": "4gamin"}
{"word": ["Voodoo"], "author": "almabrds"}
{"word": ["Hendrix"], "author": "Nel-A"}
{"word": ["Woodstock."], "author": "sauvignon1"}
{"word": ["music"], "author": "l0rdtr3k"}
{"word": ["Stones"], "author": "Dischord"}
{"word": ["Throwing."], "author": "tarangwydion"}
{"word": ["Rocks"], "author": "almabrds"}
{"word": ["Aerosmith"], "author": "Lou"}
{"word": ["led zepplin"], "author": "SlappyBag"}
{"word": [" Bulb. ", " ", " * It's a one-word game, so I ignore \"Zeppelin\" and concentrate on your first word \"Led\", which I pretend to be ", ", and thus the bulb association."], "author": "tarangwydion"}
{"word": ["pear"], "author": "moomphas"}
{"word": ["Apple"], "author": "Stuff"}
{"word": ["Jobs"], "author": "Nel-A"}
{"word": ["economy"], "author": "SlappyBag"}
{"word": ["Sucks"], "author": "Argentum42"}
{"word": ["Suction. ", " ", " * was thinking to put in \"Windows\" but it is way too early in the morning here to bash it :-P"], "author": "tarangwydion"}
{"word": ["vacuum"], "author": "SlappyBag"}
{"word": ["Clean"], "author": "Argentum42"}
{"word": ["Dish"], "author": "Detlik"}
{"word": ["Washer."], "author": "tarangwydion"}
{"word": ["Wash"], "author": "TrollumThinks"}
{"word": ["Nuts"], "author": "Gilozard"}
{"word": ["crazy"], "author": "moomphas"}
{"word": ["Lobotomy"], "author": "Dischord"}
{"word": ["Landon"], "author": "Lou"}
{"word": ["Lan (Daniel=Dan. Landon=Lan)"], "author": "almabrds"}
{"word": ["party"], "author": "SlappyBag"}
{"word": ["electro"], "author": "l0rdtr3k"}
{"word": ["Magnetic."], "author": "tarangwydion"}
{"word": ["Charismatic"], "author": "Nel-A"}
{"word": ["Charming"], "author": "Argentum42"}
{"word": ["Prince"], "author": "ExecB5"}
{"word": ["Caspian"], "author": "Lou"}
{"word": ["failure"], "author": "moomphas"}
{"word": [" Bankruptcy"], "author": "sloganvirst"}
{"word": ["Money"], "author": "ExecB5"}
{"word": ["Minerals (Starcraft)"], "author": "almabrds"}
{"word": ["Gemstones"], "author": "Argentum42"}
{"word": ["Obsidian"], "author": "Stuff"}
{"word": ["fallout"], "author": "SlappyBag"}
{"word": ["isle"], "author": "l0rdtr3k"}
{"word": ["Gilligan's"], "author": "Dischord"}
{"word": ["Minnow ", " ", " (EDIT: sorry I fudged up! Go from SlappyBag's sexy please!)"], "author": "Nel-A"}
{"word": ["sexy"], "author": "SlappyBag"}
{"word": ["chick"], "author": "moomphas"}
{"word": ["hen"], "author": "TrollumThinks"}
{"word": ["Farm"], "author": "almabrds"}
{"word": ["cow"], "author": "laneth"}
{"word": [], "author": "Stuff"}
{"word": ["5 ", " ", " "], "author": "ExecB5"}
{"word": ["Hand"], "author": "almabrds"}
{"word": [" Paw."], "author": "sloganvirst"}
{"word": ["Bear"], "author": "Nel-A"}
{"word": ["sexy"], "author": "SlappyBag"}
{"word": ["Opinion"], "author": "Stuff"}
{"word": ["Subjective"], "author": "Dischord"}
{"word": ["metaphor"], "author": "ExecB5"}
{"word": ["word"], "author": "SlappyBag"}
{"word": ["play"], "author": "TrollumThinks"}
{"word": ["Player"], "author": "almabrds"}
{"word": ["gamer"], "author": "moomphas"}
{"word": ["Competitive"], "author": "Nel-A"}
{"word": ["Spirit"], "author": "Lou"}
{"word": ["World"], "author": "Stuff"}
{"word": ["Disaster"], "author": "Psyringe"}
{"word": ["Tragedy"], "author": "Nel-A"}
{"word": [" Shakespeare"], "author": "zomgieee"}
{"word": ["^ Quill"], "author": "4gamin"}
{"word": ["porcupine"], "author": "SlappyBag"}
{"word": ["Hedgehog"], "author": "agogfan"}
{"word": ["supersonic"], "author": "Psyringe"}
{"word": ["confused"], "author": "SlappyBag"}
{"word": ["sleepy"], "author": "l0rdtr3k"}
{"word": ["decaffeinated"], "author": "TrollumThinks"}
{"word": ["Wired"], "author": "Lou"}
{"word": ["magazine"], "author": "SlappyBag"}
{"word": [" Clip."], "author": "sloganvirst"}
{"word": ["hair"], "author": "moomphas"}
{"word": ["bald"], "author": "laneth"}
{"word": [], "author": "almabrds"}
{"word": ["hitman"], "author": "SlappyBag"}
{"word": ["Guns"], "author": "ExecB5"}
{"word": ["Hired"], "author": "Dischord"}
{"word": ["Mercenary"], "author": "InkPanther"}
{"word": ["murderer"], "author": "SlappyBag"}
{"word": ["Jason"], "author": "laneth"}
{"word": ["Argonauts"], "author": "Nel-A"}
{"word": ["Fleece"], "author": "Lou"}
{"word": ["sheep"], "author": "SlappyBag"}
{"word": ["humility"], "author": "l0rdtr3k"}
{"word": [" embarasment."], "author": "sloganvirst"}
{"word": ["disgraced"], "author": "SlappyBag"}
{"word": ["Discredited"], "author": "almabrds"}
{"word": ["deprecate"], "author": "Lou"}
{"word": ["java"], "author": "laneth"}
{"word": ["Tea ", " ", " "], "author": "ExecB5"}
{"word": ["mister"], "author": "SlappyBag"}
{"word": ["Team"], "author": "Nel-A"}
{"word": ["Worms (Team17)"], "author": "moomphas"}
{"word": ["Crows"], "author": "almabrds"}
{"word": ["murder"], "author": "sauvignon1"}
{"word": ["illegal"], "author": "SlappyBag"}
{"word": ["miscreant"], "author": "Leucius"}
{"word": ["Scoundrel."], "author": "tarangwydion"}
{"word": ["dog"], "author": "SlappyBag"}
{"word": ["Snoopy"], "author": "almabrds"}
{"word": ["cancer"], "author": "sauvignon1"}
{"word": ["MetLife"], "author": "Lou"}
{"word": ["insurance"], "author": "laneth"}
{"word": ["health"], "author": "Argentum42"}
{"word": ["Vitamin."], "author": "tarangwydion"}
{"word": [], "author": "Stuff"}
{"word": ["cartoon"], "author": "laneth"}
{"word": ["anime"], "author": "SlappyBag"}
{"word": ["Animation"], "author": "Nel-A"}
{"word": ["Disney"], "author": "Jonni"}
{"word": [" Channel"], "author": "almabrds"}
{"word": ["television"], "author": "moomphas"}
{"word": ["channel"], "author": "l0rdtr3k"}
{"word": ["watch"], "author": "SlappyBag"}
{"word": ["Swatch."], "author": "tarangwydion"}
{"word": ["Schwing!"], "author": "wpegg"}
{"word": ["boner"], "author": "SlappyBag"}
{"word": ["Bone"], "author": "ExecB5"}
{"word": ["Femur"], "author": "Lou"}
{"word": ["leg"], "author": "laneth"}
{"word": ["Kick."], "author": "tarangwydion"}
{"word": ["ban"], "author": "moomphas"}
{"word": ["Banner"], "author": "Nel-A"}
{"word": ["Year"], "author": "Stuff"}
{"word": ["Christmas"], "author": "laneth"}
{"word": ["Birth"], "author": "Nel-A"}
{"word": ["Mother"], "author": "Jonni"}
{"word": ["Earthbound."], "author": "bevinator"}
{"word": ["Alien"], "author": "SlappyBag"}
{"word": ["acid"], "author": "laneth"}
{"word": ["Predator"], "author": "almabrds"}
{"word": ["Hawk"], "author": "l0rdtr3k"}
{"word": ["Animal"], "author": "RafaelLVX"}
{"word": ["Drums"], "author": "4gamin"}
{"word": [" drummer"], "author": "sloganvirst"}
{"word": ["jazz"], "author": "laneth"}
{"word": ["Fourplay"], "author": "Lou"}
{"word": ["SEX"], "author": "SlappyBag"}
{"word": ["Yawn"], "author": "Stuff"}
{"word": ["Reflex"], "author": "Dischord"}
{"word": ["Arcade."], "author": "tarangwydion"}
{"word": ["Penny"], "author": "Lou"}
{"word": ["Pound"], "author": "Nel-A"}
{"word": ["Ounce"], "author": "ExecB5"}
{"word": ["Strength."], "author": "tarangwydion"}
{"word": ["muscle"], "author": "laneth"}
{"word": ["Strength"], "author": "SlappyBag"}
{"word": ["Weakness"], "author": "almabrds"}
{"word": ["insomnia"], "author": "reaver894"}
{"word": ["now"], "author": "RafaelLVX"}
{"word": ["night"], "author": "laneth"}
{"word": ["Moon"], "author": "almabrds"}
{"word": ["sleepy"], "author": "RafaelLVX"}
{"word": ["dozy"], "author": "TrollumThinks"}
{"word": ["Coffe"], "author": "almabrds"}
{"word": ["Tea"], "author": "SlappyBag"}
{"word": ["cup"], "author": "laneth"}
{"word": ["D ", " ", " (no offense intended.)"], "author": "Dischord"}
{"word": ["offended"], "author": "SlappyBag"}
{"word": ["Insulted"], "author": "almabrds"}
{"word": ["Angry"], "author": "ExecB5"}
{"word": ["birds"], "author": "l0rdtr3k"}
{"word": ["Bees."], "author": "tarangwydion"}
{"word": ["sex"], "author": "SlappyBag"}
{"word": ["women."], "author": "Pangaea666"}
{"word": ["Wife"], "author": "Nel-A"}
{"word": ["husband"], "author": "SlappyBag"}
{"word": ["marriage"], "author": "laneth"}
{"word": ["drag"], "author": "moomphas"}
{"word": ["Net"], "author": "Stuff"}
{"word": ["Fishing"], "author": "Nel-A"}
{"word": ["hunting"], "author": "SlappyBag"}
{"word": ["Gathering"], "author": "4gamin"}
{"word": ["Dust"], "author": "KOCollins"}
{"word": ["cloud"], "author": "laneth"}
{"word": ["Storm"], "author": "Dischord"}
{"word": ["wolverine"], "author": "SlappyBag"}
{"word": ["Quickhatch."], "author": "tarangwydion"}
{"word": ["Claws"], "author": "ExecB5"}
{"word": ["Law"], "author": "almabrds"}
{"word": ["trouble"], "author": "Niggles"}
{"word": ["tribble"], "author": "TrollumThinks"}
{"word": ["rabbit"], "author": "laneth"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Orbit ", " ", " ( As in ", " )"], "author": "Stuff"}
{"word": ["Planet"], "author": "Nel-A"}
{"word": ["Hollywood"], "author": "ExecB5"}
{"word": ["Bollywood ", " (<= 3 stars!)"], "author": "almabrds"}
{"word": ["India"], "author": "laneth"}
{"word": ["crowd"], "author": "moomphas"}
{"word": ["massacre"], "author": "SlappyBag"}
{"word": ["happiness (<.< dont look at me like that!!!)"], "author": "Detlik"}
{"word": ["$money$"], "author": "laneth"}
{"word": ["need"], "author": "l0rdtr3k"}
{"word": ["Necessity."], "author": "tarangwydion"}
{"word": ["water"], "author": "SlappyBag"}
{"word": ["deluge"], "author": "TrollumThinks"}
{"word": ["Ark"], "author": "Lou"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["records"], "author": "TrollumThinks"}
{"word": ["Vinyl"], "author": "agogfan"}
{"word": ["analog"], "author": "laneth"}
{"word": ["Digital"], "author": "Nel-A"}
{"word": ["Watch"], "author": "ExecB5"}
{"word": ["Listen"], "author": "almabrds"}
{"word": ["Closely"], "author": "Lou"}
{"word": ["Following"], "author": "reaver894"}
{"word": ["stalking"], "author": "SlappyBag"}
{"word": ["stalker"], "author": "l0rdtr3k"}
{"word": ["Charming"], "author": "Detlik"}
{"word": ["curtains"], "author": "reaver894"}
{"word": ["Mobster"], "author": "Stuff"}
{"word": ["gangster"], "author": "SlappyBag"}
{"word": ["Mafiosa"], "author": "Dischord"}
{"word": ["Alex"], "author": "Lou"}
{"word": ["Anonymize"], "author": "Dischord"}
{"word": ["privacy"], "author": "Niggles"}
{"word": ["Secret"], "author": "SlappyBag"}
{"word": ["Deodorant"], "author": "4gamin"}
{"word": ["Odor."], "author": "tarangwydion"}
{"word": ["stink"], "author": "laneth"}
{"word": [], "author": "Stuff"}
{"word": ["Ant"], "author": "ExecB5"}
{"word": ["Uncle"], "author": "SlappyBag"}
{"word": ["(uncle) Sam. ", " ", " ", " Ant, not aunt. :P"], "author": "almabrds"}
{"word": ["government"], "author": "laneth"}
{"word": ["Policy."], "author": "tarangwydion"}
{"word": ["Obama ", " ", " I know."], "author": "SlappyBag"}
{"word": ["Idiot"], "author": "Lou"}
{"word": ["Stupid. ", " ", " ", " Oh ok. I thought you had understood other thing. Not calling you dumb or anything, sorry if it sounded like that."], "author": "almabrds"}
{"word": ["."], "author": "tarangwydion"}
{"word": [], "author": "KOCollins"}
{"word": ["hunting"], "author": "laneth"}
{"word": ["Weapons"], "author": "Nel-A"}
{"word": ["Shotgun"], "author": "almabrds"}
{"word": ["wedding"], "author": "SlappyBag"}
{"word": ["Cerimony"], "author": "almabrds"}
{"word": ["Graduation"], "author": "ExecB5"}
{"word": ["Qualification"], "author": "Nel-A"}
{"word": ["Job."], "author": "tarangwydion"}
{"word": [], "author": "Stuff"}
{"word": ["Wind"], "author": "Ivory&Gold"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["."], "author": "Ivory&Gold"}
{"word": ["Chireadan"], "author": "Lou"}
{"word": ["Yossarian"], "author": "4gamin"}
{"word": ["antihero"], "author": "laneth"}
{"word": ["Villain"], "author": "SlappyBag"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Cage"], "author": "Nel-A"}
{"word": ["Johnny"], "author": "ExecB5"}
{"word": ["Bravo"], "author": "Lou"}
{"word": ["Radiation"], "author": "almabrds"}
{"word": ["Mutated"], "author": "SlappyBag"}
{"word": ["Xmen"], "author": "laneth"}
{"word": ["Marvel"], "author": "ExecB5"}
{"word": ["Wonder"], "author": "Lou"}
{"word": ["woman"], "author": "reaver894"}
{"word": ["Hot"], "author": "ExecB5"}
{"word": ["Tea"], "author": "almabrds"}
{"word": ["bag"], "author": "reaver894"}
{"word": [], "author": "almabrds"}
{"word": ["Pwned"], "author": "SlappyBag"}
{"word": ["Owned."], "author": "tarangwydion"}
{"word": ["Possessed"], "author": "Stuff"}
{"word": ["Demon"], "author": "KOCollins"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["emperor"], "author": "SlappyBag"}
{"word": ["realism"], "author": "RafaelLVX"}
{"word": ["magical"], "author": "Ivory&Gold"}
{"word": ["Wand"], "author": "Nel-A"}
{"word": ["Wizard"], "author": "Stuff"}
{"word": ["Gandalf"], "author": "l0rdtr3k"}
{"word": ["Merlin"], "author": "KOCollins"}
{"word": ["Morgana"], "author": "laneth"}
{"word": ["Web"], "author": "SlappyBag"}
{"word": ["Slinger."], "author": "tarangwydion"}
{"word": ["Stinger"], "author": "almabrds"}
{"word": ["pinch"], "author": "SlappyBag"}
{"word": ["salt"], "author": "TrollumThinks"}
{"word": ["Lake."], "author": "tarangwydion"}
{"word": ["lochness"], "author": "SlappyBag"}
{"word": ["Nessie"], "author": "TrollumThinks"}
{"word": ["Sighting"], "author": "Niggles"}
{"word": ["Eyes"], "author": "almabrds"}
{"word": ["nose"], "author": "SlappyBag"}
{"word": ["Nosey"], "author": "Nel-A"}
{"word": [], "author": "Stuff"}
{"word": ["Dwarf."], "author": "tarangwydion"}
{"word": ["Beard"], "author": "ExecB5"}
{"word": ["hair"], "author": "SlappyBag"}
{"word": ["blonde"], "author": "Ivory&Gold"}
{"word": ["Jokes"], "author": "Lou"}
{"word": ["Conan"], "author": "SlappyBag"}
{"word": ["Brian"], "author": "Rohan15"}
{"word": ["Blessed"], "author": "Nel-A"}
{"word": ["endowed"], "author": "SlappyBag"}
{"word": [], "author": "Stuff"}
{"word": ["Money"], "author": "ExecB5"}
{"word": ["Hefner"], "author": "SlappyBag"}
{"word": ["Geezer"], "author": "Stuff"}
{"word": ["Weezer"], "author": "Nel-A"}
{"word": ["rock"], "author": "icepowdah"}
{"word": ["Solid"], "author": "4gamin"}
{"word": ["Snake"], "author": "almabrds"}
{"word": ["Animal"], "author": "ExecB5"}
{"word": ["tiger"], "author": "l0rdtr3k"}
{"word": ["Crouching."], "author": "tarangwydion"}
{"word": ["Pooping"], "author": "SlappyBag"}
{"word": ["Troll"], "author": "Stuff"}
{"word": ["Bridge"], "author": "SimonG"}
{"word": ["london"], "author": "l0rdtr3k"}
{"word": ["Yuck"], "author": "Nel-A"}
{"word": ["Eww"], "author": "SlappyBag"}
{"word": ["Disgusting."], "author": "tarangwydion"}
{"word": ["Gusting"], "author": "TrollumThinks"}
{"word": ["Mistral"], "author": "Lou"}
{"word": ["Wind"], "author": "ExecB5"}
{"word": ["Sail"], "author": "Stuff"}
{"word": ["Sea"], "author": "Nel-A"}
{"word": ["Shore"], "author": "SlappyBag"}
{"word": ["Line."], "author": "tarangwydion"}
{"word": ["Tangent"], "author": "Lou"}
{"word": ["geometry"], "author": "laneth"}
{"word": ["Square"], "author": "SlappyBag"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Smallpox"], "author": "almabrds"}
{"word": ["Illness"], "author": "SlappyBag"}
{"word": ["Mental"], "author": "Dischord"}
{"word": ["Maniac"], "author": "Detlik"}
{"word": ["rage"], "author": "laneth"}
{"word": [" Blind"], "author": "Arianus.836"}
{"word": ["Deaf"], "author": "SlappyBag"}
{"word": [" what?!"], "author": "Arianus.836"}
{"word": ["Now."], "author": "tarangwydion"}
{"word": ["Time."], "author": "spindown"}
{"word": ["what?!"], "author": "SlappyBag"}
{"word": ["Watt?!"], "author": "TrollumThinks"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Angry Video Game Nerd! (aka AVGN)"], "author": "DarkSlim"}
{"word": ["Sad"], "author": "almabrds"}
{"word": ["Unhappy"], "author": "Nel-A"}
{"word": ["school"], "author": "l0rdtr3k"}
{"word": ["Masturbate"], "author": "SlappyBag"}
{"word": ["Adolescent"], "author": "Stuff"}
{"word": ["Juvenile."], "author": "tarangwydion"}
{"word": ["detention"], "author": "SlappyBag"}
{"word": ["Island"], "author": "almabrds"}
{"word": ["Fantasy"], "author": "TrollumThinks"}
{"word": ["Final"], "author": "DarkSlim"}
{"word": ["Complete"], "author": "Nel-A"}
{"word": ["Collection"], "author": "SlappyBag"}
{"word": ["Compilation"], "author": "almabrds"}
{"word": ["Anthology."], "author": "tarangwydion"}
{"word": ["Zork"], "author": "Lou"}
{"word": ["Zorak"], "author": "ExecB5"}
{"word": ["Borat"], "author": "SlappyBag"}
{"word": ["Mustache"], "author": "almabrds"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["UniBrow"], "author": "Lou"}
{"word": ["Sexy"], "author": "SlappyBag"}
{"word": ["Opinion"], "author": "Stuff"}
{"word": ["Taste"], "author": "almabrds"}
{"word": ["Food."], "author": "SerpentineCougar"}
{"word": ["Worm"], "author": "KOCollins"}
{"word": ["Spice"], "author": "Stuff"}
{"word": [], "author": "TrollumThinks"}
{"word": ["obscure"], "author": "SlappyBag"}
{"word": [" ", " (not on sale anymore)"], "author": "almabrds"}
{"word": ["Retro"], "author": "DarkSlim"}
{"word": ["Dog ", " (ninja'd!!) ", " ", " flares!"], "author": "Nel-A"}
{"word": ["Light"], "author": "ExecB5"}
{"word": ["Photon"], "author": "Dischord"}
{"word": ["Particle"], "author": "BlackenedZoid"}
{"word": ["Physics"], "author": "KOCollins"}
{"word": ["source"], "author": "l0rdtr3k"}
{"word": ["Code"], "author": "SerpentineCougar"}
{"word": ["Name."], "author": "tarangwydion"}
{"word": ["Title"], "author": "Nel-A"}
{"word": ["Ownership"], "author": "Stuff"}
{"word": ["Slavery"], "author": "SlappyBag"}
{"word": ["Capoeira"], "author": "ExecB5"}
{"word": ["Brazilian"], "author": "Lou"}
{"word": ["Shaved"], "author": "Nel-A"}
{"word": ["beard"], "author": "l0rdtr3k"}
{"word": ["Elder"], "author": "Lenok"}
{"word": ["scrolls"], "author": "l0rdtr3k"}
{"word": ["Lawsuit"], "author": "SlappyBag"}
{"word": ["Lawyer"], "author": "Nel-A"}
{"word": ["Court"], "author": "almabrds"}
{"word": ["ship"], "author": "jefequeso"}
{"word": ["Vessel."], "author": "tarangwydion"}
{"word": [" STARSHIP!"], "author": "Arianus.836"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Airplane"], "author": "Lou"}
{"word": ["Stars"], "author": "SlappyBag"}
{"word": ["Nemesis"], "author": "ExecB5"}
{"word": ["."], "author": "tarangwydion"}
{"word": [], "author": "almabrds"}
{"word": ["Lizard"], "author": "bsu"}
{"word": ["Reptile"], "author": "ExecB5"}
{"word": ["Villain"], "author": "SlappyBag"}
{"word": ["Villa"], "author": "Nel-A"}
{"word": ["Mansion"], "author": "DarkSlim"}
{"word": ["Tent"], "author": "almabrds"}
{"word": [" cot"], "author": "Arianus.836"}
{"word": ["Bed"], "author": "SerpentineCougar"}
{"word": [], "author": "Stuff"}
{"word": ["Hard"], "author": "SlappyBag"}
{"word": ["Nails"], "author": "Robbeasy"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Shoes"], "author": "ExecB5"}
{"word": [], "author": "Lenok"}
{"word": ["Arcade"], "author": "Detlik"}
{"word": ["pinball"], "author": "KneeTheCap"}
{"word": ["Score"], "author": "almabrds"}
{"word": ["Card"], "author": "Stuff"}
{"word": ["credit"], "author": "klaattu"}
{"word": ["poor"], "author": "SlappyBag"}
{"word": ["Thing."], "author": "tarangwydion"}
{"word": ["Object"], "author": "Nel-A"}
{"word": ["object (v)"], "author": "TrollumThinks"}
{"word": ["Paradox"], "author": "almabrds"}
{"word": [". ", " ", " * While it is Corel's property now, to me Paradox always links to Borland."], "author": "tarangwydion"}
{"word": ["Delphi"], "author": "bsu"}
{"word": ["Greece"], "author": "SlappyBag"}
{"word": ["Finance"], "author": "Nel-A"}
{"word": ["math"], "author": "l0rdtr3k"}
{"word": ["Equation"], "author": "ExecB5"}
{"word": ["Balance"], "author": "CathKaligna"}
{"word": ["topple"], "author": "SlappyBag"}
{"word": ["Libya"], "author": "summitus"}
{"word": ["Oil"], "author": "Psyringe"}
{"word": ["Barrel"], "author": "Nel-A"}
{"word": ["Penny"], "author": "zephyrduo"}
{"word": ["Arcade"], "author": "SerpentineCougar"}
{"word": ["Reflex."], "author": "tarangwydion"}
{"word": ["Bow"], "author": "drevo2"}
{"word": ["Arrow"], "author": "ExecB5"}
{"word": ["Feather"], "author": "almabrds"}
{"word": ["duster"], "author": "TrollumThinks"}
{"word": ["Dodge"], "author": "Stuff"}
{"word": ["Ninja"], "author": "CathKaligna"}
{"word": ["assassin"], "author": "Psyringe"}
{"word": ["creed"], "author": "klaattu"}
{"word": ["Faith"], "author": "Nel-A"}
{"word": ["Hill"], "author": "cymrean"}
{"word": ["Boot"], "author": "summitus"}
{"word": ["Foot"], "author": "ExecB5"}
{"word": ["Centimeter"], "author": "SlappyBag"}
{"word": ["Unit."], "author": "tarangwydion"}
{"word": ["soldier"], "author": "l0rdtr3k"}
{"word": ["troop"], "author": "danteveli"}
{"word": ["Mission"], "author": "almabrds"}
{"word": ["Impossible"], "author": "Lou"}
{"word": [], "author": "TrollumThinks"}
{"word": ["Obscure"], "author": "SlappyBag"}
{"word": ["Remote"], "author": "almabrds"}
{"word": ["Control"], "author": "Stuff"}
{"word": ["Authority"], "author": "Cavalary"}
{"word": ["Respect"], "author": "RightInPot"}
{"word": ["idol"], "author": "danteveli"}
{"word": ["Statue"], "author": "SerpentineCougar"}
{"word": ["Angel"], "author": "Lenok"}
{"word": ["Gabriel"], "author": "Lou"}
{"word": ["Supernatural"], "author": "SlappyBag"}
{"word": ["Spiritual"], "author": "Nel-A"}
{"word": ["uprising"], "author": "BlackenedZoid"}
{"word": ["Rebel"], "author": "Cavalary"}
{"word": ["Without a Cause..."], "author": "Adomas"}
{"word": ["useless"], "author": "KneeTheCap"}
{"word": ["superfluous"], "author": "TrollumThinks"}
{"word": ["excessive"], "author": "Lou"}
{"word": ["Fat"], "author": "SlappyBag"}
{"word": [], "author": "Stuff"}
{"word": ["Cojones"], "author": "almabrds"}
{"word": ["Guts"], "author": "TheTrveFenris"}
{"word": ["eviscerate"], "author": "KOCollins"}
{"word": ["dissect"], "author": "Lou"}
{"word": ["Cut."], "author": "tarangwydion"}
{"word": ["Paste"], "author": "Dumas1"}
{"word": ["Glue"], "author": "SerpentineCougar"}
{"word": ["Gum"], "author": "ExecB5"}
{"word": ["Chewing."], "author": "tarangwydion"}
{"word": ["Chewbacca"], "author": "ExecB5"}
{"word": ["Smuggler"], "author": "4gamin"}
{"word": [], "author": "almabrds"}
{"word": ["bird"], "author": "Sargonza"}
{"word": ["wings"], "author": "ExecB5"}
{"word": ["Paul"], "author": "Lou"}
{"word": ["Ephesians"], "author": "Dischord"}
{"word": ["Amour"], "author": "Nel-A"}
{"word": ["Illicit."], "author": "tarangwydion"}
{"word": ["Common"], "author": "Dischord"}
{"word": ["Sense"], "author": "ExecB5"}
{"word": ["Sixth"], "author": "TheTrveFenris"}
{"word": ["satan"], "author": "SlappyBag"}
{"word": ["Lucifer."], "author": "tarangwydion"}
{"word": ["Angel"], "author": "ExecB5"}
{"word": ["Metatron"], "author": "Nel-A"}
{"word": ["shin megami tensei"], "author": "danteveli"}
{"word": [], "author": "Stuff"}
{"word": ["lost-the"], "author": "Sargonza"}
{"word": ["Island"], "author": "SlappyBag"}
{"word": ["Dharma (Initiative)"], "author": "almabrds"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["crap"], "author": "Niggles"}
{"word": ["excrement"], "author": "TrollumThinks"}
{"word": ["Feces"], "author": "almabrds"}
{"word": ["toilet"], "author": "klaattu"}
{"word": ["Paper"], "author": "ExecB5"}
{"word": ["News"], "author": "Stuff"}
{"word": ["Aggregator."], "author": "tarangwydion"}
{"word": ["Cascade"], "author": "almabrds"}
{"word": ["Casket"], "author": "faecrool"}
{"word": ["Open"], "author": "TheTrveFenris"}
{"word": ["Liberal"], "author": "SlappyBag"}
{"word": ["Generous"], "author": "4gamin"}
{"word": ["magnanimous"], "author": "Lou"}
{"word": ["Magnus"], "author": "TrollumThinks"}
{"word": [], "author": "KOCollins"}
{"word": ["Circus."], "author": "tarangwydion"}
{"word": ["Clown"], "author": "ExecB5"}
{"word": [], "author": "Stuff"}
{"word": ["Tylenol"], "author": "SerpentineCougar"}
{"word": ["Viagra (hahaha)"], "author": "almabrds"}
{"word": ["Pill"], "author": "ExecB5"}
{"word": ["Matrix"], "author": "SlappyBag"}
{"word": ["Slowmo"], "author": "faecrool"}
{"word": ["Mo'Slo ", " ", " * for DOS: ", " "], "author": "tarangwydion"}
{"word": ["faster"], "author": "Niggles"}
{"word": ["furiouser"], "author": "TrollumThinks"}
{"word": ["Curiouser"], "author": "Nel-A"}
{"word": ["Curious"], "author": "ExecB5"}
{"word": ["George"], "author": "Lou"}
{"word": ["Kramer"], "author": "SlappyBag"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Street (Fighter)"], "author": "ExecB5"}
{"word": ["Gang"], "author": "KOCollins"}
{"word": ["Initiation"], "author": "4gamin"}
{"word": ["Cult"], "author": "ExecB5"}
{"word": ["Apollo"], "author": "Cleidophoros"}
{"word": ["Creed"], "author": "Nel-A"}
{"word": ["Assassins"], "author": "almabrds"}
{"word": ["Hashish"], "author": "Profanity"}
{"word": ["Kebab"], "author": "SerpentineCougar"}
{"word": ["Food"], "author": "ExecB5"}
{"word": ["Cook."], "author": "tarangwydion"}
{"word": ["Cookie"], "author": "almabrds"}
{"word": ["Biscuit"], "author": "TrollumThinks"}
{"word": ["Tin"], "author": "KOCollins"}
{"word": ["Oil"], "author": "almabrds"}
{"word": ["slick"], "author": "Niggles"}
{"word": ["Salesman"], "author": "KOCollins"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Cruise"], "author": "Nel-A"}
{"word": ["pleasure "], "author": "l0rdtr3k"}
{"word": [" Hedonist"], "author": "Nel-A"}
{"word": ["what"], "author": "SlappyBag"}
{"word": ["inquisitive"], "author": "TrollumThinks"}
{"word": ["Curious"], "author": "Lou"}
{"word": ["Serious"], "author": "ExecB5"}
{"word": ["Sam"], "author": "Niggles"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["entertainer"], "author": "Psyringe"}
{"word": ["Entertainment"], "author": "ExecB5"}
{"word": ["gridiron"], "author": "Niggles"}
{"word": [], "author": "almabrds"}
{"word": ["puppets"], "author": "l0rdtr3k"}
{"word": ["muppets"], "author": "SlappyBag"}
{"word": ["Socks"], "author": "ExecB5"}
{"word": ["Santa."], "author": "tarangwydion"}
{"word": ["beard"], "author": "icepowdah"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Beer"], "author": "almabrds"}
{"word": ["Pong."], "author": "tarangwydion"}
{"word": ["Ping"], "author": "TrollumThinks"}
{"word": [], "author": "KOCollins"}
{"word": [" Yellow ", " ", " EDIT: ninja'd. Previously: ", " ", " ", "."], "author": "tarangwydion"}
{"word": [" purple"], "author": "Niggles"}
{"word": ["haze"], "author": "icepowdah"}
{"word": [], "author": "Stuff"}
{"word": ["Dead"], "author": "Lou"}
{"word": ["serious"], "author": "hercufles"}
{"word": ["Sam"], "author": "icepowdah"}
{"word": ["Vampire"], "author": "SlappyBag"}
{"word": ["teeth"], "author": "hercufles"}
{"word": ["sparkles "], "author": "l0rdtr3k"}
{"word": ["frankenstein's monster"], "author": "hercufles"}
{"word": ["green"], "author": "ExecB5"}
{"word": ["thumb"], "author": "icepowdah"}
{"word": ["Controller"], "author": "Moargun"}
{"word": ["Thumbstick"], "author": "Nel-A"}
{"word": ["stolen"], "author": "Niggles"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Roman"], "author": "ExecB5"}
{"word": ["Gladius"], "author": "Niggles"}
{"word": ["cesear"], "author": "hercufles"}
{"word": ["salad"], "author": "PandaLiang"}
{"word": ["Mayonnaise"], "author": "almabrds"}
{"word": ["Zack"], "author": "Lou"}
{"word": ["Jack"], "author": "ExecB5"}
{"word": ["Crack"], "author": "Elenarie"}
{"word": ["Pipe"], "author": "Nel-A"}
{"word": ["sewer"], "author": "KneeTheCap"}
{"word": ["Rat"], "author": "Dischord"}
{"word": [], "author": "Stuff"}
{"word": ["Dawn"], "author": "hercufles"}
{"word": ["Biplane"], "author": "4gamin"}
{"word": [" airplane"], "author": "Arianus.836"}
{"word": ["Shirley"], "author": "SlappyBag"}
{"word": ["Hollywood"], "author": "icepowdah"}
{"word": ["Boulevarde"], "author": "Niggles"}
{"word": ["silicones"], "author": "hercufles"}
{"word": ["Lawsuits"], "author": "Dischord"}
{"word": ["Lawyer"], "author": "ExecB5"}
{"word": ["Lie"], "author": "icepowdah"}
{"word": ["Obfuscate ", " ", " Edit for drinking before posting, ie: spelling!"], "author": "Dischord"}
{"word": ["confusing"], "author": "Niggles"}
{"word": ["befuddle"], "author": "Ornery_Ocelot"}
{"word": [], "author": "Stuff"}
{"word": ["Mr."], "author": "TrollumThinks"}
{"word": ["Scrooge"], "author": "Dischord"}
{"word": ["Ghosts"], "author": "4gamin"}
{"word": ["Spirits"], "author": "TrollumThinks"}
{"word": ["Supernatural"], "author": "Niggles"}
{"word": ["Magic"], "author": "SerpentineCougar"}
{"word": ["Might"], "author": "PandaLiang"}
{"word": ["Dexterity"], "author": "Lou"}
{"word": ["evasion"], "author": "l0rdtr3k"}
{"word": ["armour"], "author": "hercufles"}
{"word": ["Useless"], "author": "almabrds"}
{"word": ["this topic"], "author": "hercufles"}
{"word": [" One. ", " ", " * one word, that is, not two :-)"], "author": "tarangwydion"}
{"word": ["Two"], "author": "ExecB5"}
{"word": ["Worlds."], "author": "tarangwydion"}
{"word": ["collide"], "author": "TrollumThinks"}
{"word": ["smash"], "author": "SlappyBag"}
{"word": ["......it"], "author": "Niggles"}
{"word": ["clown"], "author": "hercufles"}
{"word": ["Krusty"], "author": "Nel-A"}
{"word": ["bart"], "author": "hercufles"}
{"word": ["Homer"], "author": "ExecB5"}
{"word": ["foooooooooooood"], "author": "hercufles"}
{"word": ["Donuts"], "author": "almabrds"}
{"word": ["Sprinkles"], "author": "maycett"}
{"word": ["Rain"], "author": "SerpentineCougar"}
{"word": ["scorpion"], "author": "hercufles"}
{"word": ["King"], "author": "Lou"}
{"word": ["Jimmer"], "author": "4gamin"}
{"word": ["Jimmy"], "author": "ExecB5"}
{"word": ["lock"], "author": "Niggles"}
{"word": ["Password."], "author": "tarangwydion"}
{"word": ["BlackMenFTW69 ", " ", " ", " ", ";)"], "author": "SlappyBag"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Secrecy"], "author": "TrollumThinks"}
{"word": ["Confidential"], "author": "Stuff"}
{"word": ["Conspiracy"], "author": "4gamin"}
{"word": [], "author": "almabrds"}
{"word": ["KISS"], "author": "Lou"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Acronym"], "author": "park_84"}
{"word": ["RADAR"], "author": "Nel-A"}
{"word": [" ;-D"], "author": "KOCollins"}
{"word": ["Birds"], "author": "TrollumThinks"}
{"word": ["Hitchcock."], "author": "tarangwydion"}
{"word": ["Silhouette"], "author": "KOCollins"}
{"word": ["Shadow"], "author": "ExecB5"}
{"word": ["Puppet"], "author": "Stuff"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["falcon"], "author": "l0rdtr3k"}
{"word": ["Maltese"], "author": "TrollumThinks"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Superman"], "author": "SlappyBag"}
{"word": ["Supergirl"], "author": "ExecB5"}
{"word": ["Sexy"], "author": "park_84"}
{"word": ["Butt"], "author": "Niggles"}
{"word": ["Ugly"], "author": "KOCollins"}
{"word": ["Duckling"], "author": "Dischord"}
{"word": ["Quack"], "author": "Niggles"}
{"word": ["Psyduck"], "author": "SlappyBag"}
{"word": ["Headache"], "author": "maycett"}
{"word": ["Kids"], "author": "park_84"}
{"word": ["Gifts"], "author": "SerpentineCougar"}
{"word": ["Presents."], "author": "tarangwydion"}
{"word": ["none"], "author": "Niggles"}
{"word": ["nought"], "author": "TrollumThinks"}
{"word": ["Zero"], "author": "PandaLiang"}
{"word": ["Hero"], "author": "Nel-A"}
{"word": ["Impossibru!"], "author": "SlappyBag"}
{"word": ["Asian"], "author": "ExecB5"}
{"word": ["anime"], "author": "l0rdtr3k"}
{"word": ["Eyes"], "author": "SerpentineCougar"}
{"word": ["See"], "author": "TrollumThinks"}
{"word": ["blind"], "author": "Niggles"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Murder"], "author": "SlappyBag"}
{"word": ["Bloody"], "author": "KOCollins"}
{"word": ["hell"], "author": "Niggles"}
{"word": ["divine"], "author": "PandaLiang"}
{"word": [], "author": "Stuff"}
{"word": [], "author": "Lou"}
{"word": ["Dumbfounded"], "author": "SlappyBag"}
{"word": ["Astonished."], "author": "tarangwydion"}
{"word": ["Stunned"], "author": "Niggles"}
{"word": ["Shocked"], "author": "Nel-A"}
{"word": ["Electrified"], "author": "SlappyBag"}
{"word": ["Grease"], "author": "park_84"}
{"word": [], "author": "KOCollins"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Detective (Comics)"], "author": "ExecB5"}
{"word": ["Investigate"], "author": "SlappyBag"}
{"word": ["Motive."], "author": "tarangwydion"}
{"word": ["Clue"], "author": "Lou"}
{"word": ["Clueless"], "author": "TrollumThinks"}
{"word": ["Devoid"], "author": "Nel-A"}
{"word": ["Empty"], "author": "Stuff"}
{"word": ["Sexy"], "author": "SlappyBag"}
{"word": ["cry"], "author": "l0rdtr3k"}
{"word": ["Far"], "author": "Stuff"}
{"word": ["out"], "author": "Niggles"}
{"word": ["cast"], "author": "PandaLiang"}
{"word": ["Gypsum."], "author": "tarangwydion"}
{"word": ["chalky"], "author": "Niggles"}
{"word": ["Semen"], "author": "SlappyBag"}
{"word": ["Child"], "author": "Stuff"}
{"word": ["Innocent."], "author": "tarangwydion"}
{"word": ["Victim."], "author": "ExecB5"}
{"word": ["revenge"], "author": "Niggles"}
{"word": ["Kratos"], "author": "PandaLiang"}
{"word": ["Cheetos"], "author": "4gamin"}
{"word": ["tasty"], "author": "Niggles"}
{"word": ["Spicy."], "author": "tarangwydion"}
{"word": ["Destruction"], "author": "Nroug7"}
{"word": ["reconstruction"], "author": "Niggles"}
{"word": ["Chainsaw"], "author": "Nroug7"}
{"word": ["Texas"], "author": "PandaLiang"}
{"word": ["Mexico."], "author": "Nroug7"}
{"word": ["Enchilada"], "author": "Niggles"}
{"word": ["diarrhea"], "author": "SlappyBag"}
{"word": ["Guitar"], "author": "Lou"}
{"word": ["Distortion."], "author": "ExecB5"}
{"word": ["marijuana"], "author": "SlappyBag"}
{"word": ["Drug"], "author": "Stuff"}
{"word": ["sickness"], "author": "PandaLiang"}
{"word": ["Death."], "author": "Nroug7"}
{"word": ["purgatory"], "author": "Niggles"}
{"word": ["Sacrifice"], "author": "Nroug7"}
{"word": ["Lamb"], "author": "SerpentineCougar"}
{"word": ["chop"], "author": "Niggles"}
{"word": ["Meat."], "author": "Nroug7"}
{"word": ["Sirloin"], "author": "PandaLiang"}
{"word": ["steak"], "author": "wolfsnake"}
{"word": ["Lamb."], "author": "Nroug7"}
{"word": ["Silence"], "author": "ExecB5"}
{"word": ["Hill"], "author": "PandaLiang"}
{"word": ["top"], "author": "Niggles"}
{"word": ["gyroscope"], "author": "4gamin"}
{"word": ["telescope"], "author": "PandaLiang"}
{"word": ["Peep"], "author": "SlappyBag"}
{"word": ["Tom."], "author": "tarangwydion"}
{"word": ["Jerry"], "author": "gdveiga"}
{"word": ["Mouse"], "author": "ExecB5"}
{"word": ["Squeak!"], "author": "Niggles"}
{"word": ["Bubble"], "author": "TrollumThinks"}
{"word": ["gum"], "author": "PandaLiang"}
{"word": ["Bazooka"], "author": "Lou"}
{"word": ["Explosion"], "author": "SerpentineCougar"}
{"word": ["Ejaculate"], "author": "SlappyBag"}
{"word": ["semen"], "author": "Niggles"}
{"word": ["Concrete. ", " ", " * semen in Indonesian means cement :-D"], "author": "tarangwydion"}
{"word": ["Jungle."], "author": "adamzs"}
{"word": ["Welcome"], "author": "SlappyBag"}
{"word": ["back!"], "author": "PandaLiang"}
{"word": ["front"], "author": "Niggles"}
{"word": ["Western"], "author": "Nel-A"}
{"word": ["cowboys"], "author": "Sargonza"}
{"word": ["aliens."], "author": "Nroug7"}
{"word": ["UFO"], "author": "PandaLiang"}
{"word": ["Einstein"], "author": "Nroug7"}
{"word": ["Dog"], "author": "Lou"}
{"word": ["cat"], "author": "l0rdtr3k"}
{"word": ["Stevens"], "author": "Stuff"}
{"word": ["Angelsea"], "author": "Dischord"}
{"word": ["Wales"], "author": "Nel-A"}
{"word": ["Speed"], "author": "PandaLiang"}
{"word": ["Meth"], "author": "SlappyBag"}
{"word": ["booze"], "author": "Niggles"}
{"word": ["Alcoholic."], "author": "tarangwydion"}
{"word": ["workaholic"], "author": "PandaLiang"}
{"word": ["Driven"], "author": "Stuff"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Arnie"], "author": "Niggles"}
{"word": ["Metal."], "author": "Nroug7"}
{"word": ["gear"], "author": "Niggles"}
{"word": ["Solid."], "author": "Nroug7"}
{"word": ["Liquid"], "author": "TrollumThinks"}
{"word": ["Light"], "author": "Stuff"}
{"word": ["electromagnetism"], "author": "PandaLiang"}
{"word": ["Tesla"], "author": "Dischord"}
{"word": ["Lightning"], "author": "OctopusMan"}
{"word": ["Charger"], "author": "SlappyBag"}
{"word": ["Battery"], "author": "ExecB5"}
{"word": ["Life"], "author": "KOCollins"}
{"word": ["Death."], "author": "Nroug7"}
{"word": ["Note"], "author": "Nel-A"}
{"word": ["Milk"], "author": "OctopusMan"}
{"word": ["cow"], "author": "l0rdtr3k"}
{"word": ["Pastures"], "author": "Nroug7"}
{"word": ["Greener"], "author": "SaraB123"}
{"word": ["Sustainable"], "author": "OctopusMan"}
{"word": ["Endurance"], "author": "SaraB123"}
{"word": ["Run"], "author": "maycett"}
{"word": ["Sprint"], "author": "Stuff"}
{"word": ["Shift"], "author": "ExecB5"}
{"word": ["Keppler"], "author": "PandaLiang"}
{"word": [], "author": "KOCollins"}
{"word": ["Jedi"], "author": "SlappyBag"}
{"word": ["Force"], "author": "ExecB5"}
{"word": ["Strength"], "author": "Oddworld"}
{"word": ["Power"], "author": "Nel-A"}
{"word": ["."], "author": "tarangwydion"}
{"word": [], "author": "HampsterStyle"}
{"word": ["series"], "author": "MrAlphaNumeric"}
{"word": ["fourier"], "author": "PandaLiang"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Fasting."], "author": "tarangwydion"}
{"word": ["Hungry"], "author": "TrollumThinks"}
{"word": ["starve"], "author": "Niggles"}
{"word": ["food"], "author": "Raptomex"}
{"word": ["Energy"], "author": "KOCollins"}
{"word": ["chocolate."], "author": "MrAlphaNumeric"}
{"word": ["Mocha"], "author": "PandaLiang"}
{"word": ["Latte"], "author": "Lou"}
{"word": ["Coffee"], "author": "SlappyBag"}
{"word": ["Milk"], "author": "ExecB5"}
{"word": ["galaxy"], "author": "PandaLiang"}
{"word": ["Spiral"], "author": "TrollumThinks"}
{"word": ["Helix"], "author": "Stuff"}
{"word": ["Double"], "author": "MrAlphaNumeric"}
{"word": ["Pair"], "author": "maycett"}
{"word": ["dipole"], "author": "PandaLiang"}
{"word": ["magnet"], "author": "icepowdah"}
{"word": ["X-Men"], "author": "SlappyBag"}
{"word": ["Rogue"], "author": "ExecB5"}
{"word": ["Shadows"], "author": "KOCollins"}
{"word": ["Dark"], "author": "Lou"}
{"word": ["Space."], "author": "MrAlphaNumeric"}
{"word": ["nebula"], "author": "Niggles"}
{"word": ["supernova"], "author": "PandaLiang"}
{"word": ["Chevy"], "author": "SaraB123"}
{"word": ["Detroit"], "author": "icepowdah"}
{"word": [], "author": "Stuff"}
{"word": ["Blues"], "author": "SlappyBag"}
{"word": ["Moody"], "author": "Niggles"}
{"word": ["Mad-Eye"], "author": "PandaLiang"}
{"word": ["Wizard"], "author": "Nel-A"}
{"word": ["Familiar"], "author": "KOCollins"}
{"word": ["\"Catspaw\""], "author": "Lou"}
{"word": ["Dance"], "author": "SlappyBag"}
{"word": ["Groove"], "author": "Muskeato"}
{"word": ["Funk"], "author": "4gamin"}
{"word": [], "author": "Stuff"}
{"word": ["boogie"], "author": "Niggles"}
{"word": ["Man"], "author": "ExecB5"}
{"word": ["mice"], "author": "PandaLiang"}
{"word": ["blind"], "author": "Lou"}
{"word": ["Deaf"], "author": "SlappyBag"}
{"word": ["Dumb"], "author": "Niggles"}
{"word": ["Mute"], "author": "Matchstickman"}
{"word": ["sound"], "author": "l0rdtr3k"}
{"word": ["Wave"], "author": "maycett"}
{"word": ["Hello!"], "author": "Matchstickman"}
{"word": ["friend"], "author": "demeternorbi"}
{"word": ["trust"], "author": "MrAlphaNumeric"}
{"word": ["worthy"], "author": "Niggles"}
{"word": ["Valuable"], "author": "HuntingNoob"}
{"word": ["Precious"], "author": "Lou"}
{"word": [], "author": "Stuff"}
{"word": ["Fish"], "author": "SaraB123"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Meme"], "author": "SlappyBag"}
{"word": ["Base"], "author": "Matchstickman"}
{"word": [". ", " ", " * anybody remembers that?"], "author": "tarangwydion"}
{"word": ["Goats. ", " ", " (Dbase programmers I knew had them)"], "author": "SaraB123"}
{"word": [], "author": "Stuff"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Karate."], "author": "tarangwydion"}
{"word": ["Japan"], "author": "HuntingNoob"}
{"word": ["Country"], "author": "maycett"}
{"word": ["Little"], "author": "Matchstickman"}
{"word": [], "author": "Stuff"}
{"word": ["Sith"], "author": "SlappyBag"}
{"word": ["Dark"], "author": "ExecB5"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["..life"], "author": "Niggles"}
{"word": ["Health."], "author": "ExecB5"}
{"word": ["Care"], "author": "maycett"}
{"word": ["Bear"], "author": "Matchstickman"}
{"word": ["Pig"], "author": "SlappyBag"}
{"word": ["Cops."], "author": "tarangwydion"}
{"word": ["Donuts"], "author": "Niggles"}
{"word": ["Coffee"], "author": "Lou"}
{"word": [], "author": "PandaLiang"}
{"word": [], "author": "HampsterStyle"}
{"word": ["purple"], "author": "Niggles"}
{"word": [". ", " ", " * see that hidden .purple folder under your home directory created by Pidgin? It's alive! :-D"], "author": "tarangwydion"}
{"word": [], "author": "Matchstickman"}
{"word": ["Drive"], "author": "SlappyBag"}
{"word": ["Motivate"], "author": "4gamin"}
{"word": [], "author": "HampsterStyle"}
{"word": ["dubbing"], "author": "Psyringe"}
{"word": [], "author": "HampsterStyle"}
{"word": ["youtube"], "author": "Niggles"}
{"word": ["dead"], "author": "Kunovski"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Rich"], "author": "SlappyBag"}
{"word": ["geezer"], "author": "Niggles"}
{"word": ["Eccentricity."], "author": "tarangwydion"}
{"word": ["Agitated"], "author": "ExecB5"}
{"word": ["Irritated"], "author": "Nel-A"}
{"word": ["Angry"], "author": "maycett"}
{"word": ["birds"], "author": "Sargonza"}
{"word": ["Hitchcock"], "author": "Trevorish"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Death"], "author": "SlappyBag"}
{"word": ["Gate."], "author": "tarangwydion"}
{"word": ["Cycle"], "author": "Lou"}
{"word": ["Motor"], "author": "Stuff"}
{"word": ["Head"], "author": "ExecB5"}
{"word": ["hunter"], "author": "Kunovski"}
{"word": ["killer"], "author": "downloadmunkey"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Band"], "author": "SlappyBag"}
{"word": [], "author": "HampsterStyle"}
{"word": ["old"], "author": "Niggles"}
{"word": ["fossil"], "author": "PandaLiang"}
{"word": ["New"], "author": "Arianus.836"}
{"word": ["Latest."], "author": "tarangwydion"}
{"word": ["trend"], "author": "Niggles"}
{"word": ["Twitter"], "author": "Nel-A"}
{"word": ["follower"], "author": "acard87"}
{"word": ["cult"], "author": "Niggles"}
{"word": [], "author": "Kunovski"}
{"word": ["Cat"], "author": "maycett"}
{"word": ["Nastassja"], "author": "Lou"}
{"word": ["Foreign"], "author": "SlappyBag"}
{"word": ["Soil"], "author": "Niggles"}
{"word": ["earth"], "author": "Maighstir"}
{"word": ["Fire"], "author": "ExecB5"}
{"word": ["Fighter."], "author": "tarangwydion"}
{"word": ["arcade"], "author": "PandaLiang"}
{"word": ["Penny"], "author": "Lou"}
{"word": [], "author": "HampsterStyle"}
{"word": [], "author": "Stuff"}
{"word": ["Bob"], "author": "Arianus.836"}
{"word": ["MicroSoft"], "author": "Lou"}
{"word": ["Puma"], "author": "SlappyBag"}
{"word": ["Cat"], "author": "LoloPinky"}
{"word": ["Fight"], "author": "maycett"}
{"word": ["kill"], "author": "Niggles"}
{"word": ["Hitman."], "author": "tarangwydion"}
{"word": ["Bald"], "author": "icepowdah"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Powers!"], "author": "SlappyBag"}
{"word": [], "author": "Stuff"}
{"word": ["Mission."], "author": "ExecB5"}
{"word": ["complete"], "author": "PandaLiang"}
{"word": ["Onwards!"], "author": "SlappyBag"}
{"word": ["Rewards"], "author": "ExecB5"}
{"word": ["rich"], "author": "Niggles"}
{"word": ["Filthy."], "author": "tarangwydion"}
{"word": ["Dust"], "author": "HuntingNoob"}
{"word": ["dirt"], "author": "Niggles"}
{"word": ["Dirty"], "author": "ExecB5"}
{"word": ["Laundry"], "author": "Lou"}
{"word": [], "author": "Stuff"}
{"word": ["Mafia"], "author": "SlappyBag"}
{"word": ["Family"], "author": "Detlik"}
{"word": ["Important"], "author": "grinninglich"}
{"word": ["information"], "author": "Niggles"}
{"word": [" Database"], "author": "Shadyhacker"}
{"word": ["Oracle."], "author": "tarangwydion"}
{"word": ["Matrix"], "author": "SlappyBag"}
{"word": ["algebra"], "author": "PandaLiang"}
{"word": ["Yuck"], "author": "Niggles"}
{"word": ["Disgust."], "author": "tarangwydion"}
{"word": ["Masturbation"], "author": "Shadyhacker"}
{"word": ["Blindness"], "author": "4gamin"}
{"word": ["Useless"], "author": "SlappyBag"}
{"word": ["Waste."], "author": "tarangwydion"}
{"word": ["Water"], "author": "ExecB5"}
{"word": ["oxygen"], "author": "Niggles"}
{"word": ["Plants"], "author": "SlappyBag"}
{"word": ["zombie"], "author": "PandaLiang"}
{"word": ["brains"], "author": "Niggles"}
{"word": ["Brainiac."], "author": "tarangwydion"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Spider"], "author": "ExecB5"}
{"word": ["Exile"], "author": "PandaLiang"}
{"word": ["Banish"], "author": "Stuff"}
{"word": ["Demon"], "author": "Artemis_E"}
{"word": ["Azazel"], "author": "Lou"}
{"word": ["God"], "author": "SlappyBag"}
{"word": ["Good."], "author": "tarangwydion"}
{"word": ["evil"], "author": "Niggles"}
{"word": ["Twin"], "author": "maycett"}
{"word": ["Paternal"], "author": "Niggles"}
{"word": ["Bond."], "author": "tarangwydion"}
{"word": ["hydrogen"], "author": "PandaLiang"}
{"word": ["Oxygen"], "author": "ExecB5"}
{"word": ["Diatomic"], "author": "Dischord"}
{"word": ["Dexter."], "author": "SLVPRO"}
{"word": ["Fletcher"], "author": "Pwncracker"}
{"word": ["Detective"], "author": "SlappyBag"}
{"word": ["Defective!"], "author": "Fever_Discordia"}
{"word": ["Vista"], "author": "GoJays2025"}
{"word": ["Education. ", " ", " * There is this overseas study consultant near where I live called Vista. I choose this one, hence the word \"Education\", and honestly try not to go with the more obvious word \"Sucks\" as in \"Windows Vista sucks\" :-P"], "author": "tarangwydion"}
{"word": ["University"], "author": "Niggles"}
{"word": ["Seminars"], "author": "GoJays2025"}
{"word": ["Boring"], "author": "SlappyBag"}
{"word": ["Drilling"], "author": "Stuff"}
{"word": ["Dentist"], "author": "Lou"}
{"word": ["nurse"], "author": "Niggles"}
{"word": ["shark"], "author": "GoJays2025"}
{"word": ["Helicopter (as in \"Black Shark\")"], "author": "ZPavelZ"}
{"word": ["Whale"], "author": "SlappyBag"}
{"word": ["Blue"], "author": "ExecB5"}
{"word": ["Moon"], "author": "Niggles"}
{"word": ["space"], "author": "l0rdtr3k"}
{"word": ["Lost."], "author": "tarangwydion"}
{"word": ["World"], "author": "Niggles"}
{"word": ["Planet"], "author": "Stuff"}
{"word": ["Pluto?"], "author": "PandaLiang"}
{"word": ["Icey"], "author": "Niggles"}
{"word": ["Alchohol"], "author": "SlappyBag"}
{"word": ["drunk"], "author": "Niggles"}
{"word": ["Master. ", " ", " * as in Drunken Master."], "author": "tarangwydion"}
{"word": ["Po ", " ", " *as in Master Po"], "author": "Stuff"}
{"word": ["PANDA!!!!!!!!!!!!!!!!!!!! ", " ", " This Master Po........."], "author": "PandaLiang"}
{"word": ["Plump (hehehehehe) ;)"], "author": "Niggles"}
{"word": ["Peaches"], "author": "maycett"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Lost"], "author": "Artemis_E"}
{"word": ["found"], "author": "PandaLiang"}
{"word": ["box"], "author": "Detlik"}
{"word": ["Cat"], "author": "maycett"}
{"word": ["Dog"], "author": "ExecB5"}
{"word": [" Bone"], "author": "Artemis_E"}
{"word": ["Body"], "author": "ExecB5"}
{"word": ["Corpus"], "author": "Dischord"}
{"word": ["Christi. ", " ", " * don't know any other word that goes with Corpus, so Christi it is."], "author": "tarangwydion"}
{"word": ["Girl"], "author": "SlappyBag"}
{"word": ["Lesbian"], "author": "Niggles"}
{"word": ["Thirteen"], "author": "Lou"}
{"word": ["Lolicon"], "author": "Artemis_E"}
{"word": ["Prison"], "author": "HuntingNoob"}
{"word": ["rape"], "author": "Shadyhacker"}
{"word": ["illegal"], "author": "SlappyBag"}
{"word": ["drugs"], "author": "Niggles"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Clone"], "author": "Lou"}
{"word": ["Copy"], "author": "Nel-A"}
{"word": ["Paste"], "author": "Stuff"}
{"word": ["Delete"], "author": "Niggles"}
{"word": ["Vanish"], "author": "NoH"}
{"word": ["Spanish"], "author": "Pwncracker"}
{"word": ["Paella"], "author": "Niggles"}
{"word": ["Polenta"], "author": "4gamin"}
{"word": ["Mediterranean"], "author": "park_84"}
{"word": ["Delicous"], "author": "SlappyBag"}
{"word": ["Tasty. ", " ", " * I assume you meant \"delicious\""], "author": "tarangwydion"}
{"word": ["Pizza"], "author": "Niggles"}
{"word": ["Italy"], "author": "l0rdtr3k"}
{"word": ["pasta"], "author": "Niggles"}
{"word": ["Fasta"], "author": "maycett"}
{"word": ["Fiesta"], "author": "Lou"}
{"word": ["Steak."], "author": "tarangwydion"}
{"word": ["Potatoes"], "author": "Niggles"}
{"word": ["Harvest"], "author": "HuntingNoob"}
{"word": ["Moon"], "author": "Stuff"}
{"word": [], "author": "park_84"}
{"word": ["Hitler"], "author": "Arianus.836"}
{"word": ["Heimlich"], "author": "DieRuhe"}
{"word": ["Choking"], "author": "Arianus.836"}
{"word": ["throat"], "author": "Niggles"}
{"word": ["Infection."], "author": "CaptainAppleMan"}
{"word": ["Outbreak."], "author": "tarangwydion"}
{"word": ["Virus"], "author": "Niggles"}
{"word": ["rabies"], "author": "PandaLiang"}
{"word": ["Insane"], "author": "SlappyBag"}
{"word": ["Brain"], "author": "HuntingNoob"}
{"word": ["Cell."], "author": "CaptainAppleMan"}
{"word": ["Prison"], "author": "Stuff"}
{"word": ["Ministry"], "author": "Lou"}
{"word": ["Science"], "author": "Niggles"}
{"word": ["Aperture"], "author": "SlappyBag"}
{"word": ["optics"], "author": "PandaLiang"}
{"word": ["fiber"], "author": "Pwncracker"}
{"word": ["Light"], "author": "park_84"}
{"word": ["saber"], "author": "Niggles"}
{"word": ["tiger"], "author": "park_84"}
{"word": ["Shark"], "author": "Pocketim"}
{"word": ["infested"], "author": "Runningniko"}
{"word": ["Rats"], "author": "HuntingNoob"}
{"word": ["Cheese"], "author": "SlappyBag"}
{"word": ["Wiz"], "author": "Lou"}
{"word": ["Wizard."], "author": "tarangwydion"}
{"word": ["Bard"], "author": "Niggles"}
{"word": ["Wily"], "author": "sgtlumpy"}
{"word": ["Cayote"], "author": "Nel-A"}
{"word": ["Slapstick."], "author": "CaptainAppleMan"}
{"word": ["comedy"], "author": "the_bard"}
{"word": [" Chaplin"], "author": "Arianus.836"}
{"word": ["Priest"], "author": "SaraB123"}
{"word": [" Choir"], "author": "Arianus.836"}
{"word": ["band"], "author": "the_bard"}
{"word": ["Drummer"], "author": "HuntingNoob"}
{"word": [" Snare"], "author": "Arianus.836"}
{"word": ["Trap"], "author": "Niggles"}
{"word": [" Entrapment"], "author": "Arianus.836"}
{"word": ["Gnome"], "author": "Artemis_E"}
{"word": [" Dwarf"], "author": "Arianus.836"}
{"word": ["Forge"], "author": "the_bard"}
{"word": [" Metallurgist"], "author": "Arianus.836"}
{"word": ["Alloys."], "author": "tarangwydion"}
{"word": ["Metal"], "author": "ExecB5"}
{"word": ["Gear"], "author": "Lou"}
{"word": [". ", " ", " * I never play that game, but it's the first thing that comes to mind with the word \"gear\", which of course also shows that I never play Metal Gear Solid :-)"], "author": "tarangwydion"}
{"word": ["Perfect"], "author": "Artemis_E"}
{"word": ["Dark"], "author": "Niggles"}
{"word": ["Ages"], "author": "the_bard"}
{"word": ["Sega"], "author": "Nel-A"}
{"word": ["Sonic"], "author": "Niggles"}
{"word": ["decadence"], "author": "park_84"}
{"word": ["rome"], "author": "Niggles"}
{"word": ["catacombs"], "author": "the_bard"}
{"word": ["Tomb"], "author": "SlappyBag"}
{"word": ["Lara"], "author": "park_84"}
{"word": ["Boobs"], "author": "Niggles"}
{"word": ["Nipples."], "author": "tarangwydion"}
{"word": [], "author": "Lou"}
{"word": ["Stupid"], "author": "Niggles"}
{"word": [" Spears"], "author": "Arianus.836"}
{"word": ["Phalanx"], "author": "Dischord"}
{"word": ["Attack"], "author": "Lou"}
{"word": [" Fight"], "author": "the_bard"}
{"word": ["Club"], "author": "ExecB5"}
{"word": ["Sandwich."], "author": "CaptainAppleMan"}
{"word": ["olive"], "author": "the_bard"}
{"word": ["Garden."], "author": "CaptainAppleMan"}
{"word": ["Secret."], "author": "tarangwydion"}
{"word": ["Mysterious"], "author": "SlappyBag"}
{"word": ["Enigmatic"], "author": "TrollumThinks"}
{"word": ["Goatee."], "author": "tarangwydion"}
{"word": ["mohawk"], "author": "Niggles"}
{"word": ["Rebellious"], "author": "SlappyBag"}
{"word": ["punk"], "author": "Niggles"}
{"word": ["Cyber."], "author": "tarangwydion"}
{"word": ["hacker"], "author": "SlappyBag"}
{"word": ["."], "author": "tarangwydion"}
{"word": [" New"], "author": "the_bard"}
{"word": ["old"], "author": "Niggles"}
{"word": [" Aged"], "author": "the_bard"}
{"word": ["Wine"], "author": "bsu"}
{"word": ["Mac"], "author": "Lou"}
{"word": [" big"], "author": "the_bard"}
{"word": ["boobs"], "author": "Niggles"}
{"word": ["sell"], "author": "the_bard"}
{"word": ["Sales."], "author": "tarangwydion"}
{"word": ["Customers"], "author": "HuntingNoob"}
{"word": [" Addicts"], "author": "the_bard"}
{"word": [" Druggy."], "author": "sloganvirst"}
{"word": ["needles"], "author": "Niggles"}
{"word": ["Spruce"], "author": "Artemis_E"}
{"word": ["clean"], "author": "SlappyBag"}
{"word": ["House"], "author": "AegisRunestone"}
{"word": ["Full."], "author": "tarangwydion"}
{"word": ["glass"], "author": "Niggles"}
{"word": ["House. ", " ", " * coming full circle, eh? :-)"], "author": "tarangwydion"}
{"word": ["Gregory"], "author": "Lou"}
{"word": ["Peck ", " ", " ", "/"], "author": "ExecB5"}
{"word": ["wood"], "author": "the_bard"}
{"word": ["chuck"], "author": "Niggles"}
{"word": ["throw"], "author": "sgtlumpy"}
{"word": ["Toss"], "author": "liamlemon7"}
{"word": ["wank"], "author": "the_bard"}
{"word": ["sperm"], "author": "Niggles"}
{"word": ["Whale."], "author": "tarangwydion"}
{"word": ["Blubber"], "author": "Niggles"}
{"word": ["Cry"], "author": "sloganvirst"}
{"word": ["Tears"], "author": "Lou"}
{"word": ["Fears"], "author": "TrollumThinks"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Waker"], "author": "AegisRunestone"}
{"word": ["Sleeper"], "author": "Niggles"}
{"word": ["Oversleep"], "author": "HuntingNoob"}
{"word": ["Overlord"], "author": "TrollumThinks"}
{"word": [". ", " ", " * My aging laptop is sadly not powerful enough to play that game."], "author": "tarangwydion"}
{"word": ["Onions"], "author": "Lou"}
{"word": ["cry"], "author": "Niggles"}
{"word": ["Fry"], "author": "ExecB5"}
{"word": ["Friday"], "author": "almabrds"}
{"word": ["Saturday"], "author": "Niggles"}
{"word": ["Night."], "author": "tarangwydion"}
{"word": ["Live."], "author": "spindown"}
{"word": ["Dead"], "author": "Niggles"}
{"word": ["Drop."], "author": "tarangwydion"}
{"word": ["Kick"], "author": "Niggles"}
{"word": ["ass"], "author": "the_bard"}
{"word": ["Pants"], "author": "almabrds"}
{"word": ["wet"], "author": "Niggles"}
{"word": ["Moist"], "author": "ExecB5"}
{"word": ["p... ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " u... ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " dding"], "author": "the_bard"}
{"word": ["Flan"], "author": "ExecB5"}
{"word": ["Calmness"], "author": "almabrds"}
{"word": ["RAPE"], "author": "SlappyBag"}
{"word": ["Victim."], "author": "tarangwydion"}
{"word": ["Trap"], "author": "almabrds"}
{"word": ["Hunter"], "author": "ExecB5"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Rolled"], "author": "Lou"}
{"word": ["Sushi"], "author": "PandaLiang"}
{"word": ["Fish"], "author": "Niggles"}
{"word": ["Sheep"], "author": "drevo2"}
{"word": ["Shepard"], "author": "Lou"}
{"word": ["Staff"], "author": "ExecB5"}
{"word": ["Wizard"], "author": "the_bard"}
{"word": ["Fireball"], "author": "Niggles"}
{"word": ["Jackson"], "author": "Leroux"}
{"word": ["Legend"], "author": "HuntingNoob"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["GOG"], "author": "PandaLiang"}
{"word": ["gag"], "author": "drevo2"}
{"word": ["Reflex"], "author": "the_bard"}
{"word": ["neuron"], "author": "PandaLiang"}
{"word": ["Brain"], "author": "ExecB5"}
{"word": ["Pinky"], "author": "Lou"}
{"word": ["Kiss"], "author": "Psyringe"}
{"word": ["Thunder"], "author": "the_bard"}
{"word": ["AC/DC"], "author": "icepowdah"}
{"word": ["Current."], "author": "tarangwydion"}
{"word": ["curren$y"], "author": "SlappyBag"}
{"word": ["peso"], "author": "Niggles"}
{"word": ["Argentina"], "author": "HuntingNoob"}
{"word": ["Cristina (Fern\u00e1ndez de Kirchner)"], "author": "almabrds"}
{"word": ["Female"], "author": "ExecB5"}
{"word": ["Warrior."], "author": "tarangwydion"}
{"word": ["Mars"], "author": "the_bard"}
{"word": ["Bar"], "author": "Niggles"}
{"word": ["Alcohol"], "author": "Nel-A"}
{"word": ["Moonshine"], "author": "the_bard"}
{"word": ["Jug"], "author": "Niggles"}
{"word": ["Container."], "author": "tarangwydion"}
{"word": ["toxic"], "author": "the_bard"}
{"word": ["avenger"], "author": "DieRuhe"}
{"word": ["mop"], "author": "the_bard"}
{"word": ["bucket"], "author": "TrollumThinks"}
{"word": ["list"], "author": "the_bard"}
{"word": ["form"], "author": "sloganvirst"}
{"word": ["mold"], "author": "the_bard"}
{"word": ["Fungus"], "author": "SlappyBag"}
{"word": ["Spore"], "author": "Lou"}
{"word": ["Fern"], "author": "Dischord"}
{"word": ["Plant"], "author": "almabrds"}
{"word": ["wood"], "author": "PandaLiang"}
{"word": ["pizza"], "author": "CaptainGyro"}
{"word": ["italy"], "author": "Niggles"}
{"word": ["Rome"], "author": "Dischord"}
{"word": ["Sodomy"], "author": "michaelleung"}
{"word": ["Horse"], "author": "spindown"}
{"word": ["Poo"], "author": "Niggles"}
{"word": ["Fly"], "author": "almabrds"}
{"word": ["Levitate"], "author": "Lou"}
{"word": ["Ascend"], "author": "Dischord"}
{"word": ["Descend"], "author": "ExecB5"}
{"word": ["Down."], "author": "tarangwydion"}
{"word": ["depressing"], "author": "Niggles"}
{"word": ["Uplifting"], "author": "Dischord"}
{"word": ["Boner"], "author": "SlappyBag"}
{"word": ["Donor"], "author": "drevo2"}
{"word": ["Blood"], "author": "almabrds"}
{"word": ["Twilight"], "author": "SlappyBag"}
{"word": ["Zone"], "author": "Niggles"}
{"word": ["Safety."], "author": "tarangwydion"}
{"word": ["Bunker"], "author": "almabrds"}
{"word": ["Guns"], "author": "Niggles"}
{"word": ["Glory"], "author": "the_bard"}
{"word": ["Quest. ", " ", " * Quest for Glory, of course."], "author": "tarangwydion"}
{"word": ["Champion"], "author": "Lou"}
{"word": ["Norrath"], "author": "almabrds"}
{"word": ["crap"], "author": "Niggles"}
{"word": ["crab"], "author": "PandaLiang"}
{"word": [], "author": "HampsterStyle"}
{"word": ["seafood"], "author": "Niggles"}
{"word": ["Platter."], "author": "tarangwydion"}
{"word": ["pupu"], "author": "spindown"}
{"word": ["Alien. ", " ", " ", " ", " (...because I THINK that's also the name of the alien in FFVIII, isn't it?)"], "author": "Cyridia"}
{"word": ["Legal. ", " ", " * With Sting's voice singing, \"I'm an alien, I'm a legal alien. I'm an Englishman in New York...\""], "author": "tarangwydion"}
{"word": ["Lego"], "author": "PandaLiang"}
{"word": ["Bricks"], "author": "almabrds"}
{"word": ["Builders"], "author": "michaelleung"}
{"word": ["Hammerites."], "author": "tarangwydion"}
{"word": ["Nail"], "author": "SlappyBag"}
{"word": ["Jesus ", " ", " Sorry, this was to tempting :P"], "author": "storn"}
{"word": ["Wall"], "author": "Niggles"}
{"word": ["Communists"], "author": "michaelleung"}
{"word": [], "author": "HampsterStyle"}
{"word": ["wasp"], "author": "kmonster"}
{"word": ["Honey."], "author": "tarangwydion"}
{"word": ["comb"], "author": "the_bard"}
{"word": ["jelly"], "author": "Niggles"}
{"word": ["Bean"], "author": "Cyridia"}
{"word": ["Mr."], "author": "Lou"}
{"word": [" :P"], "author": "HampsterStyle"}
{"word": ["Missis"], "author": "kmonster"}
{"word": ["Lesbians"], "author": "michaelleung"}
{"word": ["Hot"], "author": "Niggles"}
{"word": ["cold"], "author": "lightfoot8"}
{"word": ["Nipples"], "author": "FraterPerdurabo"}
{"word": ["inverted"], "author": "Rohan15"}
{"word": ["Bob"], "author": "SlappyBag"}
{"word": ["Uncle"], "author": "FraterPerdurabo"}
{"word": ["Cry"], "author": "lightfoot8"}
{"word": ["whiners"], "author": "spindown"}
{"word": ["losers"], "author": "Rohan15"}
{"word": ["Sore."], "author": "tarangwydion"}
{"word": ["Spore"], "author": "ExecB5"}
{"word": ["shroom"], "author": "the_bard"}
{"word": ["Dwarves"], "author": "Tulivu"}
{"word": ["Gimli"], "author": "Lou"}
{"word": ["Axe"], "author": "ExecB5"}
{"word": ["Golden"], "author": "the_bard"}
{"word": ["pee"], "author": "SlappyBag"}
{"word": ["warm"], "author": "the_bard"}
{"word": ["hot"], "author": "kmonster"}
{"word": ["Pink"], "author": "lightfoot8"}
{"word": ["Panther"], "author": "Nel-A"}
{"word": ["Cat"], "author": "Niggles"}
{"word": ["People."], "author": "tarangwydion"}
{"word": ["Bipedal"], "author": "Dischord"}
{"word": ["Barney."], "author": "tarangwydion"}
{"word": ["Fred"], "author": "almabrds"}
{"word": ["Flint ", " ", " (edit as ninja'd)"], "author": "TrollumThinks"}
{"word": ["Wilma!"], "author": "the_bard"}
{"word": ["Dino"], "author": "Zangtesu"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Goalkeeper"], "author": "Zangtesu"}
{"word": ["Football"], "author": "Niggles"}
{"word": ["Tournament"], "author": "OrionKai"}
{"word": ["Planescape"], "author": "kmonster"}
{"word": ["Cutter"], "author": "Leroux"}
{"word": ["emo"], "author": "the_bard"}
{"word": ["Vampires"], "author": "OrionKai"}
{"word": ["exwife"], "author": "park_84"}
{"word": ["annulling"], "author": "lightfoot8"}
{"word": ["freedom"], "author": "OrionKai"}
{"word": ["illusion"], "author": "agogfan"}
{"word": ["mirror"], "author": "the_bard"}
{"word": ["reflection"], "author": "Lou"}
{"word": ["past"], "author": "OrionKai"}
{"word": ["Future"], "author": "Zangtesu"}
{"word": ["no"], "author": "amok"}
{"word": ["way"], "author": "the_bard"}
{"word": ["bread"], "author": "lightfoot8"}
{"word": ["dough"], "author": "the_bard"}
{"word": ["nut"], "author": "park_84"}
{"word": ["Wangs"], "author": "michaelleung"}
{"word": ["Douche ^"], "author": "Rohan15"}
{"word": ["Baggins"], "author": "Leroux"}
{"word": ["Bilbo"], "author": "OrionKai"}
{"word": ["Smaug"], "author": "SimpleUser"}
{"word": ["Pokemon"], "author": "SlappyBag"}
{"word": ["pok-e-who-tes"], "author": "lightfoot8"}
{"word": ["Pocahontas"], "author": "the_bard"}
{"word": ["John"], "author": "Zangtesu"}
{"word": ["Wayne"], "author": "the_bard"}
{"word": ["Gacy"], "author": "Lou"}
{"word": ["jr."], "author": "OrionKai"}
{"word": ["Mr."], "author": "almabrds"}
{"word": ["Bean"], "author": "the_bard"}
{"word": ["Mexico"], "author": "SlappyBag"}
{"word": ["Immigrants"], "author": "michaelleung"}
{"word": ["wizardry"], "author": "kmonster"}
{"word": ["ultima"], "author": "pingu53"}
{"word": ["Underworld."], "author": "tarangwydion"}
{"word": ["Darkness"], "author": "Rohan15"}
{"word": ["Light"], "author": "Niggles"}
{"word": ["Electricity"], "author": "storn"}
{"word": ["Pikachu"], "author": "Zangtesu"}
{"word": ["Yellow."], "author": "tarangwydion"}
{"word": ["Gold"], "author": "almabrds"}
{"word": ["watch"], "author": "Suzaku-sama"}
{"word": ["out"], "author": "PandaLiang"}
{"word": ["Gay"], "author": "michaelleung"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Zorro."], "author": "opoterser"}
{"word": ["Tits"], "author": "SlappyBag"}
{"word": ["fits"], "author": "kmonster"}
{"word": ["epilepsy"], "author": "OrionKai"}
{"word": ["electroencephalogram"], "author": "Dischord"}
{"word": ["Supercalifragilisticexpialidocious"], "author": "Lou"}
{"word": ["Pneumonoultramicroscopicsilicovolcanoconiosis"], "author": "michaelleung"}
{"word": [], "author": "the_bard"}
{"word": ["Llanfairpwllgwyngyllgogerychwyrndrobwllllantysiliogogogoch"], "author": "Lou"}
{"word": [], "author": "the_bard"}
{"word": ["Nothing"], "author": "ExecB5"}
{"word": ["invisible"], "author": "the_bard"}
{"word": ["Transparent"], "author": "Lou"}
{"word": ["Glass"], "author": "almabrds"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Stephen :B"], "author": "F4LL0UT"}
{"word": ["Old ;)"], "author": "Niggles"}
{"word": ["Spice"], "author": "the_bard"}
{"word": ["Islands"], "author": "Dischord"}
{"word": ["Zombie"], "author": "SlappyBag"}
{"word": ["Dead"], "author": "Rohan15"}
{"word": ["Grateful"], "author": "the_bard"}
{"word": ["selfish"], "author": "Niggles"}
{"word": ["gene"], "author": "spindown"}
{"word": ["Machine."], "author": "tarangwydion"}
{"word": ["Green"], "author": "the_bard"}
{"word": ["Grass"], "author": "Leroux"}
{"word": ["high"], "author": "the_bard"}
{"word": ["happy"], "author": "Niggles"}
{"word": ["Hahahahaha"], "author": "PandaLiang"}
{"word": ["maniacal"], "author": "TrollumThinks"}
{"word": ["crazy"], "author": "Niggles"}
{"word": ["mofo"], "author": "spindown"}
{"word": ["Bamf"], "author": "OrangeTicTacs"}
{"word": ["fu"], "author": "the_bard"}
{"word": ["kung"], "author": "kmonster"}
{"word": ["lao"], "author": "OrionKai"}
{"word": ["china"], "author": "SlappyBag"}
{"word": ["Japan"], "author": "OrionKai"}
{"word": ["saki"], "author": "Niggles"}
{"word": ["Miyanaga"], "author": "Lou"}
{"word": ["naga"], "author": "kmonster"}
{"word": ["water"], "author": "axakovec"}
{"word": ["Witch"], "author": "the_bard"}
{"word": ["warlock"], "author": "OrionKai"}
{"word": [], "author": "HampsterStyle"}
{"word": ["pledge"], "author": "drevo2"}
{"word": ["Clean"], "author": "SlappyBag"}
{"word": ["Sheet."], "author": "tarangwydion"}
{"word": ["rain"], "author": "the_bard"}
{"word": ["Thunder"], "author": "Lou"}
{"word": ["Lightning"], "author": "Zangtesu"}
{"word": ["Zeus"], "author": "Rohan15"}
{"word": ["thunderbringer"], "author": "axakovec"}
{"word": ["flatulence"], "author": "moderately_neeto"}
{"word": ["turbulence"], "author": "kmonster"}
{"word": ["Plane"], "author": "Tiefood"}
{"word": ["Da."], "author": "the_bard"}
{"word": ["Yes"], "author": "Dischord"}
{"word": ["indeed"], "author": "OrionKai"}
{"word": ["Exactamundo!"], "author": "SlappyBag"}
{"word": [], "author": "HampsterStyle"}
{"word": ["no comprende"], "author": "moderately_neeto"}
{"word": ["Huh?"], "author": "OrionKai"}
{"word": ["What?"], "author": "tarangwydion"}
{"word": ["Say"], "author": "Lou"}
{"word": ["what"], "author": "kmonster"}
{"word": ["chicken butt"], "author": "moderately_neeto"}
{"word": ["^ OOPS"], "author": "Lou"}
{"word": ["Bazinga"], "author": "Zangtesu"}
{"word": ["SHELDON!!!!"], "author": "OrionKai"}
{"word": ["mister"], "author": "axakovec"}
{"word": ["Miser"], "author": "Nel-A"}
{"word": ["Scrooge"], "author": "Lou"}
{"word": ["Ghost"], "author": "SlappyBag"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Love"], "author": "ExecB5"}
{"word": ["Subjective"], "author": "Dischord"}
{"word": ["objective"], "author": "Niggles"}
{"word": ["completed"], "author": "OrionKai"}
{"word": ["Finished."], "author": "tarangwydion"}
{"word": ["Finito!"], "author": "Zangtesu"}
{"word": ["Bandito"], "author": "Lou"}
{"word": ["Frito"], "author": "Dischord"}
{"word": ["tortilla"], "author": "the_bard"}
{"word": ["salsa"], "author": "Moffatclan"}
{"word": ["Latinas!!!!"], "author": "OrionKai"}
{"word": ["Sexy"], "author": "Rohan15"}
{"word": ["catwoman"], "author": "axakovec"}
{"word": ["meow"], "author": "the_bard"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Jedi"], "author": "SlappyBag"}
{"word": ["sith"], "author": "axakovec"}
{"word": ["saber"], "author": "dragonbeast"}
{"word": ["Tooth"], "author": "the_bard"}
{"word": ["tiger"], "author": "OrionKai"}
{"word": ["Stripe"], "author": "moderately_neeto"}
{"word": ["Star"], "author": "kmonster"}
{"word": ["Trek"], "author": "Moffatclan"}
{"word": ["Bicycle."], "author": "tarangwydion"}
{"word": ["tour"], "author": "the_bard"}
{"word": ["Bus"], "author": "Leroux"}
{"word": ["road"], "author": "the_bard"}
{"word": ["congestion"], "author": "michaelleung"}
{"word": ["pollution"], "author": "Niggles"}
{"word": ["Ozone"], "author": "OrionKai"}
{"word": ["earth"], "author": "axakovec"}
{"word": ["home"], "author": "OrionKai"}
{"word": ["boy"], "author": "Leroux"}
{"word": ["girl"], "author": "Niggles"}
{"word": ["Wonder."], "author": "tarangwydion"}
{"word": ["why"], "author": "the_bard"}
{"word": ["because"], "author": "Moffatclan"}
{"word": ["reason"], "author": "axakovec"}
{"word": ["lie"], "author": "Niggles"}
{"word": ["where"], "author": "kmonster"}
{"word": ["wolf"], "author": "Leroux"}
{"word": ["wang"], "author": "SlappyBag"}
{"word": ["boner ;)"], "author": "Niggles"}
{"word": ["beach"], "author": "axakovec"}
{"word": ["babes"], "author": "Niggles"}
{"word": ["females"], "author": "dragonbeast"}
{"word": ["Shopping"], "author": "almabrds"}
{"word": ["clich\u00e9"], "author": "Leroux"}
{"word": ["Generic"], "author": "ExecB5"}
{"word": ["cleric"], "author": "kmonster"}
{"word": ["Heal"], "author": "SlappyBag"}
{"word": ["priest"], "author": "axakovec"}
{"word": ["catholic"], "author": "dragonbeast"}
{"word": ["hindu"], "author": "Niggles"}
{"word": [". ", " ", " * sorry, but Hindu dagger in Tintin is the first thing that comes to mind, although it is actually not a kukri but a ", "."], "author": "tarangwydion"}
{"word": ["Blade"], "author": "Stuff"}
{"word": ["Vampire"], "author": "Zangtesu"}
{"word": ["twilight"], "author": "SlappyBag"}
{"word": ["vomit"], "author": "OrionKai"}
{"word": ["gag"], "author": "moderately_neeto"}
{"word": ["maggot"], "author": "the_bard"}
{"word": ["Fly"], "author": "Stuff"}
{"word": ["ugly"], "author": "axakovec"}
{"word": ["you"], "author": "SlappyBag"}
{"word": ["pronoun"], "author": "Dischord"}
{"word": ["now"], "author": "kmonster"}
{"word": ["tomorrow"], "author": "Niggles"}
{"word": ["Better."], "author": "tarangwydion"}
{"word": ["ameliorate"], "author": "Lou"}
{"word": ["progression"], "author": "OrionKai"}
{"word": ["evolution"], "author": "axakovec"}
{"word": ["Catastrophe"], "author": "almabrds"}
{"word": ["Earthquake"], "author": "somegamer786.960"}
{"word": ["Typhoon"], "author": "Stuff"}
{"word": ["Cyclone"], "author": "Lou"}
{"word": ["Hurricane"], "author": "somegamer786.960"}
{"word": ["Dylan"], "author": "Dischord"}
{"word": ["Name"], "author": "somegamer786.960"}
{"word": ["meow"], "author": "kmonster"}
{"word": ["pussy"], "author": "Niggles"}
{"word": ["cat"], "author": "axakovec"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Comic"], "author": "somegamer786.960"}
{"word": ["funny"], "author": "Niggles"}
{"word": [], "author": "Stuff"}
{"word": ["Comfertable"], "author": "somegamer786.960"}
{"word": ["fart"], "author": "kmonster"}
{"word": ["Eww"], "author": "somegamer786.960"}
{"word": ["Vomit"], "author": "somegamer786.960"}
{"word": ["spit"], "author": "Leroux"}
{"word": ["Blood"], "author": "almabrds"}
{"word": ["Liquid"], "author": "somegamer786.960"}
{"word": ["viscosity"], "author": "SlappyBag"}
{"word": ["Resistance"], "author": "somegamer786.960"}
{"word": ["Futility"], "author": "Lou"}
{"word": ["Useless"], "author": "somegamer786.960"}
{"word": ["full"], "author": "kmonster"}
{"word": ["Blown."], "author": "tarangwydion"}
{"word": ["Mind"], "author": "spindown"}
{"word": ["Matter"], "author": "Niggles"}
{"word": ["Mass"], "author": "johnny_gog"}
{"word": ["Ass"], "author": "SlappyBag"}
{"word": ["Donkey"], "author": "spindown"}
{"word": ["Kong"], "author": "Niggles"}
{"word": ["King"], "author": "axakovec"}
{"word": ["Cobra"], "author": "Stuff"}
{"word": ["beer"], "author": "OrionKai"}
{"word": ["Germany ", " ", " (Austria and Denmark also come to mind)"], "author": "Dischord"}
{"word": ["Europe"], "author": "somegamer786.960"}
{"word": ["Folk"], "author": "scriptbr"}
{"word": ["Song"], "author": "somegamer786.960"}
{"word": ["Two"], "author": "Leroux"}
{"word": ["Binary"], "author": "HampsterStyle"}
{"word": ["three"], "author": "kmonster"}
{"word": ["some"], "author": "Leroux"}
{"word": ["ooh"], "author": "dragonbeast"}
{"word": ["YEAH"], "author": "somegamer786.960"}
{"word": ["BABY"], "author": "Niggles"}
{"word": ["DAMN"], "author": "Dischord"}
{"word": ["Dang"], "author": "somegamer786.960"}
{"word": ["Curse"], "author": "somegamer786.960"}
{"word": ["Voodoo"], "author": "Dischord"}
{"word": ["doll"], "author": "Niggles"}
{"word": ["paper"], "author": "kmonster"}
{"word": ["Airplane"], "author": "somegamer786.960"}
{"word": ["Pitch"], "author": "johnny_gog"}
{"word": ["Slow"], "author": "Lou"}
{"word": ["Newt"], "author": "SlappyBag"}
{"word": ["scorpion"], "author": "zestybrick"}
{"word": ["mortal combat"], "author": "axakovec"}
{"word": ["Blood"], "author": "dragonbeast"}
{"word": ["true"], "author": "kmonster"}
{"word": ["lies"], "author": "OrionKai"}
{"word": ["Romney"], "author": "SlappyBag"}
{"word": ["Rooney"], "author": "PandaLiang"}
{"word": ["Sucks"], "author": "Niggles"}
{"word": ["Bus. ", " ", " (A saying, waiting for Rooney's goals is like waiting for buses. They don't come for a long long time, once they come, they come in packs)"], "author": "PandaLiang"}
{"word": ["Succubus. ", " ", " Although technically I was associating the previous two words. Am I disqualified?"], "author": "Loonie"}
{"word": [" brilliant"], "author": "PandaLiang"}
{"word": ["Gleam"], "author": "Lou"}
{"word": ["Eye"], "author": "somegamer786.960"}
{"word": ["tower"], "author": "dragonbeast"}
{"word": ["Crash"], "author": "SlappyBag"}
{"word": ["Airplane"], "author": "somegamer786.960"}
{"word": ["pancake"], "author": "kmonster"}
{"word": ["Yummy"], "author": "somegamer786.960"}
{"word": ["brains"], "author": "the_bard"}
{"word": ["Zombies"], "author": "Zangtesu"}
{"word": ["Triskelion --> Ninja'd"], "author": "Lou"}
{"word": ["Samurai"], "author": "ExecB5"}
{"word": ["Showdown"], "author": "Leroux"}
{"word": ["last"], "author": "kmonster"}
{"word": ["first"], "author": "dragonbeast"}
{"word": ["winner"], "author": "axakovec"}
{"word": ["Lottery"], "author": "Dischord"}
{"word": ["Numbers"], "author": "almabrds"}
{"word": ["Mathematics"], "author": "SlappyBag"}
{"word": ["Boring"], "author": "Niggles"}
{"word": ["Work."], "author": "tarangwydion"}
{"word": ["Profession"], "author": "Lou"}
{"word": ["Biochemist"], "author": "Zangtesu"}
{"word": ["anthrax"], "author": "Niggles"}
{"word": ["Mosh"], "author": "the_bard"}
{"word": ["Pit"], "author": "DCT"}
{"word": ["Spikes"], "author": "almabrds"}
{"word": ["Fatality"], "author": "DCT"}
{"word": ["Babeality"], "author": "OrionKai"}
{"word": ["word?"], "author": "SlappyBag"}
{"word": ["Stupid"], "author": "somegamer786.960"}
{"word": ["Uneducated ", " ", "I know it needs to be one word posts but Babeality is associated fatality due to Mortal Kombat 9, 10, don't care. But it was included in the new Mortal Kombat."], "author": "somegamer786.960"}
{"word": ["crybaby"], "author": "kmonster"}
{"word": ["wah"], "author": "the_bard"}
{"word": ["wha-wha-pedal ", " ", " edit: included - to make into one word, not cheating at all...."], "author": "amok"}
{"word": ["milk"], "author": "Niggles"}
{"word": ["box"], "author": "the_bard"}
{"word": ["Drop."], "author": "tarangwydion"}
{"word": ["Cough"], "author": "Lou"}
{"word": ["splutter"], "author": "OrionKai"}
{"word": ["Splooge"], "author": "SlappyBag"}
{"word": ["Ejaculation"], "author": "ExecB5"}
{"word": ["Sperm"], "author": "somegamer786.960"}
{"word": ["Egg"], "author": "somegamer786.960"}
{"word": ["Ovum"], "author": "Niggles"}
{"word": ["fertilize"], "author": "the_bard"}
{"word": ["conception"], "author": "OrionKai"}
{"word": ["magic"], "author": "axakovec"}
{"word": ["Wizard"], "author": "Stuff"}
{"word": ["harmonica"], "author": "the_bard"}
{"word": ["Western"], "author": "somegamer786.960"}
{"word": ["Eastwood"], "author": "OrionKai"}
{"word": ["Future"], "author": "SlappyBag"}
{"word": ["Rama"], "author": "somegamer786.960"}
{"word": ["SPAM! ", " ", " "], "author": "tarangwydion"}
{"word": ["Wanker"], "author": "Niggles"}
{"word": ["idiot"], "author": "dragonbeast"}
{"word": ["Santorum"], "author": "spindown"}
{"word": ["Desperate"], "author": "Stuff"}
{"word": ["Housewives"], "author": "axakovec"}
{"word": ["soap"], "author": "kmonster"}
{"word": ["shower ;)"], "author": "Niggles"}
{"word": ["song"], "author": "Accatone"}
{"word": ["opera"], "author": "dragonbeast"}
{"word": ["Penguin."], "author": "CaptainAppleMan"}
{"word": ["Linux"], "author": "Tallima"}
{"word": ["Unix"], "author": "the_bard"}
{"word": ["Wrong thread (Shut up about only one word thing) and SPAM. ", " ", "Macintosh"], "author": "somegamer786.960"}
{"word": ["iPod"], "author": "SlappyBag"}
{"word": ["Walkman"], "author": "soavio"}
{"word": ["Sony"], "author": "Niggles"}
{"word": ["playstation"], "author": "Accatone"}
{"word": ["Console."], "author": "tarangwydion"}
{"word": ["Sega"], "author": "Lou"}
{"word": ["Dreamcast"], "author": "the_bard"}
{"word": ["Sonic"], "author": "Accatone"}
{"word": ["BOOM!"], "author": "TrollumThinks"}
{"word": [" _______________________ ", " ", " Sonic is one of the better character . Its really a great character .There are many movies based on this character .I watched them ", " in hd quality . That was quite good experience"], "author": "sabrasmith11"}
{"word": [" ", " . . . =) ", " ", " Bomb"], "author": "Stuff"}
{"word": ["Kick"], "author": "SeaOfInsanity"}
{"word": ["Falcon"], "author": "somegamer786.960"}
{"word": ["Snowman"], "author": "the_bard"}
{"word": ["cool"], "author": "dragonbeast"}
{"word": ["Awesome"], "author": "somegamer786.960"}
{"word": ["Awful"], "author": "almabrds"}
{"word": ["Steelers"], "author": "SlappyBag"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Mommy"], "author": "kmonster"}
{"word": ["Dearest"], "author": "Lou"}
{"word": ["beloved"], "author": "Accatone"}
{"word": ["wife"], "author": "dragonbeast"}
{"word": ["Kitchen"], "author": "SlappyBag"}
{"word": ["prison"], "author": "kmonster"}
{"word": ["Escape"], "author": "somegamer786.960"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Goddess"], "author": "the_bard"}
{"word": ["Destruction"], "author": "Lou"}
{"word": ["Ruins"], "author": "almabrds"}
{"word": ["Applesauce (I don't know, it was the first word that popped into my head. I'm weird)"], "author": "Gazoinks"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Bacon"], "author": "Niggles"}
{"word": ["ribs"], "author": "dragonbeast"}
{"word": [". ", " ", " * DISCLAIMER: not in any way affiliated with the above chained restaurant business. But when I see ribs, that's the first place that comes to mind."], "author": "tarangwydion"}
{"word": ["food"], "author": "Accatone"}
{"word": ["expired"], "author": "dragonbeast"}
{"word": ["gross"], "author": "Niggles"}
{"word": ["Domestic"], "author": "somegamer786.960"}
{"word": ["abuse"], "author": "SlappyBag"}
{"word": ["punch"], "author": "Niggles"}
{"word": ["Hawaiian"], "author": "DoctorButler"}
{"word": ["Magnum"], "author": "Lou"}
{"word": ["weapon"], "author": "Accatone"}
{"word": ["axe"], "author": "dragonbeast"}
{"word": ["grind"], "author": "Niggles"}
{"word": ["MMORPG"], "author": "dragonbeast"}
{"word": ["Aion"], "author": "OrionKai"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Solder"], "author": "OrionKai"}
{"word": ["electronics"], "author": "Niggles"}
{"word": ["electricity"], "author": "igogfg"}
{"word": ["charisma"], "author": "OrionKai"}
{"word": ["social"], "author": "dragonbeast"}
{"word": ["empty"], "author": "dragonbeast"}
{"word": ["Space"], "author": "somegamer786.960"}
{"word": ["Lord"], "author": "the_bard"}
{"word": ["Ozai"], "author": "OrionKai"}
{"word": ["World"], "author": "SlappyBag"}
{"word": ["War"], "author": "somegamer786.960"}
{"word": ["Fallout"], "author": "Gazoinks"}
{"word": ["Nuclear"], "author": "somegamer786.960"}
{"word": ["Bomb"], "author": "somegamer786.960"}
{"word": ["bay"], "author": "OrionKai"}
{"word": ["ship"], "author": "dragonbeast"}
{"word": ["Borialis ", " ", " (Half-Life Reference)"], "author": "somegamer786.960"}
{"word": ["Arctic"], "author": "Raneman25"}
{"word": ["Circle"], "author": "Niggles"}
{"word": ["Sphere"], "author": "somegamer786.960"}
{"word": ["Dragon."], "author": "tarangwydion"}
{"word": ["Dungeon"], "author": "Dischord"}
{"word": ["crawl"], "author": "lightfoot8"}
{"word": ["knee"], "author": "Accatone"}
{"word": ["crossbow"], "author": "dragonbeast"}
{"word": ["huntsman"], "author": "OrionKai"}
{"word": ["deer"], "author": "axakovec"}
{"word": ["gamey"], "author": "Niggles"}
{"word": ["COD"], "author": "somegamer786.960"}
{"word": ["Noobs"], "author": "HampsterStyle"}
{"word": ["omgpwnage"], "author": "dragonbeast"}
{"word": ["PWNAGE"], "author": "somegamer786.960"}
{"word": ["Loser"], "author": "SlappyBag"}
{"word": ["Conquered"], "author": "Stuff"}
{"word": ["Vanquished"], "author": "Dischord"}
{"word": ["Sundered"], "author": "Fumarole"}
{"word": ["France"], "author": "Lou"}
{"word": ["Escargo ;)"], "author": "Niggles"}
{"word": ["peel"], "author": "lightfoot8"}
{"word": ["Out"], "author": "the_bard"}
{"word": ["down"], "author": "bencore88"}
{"word": [" :P"], "author": "HampsterStyle"}
{"word": ["pancake"], "author": "OrionKai"}
{"word": ["Waffle"], "author": "Ultimatum"}
{"word": ["Belgian"], "author": "Lou"}
{"word": ["home"], "author": "dragonbeast"}
{"word": ["...page :)"], "author": "kasieczek"}
{"word": ["GOG.com"], "author": "somegamer786.960"}
{"word": [], "author": "almabrds"}
{"word": ["Fake"], "author": "somegamer786.960"}
{"word": ["silicone"], "author": "Fumarole"}
{"word": ["Silicon"], "author": "somegamer786.960"}
{"word": [], "author": "HampsterStyle"}
{"word": ["Modulating"], "author": "lightfoot8"}
{"word": ["Modulator"], "author": "SweenMachine"}
{"word": ["Amplitude"], "author": "Nightfall87"}
{"word": ["Airplane"], "author": "SlappyBag"}
{"word": ["Crash"], "author": "Niggles"}
{"word": ["BSOD."], "author": "tarangwydion"}
{"word": ["BDSM ", " ", " I have no idea what bsod means, but the letters reminded me of that."], "author": "ExecB5"}
{"word": ["Erotic. ", " ", " * BSOD: "], "author": "tarangwydion"}
{"word": ["searching!"], "author": "OrionKai"}
{"word": ["net"], "author": "Accatone"}
{"word": ["fish"], "author": "dragonbeast"}
{"word": ["Aquatic"], "author": "Stuff"}
{"word": ["life"], "author": "park_84"}
{"word": ["Zissou"], "author": "SweenMachine"}
{"word": ["Adidas"], "author": "somegamer786.960"}
{"word": ["Trainers."], "author": "Ultimatum"}
{"word": ["Pokemon"], "author": "somegamer786.960"}
{"word": ["Game"], "author": "somegamer786.960"}
{"word": ["boy"], "author": "Fumarole"}
{"word": ["girl"], "author": "F4LL0UT"}
{"word": ["kitchen"], "author": "SlappyBag"}
{"word": ["Chef."], "author": "tarangwydion"}
{"word": ["Dinner"], "author": "Elenarie"}
{"word": ["date"], "author": "the_bard"}
{"word": ["puffins"], "author": "Kynes"}
{"word": ["fish"], "author": "duffymoon"}
{"word": ["shark"], "author": "ExecB5"}
{"word": [], "author": "HampsterStyle"}
{"word": ["jumpstyle"], "author": "axakovec"}
{"word": ["parkour"], "author": "OrionKai"}
{"word": ["Batman."], "author": "Luckmann"}
{"word": ["robin"], "author": "Accatone"}
{"word": ["arrows"], "author": "dragonbeast"}
{"word": ["Elf"], "author": "SlappyBag"}
{"word": ["Christmas"], "author": "somegamer786.960"}
{"word": ["Shopping."], "author": "Ultimatum"}
{"word": ["women"], "author": "the_bard"}
{"word": ["flowers"], "author": "Elenarie"}
{"word": ["Thorns"], "author": "somegamer786.960"}
{"word": ["Rose"], "author": "Lou"}
{"word": ["Bush"], "author": "somegamer786.960"}
{"word": ["trim"], "author": "the_bard"}
{"word": ["Space."], "author": "tarangwydion"}
{"word": ["Portal"], "author": "axakovec"}
{"word": ["Guardian"], "author": "Lou"}
{"word": ["Angel."], "author": "tarangwydion"}
{"word": ["Wings"], "author": "TrollumThinks"}
{"word": ["dragons"], "author": "dragonbeast"}
{"word": ["born"], "author": "SlappyBag"}
{"word": ["First."], "author": "tarangwydion"}
{"word": ["of"], "author": "the_bard"}
{"word": ["the"], "author": "bencore88"}
{"word": ["how"], "author": "Niggles"}
{"word": ["owl"], "author": "Accatone"}
{"word": ["prowl"], "author": "OrionKai"}
{"word": ["Bengal"], "author": "SlappyBag"}
{"word": ["Tiger"], "author": "SapphireBullets"}
{"word": ["cat"], "author": "dragonbeast"}
{"word": ["stalk"], "author": "the_bard"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Road"], "author": "somegamer786.960"}
{"word": ["Street"], "author": "ExecB5"}
{"word": ["Trash"], "author": "the_bard"}
{"word": ["Grouch"], "author": "SapphireBullets"}
{"word": ["Bins"], "author": "Ultimatum"}
{"word": ["Recycling"], "author": "Stuff"}
{"word": ["Triangle"], "author": "SapphireBullets"}
{"word": ["Bermuda"], "author": "SlappyBag"}
{"word": ["Beach"], "author": "Niggles"}
{"word": ["sand"], "author": "dragonbeast"}
{"word": ["sea"], "author": "Ultimatum"}
{"word": ["Monkeys"], "author": "Lou"}
{"word": ["Bananas"], "author": "Elenarie"}
{"word": ["Go."], "author": "tarangwydion"}
{"word": ["Order"], "author": "almabrds"}
{"word": ["system"], "author": "Accatone"}
{"word": ["crash"], "author": "dragonbeast"}
{"word": ["dummy"], "author": "OrionKai"}
{"word": ["Pacifier"], "author": "SapphireBullets"}
{"word": ["Diplomat"], "author": "Stuff"}
{"word": ["smuggle"], "author": "the_bard"}
{"word": ["Rebel"], "author": "somegamer786.960"}
{"word": ["Resistance"], "author": "Ultimatum"}
{"word": ["Fight"], "author": "Dizzard.495"}
{"word": ["Battle"], "author": "somegamer786.960"}
{"word": ["ACT"], "author": "SlappyBag"}
{"word": ["A"], "author": "somegamer786.960"}
{"word": ["Alphabet."], "author": "tarangwydion"}
{"word": ["Soup"], "author": "Niggles"}
{"word": ["salad"], "author": "the_bard"}
{"word": ["Lettuce"], "author": "Dizzard.495"}
{"word": ["pray"], "author": "the_bard"}
{"word": ["sanity"], "author": "Psyringe"}
{"word": ["Frayed"], "author": "SapphireBullets"}
{"word": ["Knights"], "author": "the_bard"}
{"word": ["Jousting"], "author": "Ultimatum"}
{"word": ["Medevil"], "author": "somegamer786.960"}
{"word": ["Times"], "author": "somegamer786.960"}
{"word": ["L.A."], "author": "somegamer786.960"}
{"word": ["Noire"], "author": "KneeTheCap"}
{"word": ["Rockstar"], "author": "somegamer786.960"}
{"word": ["Energy"], "author": "SlappyBag"}
{"word": ["drink"], "author": "Accatone"}
{"word": ["Beer"], "author": "SapphireBullets"}
{"word": ["Free."], "author": "tarangwydion"}
{"word": ["Freedom"], "author": "ExecB5"}
{"word": ["Conspicuous"], "author": "babark"}
{"word": ["Mystery"], "author": "SlappyBag"}
{"word": ["myst"], "author": "Accatone"}
{"word": ["mystical"], "author": "somegamer786.960"}
{"word": ["Magical."], "author": "tarangwydion"}
{"word": ["Magicka"], "author": "Fumarole"}
{"word": ["Mana"], "author": "ExecB5"}
{"word": ["Blue"], "author": "maycett"}
{"word": ["Lagoon."], "author": "tarangwydion"}
{"word": ["Black"], "author": "the_bard"}
{"word": ["Betty"], "author": "TrollumThinks"}
{"word": ["Boop"], "author": "Lou"}
{"word": ["Nose"], "author": "Dizzard.495"}
{"word": ["face"], "author": "Accatone"}
{"word": ["Plant"], "author": "KOCollins"}
{"word": ["Fission"], "author": "SweenMachine"}
{"word": ["Nuclear"], "author": "Stuff"}
{"word": ["Winter"], "author": "SapphireBullets"}
{"word": ["Wonderland"], "author": "Dizzard.495"}
{"word": ["Alice"], "author": "Zigna"}
{"word": ["School"], "author": "SlappyBag"}
{"word": ["Kid"], "author": "somegamer786.960"}
{"word": ["Kit"], "author": "almabrds"}
{"word": ["Kitty"], "author": "somegamer786.960"}
{"word": ["."], "author": "tarangwydion"}
{"word": ["Marvel"], "author": "ExecB5"}
{"word": ["Marvolo"], "author": "TrollumThinks"}
{"word": ["marvelous"], "author": "kmonster"}
{"word": ["Mansion"], "author": "SapphireBullets"}
{"word": ["Madness"], "author": "Matchstickman"}
{"word": ["Sparta"], "author": "danteveli"}
{"word": ["-cus"], "author": "OrionKai"}
{"word": ["-sing"], "author": "somegamer786.960"}
{"word": ["Sing"], "author": "SapphireBullets"}
{"word": ["song"], "author": "Fumarole"}
{"word": ["bird"], "author": "Leroux"}
{"word": ["Sixpence"], "author": "SapphireBullets"}
{"word": ["tuppence"], "author": "Fumarole"}
{"word": ["Pennies"], "author": "somegamer786.960"}
{"word": ["LOST"], "author": "SlappyBag"}
{"word": ["Where"], "author": "kmonster"}
{"word": ["Here"], "author": "Matchstickman"}
{"word": ["There"], "author": "Ultimatum"}
{"word": ["Too"], "author": "somegamer786.960"}
{"word": ["Ditto."], "author": "tarangwydion"}
{"word": ["iterate"], "author": "lightfoot8"}
{"word": ["Reiterate"], "author": "SapphireBullets"}
{"word": ["Repeat"], "author": "somegamer786.960"}
{"word": ["Robot"], "author": "Leroux"}
{"word": ["Invention"], "author": "almabrds"}
{"word": ["Necessity"], "author": "SapphireBullets"}
{"word": ["requirement"], "author": "441635"}
{"word": ["Obligation"], "author": "Stuff"}
{"word": ["Legal"], "author": "somegamer786.960"}
{"word": ["matter"], "author": "Fumarole"}
{"word": ["Dark"], "author": "Dizzard.495"}
{"word": ["Soul"], "author": "Leroux"}
{"word": ["DeLa"], "author": "SlappyBag"}
{"word": ["less"], "author": "shadowreaper1989"}
{"word": ["little ", " \"edit\" it seems i was a few seconds to slow"], "author": "dragonbeast"}
{"word": ["More"], "author": "ExecB5"}
{"word": ["Please"], "author": "somegamer786.960"}
{"word": ["Thanks"], "author": "Matchstickman"}
{"word": ["You"], "author": "somegamer786.960"}
{"word": ["yours"], "author": "Accatone"}
{"word": ["Truely"], "author": "somegamer786.960"}
{"word": ["Typo"], "author": "almabrds"}
{"word": ["Type."], "author": "ExecB5"}
{"word": ["Race"], "author": "SlappyBag"}
{"word": [" Track"], "author": "sloganvirst"}
{"word": ["Tracker"], "author": "somegamer786.960"}
{"word": ["hunt"], "author": "the_bard"}
{"word": ["Hunter"], "author": "almabrds"}
{"word": ["Hunted."], "author": "tarangwydion"}
{"word": ["Stalked"], "author": "Niggles"}
{"word": ["harrassed"], "author": "OrionKai"}
{"word": ["Thug"], "author": "Dizzard.495"}
{"word": ["Fist"], "author": "SapphireBullets"}
{"word": ["Fight"], "author": "Leroux"}
{"word": ["Saturday"], "author": "the_bard"}
{"word": ["Friday"], "author": "somegamer786.960"}
{"word": ["Thirteen"], "author": "amok"}
{"word": [], "author": "Stuff"}
{"word": ["Why"], "author": "somegamer786.960"}
{"word": ["because"], "author": "OrionKai"}
{"word": ["That"], "author": "somegamer786.960"}
{"word": ["Ass"], "author": "almabrds"}
{"word": ["Hole"], "author": "ExecB5"}
{"word": ["Hell"], "author": "BurningCa007"}
